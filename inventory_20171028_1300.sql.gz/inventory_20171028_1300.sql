--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: AspNetRoleClaims; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetRoleClaims" (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "RoleId" text NOT NULL
);


ALTER TABLE public."AspNetRoleClaims" OWNER TO inventory;

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "AspNetRoleClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AspNetRoleClaims_Id_seq" OWNER TO inventory;

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "AspNetRoleClaims_Id_seq" OWNED BY "AspNetRoleClaims"."Id";


--
-- Name: AspNetRoles; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetRoles" (
    "Id" text NOT NULL,
    "ConcurrencyStamp" text,
    "Name" character varying(256),
    "NormalizedName" character varying(256)
);


ALTER TABLE public."AspNetRoles" OWNER TO inventory;

--
-- Name: AspNetUserClaims; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetUserClaims" (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "UserId" text NOT NULL
);


ALTER TABLE public."AspNetUserClaims" OWNER TO inventory;

--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "AspNetUserClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AspNetUserClaims_Id_seq" OWNER TO inventory;

--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "AspNetUserClaims_Id_seq" OWNED BY "AspNetUserClaims"."Id";


--
-- Name: AspNetUserLogins; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetUserLogins" (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" text NOT NULL
);


ALTER TABLE public."AspNetUserLogins" OWNER TO inventory;

--
-- Name: AspNetUserRoles; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetUserRoles" (
    "UserId" text NOT NULL,
    "RoleId" text NOT NULL
);


ALTER TABLE public."AspNetUserRoles" OWNER TO inventory;

--
-- Name: AspNetUserTokens; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetUserTokens" (
    "UserId" text NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


ALTER TABLE public."AspNetUserTokens" OWNER TO inventory;

--
-- Name: AspNetUsers; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "AspNetUsers" (
    "Id" text NOT NULL,
    "AccessFailedCount" integer NOT NULL,
    "ConcurrencyStamp" text,
    "Email" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "LockoutEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp with time zone,
    "NormalizedEmail" character varying(256),
    "NormalizedUserName" character varying(256),
    "PasswordHash" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "SecurityStamp" text,
    "TwoFactorEnabled" boolean NOT NULL,
    "UserName" character varying(256)
);


ALTER TABLE public."AspNetUsers" OWNER TO inventory;

--
-- Name: Connection_Type; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Connection_Type" (
    "Connection_Type_ID" integer NOT NULL,
    "Connection_Type_Name" text
);


ALTER TABLE public."Connection_Type" OWNER TO inventory;

--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Connection_Type_Connection_Type_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Connection_Type_Connection_Type_ID_seq" OWNER TO inventory;

--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Connection_Type_Connection_Type_ID_seq" OWNED BY "Connection_Type"."Connection_Type_ID";


--
-- Name: Frequency; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Frequency" (
    "Frequency_ID" integer NOT NULL,
    "Frequency_Name" text
);


ALTER TABLE public."Frequency" OWNER TO inventory;

--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Frequency_Frequency_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Frequency_Frequency_ID_seq" OWNER TO inventory;

--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Frequency_Frequency_ID_seq" OWNED BY "Frequency"."Frequency_ID";


--
-- Name: Item; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Item" (
    "Item_ID" integer NOT NULL,
    "Model_ID" integer,
    "Serial_Number" text,
    "Inventory_Number" text,
    "Owner_ID" integer,
    "MAC_Address" text
);


ALTER TABLE public."Item" OWNER TO inventory;

--
-- Name: Item_Item_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Item_Item_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Item_ID_seq" OWNER TO inventory;

--
-- Name: Item_Item_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Item_Item_ID_seq" OWNED BY "Item"."Item_ID";


--
-- Name: Item_Mode; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Item_Mode" (
    "Item_Mode_ID" integer NOT NULL,
    "Item_Mode_Name" text
);


ALTER TABLE public."Item_Mode" OWNER TO inventory;

--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Item_Mode_Item_Mode_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Mode_Item_Mode_ID_seq" OWNER TO inventory;

--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Item_Mode_Item_Mode_ID_seq" OWNED BY "Item_Mode"."Item_Mode_ID";


--
-- Name: Item_Status; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Item_Status" (
    "Item_Status_ID" integer NOT NULL,
    "Item_Status_Name" text
);


ALTER TABLE public."Item_Status" OWNER TO inventory;

--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Item_Status_Item_Status_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Status_Item_Status_ID_seq" OWNER TO inventory;

--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Item_Status_Item_Status_ID_seq" OWNED BY "Item_Status"."Item_Status_ID";


--
-- Name: Item_Type; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Item_Type" (
    "Item_Type_ID" integer NOT NULL,
    "Item_Type_Name" text
);


ALTER TABLE public."Item_Type" OWNER TO inventory;

--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Item_Type_Item_Type_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Type_Item_Type_ID_seq" OWNER TO inventory;

--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Item_Type_Item_Type_ID_seq" OWNED BY "Item_Type"."Item_Type_ID";


--
-- Name: Location; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Location" (
    "Location_ID" integer NOT NULL,
    "Device_Name" text,
    "PhysicalConnected_Item_ID" integer,
    "From_Site_ID" integer,
    "To_Site_ID" integer,
    "Item_Status_ID" integer,
    "Start_Date" date,
    "End_Date" date,
    "Item_IP_Address" text,
    "Item_Mode_ID" integer,
    "Item_SSID" text,
    "Technician_ID" integer,
    "Assigner_ID" integer,
    "Transfer_Status_ID" integer,
    "Description" text,
    "Item_ID" integer
);


ALTER TABLE public."Location" OWNER TO inventory;

--
-- Name: Location_Location_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Location_Location_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Location_Location_ID_seq" OWNER TO inventory;

--
-- Name: Location_Location_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Location_Location_ID_seq" OWNED BY "Location"."Location_ID";


--
-- Name: Manufacturer; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Manufacturer" (
    "Manufacturer_ID" integer NOT NULL,
    "Manufacturer_Name" text NOT NULL
);


ALTER TABLE public."Manufacturer" OWNER TO inventory;

--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Manufacturer_Manufacturer_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Manufacturer_Manufacturer_ID_seq" OWNER TO inventory;

--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Manufacturer_Manufacturer_ID_seq" OWNED BY "Manufacturer"."Manufacturer_ID";


--
-- Name: Model; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Model" (
    "Model_ID" integer NOT NULL,
    "Model_Name" text NOT NULL,
    "Manufacturer_ID" integer,
    "Power" text,
    "Frequency_ID" integer,
    "Item_Type_ID" integer
);


ALTER TABLE public."Model" OWNER TO inventory;

--
-- Name: Model_Model_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Model_Model_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Model_Model_ID_seq" OWNER TO inventory;

--
-- Name: Model_Model_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Model_Model_ID_seq" OWNED BY "Model"."Model_ID";


--
-- Name: Owner; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Owner" (
    "Owner_ID" integer NOT NULL,
    "Owner_Name" text
);


ALTER TABLE public."Owner" OWNER TO inventory;

--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Owner_Owner_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Owner_Owner_ID_seq" OWNER TO inventory;

--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Owner_Owner_ID_seq" OWNED BY "Owner"."Owner_ID";


--
-- Name: Region; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Region" (
    "Region_ID" integer NOT NULL,
    "Region_Name" text
);


ALTER TABLE public."Region" OWNER TO inventory;

--
-- Name: Region_Region_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Region_Region_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Region_Region_ID_seq" OWNER TO inventory;

--
-- Name: Region_Region_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Region_Region_ID_seq" OWNED BY "Region"."Region_ID";


--
-- Name: Site; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Site" (
    "Site_ID" integer NOT NULL,
    "Site_Name" text,
    "Site_Type_ID" integer,
    "Region_ID" integer,
    "Address" text,
    "Latitude" double precision,
    "Longitude" double precision,
    "Responsive_Person_ID" integer,
    "Connection_Type_ID" integer,
    "Head_Name" text,
    "Head_Phone_1" text,
    "Head_Phone_2" text,
    "Head_Phone_3" text,
    "Operator_Name" text,
    "Operator_Phone_1" text,
    "Operator_Phone_2" text,
    "Operator_Phone_3" text,
    "Description" text,
    "Connected_Comp_Count" integer,
    "School_Comp_Count" integer
);


ALTER TABLE public."Site" OWNER TO inventory;

--
-- Name: Site_Site_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Site_Site_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Site_Site_ID_seq" OWNER TO inventory;

--
-- Name: Site_Site_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Site_Site_ID_seq" OWNED BY "Site"."Site_ID";


--
-- Name: Site_Type; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Site_Type" (
    "Site_Type_ID" integer NOT NULL,
    "Site_Type_Name" text
);


ALTER TABLE public."Site_Type" OWNER TO inventory;

--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Site_Type_Site_Type_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Site_Type_Site_Type_ID_seq" OWNER TO inventory;

--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Site_Type_Site_Type_ID_seq" OWNED BY "Site_Type"."Site_Type_ID";


--
-- Name: Transfer_Status; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Transfer_Status" (
    "Transfer_Status_ID" integer NOT NULL,
    "Transfer_Status_Name" text
);


ALTER TABLE public."Transfer_Status" OWNER TO inventory;

--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Transfer_Status_Transfer_Status_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Transfer_Status_Transfer_Status_ID_seq" OWNER TO inventory;

--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Transfer_Status_Transfer_Status_ID_seq" OWNED BY "Transfer_Status"."Transfer_Status_ID";


--
-- Name: Worker; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Worker" (
    "Worker_ID" integer NOT NULL,
    "Worker_Name" text,
    "Worker_Position_ID" integer,
    "Phone_Work" text,
    "Phone_Pers" text,
    "Email_Work" text,
    "Email_Pers" text
);


ALTER TABLE public."Worker" OWNER TO inventory;

--
-- Name: Worker_Position; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "Worker_Position" (
    "Worker_Position_ID" integer NOT NULL,
    "Worker_Position_Name" text
);


ALTER TABLE public."Worker_Position" OWNER TO inventory;

--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Worker_Position_Worker_Position_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Worker_Position_Worker_Position_ID_seq" OWNER TO inventory;

--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Worker_Position_Worker_Position_ID_seq" OWNED BY "Worker_Position"."Worker_Position_ID";


--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE "Worker_Worker_ID_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Worker_Worker_ID_seq" OWNER TO inventory;

--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE "Worker_Worker_ID_seq" OWNED BY "Worker"."Worker_ID";


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: inventory; Tablespace: 
--

CREATE TABLE "__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO inventory;

--
-- Name: vwAsigner; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwAsigner" AS
    SELECT "Worker"."Worker_ID", "Worker"."Worker_Name", "Worker"."Worker_Position_ID", "Worker"."Phone_Work", "Worker"."Phone_Pers", "Worker"."Email_Work", "Worker"."Email_Pers", "Worker_Position"."Worker_Position_Name" FROM ("Worker" LEFT JOIN "Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")));


ALTER TABLE public."vwAsigner" OWNER TO inventory;

--
-- Name: vwFromSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwFromSite" AS
    SELECT "Site"."Site_ID", "Site"."Site_Name", "Site"."Site_Type_ID", "Site"."Region_ID", "Site_Type"."Site_Type_Name", "Region"."Region_Name", pg_catalog.concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info", pg_catalog.concat_ws(' '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name") AS "Site_Full_Name" FROM (("Site" LEFT JOIN "Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID"))) LEFT JOIN "Region" ON (("Site"."Region_ID" = "Region"."Region_ID")));


ALTER TABLE public."vwFromSite" OWNER TO inventory;

--
-- Name: vwItem; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwItem" AS
    SELECT "Item"."Item_ID", "Item"."Model_ID", "Item"."Serial_Number", "Item"."Inventory_Number", "Item"."Owner_ID", "Item"."MAC_Address", "Model"."Model_Name", "Model"."Manufacturer_ID", "Model"."Power", "Model"."Frequency_ID", "Model"."Item_Type_ID", "Owner"."Owner_Name", "Manufacturer"."Manufacturer_Name", "Item_Type"."Item_Type_Name", "Frequency"."Frequency_Name", pg_catalog.concat_ws(' - '::text, "Item"."Serial_Number", "Model"."Model_Name", "Owner"."Owner_Name") AS "Item_Info" FROM ((((("Item" LEFT JOIN "Model" ON (("Item"."Model_ID" = "Model"."Model_ID"))) LEFT JOIN "Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID"))) LEFT JOIN "Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID"))) LEFT JOIN "Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID"))) LEFT JOIN "Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwItem" OWNER TO inventory;

--
-- Name: vwPCItem; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwPCItem" AS
    SELECT "Item"."Item_ID", "Item"."Model_ID", "Item"."Serial_Number", "Item"."Inventory_Number", "Item"."Owner_ID", "Item"."MAC_Address", "Model"."Model_Name", "Model"."Manufacturer_ID", "Model"."Power", "Model"."Frequency_ID", "Model"."Item_Type_ID", "Owner"."Owner_Name", "Manufacturer"."Manufacturer_Name", "Item_Type"."Item_Type_Name", "Frequency"."Frequency_Name", pg_catalog.concat_ws(' - '::text, "Item"."Serial_Number", "Model"."Model_Name", "Owner"."Owner_Name") AS "Item_Info" FROM ((((("Item" LEFT JOIN "Model" ON (("Item"."Model_ID" = "Model"."Model_ID"))) LEFT JOIN "Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID"))) LEFT JOIN "Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID"))) LEFT JOIN "Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID"))) LEFT JOIN "Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwPCItem" OWNER TO inventory;

--
-- Name: vwTechnisian; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwTechnisian" AS
    SELECT "Worker"."Worker_ID", "Worker"."Worker_Name", "Worker"."Worker_Position_ID", "Worker"."Phone_Work", "Worker"."Phone_Pers", "Worker"."Email_Work", "Worker"."Email_Pers", "Worker_Position"."Worker_Position_Name" FROM ("Worker" LEFT JOIN "Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")));


ALTER TABLE public."vwTechnisian" OWNER TO inventory;

--
-- Name: vwToSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwToSite" AS
    SELECT "Site"."Site_ID", "Site"."Site_Name", "Site"."Site_Type_ID", "Site"."Region_ID", "Site_Type"."Site_Type_Name", "Region"."Region_Name", pg_catalog.concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info", pg_catalog.concat_ws(' '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name") AS "Site_full_Name" FROM (("Site" LEFT JOIN "Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID"))) LEFT JOIN "Region" ON (("Site"."Region_ID" = "Region"."Region_ID")));


ALTER TABLE public."vwToSite" OWNER TO inventory;

--
-- Name: vwLocation; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwLocation" AS
    SELECT "Location"."Location_ID", "Location"."Device_Name", "Location"."PhysicalConnected_Item_ID", "vwPCItem"."Serial_Number" AS "PC_Serial_Number", "vwPCItem"."Model_Name" AS "PC_Model_Name", "vwPCItem"."Owner_Name" AS "PC_Owner_Name", "vwPCItem"."Item_Info" AS "PC_Item_Info", "Location"."From_Site_ID", "vwFromSite"."Site_Name" AS "From_Site", "vwFromSite"."Region_Name" AS "From_Site_Region", "vwFromSite"."Site_Info" AS "From_Site_Info", "Location"."To_Site_ID", "vwToSite"."Site_Name" AS "To_Site", "vwToSite"."Region_Name" AS "To_Site_Region", "vwToSite"."Site_Info" AS "To_Site_Info", "Location"."Item_Status_ID", "Item_Status"."Item_Status_Name", "Location"."Start_Date", "Location"."End_Date", "Location"."Item_IP_Address", "Item_Mode"."Item_Mode_Name", "Location"."Item_Mode_ID", "Location"."Item_SSID", "vwTechnisian"."Worker_Name" AS "Technician_Name", "Location"."Technician_ID", "Location"."Assigner_ID", "vwAsigner"."Worker_Name" AS "Assigner_Name", "Transfer_Status"."Transfer_Status_Name", "Location"."Transfer_Status_ID", "Location"."Description", "Location"."Item_ID", "Item"."Serial_Number" AS "Item_Serial_Number", "Item"."Inventory_Number" AS "Item_Inventory_Number", "Item"."MAC_Address" AS "Item_MAC_Address", "Model"."Model_Name" AS "Item_Model_Name", "Owner"."Owner_Name" AS "Item_Owner_Name", "Model"."Power" AS "Item_Power", "Manufacturer"."Manufacturer_Name" AS "Item_Manufacturer_Name", "Item_Type"."Item_Type_Name" AS "Item_Item_Type_Name", "Frequency"."Frequency_Name" AS "Item_Frequency_Name", "vwFromSite"."Site_Type_Name" AS "From_Site_Type_Name", "vwToSite"."Site_Type_Name" AS "To_Site_Type_Name", "vwFromSite"."Site_Full_Name" AS "From_Site_Full_Name", "vwToSite"."Site_full_Name" AS "To_Site_Full_Name", "Item"."Owner_ID" AS "Item_Owner_ID", "Item"."Model_ID" AS "Item_Model_ID" FROM (((((((((((((("Location" LEFT JOIN "vwPCItem" ON (("Location"."PhysicalConnected_Item_ID" = "vwPCItem"."Item_ID"))) LEFT JOIN "vwFromSite" ON (("Location"."From_Site_ID" = "vwFromSite"."Site_ID"))) LEFT JOIN "vwToSite" ON (("Location"."To_Site_ID" = "vwToSite"."Site_ID"))) LEFT JOIN "Item_Status" ON (("Location"."Item_Status_ID" = "Item_Status"."Item_Status_ID"))) LEFT JOIN "Item_Mode" ON (("Location"."Item_Mode_ID" = "Item_Mode"."Item_Mode_ID"))) LEFT JOIN "vwTechnisian" ON (("Location"."Technician_ID" = "vwTechnisian"."Worker_ID"))) LEFT JOIN "vwAsigner" ON (("Location"."Assigner_ID" = "vwAsigner"."Worker_ID"))) LEFT JOIN "Transfer_Status" ON (("Location"."Transfer_Status_ID" = "Transfer_Status"."Transfer_Status_ID"))) LEFT JOIN "Item" ON (("Location"."Item_ID" = "Item"."Item_ID"))) LEFT JOIN "Model" ON (("Item"."Model_ID" = "Model"."Model_ID"))) LEFT JOIN "Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID"))) LEFT JOIN "Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID"))) LEFT JOIN "Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID"))) LEFT JOIN "Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwLocation" OWNER TO inventory;

--
-- Name: vwModel; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwModel" AS
    SELECT "Model"."Model_ID", "Model"."Model_Name", "Model"."Manufacturer_ID", "Model"."Power", "Model"."Frequency_ID", "Model"."Item_Type_ID", "Manufacturer"."Manufacturer_Name", "Frequency"."Frequency_Name", "Item_Type"."Item_Type_Name", pg_catalog.concat_ws(' - '::text, "Manufacturer"."Manufacturer_Name", "Model"."Model_Name", "Item_Type"."Item_Type_Name") AS "Model_Info" FROM ((("Model" LEFT JOIN "Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID"))) LEFT JOIN "Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID"))) LEFT JOIN "Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")));


ALTER TABLE public."vwModel" OWNER TO inventory;

--
-- Name: vwSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwSite" AS
    SELECT "Site"."Site_ID", "Site"."Site_Name", "Site"."Site_Type_ID", "Site"."Region_ID", "Site"."Address", "Site"."Latitude", "Site"."Longitude", "Site"."Responsive_Person_ID", "Site"."Connection_Type_ID", "Site"."Head_Name", "Site"."Head_Phone_1", "Site"."Head_Phone_2", "Site"."Head_Phone_3", "Site"."Operator_Name", "Site"."Operator_Phone_1", "Site"."Operator_Phone_2", "Site"."Operator_Phone_3", "Site"."Description", "Site"."Connected_Comp_Count", "Site"."School_Comp_Count", "Site_Type"."Site_Type_Name", "Region"."Region_Name", "Worker"."Worker_Name", "Connection_Type"."Connection_Type_Name", pg_catalog.concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info", pg_catalog.concat_ws(', '::text, "Site"."Head_Name", "Site"."Head_Phone_1", "Site"."Head_Phone_2", "Site"."Head_Phone_3") AS "Head_Info", pg_catalog.concat_ws(', '::text, "Site"."Operator_Name", "Site"."Operator_Phone_1", "Site"."Operator_Phone_2", "Site"."Operator_Phone_3") AS "Operator_Info" FROM (((("Site" LEFT JOIN "Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID"))) LEFT JOIN "Region" ON (("Site"."Region_ID" = "Region"."Region_ID"))) LEFT JOIN "Worker" ON (("Site"."Responsive_Person_ID" = "Worker"."Worker_ID"))) LEFT JOIN "Connection_Type" ON (("Site"."Connection_Type_ID" = "Connection_Type"."Connection_Type_ID")));


ALTER TABLE public."vwSite" OWNER TO inventory;

--
-- Name: vwTransfer; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwTransfer" AS
    SELECT "Location"."Location_ID", "Location"."Device_Name", "Location"."PhysicalConnected_Item_ID", "vwPCItem"."Serial_Number" AS "PC_Serial_Number", "vwPCItem"."Model_Name" AS "PC_Model_Name", "vwPCItem"."Owner_Name" AS "PC_Owner_Name", "vwPCItem"."Item_Info" AS "PC_Item_Info", "Location"."From_Site_ID", "vwFromSite"."Site_Name" AS "From_Site", "vwFromSite"."Region_Name" AS "From_Site_Region", "vwFromSite"."Site_Info" AS "From_Site_Info", "Location"."To_Site_ID", "vwToSite"."Site_Name" AS "To_Site", "vwToSite"."Region_Name" AS "To_Site_Region", "vwToSite"."Site_Info" AS "To_Site_Info", "Location"."Item_Status_ID", "Item_Status"."Item_Status_Name", "Location"."Start_Date", "Location"."End_Date", "Location"."Item_IP_Address", "Item_Mode"."Item_Mode_Name", "Location"."Item_Mode_ID", "Location"."Item_SSID", "vwTechnisian"."Worker_Name" AS "Technician_Name", "Location"."Technician_ID", "Location"."Assigner_ID", "vwAsigner"."Worker_Name" AS "Assigner_Name", "Transfer_Status"."Transfer_Status_Name", "Location"."Transfer_Status_ID", "Location"."Description", "Location"."Item_ID", "Item"."Serial_Number" AS "Item_Serial_Number", "Item"."Inventory_Number" AS "Item_Inventory_Number", "Item"."MAC_Address" AS "Item_MAC_Address", "Model"."Model_Name" AS "Item_Model_Name", "Owner"."Owner_Name" AS "Item_Owner_Name", "Model"."Power" AS "Item_Power", "Manufacturer"."Manufacturer_Name" AS "Item_Manufacturer_Name", "Item_Type"."Item_Type_Name" AS "Item_Item_Type_Name", "Frequency"."Frequency_Name" AS "Item_Frequency_Name" FROM (((((((((((((("Location" LEFT JOIN "vwPCItem" ON (("Location"."PhysicalConnected_Item_ID" = "vwPCItem"."Item_ID"))) LEFT JOIN "vwFromSite" ON (("Location"."From_Site_ID" = "vwFromSite"."Site_ID"))) LEFT JOIN "vwToSite" ON (("Location"."To_Site_ID" = "vwToSite"."Site_ID"))) LEFT JOIN "Item_Status" ON (("Location"."Item_Status_ID" = "Item_Status"."Item_Status_ID"))) LEFT JOIN "Item_Mode" ON (("Location"."Item_Mode_ID" = "Item_Mode"."Item_Mode_ID"))) LEFT JOIN "vwTechnisian" ON (("Location"."Technician_ID" = "vwTechnisian"."Worker_ID"))) LEFT JOIN "vwAsigner" ON (("Location"."Assigner_ID" = "vwAsigner"."Worker_ID"))) LEFT JOIN "Transfer_Status" ON (("Location"."Transfer_Status_ID" = "Transfer_Status"."Transfer_Status_ID"))) LEFT JOIN "Item" ON (("Location"."Item_ID" = "Item"."Item_ID"))) LEFT JOIN "Model" ON (("Item"."Model_ID" = "Model"."Model_ID"))) LEFT JOIN "Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID"))) LEFT JOIN "Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID"))) LEFT JOIN "Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID"))) LEFT JOIN "Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwTransfer" OWNER TO inventory;

--
-- Name: vwWorker; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW "vwWorker" AS
    SELECT "Worker"."Worker_ID", "Worker"."Worker_Name", "Worker"."Worker_Position_ID", "Worker"."Phone_Work", "Worker"."Phone_Pers", "Worker"."Email_Work", "Worker"."Email_Pers", "Worker_Position"."Worker_Position_Name" FROM ("Worker" LEFT JOIN "Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")));


ALTER TABLE public."vwWorker" OWNER TO inventory;

--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetRoleClaims" ALTER COLUMN "Id" SET DEFAULT nextval('"AspNetRoleClaims_Id_seq"'::regclass);


--
-- Name: Id; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetUserClaims" ALTER COLUMN "Id" SET DEFAULT nextval('"AspNetUserClaims_Id_seq"'::regclass);


--
-- Name: Connection_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Connection_Type" ALTER COLUMN "Connection_Type_ID" SET DEFAULT nextval('"Connection_Type_Connection_Type_ID_seq"'::regclass);


--
-- Name: Frequency_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Frequency" ALTER COLUMN "Frequency_ID" SET DEFAULT nextval('"Frequency_Frequency_ID_seq"'::regclass);


--
-- Name: Item_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item" ALTER COLUMN "Item_ID" SET DEFAULT nextval('"Item_Item_ID_seq"'::regclass);


--
-- Name: Item_Mode_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item_Mode" ALTER COLUMN "Item_Mode_ID" SET DEFAULT nextval('"Item_Mode_Item_Mode_ID_seq"'::regclass);


--
-- Name: Item_Status_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item_Status" ALTER COLUMN "Item_Status_ID" SET DEFAULT nextval('"Item_Status_Item_Status_ID_seq"'::regclass);


--
-- Name: Item_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item_Type" ALTER COLUMN "Item_Type_ID" SET DEFAULT nextval('"Item_Type_Item_Type_ID_seq"'::regclass);


--
-- Name: Location_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location" ALTER COLUMN "Location_ID" SET DEFAULT nextval('"Location_Location_ID_seq"'::regclass);


--
-- Name: Manufacturer_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Manufacturer" ALTER COLUMN "Manufacturer_ID" SET DEFAULT nextval('"Manufacturer_Manufacturer_ID_seq"'::regclass);


--
-- Name: Model_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Model" ALTER COLUMN "Model_ID" SET DEFAULT nextval('"Model_Model_ID_seq"'::regclass);


--
-- Name: Owner_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Owner" ALTER COLUMN "Owner_ID" SET DEFAULT nextval('"Owner_Owner_ID_seq"'::regclass);


--
-- Name: Region_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Region" ALTER COLUMN "Region_ID" SET DEFAULT nextval('"Region_Region_ID_seq"'::regclass);


--
-- Name: Site_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site" ALTER COLUMN "Site_ID" SET DEFAULT nextval('"Site_Site_ID_seq"'::regclass);


--
-- Name: Site_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site_Type" ALTER COLUMN "Site_Type_ID" SET DEFAULT nextval('"Site_Type_Site_Type_ID_seq"'::regclass);


--
-- Name: Transfer_Status_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Transfer_Status" ALTER COLUMN "Transfer_Status_ID" SET DEFAULT nextval('"Transfer_Status_Transfer_Status_ID_seq"'::regclass);


--
-- Name: Worker_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Worker" ALTER COLUMN "Worker_ID" SET DEFAULT nextval('"Worker_Worker_ID_seq"'::regclass);


--
-- Name: Worker_Position_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Worker_Position" ALTER COLUMN "Worker_Position_ID" SET DEFAULT nextval('"Worker_Position_Worker_Position_ID_seq"'::regclass);


--
-- Data for Name: AspNetRoleClaims; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetRoleClaims" ("Id", "ClaimType", "ClaimValue", "RoleId") FROM stdin;
\.


--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"AspNetRoleClaims_Id_seq"', 1, false);


--
-- Data for Name: AspNetRoles; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetRoles" ("Id", "ConcurrencyStamp", "Name", "NormalizedName") FROM stdin;
\.


--
-- Data for Name: AspNetUserClaims; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetUserClaims" ("Id", "ClaimType", "ClaimValue", "UserId") FROM stdin;
\.


--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"AspNetUserClaims_Id_seq"', 1, false);


--
-- Data for Name: AspNetUserLogins; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetUserLogins" ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM stdin;
\.


--
-- Data for Name: AspNetUserRoles; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetUserRoles" ("UserId", "RoleId") FROM stdin;
\.


--
-- Data for Name: AspNetUserTokens; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetUserTokens" ("UserId", "LoginProvider", "Name", "Value") FROM stdin;
\.


--
-- Data for Name: AspNetUsers; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "AspNetUsers" ("Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName") FROM stdin;
1a311b56-efca-4b87-ad2e-c230298a0194	0	ace966b2-3058-40e2-9324-28ab032bf23d	vahram@hf.am	f	t	\N	VAHRAM@HF.AM	VAHRAM@HF.AM	AQAAAAEAACcQAAAAECIsswshCMcJc2byFJZll24nHEvxJA4+s+KR9ruK+bIiKf2igVwMk+7U6CxX2cBFQQ==	\N	f	504be1dc-6cad-42d1-992f-0fe32884528f	f	vahram@hf.am
8f754c3b-9356-44cd-9d3c-17076a0ed9a2	0	fe169f68-4569-4345-8ba7-1904bce01017	Armen.hayrapetyan@hf.am	f	t	\N	ARMEN.HAYRAPETYAN@HF.AM	ARMEN.HAYRAPETYAN@HF.AM	AQAAAAEAACcQAAAAEOJ43XcS4hEfeoJByhqDvoKIr2DK+LOREOXypJ6hmyAvG5Qv7PShWSnkwYMjebTB3A==	\N	f	757dde3a-8ed4-4184-8639-24b666e1f629	f	Armen.hayrapetyan@hf.am
53a16ec3-9d43-457e-ac9b-8544ddec6c94	0	3f59049d-83a3-499a-99ce-2dd0467ff106	maria@hf.am	f	t	\N	MARIA@HF.AM	MARIA@HF.AM	AQAAAAEAACcQAAAAEDcbXeJxxyF/Z2CxAS1NKmbyMT6aoFLA744WIXk+BHAushhBfZ0zkP07DpZfdfhqKw==	\N	f	e7ad5d59-afdb-4be7-a0ca-1f3044f5a125	f	maria@hf.am
87fff8c8-a34b-4e1c-9b8c-fcb85f1795f2	0	fd52d17b-07b5-45bb-9498-166d9c5bf8f8	evelina@hf.am	f	t	\N	EVELINA@HF.AM	EVELINA@HF.AM	AQAAAAEAACcQAAAAEMPIGsyMmIMatt9eLefPh6oHY5ZosHOrYfN7vRdK6NfUjezE4MUgnU40AgEbiCVzug==	\N	f	28d6be29-d5ba-4e7d-93f0-1b4dbbb503a4	f	evelina@hf.am
7d33e656-99b5-44dc-81ba-86fcce8857c3	0	b5c48a48-2538-46cc-92b6-fb2fe48db9c8	syuzanna@hf.am	f	t	\N	SYUZANNA@HF.AM	SYUZANNA@HF.AM	AQAAAAEAACcQAAAAEP3gXi4dOgrQeMdpeplAlPG9lLQHY2ngLhfRGIgpQR3ix7jwzaGgqb9/x6qdgBVPcQ==	\N	f	ca3d1d80-accd-4d5d-9ba2-5d69e17bfc9c	f	syuzanna@hf.am
c94435d5-a20f-40a1-8167-ec8e28521dd3	0	b7237b09-6c80-4096-b01b-3d6c378a148e	sirekan@hf.am	f	t	\N	SIREKAN@HF.AM	SIREKAN@HF.AM	AQAAAAEAACcQAAAAEPsbU7mmNm4fk5uU+DqWUMOqvNRtNJ+yy9F9hHmcPWpKT7Ddt6LFBS76QGgg5Rx4cg==	\N	f	f72a8e86-6d5f-400b-82bc-58947aba58f1	f	sirekan@hf.am
dda3be54-1860-49da-97bc-033d1760c042	0	0a35c53c-f388-4fda-8c61-7f36593fc2b8	narine@hf.am	f	t	\N	NARINE@HF.AM	NARINE@HF.AM	AQAAAAEAACcQAAAAENUdr/Bs07izHM6juH/ynJpSAtHK7mkL7YQ52ZMRUp6xDFEreQXTodOetULmf54KzQ==	\N	f	e95d612d-6323-4e1e-b93d-e2a413ce8596	f	narine@hf.am
b8a696b0-246e-4dd7-9b13-601cfcbb89bd	0	a17d0786-fc73-483f-babc-21c75b1fe1d9	jass.manasyan@gmail.com	f	t	\N	JASS.MANASYAN@GMAIL.COM	JASS.MANASYAN@GMAIL.COM	AQAAAAEAACcQAAAAENLDoAXPdTl/OaEgl5dB5gOiIPYk2gDiaTTRFmKFIi0ui/djnIoBDEggH39ASdbNhg==	\N	f	1135941e-9469-4d4b-8e3d-34e0c1a09f0d	f	jass.manasyan@gmail.com
9e5ed0b2-3589-4f59-9f0e-5dc386efaf0b	0	52e279ef-1a84-4ee1-b4a8-25891fcbcfe7	sonahdavtyan@gmail.com	f	t	\N	SONAHDAVTYAN@GMAIL.COM	SONAHDAVTYAN@GMAIL.COM	AQAAAAEAACcQAAAAEJFIgAjVAgzf4l12oQAsY2KoiUNU7NeKRyH6Di+WYrdvicEPpV/XC4Cg2n1Zqs4d2g==	\N	f	709bef4a-eaa6-40c9-863c-971e7e2e42f4	f	sonahdavtyan@gmail.com
3c4b830a-2f12-47a0-a618-c5d82f4f58c1	0	0bb95ad6-2b66-47d2-9c22-d86f398333e2	sarmen@hf.am	f	t	\N	SARMEN@HF.AM	SARMEN@HF.AM	AQAAAAEAACcQAAAAEOs7E+A0nCrN/O1lnEEaMgBgqHdvgBJ5F3Ojj0uhLNNYSwpFiUCwlybbsuJWubWzzA==	\N	f	29e7b57f-8b14-4320-816f-a83a7104893a	f	sarmen@hf.am
d92c65b8-fba5-4030-b0c0-0cec097be158	0	b1a1d633-0995-40fc-a061-7c4de825d90d	vahe.sargsyan88@gmail.com	f	t	\N	VAHE.SARGSYAN88@GMAIL.COM	VAHE.SARGSYAN88@GMAIL.COM	AQAAAAEAACcQAAAAEPBaep/KIlokNcciOkWCSsh1jAuIhikEqNTnqq6/tl8OUMp4h0+Rj9DcH9KA+72rJw==	\N	f	e5881f93-cdea-47c0-93a7-f85397fb5b88	f	vahe.sargsyan88@gmail.com
\.


--
-- Data for Name: Connection_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Connection_Type" ("Connection_Type_ID", "Connection_Type_Name") FROM stdin;
1	Optic
2	Wireless
3	P2P
4	Hi-Line
5	3G Viva
\.


--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Connection_Type_Connection_Type_ID_seq"', 7, true);


--
-- Data for Name: Frequency; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Frequency" ("Frequency_ID", "Frequency_Name") FROM stdin;
1	2.4 Ghz
2	5 Ghz
\.


--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Frequency_Frequency_ID_seq"', 1002, true);


--
-- Data for Name: Item; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Item" ("Item_ID", "Model_ID", "Serial_Number", "Inventory_Number", "Owner_ID", "MAC_Address") FROM stdin;
8	19	802AA808FBE5	802AA808FBE5	1	802AA808FBE5
9	29	71А306126779	71А306126779	4	6C3B6BD7EADA
10	1	F09FC246E46A	F09FC246E46A	1	F09FC246E46A
11	29	71A306642F7C	71A306642F7C	4	6C3B6BDA0E84
12	1	F09FC246E355	F09FC246E355	1	F09FC246E355
13	29	71A306607AE8	71A306607AE8	4	6C3B6BD7EC2B
16	1	802AA87AE629	802AA87AE629	1	802AA87AE629
18	1	802AA87AE3BE	802AA87AE3BE	1	802AA87AE3BE
27	1	F09FC246E77D	F09FC246E77D	1	F09FC246E77D
30	1	802AA8F8799B	802AA8F8799B	1	802AA8F8799B
32	1	F09FC246E4B3	F09FC246E4B3	1	F09FC246E4B3
33	1	F09FC246E44A	F09FC246E44A	1	F09FC246E44A
34	1	F09FC246E652	F09FC246E652	1	F09FC246E652
35	1	F09FC246E5B4	F09FC246E5B4	1	F09FC246E5B4
36	1	802AA8BA1CD1	802AA8BA1CD1	1	802AA8BA1CD1
37	1	802AA8BA1CD4	802AA8BA1CD4	1	802AA8BA1CD4
38	1	802AA8BA1C4A	802AA8BA1C4A	1	802AA8BA1C4A
39	1	802AA8BA1C6D	802AA8BA1C6D	1	802AA8BA1C6D
40	1	802AA8BA1C26	802AA8BA1C26	1	802AA8BA1C26
41	1	F09FC246E16F	F09FC246E16F	1	F09FC246E16F
42	1	F09FC246E39C	F09FC246E39C	1	F09FC246E39C
43	1	F09FC246E364	F09FC246E364	1	F09FC246E364
44	1	F09FC246E0E7	F09FC246E0E7	1	F09FC246E0E7
45	1	F09FC246E340	F09FC246E340	1	F09FC246E340
46	1	802AA8F877C5	802AA8F877C5	1	802AA8F877C5
47	1	802AA8F878F5	802AA8F878F5	1	802AA8F878F5
48	1	802AA8F8802B	802AA8F8802B	1	802AA8F8802B
49	1	802AA8BC1E2B	802AA8BC1E2B	1	802AA8BC1E2B
50	1	802AA8BC1FA4	802AA8BC1FA4	1	802AA8BC1FA4
51	1	802AA8BC1E23	802AA8BC1E23	1	802AA8BC1E23
52	1	802AA8F87496	802AA8F87496	1	802AA8F87496
53	1	802AA8F880A9	802AA8F880A9	1	802AA8F880A9
54	1	802AA8F8801F	802AA8F8801F	1	802AA8F8801F
55	1	802AA8F87843	802AA8F87843	1	802AA8F87843
56	1	F09FC246E645	F09FC246E645	1	F09FC246E645
57	1	F09FC246E5AF	F09FC246E5AF	1	F09FC246E5AF
58	1	F09FC246E478	F09FC246E478	1	F09FC246E478
59	1	F09FC246E506	F09FC246E506	1	F09FC246E506
60	1	F09FC246E4C5	F09FC246E4C5	1	F09FC246E4C5
66	1	F09FC246E6D7	F09FC246E6D7	1	F09FC246E6D7
67	1	802AA8F87AB8	802AA8F87AB8	1	802AA8F87AB8
68	1	F09FC246E474	F09FC246E474	1	F09FC246E474
69	1	802AA8F875F7	802AA8F875F7	1	802AA8F875F7
70	1	F09FC246E869	F09FC246E869	1	F09FC246E869
71	1	F09FC246E6B8	F09FC246E6B8	1	F09FC246E6B8
72	1	F09FC246E860	F09FC246E860	1	F09FC246E860
73	1	F09FC246E5CD	F09FC246E5CD	1	F09FC246E5CD
74	1	F09FC246E509	F09FC246E509	1	F09FC246E509
75	1	F09FC246E22A	F09FC246E22A	1	F09FC246E22A
76	1	F09FC246E729	F09FC246E729	1	F09FC246E729
77	1	F09FC246E609	F09FC246E609	1	F09FC246E609
78	1	F09FC246E576	F09FC246E576	1	F09FC246E576
79	1	F09FC246E5EE	F09FC246E5EE	1	F09FC246E5EE
80	1	F09FC246E5D6	F09FC246E5D6	1	F09FC246E5D6
81	1	F09FC246E47F	F09FC246E47F	1	F09FC246E47F
82	1	F09FC246E45F	F09FC246E45F	1	F09FC246E45F
83	1	F09FC246E469	F09FC246E469	1	F09FC246E469
3	45	ant24072	ant24072	3	
84	1	F09FC246E330	F09FC246E330	1	F09FC246E330
65	1	F09FC246E338	F09FC246E338	1	F09FC246E338
2	29	71a306213311/652	71a306213311/652	4	6c3b6bd58896
86	1	F09FC246E431	F09FC246E431	1	F09FC246E431
61	1	F09FC246E2E9	F09FC246E2E9	1	F09FC246E2E9
1	11	24a43ca63110	24a43ca63110	3	24a43ca63110
63	1	F09FC246E7D2	F09FC246E7D2	1	F09FC246E7D2
62	1	F09FC246E1DA	F09FC246E1DA	1	F09FC246E1DA
85	1	F09FC246E30E	F09FC246E30E	1	F09FC246E30E
64	1	F09FC246E4D6	F09FC246E4D6	1	F09FC246E4D6
29	1	F09FC246E866	F09FC246E866	1	F09FC246E866
6	1	F09FC246E34D	F09FC246E34D	1	F09FC246E34D
88	1	F09FC246E43B	F09FC246E43B	1	F09FC246E43B
5	29	71a306b7445b/652	71a306b7445b/652	4	6c3b6bd7f3e1
7	29	71A30638EE7B	71A30638EE7B	4	6C3B6BDA0FCD
4	20	802aa8ae8d14	802aa8ae8d14	2	802aa8ae8d14
23	1	F09FC246E298	F09FC246E298	1	F09FC246E298
22	1	802AA806DA44	802AA806DA44	1	802AA806DA44
21	1	802AA806D7A7	802AA806D7A7	1	802AA806D7A7
19	1	802AA806DC77	802AA806DC77	1	802AA806DC77
24	1	F09FC246E825	F09FC246E825	1	F09FC246E825
87	1	F09FC246E408	F09FC246E408	1	F09FC246E408
20	1	802AA806DD0E	802AA806DD0E	1	802AA806DD0E
25	1	F09FC246EDB0	F09FC246EDB0	1	F09FC246EDB0
31	1	F09FC246E39F	F09FC246E39F	1	F09FC246E39F
28	1	F09FC246E757	F09FC246E757	1	F09FC246E757
14	1	802AA87AF8EE	802AA87AF8EE	1	802AA87AF8EE
26	1	F09FC246E613	F09FC246E613	1	F09FC246E613
17	1	F09FC246E6A5	F09FC246E6A5	1	F09FC246E6A5
15	1	802AA87AEE80	802AA87AEE80	1	802AA87AEE80
105	1	F09FC246EC88	F09FC246EC88	1	F09FC246EC88
106	1	F09FC246E3CD	F09FC246E3CD	1	F09FC246E3CD
107	1	802AA87AF7BE	802AA87AF7BE	1	802AA87AF7BE
108	1	F09FC246E3B5	F09FC246E3B5	1	F09FC246E3B5
109	1	F09FC246E368	F09FC246E368	1	F09FC246E368
110	1	F09FC246E5A0	F09FC246E5A0	1	F09FC246E5A0
111	1	F09FC246E3E4	F09FC246E3E4	1	F09FC246E3E4
112	1	F09FC246E365	F09FC246E365	1	F09FC246E365
113	1	F09FC246E2C1	F09FC246E2C1	1	F09FC246E2C1
114	1	F09FC246E6CD	F09FC246E6CD	1	F09FC246E6CD
115	1	F09FC246E8BE	F09FC246E8BE	1	F09FC246E8BE
116	1	F09FC246E665	F09FC246E665	1	F09FC246E665
117	1	F09FC246E634	F09FC246E634	1	F09FC246E634
118	1	F09FC246E7D8	F09FC246E7D8	1	F09FC246E7D8
119	1	44D9E7AE2ABB	44D9E7AE2ABB	1	44D9E7AE2ABB
120	1	44D9E7AE2ACD	44D9E7AE2ACD	1	44D9E7AE2ACD
121	1	44D9E7AE2A11	44D9E7AE2A11	1	44D9E7AE2A11
122	1	44D9E7AE2A12	44D9E7AE2A12	1	44D9E7AE2A12
123	1	44D9E7AE2A13	44D9E7AE2A13	1	44D9E7AE2A13
152	22	802AA8F1A6B8	802AA8F1A6B8	1	802AA8F1A6B8
153	22	802AA8F1A3E5	802AA8F1A3E5	1	802AA8F1A3E5
155	22	802AA8F1A6AA	802AA8F1A6AA	1	802AA8F1A6AA
156	22	802AA8F1A5A5	802AA8F1A5A5	1	802AA8F1A5A5
157	22	802AA8F1A65A	802AA8F1A65A	1	802AA8F1A65A
158	22	802AA8F1A5F7	802AA8F1A5F7	1	802AA8F1A5F7
159	22	802AA8F1A56F	802AA8F1A56F	1	802AA8F1A56F
160	22	802AA8F1A5F6	802AA8F1A5F6	1	802AA8F1A5F6
161	22	802AA8F1A590	802AA8F1A590	1	802AA8F1A590
162	22	802AA8F1A453	802AA8F1A453	1	802AA8F1A453
163	22	802AA8F1A6A9	802AA8F1A6A9	1	802AA8F1A6A9
164	22	802AA8F1A636	802AA8F1A636	1	802AA8F1A636
165	22	802AA8F1A57E	802AA8F1A57E	1	802AA8F1A57E
166	22	802AA8F19626	802AA8F19626	1	802AA8F19626
167	22	802AA8F1A573	802AA8F1A573	1	802AA8F1A573
168	22	802AA8F1A492	802AA8F1A492	1	802AA8F1A492
169	22	802AA8F1A491	802AA8F1A491	1	802AA8F1A491
170	22	802AA8F1A47E	802AA8F1A47E	1	802AA8F1A47E
171	22	802AA8F1A3D8	802AA8F1A3D8	1	802AA8F1A3D8
172	22	802AA8F1A4C6	802AA8F1A4C6	1	802AA8F1A4C6
173	22	802AA8F1A3D2	802AA8F1A3D2	1	802AA8F1A3D2
174	22	802AA8F195D7	802AA8F195D7	1	802AA8F195D7
175	22	802AA8F195ED	802AA8F195ED	1	802AA8F195ED
176	22	802AA8F1A44A	802AA8F1A44A	1	802AA8F1A44A
177	22	802AA8F1A3F9	802AA8F1A3F9	1	802AA8F1A3F9
178	22	802AA8F1A412	802AA8F1A412	1	802AA8F1A412
179	22	802AA8F1A417	802AA8F1A417	1	802AA8F1A417
180	22	802AA8F1A418	802AA8F1A418	1	802AA8F1A418
181	22	802AA8F1A423	802AA8F1A423	1	802AA8F1A423
182	22	802AA8F1A3F8	802AA8F1A3F8	1	802AA8F1A3F8
183	22	802AA8F195F1	802AA8F195F1	1	802AA8F195F1
184	22	802AA8F1A481	802AA8F1A481	1	802AA8F1A481
185	22	802AA8F1A400	802AA8F1A400	1	802AA8F1A400
100	1	F09FC246E7AB	F09FC246E7AB	1	F09FC246E7AB
124	1	F09FC246E39D	F09FC246E39D	1	F09FC246E39D
89	1	802AA8BC1B58	802AA8BC1B58	1	802AA8BC1B58
139	22	802AA8F1A623	802AA8F1A623	1	802AA8F1A623
142	22	802AA8F1A4D2	802AA8F1A4D2	1	802AA8F1A4D2
147	22	802AA8F19AB8	802AA8F19AB8	1	802AA8F19AB8
144	22	802AA8F19A8D	802AA8F19A8D	1	802AA8F19A8D
145	22	802AA8F1A3EE	802AA8F1A3EE	1	802AA8F1A3EE
138	22	802AA8F1975B 	802AA8F1975B	1	802AA8F1975B
135	22	802AA8F1A5A4	802AA8F1A5A4	1	802AA8F1A5A4
91	1	F09FC246E467	F09FC246E467	1	F09FC246E467
131	1	802AA8BA1E1A	802AA8BA1E1A	1	802AA8BA1E1A
97	1	F09FC246E4E3	F09FC246E4E3	1	F09FC246E4E3
93	1	F09FC246E369	F09FC246E369	1	F09FC246E369
146	22	802AA8F1A4CF	802AA8F1A4CF	1	802AA8F1A4CF
96	1	F09FC246E647	F09FC246E647	1	F09FC246E647
94	1	802AA8BC1E89	802AA8BC1E89	1	802AA8BC1E89
136	22	802AA8F1AA9E	802AA8F1AA9E	1	802AA8F1AA9E
102	1	F09FC246E993	F09FC246E993	1	F09FC246E993
149	22	802AA8F1A494	802AA8F1A494	1	802AA8F1A494
143	22	802AA8F195D0	802AA8F195D0	1	802AA8F195D0
140	22	802AA8F1A3F4	802AA8F1A3F4	1	802AA8F1A3F4
137	22	802AA8F1A588	802AA8F1A588	1	802AA8F1A588
99	1	F09FC246EC4A	F09FC246EC4A	1	F09FC246EC4A
128	1	F09FC246E682	F09FC246E682	1	F09FC246E682
127	1	F09FC246E5C8	F09FC246E5C8	1	F09FC246E5C8
95	1	F09FC246E742	F09FC246E742	1	F09FC246E742
126	1	F09FC246E565	F09FC246E565	1	F09FC246E565
103	1	F09FC246E4AE	F09FC246E4AE	1	F09FC246E4AE
133	1	F09FC246E536	F09FC246E536	1	F09FC246E536
101	1	802AA8F8777F	802AA8F8777F	1	802AA8F8777F
129	1	F09FC246E406	F09FC246E406	1	F09FC246E406
134	22	802AA8F19A84	802AA8F19A84	1	802AA8F19A84
132	1	F09FC246E1F7	F09FC246E1F7	1	F09FC246E1F7
130	1	F09FC246E48A	F09FC246E48A	1	F09FC246E48A
148	22	802AA8F1A4D9	802AA8F1A4D9	1	802AA8F1A4D9
125	1	F09FC246E89F	F09FC246E89F	1	F09FC246E89F
98	1	F09FC246E802	F09FC246E802	1	F09FC246E802
150	22	802AA8F1A5F8	802AA8F1A5F8	1	802AA8F1A5F8
154	22	802AA8F1A6A8	802AA8F1A6A8	1	802AA8F1A6A8
151	22	802AA8F1A698	802AA8F1A698	1	802AA8F1A698
90	1	0418D68A3169	0418D68A3169	3	0418D68A3169
186	22	802AA8F1A47A	802AA8F1A47A	1	802AA8F1A47A
187	22	802AA8F195CE	802AA8F195CE	1	802AA8F195CE
188	22	802AA8F19DB4	802AA8F19DB4	1	802AA8F19DB4
197	5	802AA8A485AE	802AA8A485AE	1	802AA8A485AE
198	19	802AA806CFC7	802AA806CFC7	1	802AA806CFC7
199	19	802AA806C969	802AA806C969	1	802AA806C969
202	8	802AA8B83AE6	802AA8B83AE6	1	802AA8B83AE6
203	10	0418D6F6E232	0418D6F6E232	1	0418D6F6E232
204	10	0418D6F475A4	0418D6F475A4	1	0418D6F475A4
205	8	802AA8B83A23	802AA8B83A23	1	802AA8B83A23
211	6	68725128403B	68725128403B	3	68725128403B
214	6	68725120357D	68725120357D	3	68725120357D
216	6	687251284134	687251284134	3	687251284134
219	6	68725128406F	68725128406F	3	68725128406F
222	6	6872512840A9	6872512840A9	3	6872512840A9
254	28	FTX1539B01F	FTX1539B01F	3	708105926е94
256	28	FTX1538B0QY	FTX1538B0QY	3	708105926D22
258	28	FTX1538B0CQ	FTX1538B0CQ	3	70810592754C
259	28	FTX1539B023	FTX1539B023	3	708105926F74
260	28	FTX1538B0SZ	FTX1538B0SZ	3	70810592734E
261	28	FTX1538B0EP	FTX1538B0EP	3	7081059273D0
263	28	FTX1538B0SC	FTX1538B0SC	3	7081052FC88C
264	28	FTX1538B0Q5	FTX1538B0Q5	3	708105926D78
265	28	FTX1237B2YU	FTX1237B2YU	1	001D70977D46
266	28	FTX1126B2YJ	FTX1126B2YJ	1	001C587ACD8E
267	28	FTX1237B2Y9	FTX1237B2Y9	1	001D70978C60
268	28	FTX1520B0WG	FTX1520B0WG	1	405539FC4570
269	28	FTX1340B11X	FTX1340B11X	1	00260B4D186C
270	28	FTX1144B1GP	FTX1144B1GP	1	001DA1CDE14C
271	28	FTX1126B2KL	FTX1126B2KL	1	001C587AD05C
272	28	FTX1126B2KM	FTX1126B2KM	1	001C587AD154
273	28	FTX1126B2RD	FTX1126B2RD	1	001C5857ED16
274	28	FTX1237B2YD	FTX1237B2YD	1	001D709784A6
275	24	FTX1549U05B	FTX1549U05B	3	649EF3010646
276	24	FTX1539U07S	FTX1539U07S	3	7081053A7836
277	24	FTX1539U083	FTX1539U083	3	7081053A78E8
278	24	FTX1549U05G	FTX1549U05G	3	649EF301043C
279	24	FTX1549U06G	FTX1549U06G	3	649EF3010600
280	24	FTX1539U08G	FTX1539U08G	3	7081053A79BC
281	24	FTX1549U04F	FTX1549U04F	3	649EF3010330
282	24	FTX1549U062	FTX1549U062	3	649EF3010688
255	28	FTX1537B09D	FTX1537B09D	3	708105927122
257	28	FTX1538B0PJ	FTX1538B0PJ	3	708105927306
262	28	FTX1538B0VJ	FTX1538B0VJ	3	708105927316
218	6	6872514412CD	6872514412CD	3	6872514412CD
251	17	802AA86AF17D	802AA86AF17D	1	802AA86AF17D
245	17	802AA86AEE14	802AA86AEE14	1	802AA86AEE14
250	17	802AA86AEE4B	802AA86AEE4B	1	802AA86AEE4B
229	6	68725166C521	68725166C521	1	68725166C521
209	6	687251284014	687251284014	3	687251284014
208	6	68725128412E	68725128412E	3	68725128412E
234	6	6872512840E6	6872512840E6	3	6872512840E6
213	6	687251284184	687251284184	3	687251284184
215	6	687251203514	687251203514	3	687251203514
217	6	68725166C535	68725166C535	1	68725166C535
224	6	68725128400B	68725128400B	3	68725128400B
194	3	F09FC250433B	F09FC250433B	1	F09FC250433B
190	23	802AA81F523A	802AA81F523A	1	802AA81F523A
220	6	24A43C962B65	24A43C962B65	3	24A43C962B65
223	6	68725140CA4B	68725140CA4B	3	68725140CA4B
191	4	802AA8240BB1	802AA8240BB1	1	802AA8240BB1
210	6	68725166C519	68725166C519	1	68725166C519
196	3	F09FC25022B6	F09FC25022B6	1	F09FC25022B6
206	6	6872512035BD	6872512035BD	3	6872512035BD
212	6	687251441278	687251441278	3	687251441278
207	6	687251284198	687251284198	3	687251284198
193	3	F09FC2502453	F09FC2502453	1	F09FC2502453
195	3	F09FC2504444	F09FC2504444	1	F09FC2504444
192	4	802AA8240A9B	802AA8240A9B	1	802AA8240A9B
221	6	687251203629	687251203629	3	687251203629
252	17	802AA86AF0D4	802AA86AF0D4	1	802AA86AF0D4
283	24	FTX1549U05A	FTX1549U05A	3	649EF30106C0
284	24	FTX1539U08F	FTX1539U08F	3	7081053A78FA
285	24	FTX1539U09K	FTX1539U09K	3	7081053A7574
286	24	FTX1539U06V	FTX1539U06V	3	7081053A765C
287	24	FTX1539U0AH	FTX1539U0AH	3	7081053A757A
291	5	802AA8A4C300	802AA8A4C300	1	802AA8A4C300
292	5	802AA8A4C2ED	802AA8A4C2ED	1	802AA8A4C2ED
293	5	802AA8A4C36E	802AA8A4C36E	1	802AA8A4C36E
294	5	802AA8A4C282	802AA8A4C282	1	802AA8A4C282
295	5	802AA8A4C905	802AA8A4C905	1	802AA8A4C905
296	5	802AA8A4C9BE	802AA8A4C9BE	1	802AA8A4C9BE
315	50	AM2D40814	AM2D40814	1	
316	50	AM2D40815	AM2D40815	1	
317	50	AM2D40816	AM2D40816	1	
318	50	AM2D40817	AM2D40817	1	
328	58	RD5G13903	RD5G13903	1	
329	58	RD5G13900	RD5G13900	1	
330	58	RD5G14842	RD5G14842	1	
331	58	RD5G13905	RD5G13905	1	
335	15	24A43C74B58A	24A43C74B58A	3	24A43C74B58A
339	29	71A3066D8B72	71A3066D8B72	4	6C3B6BD7501D
366	29	71A30610A384	71A30610A384	4	6C3B6BDA0D1C
367	29	71A306AA61C3	71A306AA61C3	4	6C3B6BDA0CD4
368	29	71A306D3AD55	71A306D3AD55	4	6C3B6BD7F2C7
369	29	71A306E0CCDE	71A306E0CCDE	4	6C3B6BD7E865
370	29	71B9069C540F	71B9069C540F	4	6C3B6B86EDFD
371	29	71A3067B73CC	71A3067B73CC	4	6C3B6BDA0C02
372	29	71A306B6788D	71A306B6788D	4	6C3B6BDC595A
373	29	71A3068C3B46	71A3068C3B46	4	6C3B6BDA0CCE
374	29	71A306CD25E0	71A306CD25E0	4	6C3B6BD7E7D5
375	29	71A306059E2C	71A306059E2C	4	6C3B6BD7E877
376	29	71A3065E1DA9	71A3065E1DA9	4	6C3B6BD58765
377	29	71A306B660E0	71A306B660E0	4	6C3B6BD75503
378	29	71A30676BADC	71A30676BADC	4	6C3B6BDA106A
379	29	71A306DF5D24	71A306DF5D24	4	6C3B6BDA104C
380	29	71A306E8B71A	71A306E8B71A	4	6C3B6BD58603
381	29	71A3064253B8	71A3064253B8	4	6C3B6BDC5D4A
382	29	71A3068E48E9	71A3068E48E9	4	6C3B6BD75569
383	29	71A306BA19EF	71A306BA19EF	4	6C3B6BD7566B
384	29	71A306DA9B59	71A306DA9B59	4	6C3B6BD7EA6F
320	51	AM2B90613	AM2B90613	1	
340	29	71A306FF1858	71A306FF1858	4	6C3B6BD5887F
299	20	802AA8AE8D12	802AA8AE8D12	1	802AA8AE8D12
311	51	AM2E11835	AM2E11835	1	
301	20	802AA8AE8D13	802AA8AE8D13	1	802AA8AE8D13
333	16	6872515E278C	6872515E278C	1	6872515E278C
313	51	AM2E11836	AM2E11836	1	
298	5	802AA8A4C318	802AA8A4C318	1	802AA8A4C318
305	21	F09FC24AADE9	F09FC24AADE9	1	F09FC24AADE9
304	21	F09FC24AAC3D	F09FC24AAC3D	1	F09FC24AAC3D
336	15	24A43C74B5D9	24A43C74B5D9	3	24A43C74B5D9
353	29	71B906025CCC	71B906025CCC	4	6C3B6BAE5176
322	51	AM2B90639	AM2B90639	1	
314	51	AM2E11838	AM2E11838	1	
354	29	71B9065E81B5	71B9065E81B5	4	6C3B6BAE8250
289	5	802AA8A4C1C8	802AA8A4C1C8	1	802AA8A4C1C8
288	5	802AA8A4C225	802AA8A4C225	1	802AA8A4C225
341	29	71A306F30233	71A306F30233	4	6C3B6BDC6E78
312	51	AM2E11837	AM2E11837	1	
303	20	802AA8AE8F4F	802AA8AE8F4F	1	802AA8AE8F4F
290	5	802AA8A4C2A5	802AA8A4C2A5	1	802AA8A4C2A5
321	51	AM2B90636	AM2B90636	1	
302	20	802AA8AE8FB1	802AA8AE8FB1	1	802AA8AE8FB1
356	29	71B9060AF929	71B9060AF929	4	6C3B6BAE5152
355	29	71A306E4ADE1	71A306E4ADE1	4	6C3B6BD7F153
345	29	71A30625429D	71A30625429D	4	6C3B6BDA111E
348	29	71B90686EB92	71B90686EB92	4	6C3B6B86ED07
338	15	687251307FAA	687251307FAA	3	687251307FAA
300	20	802AA8AE8EC7	802AA8AE8EC7	1	802AA8AE8EC7
364	29	71A306B6711B	71A306B6711B	4	6C3B6BD756C5
306	21	F09FC24AAE84	F09FC24AAE84	1	F09FC24AAE84
359	29	71A30675EA26	71A30675EA26	4	6C3B6BD59383
361	29	71A3062E5B3E	71A3062E5B3E	4	6C3B6BDC698C
346	29	71B906E4A1F8	71B906E4A1F8	4	6C3B6B86ED0D
357	29	71A306CF95B4	71A306CF95B4	4	6C3B6BD58831
349	29	71B9066F339E	71B9066F339E	4	6C3B6BAE832E
297	5	802AA8A4C2D4	802AA8A4C2D4	1	802AA8A4C2D4
352	29	71B906EB7AB4	71B906EB7AB4	4	6C3B6BAE83A0
347	29	71B906FA2D00	71B906FA2D00	4	6C3B6BAE5182
337	15	687251307E78	687251307E78	3	687251307E78
334	15	24A43C74B61D	24A43C74B61D	3	24A43C74B61D
362	29	71A306AC5DCC	71A306AC5DCC	4	6C3B6BD59371
351	29	71B9065CE245	71B9065CE245	4	6C3B6BAE525A
365	29	71A3064CCEAD	71A3064CCEAD	4	6C3B6BDA15EC
360	29	71A30636666A	71A30636666A	4	6C3B6BD5938F
363	29	71B9063298BE	71B9063298BE	4	6C3B6BAFB1DA
350	29	71B906CE6DFD	71B906CE6DFD	4	6C3B6BAE5146
342	29	71B906710509	71B906710509	4	6C3B6BAFB210
332	15	6872515C26BA	6872515C26BA	1	6872515C26BA
358	29	71B906239AEA	71B906239AEA	4	6C3B6BAE5170
386	29	71A30664093D	71A30664093D	4	6C3B6BDC5D50
387	29	71A30675101F	71A30675101F	4	6C3B6BD586E1
388	29	71A3062D4EE1	71A3062D4EE1	4	6C3B6BDC5CDE
389	29	71A306D76AC3	71A306D76AC3	4	6C3B6BD75659
390	29	71A30679B731	71A30679B731	4	6C3B6BD7EBCB
391	29	71A30639F7FD	71A30639F7FD	4	6C3B6BDC5D2C
392	29	71A30629D118	71A30629D118	4	6C3B6BD587AD
393	29	71A3065BBD97	71A3065BBD97	4	6C3B6BDC5D26
394	29	71A306172B6B	71A306172B6B	4	6C3B6BDC5A9E
395	29	71A3065CBC06	71A3065CBC06	4	6C3B6BD7EB47
396	29	71A3062B70B7	71A3062B70B7	4	6C3B6BD7EB8F
397	29	71A306D9CAEB	71A306D9CAEB	4	6C3B6BD7EAF9
398	29	71A3069F0323	71A3069F0323	4	6C3B6BD75521
399	29	71A3061A1CBD	71A3061A1CBD	4	6C3B6BD584B3
400	29	71A3067A7BB1	71A3067A7BB1	4	6C3B6BDC5D20
401	29	71A3061DE0FB	71A3061DE0FB	4	6C3B6BDC5B1C
402	29	71A3063A0FD6	71A3063A0FD6	4	6C3B6BDA105E
403	29	71A306C83673	71A306C83673	4	6C3B6BD754DF
404	29	71A30613FE17	71A30613FE17	4	6C3B6BD7564D
405	29	71A30671B47D	71A30671B47D	4	6C3B6BD75647
406	29	71A306CBD093	71A306CBD093	4	6C3B6BD7EA27
407	29	71A3068A115C	71A3068A115C	4	6C3B6BD7EC01
408	29	71A306A26EAE	71A306A26EAE	4	6C3B6BD7EA9F
409	29	71A306E74186	71A306E74186	4	6C3B6BD7EBBF
410	29	71A3061C61F8	71A3061C61F8	4	6C3B6BD7EBDD
411	29	71A3069A897D	71A3069A897D	4	6C3B6BD58771
412	29	71A306777E6A	71A306777E6A	4	6C3B6BD58747
413	29	71A306C4260F	71A306C4260F	4	6C3B6BD5879B
414	29	71A30600B2DB	71A30600B2DB	4	6C3B6BD5878F
415	29	71A306A6B244	71A306A6B244	4	6C3B6BD79Ed3
416	29	71A306666748	71A306666748	4	6C3B6BDC5CF6
417	29	71A306C84EFB	71A306C84EFB	4	6C3B6BD58735
418	29	71A3066822DA	71A3066822DA	4	6C3B6BD585C1
419	29	71A306369C53	71A306369C53	4	6C3B6BD586ED
420	29	71A30650D4F2	71A30650D4F2	4	6C3B6BD7EBE9
421	29	71A306DDBC89	71A306DDBC89	4	6C3B6BDA0FDA
422	29	71A3062C4ABD	71A3062C4ABD	4	6C3B6BD7563B
423	29	71A306E8DE69	71A306E8DE69	4	6C3B6BD7562f
424	29	71A30636CEBB	71A30636CEBB	4	6C3B6BDC5D14
425	29	71A30679839A	71A30679839A	4	6C3B6BDA1052
430	30	416501A2E8E2	416501A2E8E2	4	000C427FB055
431	30	416501A2E8DA	416501A2E8DA	4	000C427FB06D
432	30	416501A2E8DF	416501A2E8DF	4	000C427FB068
433	30	416501A2E89E	416501A2E89E	4	000C427FB029
434	30	416501A2E8F8	416501A2E8F8	4	000C427FB04F
435	30	416501A2F772	416501A2F772	4	000C427FAFC5
436	30	416501A2E8F5	416501A2E8F5	4	000C427fB042
437	30	416501A2E9E0	416501A2E9E0	4	000C427FB157
438	30	416501A2E8DC	416501A2E8DC	4	000C427FB06B
443	11	68725166890C	68725166890C	1	68725166890C
444	11	68725166898D	68725166898D	1	68725166898D
445	11	6872516689B0	6872516689B0	1	6872516689B0
446	11	68725164A8DF	68725164A8DF	3	68725164A8DF
447	11	6872514A49A5	6872514A49A5	3	6872514A49A5
448	11	687251668A2E	687251668A2E	1	687251668A2E
449	11	687251668984	687251668984	1	687251668984
450	11	68725166893A	68725166893A	1	68725166893A
451	11	687251668856	687251668856	1	687251668856
452	11	6872516688F3	6872516688F3	1	6872516688F3
453	11	6872514A49C5	6872514A49C5	3	6872514A49C5
454	11	6872514A49A0	6872514A49A0	3	6872514A49A0
455	11	687251668921	687251668921	1	687251668921
456	11	6872516689A7	6872516689A7	1	6872516689A7
457	11	687251668854	687251668854	1	687251668854
458	11	687251668A18	687251668A18	1	687251668A18
459	11	687251668A1C	687251668A1C	1	687251668A1C
464	11	24A43C9E12D5	24A43C9E12D5	3	24A43C9E12D5
465	11	68725120DE2B	68725120DE2B	3	68725120DE2B
476	11	68725122668B	68725122668B	3	68725122668B
426	29	71B906173598	71B906173598	4	6C3B6B86EE8D
428	29	71B906D5B5C2	71B906D5B5C2	4	6C3B6BAFB3AB
427	29	71A306E0545B	71A306E0545B	4	6C3B6BDA0A40
477	11	24A43CA62E8E	24A43CA62E8E	3	24A43CA62E8E
466	11	68725120DDB3	68725120DDB3	3	68725120DDB3
429	29	71A306171D99	71A306171D99	4	6C3B6BD589F3
467	11	68725120E1AD	68725120E1AD	3	68725120E1AD
475	11	24A43CA62DBE	24A43CA62DBE	3	24A43CA62DBE
473	11	24A43CA62DC8	24A43CA62DC8	3	24A43CA62DC8
469	11	68725120DD95	68725120DD95	3	68725120DD95
463	11	68725120E19A	68725120E19A	3	68725120E19A
481	11	68725122650F	68725122650F	3	68725122650F
460	11	24A43CA6319D	24A43CA6319D	3	24A43CA6319D
468	11	24A43C9E1285	24A43C9E1285	3	24A43C9E1285
470	11	24A43CA63155	24A43CA63155	3	24A43CA63155
474	11	6872514A4959	6872514A4959	3	6872514A4959
479	11	68725120DECE	68725120DECE	3	68725120DECE
472	11	68725120DD7D	68725120DD7D	3	68725120DD7D
471	11	24A43CA62EAA	24A43CA62EAA	3	24A43CA62EAA
385	29	71A30654D639	71A30654D639	4	6C3B6BD586E7
461	11	6872514A4834	6872514A4834	3	
478	11	24A43C9E12B7	24A43C9E12B7	3	24A43C9E12B7
483	11	68725120Е182	68725120Е182	3	68725120Е182
490	11	24A43CF89BF3	24A43CF89BF3	3	24A43CF89BF3
497	11	24A43CA62E67	24A43CA62E67	3	24A43CA62E67
498	14	002722CA92F7	002722CA92F7	1	002722CA92F7
501	14	002722A84812	002722A84812	1	002722A84812
503	14	DC9FDB5410CF	DC9FDB5410CF	1	DC9FDB5410CF
504	14	002722CA9370	002722CA9370	1	002722CA9370
505	14	002722A6B80E	002722A6B80E	1	002722A6B80E
506	14	00272298BE89	00272298BE89	1	00272298BE89
507	14	0027223212EE	0027223212EE	1	0027223212EE
510	14	0027223212AD	0027223212AD	5	0027223212AD
511	14	DC9FDB5412E0	DC9FDB5412E0	5	DC9FDB5412E0
512	14	6872510231C1	6872510231C1	5	6872510231C1
517	14	1119T0027223	1119T0027223	5	
519	13	002722E6EC8E	002722E6EC8E	1	002722E6EC8E
521	13	DC9FDB522224	DC9FDB522224	3	DC9FDB522224
522	13	DC9FDB52214F	DC9FDB52214F	3	DC9FDB52214F
525	13	DC9FDB5221AF	DC9FDB5221AF	3	DC9FDB5221AF
526	13	DC9FDB5221DC	DC9FDB5221DC	3	DC9FDB5221DC
528	13	DC9FDB5005F2	DC9FDB5005F2	3	DC9FDB5005F2
529	13	002722EE8031	002722EE8031	3	002722EE8031
532	13	DC9FDB522201	DC9FDB522201	3	DC9FDB522201
534	13	002722E6EC5C	002722E6EC5C	3	002722E6EC5C
535	13	002722E6EC7F	002722E6EC7F	3	002722E6EC7F
540	13	DC9FDBA67D92	DC9FDBA67D92	3	DC9FDBA67D92
544	13	DC9FDBA67D91	DC9FDBA67D91	3	DC9FDBA67D91
545	13	DC9FDB500602	DC9FDB500602	3	DC9FDB500602
546	13	DC9FDB522202	DC9FDB522202	3	DC9FDB522202
550	13	002722E6ED2A	002722E6ED2A	3	002722E6ED2A
553	13	002722E6ECEC	002722E6ECEC	3	002722E6ECEC
556	13	DC9FDB5221EA	DC9FDB5221EA	3	DC9FDB5221EA
559	13	DC9FDB500632	DC9FDB500632	3	DC9FDB500632
561	13	002722EE7FE9	002722EE7FE9	3	002722EE7FE9
564	13	DC9FDB5005F9	BC9FDB5005F9	3	BC9FDB5005F9
565	13	DC9FDB5005FF	DC9FDB5005FF	3	DC9FDB5005FF
566	13	002722E6Ec91	002722E6Ec91	3	002722E6Ec91
567	13	DC9FDB5321BC	DC9FDB5321BC	1	DC9FDB5321BC
569	53	RD2A05529	RD2A05529	3	
570	53	RD2A05503	RD2A05503	3	
571	53	RD2A05210	RD2A05210	3	
572	53	RD2A05224	RD2A05224	3	
573	53	RD2A11126	RD2A11126	3	
574	53	RD2A09502	RD2A09502	3	
575	53	RD2A05206	RD2A05206	3	
576	53	RD2A08113	RD2A08113	3	
577	53	RD2A04799	RD2A04799	3	
578	53	RD2A08119	RD2A08119	3	
579	53	RD2A09486	RD2A09486	3	
580	31	23210456310	23210456310	1	23210456310
581	31	23209452687	23209452687	1	23209452687
531	13	002722E6EC90	002722E6EC90	1	002722E6EC90
509	14	00272298BE8A	00272298BE8A	1	00272298BE8A
542	13	DC9FDBA67E0F	DC9FDBA67E0F	3	DC9FDBA67E0F
560	13	DC9FDB5005EE	DC9FDB5005EE	3	DC9FDB5005EE
508	14	00272298BF07	00272298BF07	1	00272298BF07
549	13	002722EE8042	002722EE8042	3	002722EE8042
486	11	24A43CA6312E	24A43CA6312E	3	24A43CA6312E
499	14	68725102323A	68725102323A	5	68725102323A
500	14	0027223212A3	0027223212A3	5	0027223212A3
502	14	0027223212DD	0027223212DD	5	0027223212DD
513	14	00272298BEB1	00272298BEB1	1	00272298BEB1
514	14	DC9FDB3250A4	DC9FDB3250A4	1	DC9FDB3250A4
516	14	002722A8456D	002722A8456D	1	002722A8456D
518	13	002722E6ED32	002722E6ED32	3	002722E6ED32
555	13	002722E6ED3B	002722E6ED3B	1	002722E6ED3B
491	11	24A43CA62EA2	24A43CA62EA2	3	24A43CA62EA2
552	13	002722EE8059	002722EE8059	3	002722EE8059
558	13	002722E6ED26	002722E6ED26	3	002722E6ED26
541	13	DC9FDBA67E85	DC9FDBA67E85	3	DC9FDBA67E85
524	13	DC9FDBA67D7A	DC9FDBA67D7A	3	DC9FDBA67D7A
543	13	002722EE7F9C	002722EE7F9C	1	002722EE7F9C
523	13	DC9FDBA67EA6	DC9FDBA67EA6	3	DC9FDBA67EA6
538	13	002722EE7FDB	002722EE7FDB	3	002722EE7FDB
547	13	DC9FDB5005A3	DC9FDB5005A3	3	DC9FDB5005A3
489	11	68725120DE93	68725120DE93	3	68725120DE93
493	11	68725122656B	68725122656B	3	68725122656B
551	13	DC9FDB50052C	DC9FDB50052C	3	DC9FDB50052C
568	13	DC9FDB5221BC	DC9FDB5221BC	3	DC9FDB5221BC
527	13	DC9FDB500629	DC9FDB500629	3	DC9FDB500629
537	13	002722E6ED23	002722E6ED23	3	002722E6ED23
482	11	6872512265D0	6872512265D0	3	6872512265D0
557	13	DC9FDB5005E7	DC9FDB5005E7	3	DC9FDB5005E7
533	13	DC9FDB5005D0	DC9FDB5005D0	3	DC9FDB5005D0
520	13	DC9FDB50057C	DC9FDB50057C	3	DC9FDB50057C
562	13	002722EE7FA8	002722EE7FA8	3	002722EE7FA8
548	13	002722EE7F7D	002722EE7F7D	3	002722EE7F7D
554	13	DC9FDBA67E83	DC9FDBA67E83	3	DC9FDBA67E83
484	11	68725120DD9E	68725120DD9E	3	68725120DD9E
494	11	68725120E1B0	68725120E1B0	3	68725120E1B0
495	11	24A43CA62EB0	24A43CA62EB0	3	24A43CA62EB0
539	13	DC9FDB5221AE	DC9FDB5221AE	1	DC9FDB5221AE
530	13	DC9FDBA67D7C	DC9FDBA67D7C	3	DC9FDBA67D7C
485	11	68725120DD7B	68725120DD7B	3	68725120DD7B
536	13	DC9FDB50056C	DC9FDB50056C	3	DC9FDB50056C
492	11	6872516688E8	6872516688Е8	1	6872516688Е8
487	11	6872514A4A0D	6872514A4A0D	3	6872514A4A0D
582	31	23210456345	23210456345	3	23210456345
583	31	23210564618	23210564618	3	23210564618
584	31	23210268246	23210268246	3	23210268246
585	31	23210268242	23210268242	3	23210268242
586	31	23210456359	23210456359	3	23210456359
587	31	23210456437	23210456437	3	23210456437
588	31	23210456336	23210456336	3	23210456336
589	31	23210456376	23210456376	3	23210456376
590	31	23210456373	23210456373	3	23210456373
591	31	23210456326	23210456326	3	23210456326
592	31	23210456444	23210456444	3	23210456444
593	31	23210564584	23210564584	3	23210564584
594	31	23210456343	23210456343	3	23210456343
595	31	23210456324	23210456324	3	23210456324
596	31	23210456381	23210456381	3	23210456381
597	31	23210268279	23210268279	3	23210268279
598	31	23210456397	23210456397	3	23210456397
599	31	23210456307	23210456307	3	23210456307
600	31	23210456298	23210456298	3	23210456298
601	31	23210456435	23210456435	3	23210456435
602	31	23210456305	23210456305	3	23210456305
603	31	23210456390	23210456390	3	23210456390
604	31	23210456360	23210456360	3	23210456360
605	31	23210268243	23210268243	3	23210268243
606	31	23210456308	23210456308	3	23210456308
607	31	23210456400	23210456400	3	23210456400
608	31	23210268663	23210268663	3	23210268663
609	31	23210456296	23210456296	3	23210456296
610	31	23210456335	23210456335	3	23210456335
611	31	23210268251	23210268251	3	23210268251
612	31	23210456368	23210456368	3	23210456368
613	31	23210456434	23210456434	3	23210456434
614	31	23210456421	23210456421	3	23210456421
615	31	23210456334	23210456334	3	23210456334
616	31	23210456358	23210456358	3	23210456358
617	31	23210456363	23210456363	3	23210456363
618	31	23210456374	23210456374	3	23210456374
619	31	23210456331	23210456331	3	23210456331
620	31	23210564564	23210564564	3	23210564564
621	31	23210564566	23210564566	3	23210564566
622	31	23210456323	23210456323	3	23210456323
623	31	23210456348	23210456348	3	23210456348
624	31	23210456355	23210456355	3	23210456355
625	31	23210456300	23210456300	3	23210456300
626	31	23210456431	23210456431	3	23210456431
627	31	23210456317	23210456317	3	23210456317
628	31	23210456366	23210456366	3	23210456366
629	31	23210564616	23210564616	3	23210564616
630	31	23210268648	23210268648	3	23210268648
631	31	23210456383	23210456383	3	23210456383
632	31	23210456404	23210456404	3	23210456404
633	31	23210456314	23210456314	3	23210456314
634	31	23210456312	23210456312	3	23210456312
635	50	AM2D30892	AM2D30892	1	
639	48	ant15002	ant15002	1	
640	48	ant15003	ant15003	1	
641	48	ant15004	ant15004	1	
642	48	ant15005	ant15005	1	
643	48	ant15006	ant15006	1	
644	48	ant15007	ant15007	1	
645	48	ant15008	ant15008	1	
646	48	ant15009	ant15009	1	
647	48	ant15010	ant15010	1	
648	48	ant15011	ant15011	1	
649	48	ant15012	ant15012	1	
650	48	ant15013	ant15013	1	
651	48	ant15014	ant15014	1	
652	48	ant15015	ant15015	1	
653	48	ant15016	ant15016	1	
654	48	ant15017	ant15017	1	
655	48	ant15018	ant15018	1	
656	48	ant15019	ant15019	1	
657	48	ant15020	ant15020	1	
658	48	ant15021	ant15021	1	
659	48	ant15022	ant15022	3	
660	48	ant15023	ant15023	3	
661	48	ant15024	ant15024	3	
662	48	ant15025	ant15025	3	
663	48	ant15026	ant15026	3	
664	48	ant15027	ant15027	3	
665	48	ant15028	ant15028	3	
666	48	ant15029	ant15029	3	
667	48	ant15030	ant15030	3	
668	48	ant15031	ant15031	3	
669	48	ant15032	ant15032	3	
670	48	ant15033	ant15033	3	
671	48	ant15034	ant15034	3	
672	48	ant15035	ant15035	3	
673	48	ant15036	ant15036	3	
677	45	ant24004	ant24004	1	
678	45	ant24005	ant24005	1	
679	45	ant24006	ant24006	1	
680	45	ant24007	ant24007	1	
681	45	ant24008	ant24008	1	
682	45	ant24009	ant24009	1	
683	45	ant24010	ant24010	1	
684	45	ant24011	ant24011	1	
685	45	ant24012	ant24012	1	
687	45	ant24014	ant24014	3	
688	45	ant24015	ant24015	3	
689	45	ant24016	ant24016	3	
690	45	ant24017	ant24017	3	
691	45	ant24018	ant24018	3	
692	45	ant24019	ant24019	3	
693	45	ant24020	ant24020	3	
694	45	ant24021	ant24021	3	
637	50	AM2D39551	AM2D39551	1	
674	45	ant24001	ant24001	1	
676	45	ant24003	ant24003	1	
675	45	ant24002	ant24002	1	
636	50	AM2D30947	AM2D30947	1	
695	45	ant24022	ant24022	3	
696	45	ant24023	ant24023	3	
697	45	ant24024	ant24024	3	
698	45	ant24025	ant24025	3	
699	45	ant24026	ant24026	3	
700	45	ant24027	ant24027	3	
701	45	ant24028	ant24028	3	
702	45	ant24029	ant24029	3	
703	45	ant24030	ant24030	3	
704	45	ant24031	ant24031	3	
705	45	ant24032	ant24032	3	
706	45	ant24033	ant24033	3	
707	45	ant24034	ant24034	3	
708	45	ant24035	ant24035	3	
709	45	ant24036	ant24036	3	
710	45	ant24037	ant24037	3	
711	45	ant24038	ant24038	3	
712	45	ant24039	ant24039	3	
713	45	ant24040	ant24040	3	
714	45	ant24041	ant24041	3	
715	45	ant24042	ant24042	3	
716	45	ant24043	ant24043	3	
717	45	ant24044	ant24044	3	
718	45	ant24045	ant24045	3	
719	45	ant24046	ant24046	3	
720	45	ant24047	ant24047	3	
721	45	ant24048	ant24048	3	
722	45	ant24049	ant24049	3	
723	45	ant24050	ant24050	3	
724	45	ant24051	ant24051	3	
725	45	ant24052	ant24052	3	
726	45	ant24053	ant24053	3	
727	45	ant24054	ant24054	3	
728	45	ant24055	ant24055	3	
729	45	ant24056	ant24056	3	
730	45	ant24057	ant24057	3	
731	45	ant24058	ant24058	3	
732	45	ant24059	ant24059	3	
733	45	ant24060	ant24060	3	
734	45	ant24061	ant24061	3	
735	45	ant24062	ant24062	3	
736	45	ant24063	ant24063	3	
737	45	ant24064	ant24064	3	
738	45	ant24065	ant24065	3	
739	45	ant24066	ant24066	3	
740	45	ant24067	ant24067	3	
741	45	ant24068	ant24068	3	
742	45	ant24069	ant24069	3	
743	45	ant24070	ant24070	3	
744	45	ant24071	ant24071	3	
745	54	ant2601	ant2601	1	
746	54	ant2602	ant2602	1	
747	54	ant2603	ant2603	1	
748	54	ant2604	ant2604	1	
749	54	ant2605	ant2605	1	
750	54	ant2606	ant2606	1	
751	54	ant2607	ant2607	1	
752	54	ant2608	ant2608	1	
753	46	ant1	ant1	3	
754	46	ant2	ant2	3	
755	47	ant3	ant3	3	
756	47	ant4	ant4	3	
760	33	11381207502	11381207502	3	
763	39	218924406	218924406	3	
764	39	218492011	218492011	3	
765	39	218924175	218924175	3	
766	34	13679401916	13679401916	3	
767	34	13679401912	13679401912	3	
768	41	T11308003216	T11308003216	3	B89BC9F52C82
769	41	T11308003212	T11308003212	3	B89BC9F52DA9
770	40	BKLRQ2WR0047	BKLRQ2WR0047	1	00304F6F4CFD
771	59	P1QE2AB001321	P1QE2AB001321	5	3408040A588E
772	38	F3B2174000528	F3B2174000528	5	
773	36	2142168003567	2142168003567	5	E894F6945508
774	35	12679803741	12679803741	5	647002846CD2
775	42	E2423010343000854	E2423010343000854	5	
776	60	R36F1BB024640	R36F1BB024640	1	B8A38605EE77
777	61	AVS2707002988	AVS2707002988	5	
778	43	150226E1000N00759	150226E1000N00759	3	
779	43	150226E1000N00760	150226E1000N00760	3	
780	43	150226E1000N00611	150226E1000N00611	3	
781	43	150226E1000N00612	150226E1000N00612	3	
782	1	f09fc246e417	f09fc246e417	1	f09fc246e417
783	29	71a30677859b646	71a30677859b646	4	6ceb6bafb4b5
784	20	802AA8AE8F53	802AA8AE8F53	2	802AA8AE8F53
785	29	71a306c519c8652	71a306c519c8652	4	6c3b6bd586ab
786	29	71a30642735f652	71a30642735f652	4	6c3b6bd7f14d
761	33	12B80803512	12B80803512	3	
762	37	QS082d1015069	QS082d1015069	1	
759	32	2142293005793	2142293005793	3	
758	32	12BC5105692	12BC5105692	3	
788	0	A310138800681	A310138800681	5	
789	130	LGZV8EJF3DEA0	LGZV8EJF3DEA0	5	00186EF3DEA0
253	28	FTX1538B0PN	FTX1538B0PN	3	708105927336
857	3	 F09FC2504367	F09FC2504367	1	F09FC2504367
850	8	 802AA8B83ADB	802AA8B83ADB	2	802AA8B83ADB
868	3	F09FC2502228	F09FC2502228	1	F09FC2502228
515	14	NO MAC_ADDRESS:11		5	
787	129	NO_MAC_ADDRESS:33	NO_MAC_ADDRESS:33	1	
806	29	71A30695C234/652	71A30695C234/652	\N	6C3B6BD7F0B7
807	1	F09FC246E621	F09FC246E621	1	F09FC246E621
808	29	71A306175D9B/652	71A306175D9B/652	\N	6C3B6BD7FA47
814	45	ant24073	ant24073	\N	ant24073
815	29	71b906ba1f71646	71b906ba1f71646	\N	6c3b6b86ee21
816	1	f09fc246e3ca	f09fc246e3ca	1	f09fc246e3ca
817	29	71a306be9a84652	71a306be9a84652	\N	6c3b6bdc5666
824	29	71a3066536fa	71a3066536fa	\N	6c386bdc5c60
826	29	 71b90631bf1a	 71b90631bf1a	\N	6C3B6BAE844B
828	45	ant24074	ant24074	\N	ant24074
830	29	 71a3060aa1ss	 71a3060aa1ss	\N	6c3b6bda179c
831	1	F09FC246E67C	F09FC246E67C	1	F09FC246E67C
832	45	ant24075	ant24075	\N	ant24075
805	45	ant24077	ant24077	\N	ant24077
833	45	ant24076	ant24076	\N	ant24076
834	29	71a306dcd0ee	71a306dcd0ee	\N	6c3b6bdc566c
835	1	f09fc246e412	f09fc246e412	1	f09fc246e412
836	29	71b906391aff	71b906391aff	\N	6c3b6bae846c
837	1	f09fc246ed08	f09fc246ed08	1	f09fc246ed08
838	29	71b906943016	71b906943016	\N	6c3b6bae84c0
839	29	71a306f37453	71a306f37453	\N	6c3b6bdc5ff6
841	1	f09fc246e139	f09fc246e139	1	f09fc246e139
843	1	f09fc246e3ff	f09fc246e3ff	1	f09fc246e3ff
844	29	71b906b5f630	71b906b5f630	\N	6c3b6bae84c6
842	29	71a3069eb9bb	71a3069eb9bb	\N	6c3b6bd7ee35
869	3	F09FC2502342	F09FC2502342	1	F09FC2502342
845	1	F09FC246E399	F09FC246E399	1	F09FC246E399
801	29	71A30682E408/652	71A30682E408/652	\N	6C3B6BDA1F28
800	1	F09FC246E4F2	F09FC246E4F2	1	F09FC246E4F2
851	3	 F09FC250440F	 F09FC250440F	1	 F09FC250440F
884	1	F09FC246E685	F09FC246E685	1	F09FC246E685
885	1	F09FC246E059	F09FC246E059	1	F09FC246E059
891	3	F09FC2504355	F09FC2504355	1	F09FC2504355
892	5	802AA8A4C397	802AA8A4C397	1	802AA8A4C397
897	3	F09FC250328A	F09FC250328A	1	F09FC250328A
827	28	70810592735a	70810592735a	\N	70810592735a
848	10	0418D6F6E1F2	0418D6F6E1F2	1	0418D6F6E1F2
849	14	00272298BEEA	00272298BEEA	3	00272298BEEA
853	56	ant519001	ant52001	1	ant52001
847	8	802AA8B82A7C	802AA8B82A7C	2	802AA8B82A7C
856	57	AM5G2001	AM5G2001	2	AM5G2001
855	54	ant2609	ant2609	1	ant2609
852	19	 DC9FDB941AF3	 DC9FDB941AF3	4	 DC9FDB941AF3
858	6	687251284045	687251284045	3	687251284045
859	50	AM1301	AM1301	3	AM1301
860	19	DC9FDB6E33AC	DC9FDB6E33AC	4	DC9FDB6E33AC
861	11	68725120DE2A	68725120DE2A	3	68725120DE2A
862	48	ant15037	ant15037	3	ant15037
863	22	802AA8F1A632	802AA8F1A632	1	802AA8F1A632
864	15	24A43C74B574	24A43C74B574	3	24A43C74B574
865	16	6872515E2802	6872515E2802	2	6872515E2802
866	8	802AA8B83A3F	802AA8B83A3F	1	802AA8B83A3F
870	8	802AA8B82B8A	802AA8B82B8A	2	802AA8B82B8A
867	57	AM5G2004	AM5G2004	2	AM5G2004
872	16	6872515E2B4C	6872515E2B4C	2	6872515E2B4C
871	56	AM5G2005	AM5G2005	1	AM5G2005
873	11	68725120DFF1	68725120DFF1	3	68725120DFF1
874	14	0027223212E7	0027223212E7	3	0027223212E7
875	48	ant15038	ant15038	3	ant15038
876	14	0027223212A1	0027223212A1	3	0027223212A1
877	6	68725166C2EA	68725166C2EA	1	68725166C2EA
878	50	AM1302	AM1302	1	AM1302
879	22	802AA8F1A5B0	802AA8F1A5B0	1	802AA8F1A5B0
880	6	687251441281	687251441281	3	687251441281
882	19	802AA806C5B2	802AA806C5B2	1	802AA806C5B2
881	50	AM1303	AM1303	1	AM1303
883	22	802AA8F19DED	802AA8F19DED	1	802AA8F19DED
886	22	802AA8F1AA87	802AA8F1AA87	1	802AA8F1AA87
887	6	68725166C520	68725166C520	1	68725166C520
888	50	AM1304	AM1304	1	AM1304
890	19	802AA806C9AB	802AA806C9AB	1	802AA806C9AB
894	11	68725122677F	68725122677F	3	68725122677F
895	48	ant15039	ant15039	3	ant15039
893	19	DC9FDB6E3CA5	DC9FDB6E3CA5	4	DC9FDB6E3CA5
896	22	802AA88D548B	802AA88D548B	1	802AA88D548B
804	11	68725120DDB5	68725120DDB5	3	68725120DDB5
802	1	802AA8F87BE6  	802AA8F87BE6	1	802AA8F87BE6
823	1	f09fc246e4fc	f09fc246e4fc	1	f09fc246e4fc
840	1	f09fc246e185	f09fc246e185	1	f09fc246e185
825	11	68725144DA0A	68725144DA0A	3	68725144DA0A
813	11	6872514a4a33	6872514a4a33	3	6872514a4a33
829	13	DC9FDB500630	DC9FDB500630	3	DC9FDB500630
810	29	71A30698F81B/652	71A30698F81B/652	4	6C3B6BD76775
803	29	71A306C29A78	71A306C29A78	4	6C3B6BD76715
907	5	802AA8A483EE	802AA8A483EE	1	802AA8A483EE
910	1	F09FC246E5BA	F09FC246E5BA	1	F09FC246E5BA
914	3	F09FC2504357	F09FC2504357	1	F09FC2504357
919	3	F09FC2504391	F09FC2504391	1	F09FC2504391
923	5	802AA8A4CA60	802AA8A4CA60	1	802AA8A4CA60
925	5	802AA8A4C11B	802AA8A4C11B	1	802AA8A4C11B
926	3	802AA824F135	802AA824F135	1	802AA824F135
927	3	802AA824ECFC	802AA824ECFC	1	802AA824ECFC
930	3	802AA824ED75	802AA824ED75	1	802AA824ED75
918	48	ant15042	ant15042	3	ant15042
933	3	802AA824E7ED	802AA824E7ED	1	802AA824E7ED
939	3	802AA824F171	802AA824F171	1	802AA824F171
945	3	F09FC2504396	F09FC2504396	1	F09FC2504396
950	1	802AA8F87C21	802AA8F87C21	1	802AA8F87C21
954	1	F09FC246E755	F09FC246E755	1	F09FC246E755
976	50	AM1307	AM1307	3	AM1307
970	1	802AA806DBBD	802AA806DBBD	1	802AA806DBBD
968	1	F09FC246E5A8	F09FC246E5A8	1	F09FC246E5A8
920	11	68725164A9B0	68725164A9B0	2	68725164A9B0
983	3	F09FC25022A6	F09FC25022A6	1	F09FC25022A6
984	5	802AA8A485FA	802AA8A485FA	1	802AA8A485FA
985	3	F09FC2502329	F09FC2502329	1	F09FC2502329
986	3	F09FC250234E	F09FC250234E	1	F09FC250234E
990	5	802AA8A4CB04	802AA8A4CB04	1	802AA8A4CB04
993	3	F09FC2502323	F09FC2502323	1	F09FC2502323
996	3	F09FC25022EA	F09FC25022EA	1	F09FC25022EA
966	11	68725164A933	68725164A933	2	68725164A933
488	11	6872514A495D	6872514A495D	3	6872514A495D
343	29	71A30627B46D	71A30627B46D	4	6C3B6BD7F29D
480	11	687251226351	687251226351	3	687251226351
104	1	F09FC246E3B2	F09FC246E3B2	1	F09FC246E3B2
960	131	802AA83CD223	802AA83CD223	2	802AA83CD223
854	58	5G3101	5G3101	1	5G3101
958	22	802AA8F1A5B5	802AA8F1A5B5	1	802AA8F1A5B5
977	54	ant2610	ant2610	1	ant2610
964	22	802AA8F1AA48	802AA8F1AA48	1	802AA8F1AA48
959	131	802AA83CD113	802AA83CD113	2	802AA83CD113
975	6	68725166C332	68725166C332	1	68725166C332
974	14	00272298BEA2	00272298BEA2	3	00272298BEA2
979	10	0418D6F6E22A	0418D6F6E22A	1	0418D6F6E22A
980	6	68725166C309	68725166C309	1	68725166C309
981	6	68725166C345	68725166C345	1	68725166C345
987	50	AM1308	AM1308	1	AM1308
988	51	AM1504	AM1504	1	AM1504
989	56	ant519003	ant519003	1	ant519003
991	11	687251668A31	687251668A31	1	687251668A31
992	48	ant15050	ant15050	3	ant15050
994	11	68725164A9D4	68725164A9D4	2	68725164A9D4
995	48	ant15051	ant15051	3	ant15051
899	6	68725166C5E0	68725166C5E0	1	68725166C5E0
900	51	AM1501	AM1501	1	AM1501
901	19	DC9FDB941AE3	DC9FDB941AE3	4	DC9FDB941AE3
902	11	6872514A48F0	6872514A48F0	3	6872514A48F0
903	48	ant15040	ant15040	3	ant15040
905	19	DC9FDB6E3D55	DC9FDB6E3D55	4	DC9FDB6E3D55
906	16	6872515E28A7	6872515E28A7	2	6872515E28A7
911	45	ant24078	ant24078	3	ant24078
913	11	68725164A9BF	68725164A9BF	2	68725164A9BF
915	48	ant15041	ant15041	3	ant15041
916	19	802AA808EAD2	802AA808EAD2	1	802AA808EAD2
344	29	71A30602E04B	71A30602E04B	4	6C3B6BD76007
921	48	ant15043	ant15043	3	ant15043
922	22	802AA88D5537	802AA88D5537	1	802AA88D5537
924	22	802AA8F19ACC	802AA8F19ACC	1	802AA8F19ACC
928	6	68725166C32D	 68:72:51:66:C3:2D	1	 68:72:51:66:C3:2D
929	50	AM1306	AM1306	3	AM1306
932	48	ant15044	ant15044	3	ant15044
934	11	68725120DD4B	68725120DD4B	3	68725120DD4B
935	48	ant15045	ant15045	3	ant15045
940	20	802AA8AE8D11	802AA8AE8D11	2	802AA8AE8D11
941	51	AM1502	AM1502	3	AM1502
938	19	802AA808F4DC	802AA808F4DC	1	802AA808F4DC
936	23	802AA81D0FEA	802AA81D0FEA	1	802AA81D0FEA
942	19	DC9FDB4CBAA1	DC9FDB4CBAA1	4	DC9FDB4CBAA1
943	11	6872514A4835	6872514A4835	3	6872514A4835
944	48	ant15046	ant15046	3	ant15046
946	11	68725120DDB6	68725120DDB6	3	68725120DDB6
948	16	6872515E292E	6872515E292E	2	6872515E292E
947	48	ant15047	ant15047	3	ant15047
951	6	68725140C96B	68725140C96B	3	68725140C96B
952	51	AM1503	AM1503	3	AM1503
953	11	68725166885B	68725166885B	1	68725166885B
955	22	802AA8F1A3DB	802AA8F1A3DB	1	802AA8F1A3DB
956	11	6872514A495E	6872514A495E	3	6872514A495E
961	131	802AA83CD211	802AA83CD211	2	802AA83CD211
962	11	6872514A49F5	6872514A49F5	3	6872514A49F5
963	48	ant15048	ant15048	3	ant15048
971	22	802AA8F1A6B9	802AA8F1A6B9	1	802AA8F1A6B9
972	19	802AA806AE94	802AA806AE94	1	802AA806AE94
973	11	24A43CA632D6	24A43CA632D6	3	24A43CA632D6
908	6	68725166C622	68725166C622	1	68725166C622
909	50	AM1305	AM1305	3	AM1305
912	15	24A43C74B61B	24A43C74B61B	3	24A43C74B61B
757	32	2154209000797	2154209000797	3	
898	19	DC9FDB6E3CC9	DC9FDB6E3CC9	4	DC9FDB6E3CC9
1002	3	802AA824F681	802AA824F681	1	802AA824F681
1006	3	802AA824ED03	802AA824ED03	1	802AA824ED03
1010	3	802AA824ED83	802AA824ED83	1	802AA824ED83
1011	3	802AA8645079	802AA8645079	1	802AA8645079
1012	3	802AA86450AB	802AA86450AB	1	802AA86450AB
1015	3	802AA864507A	802AA864507A	1	802AA864507A
1016	3	802AA824ED74	802AA824ED74	1	802AA824ED74
1019	3	802AA824EE13	802AA824EE13	1	802AA824EE13
1029	5	802AA8A485C8	802AA8A485C8	1	802AA8A485C8
1030	5	802AA8A4823E	802AA8A4823E	1	802AA8A4823E
1036	3	F09FC2502328	F09FC2502328	1	F09FC2502328
1043	3	F09FC2502261	F09FC2502261	1	F09FC2502261
1052	5	802AA8A4C90E	802AA8A4C90E	1	802AA8A4C90E
1054	5	802AA8A4CA15	802AA8A4CA15	1	802AA8A4CA15
1067	3	802AA824ED6B	802AA824ED6B	1	802AA824ED6B
1071	5	802AA8A4C351	802AA8A4C351	1	802AA8A4C351
1072	5	802AA8A4C311	802AA8A4C311	1	802AA8A4C311
1074	3	802AA864508B	802AA864508B	1	802AA864508B
1078	3	F09FC25042FF	F09FC25042FF	1	F09FC25042FF
1080	5	802AA8A4C2D6	802AA8A4C2D6	1	802AA8A4C2D6
1087	5	802AA8A4C1F9	802AA8A4C1F9	1	802AA8A4C1F9
1088	1	F09FC246E0CC	F09FC246E0CC	1	F09FC246E0CC
1051	6	68725166C311	68725166C311	1	68725166C311
1053	50	AM1313	AM1313	1	AM1313
1055	6	68725166C72D	68725166C72D	1	68725166C72D
1056	50	AM1314	AM1314	1	AM1314
1076	5	802AA8A4C15B	802AA8A4C15B	1	802AA8A4C15B
1077	16	6872515E2824	6872515E2824	2	6872515E2824
1060	3	802AA824F67A	802AA824F67A	1	802AA824F67A
1062	54	ant2613	ant2613	1	ant2613
1058	6	68725148522F	68725148522F	3	68725148522F
1061	14	00272298BEE8	00272298BEE8	3	00272298BEE8
1059	50	AM1315	AM1315	3	AM1315
1064	11	68725164A9E1	68725164A9E1	2	68725164A9E1
1066	48	ant15062	ant15062	3	ant15062
1065	54	ant2614	ant2614	1	ant2614
1068	6	68725166C732	68725166C732	1	68725166C732
1069	50	AM1316	AM1316	1	AM1316
1070	22	802AA88D561D	802AA88D561D	1	802AA88D561D
1075	16	6872515E2976	6872515E2976	2	6872515E2976
1079	21	44D9E7A22261	44D9E7A22261	2	44D9E7A22261
1081	6	68725166C027	68725166C027	1	68725166C027
1082	50	AM1317	AM1317	3	AM1317
1083	22	802AA8F19AB9	802AA8F19AB9	1	802AA8F19AB9
1084	6	68725166C506	68725166C506	1	68725166C506
1085	50	AM1318	AM1318	1	AM1318
1089	13	002722E6ED02	002722E6ED02	3	002722E6ED02
1091	11	687251668873	687251668873	1	687251668873
1093	15	6872515C36E3	6872515C36E3	1	6872515C36E3
1090	41	T11308003222	T11308003222	3	T11308003222
1094	6	687251203699	687251203699	3	687251203699
1092	48	ant15063	ant15063	3	ant15063
1095	53	RD2401	RD2401	3	RD2401
1097	15	6872515C1B9F	6872515C1B9F	1	6872515C1B9F
1098	11	24A43C9E122E	24A43C9E122E	3	24A43C9E122E
1100	15	6872515C37AC	6872515C37AC	1	6872515C37AC
1099	44	ant24081	ant24081	3	ant24081
1101	22	802AA8F19A7F	802AA8F19A7F	1	802AA8F19A7F
1103	48	ant15064	ant15064	3	ant15064
1049	15	6872515C34BA	6872515C34BA	2	6872515C34BA
997	11	687251668A1D	687251668A1D	1	687251668A1D
998	48	ant15052	ant15052	3	ant15052
1025	22	802AA8F1A710	802AA8F1A710	1	802AA8F1A710
1026	6	68725140CABF	68725140CABF	3	68725140CABF
1000	11	6872514A4950	6872514A4950	3	6872514A4950
1003	14	0027223212AE	0027223212AE	3	0027223212AE
1001	48	ant15053	ant15053	3	ant15053
1004	54	ant2611	ant2611	1	ant2611
1046	22	802AA8F1AA54	802AA8F1AA54	1	802AA8F1AA54
1047	6	68725166C58C	68725166C58C	1	68725166C58C
1048	50	AM1312	AM1312	3	AM1312
1007	6	68725144124B	68725144124B	3	68725144124B
1009	19	802AA808E8E1	802AA808E8E1	1	802AA808E8E1
1008	50	AM1309	AM1309	1	AM1309
1013	11	6872514A4976	6872514A4976	3	6872514A4976
1014	48	ant15054	ant15054	3	ant15054
1018	48	ant15056	ant15056	3	ant15056
1020	11	6872514A4A07	6872514A4A07	3	6872514A4A07
1021	48	ant15057	ant15057	3	ant15057
1022	14	DC9FDB3251BC	DC9FDB3251BC	3	DC9FDB3251BC
1023	48	ant15058	ant15058	3	ant15058
1024	54	ant2612	ant2612	1	ant2612
1031	6	68725166C499	68725166C499	1	68725166C499
1032	50	AM1310	AM1310	1	AM1310
1033	13	DC9FDB5221B0	DC9FDB5221B0	3	DC9FDB5221B0
1034	48	ant15059	ant15059	3	ant15059
1035	22	802AA8F19E6B	802AA8F19E6B	1	802AA8F19E6B
1037	6	687251441301	687251441301	3	687251441301
1038	50	AM1311	AM1311	3	AM1311
1040	45	ant24080	ant24080	3	ant24080
1042	28	708105926a22	708105926a22	3	708105926a22
1041	48	ant15060	ant15060	3	ant15060
1044	6	68725166C5DB	68725166C5DB	1	68725166C5DB
1045	51	AM1505	AM1505	1	AM1505
1105	6	68725166C58D	68725166C58D	1	68725166C58D
1106	50	AM1319	AM1319	3	AM1319
1119	5	802AA8A48538	802AA8A48538	1	802AA8A48538
1120	3	F09FC2502351	F09FC2502351	1	F09FC2502351
1124	3	F09FC25022AD	F09FC25022AD	1	F09FC25022AD
1137	3	802AA8240C53	802AA8240C53	1	802AA8240C53
1138	4	802AA8244E85	802AA8244E85	1	802AA8244E85
1139	3	F09FC25043A0	F09FC25043A0	1	F09FC25043A0
1142	1	F09FC246E50B	F09FC246E50B	1	F09FC246E50B
1143	3	802AA824EEC3	802AA824EEC3	1	802AA824EEC3
1146	3	F09FC2504224	F09FC2504224	1	F09FC2504224
1149	4	802AA8244EA6	802AA8244EA6	1	802AA8244EA6
189	23	802AA81F51D1	802AA81F51D1	1	802AA81F51D1
1155	3	802AA824B658	802AA824B658	1	802AA824B658
1156	1	F09FC246E1E3	F09FC246E1E3	1	F09FC246E1E3
1158	3	F09FC250418F	F09FC250418F	1	F09FC250418F
1164	1	F09FC246E49E	F09FC246E49E	1	F09FC246E49E
1165	3	802AA8645197	802AA8645197	1	802AA8645197
1168	3	802AA824B65A	802AA824B65A	1	802AA824B65A
1174	11	68725164A9E5	68725164A9E5	2	68725164A9E5
1172	3	802AA824EF20	802AA824EF20	1	802AA824EF20
1173	3	F09FC250431C	F09FC250431C	1	F09FC250431C
1177	3	F09FC25022D7	F09FC25022D7	1	F09FC25022D7
1178	3	F09FC25023ED	F09FC25023ED	1	F09FC25023ED
1179	3	F09FC2502429	F09FC2502429	1	F09FC2502429
1182	3	F09FC250241E	F09FC250241E	1	F09FC250241E
1188	3	F09FC25042C0	F09FC25042C0	1	F09FC25042C0
1189	3	F09FC2504166	F09FC2504166	1	F09FC2504166
1166	24	Cisco 1310	Cisco 1310	3	
1196	3	802AA824EEAB	802AA824EEAB	1	802AA824EEAB
1199	3	F09FC250418E	F09FC250418E	1	F09FC250418E
1198	19	DC9FDB6E3D54	DC9FDB6E3D54	4	DC9FDB6E3D54
1205	5	802AA8A4C170	802AA8A4C170	1	802AA8A4C170
1207	3	802AA824EE9D	802AA824EE9D	1	802AA824EE9D
1212	3	802AA824ED95	802AA824ED95	1	802AA824ED95
1215	3	F09FC2504274	F09FC2504274	1	F09FC2504274
1121	5	802AA8A483AC	802AA8A483AC	1	802AA8A483AC
1157	29	71A306B44979	71A306B44979	4	6C3B6BD75BBD
1108	48	ant15065	ant15065	3	ant15065
1109	22	802AA88D552C	802AA88D552C	1	802AA88D552C
1110	6	68725166C608	68725166C608	1	68725166C608
1111	50	AM1320	AM1320	3	AM1320
1112	11	6872512264AD	6872512264AD	3	6872512264AD
1113	48	ant15066	ant15066	3	ant15066
1114	23	802AA81F5286	802AA81F5286	1	802AA81F5286
1116	6	68725166C51A	68725166C51A	1	68725166C51A
1118	51	AM1507	AM1507	1	AM1507
1117	51	AM1506	AM1506	1	AM1506
1123	50	AM1321	AM1321	1	AM1321
1125	11	68725120DD9B	68725120DD9B	3	68725120DD9B
1126	45	ant24082	ant24082	3	ant24082
1129	11	24A43CA62E68	24A43CA62E68	3	24A43CA62E68
1130	48	ant15067	ant15067	3	ant15067
1128	45	ant24083	ant24083	3	ant24083
1131	22	802AA8F1A5AD	802AA8F1A5AD	1	802AA8F1A5AD
1132	22	802AA8F1A5BC	802AA8F1A5BC	1	802AA8F1A5BC
1133	6	687251441311	687251441311	3	687251441311
1140	11	24A43CA62C5E	24A43CA62C5E	3	24A43CA62C5E
1141	45	ant24084	ant24084	3	ant24084
1136	51	AM1508	AM1508	1	AM1508
1147	6	68725140C9F0	68725140C9F0	3	68725140C9F0
1148	50	AM1322	AM1322	1	AM1322
1150	11	687251226917	687251226917	3	687251226917
1154	19	44D9E7CA0FE3	44D9E7CA0FE3	4	44D9E7CA0FE3
1153	45	ant24085	ant24085	3	ant24085
1151	48	ant15069	ant15069	3	ant15069
1159	6	68725166C365	68725166C365	1	68725166C365
1160	50	AM1323	AM1323	1	AM1323
1161	22	802AA8F1A5BD	802AA8F1A5BD	1	802AA8F1A5BD
1167	48	ant15070	ant15070	3	ant15070
1163	51	AM1509	AM1509	1	AM1509
1169	11	6872514A49C1	6872514A49C1	3	6872514A49C1
1170	48	ant15071	ant15071	3	ant15071
1171	22	802AA8F1A67B	802AA8F1A67B	1	802AA8F1A67B
1175	48	ant15072	ant15072	3	ant15072
1180	11	DC9FDB5005A1	DC9FDB5005A1	3	DC9FDB5005A1
1181	48	ant15073	ant15073	3	ant15073
1183	13	002722E6ECEB	002722E6ECEB	3	002722E6ECEB
1184	48	ant15074	ant15074	3	ant15074
1185	22	802AA8F1A58C	802AA8F1A58C	1	802AA8F1A58C
1187	19	DC9FDB42B916	DC9FDB42B916	4	DC9FDB42B916
1190	11	68725164A97E	68725164A97E	2	68725164A97E
1191	48	ant15075	ant15075	3	ant15075
1192	22	802AA8F1A68F	802AA8F1A68F	1	802AA8F1A68F
1193	6	68725166C497	68725166C497	1	68725166C497
1195	13	DC9FDBA67A0F	DC9FDBA67A0F	3	DC9FDBA67A0F
1197	45	ant24086	ant24086	3	ant24086
1200	11	68725164A9B7	68725164A9B7	2	68725164A9B7
1201	48	ant15076	ant15076	3	ant15076
1202	22	802AA88D5622	802AA88D5622	1	802AA88D5622
1203	6	68725166C58B	68725166C58B	1	68725166C58B
1204	51	AM1511	AM1511	3	AM1511
1213	13	002722EE8057	002722EE8057	3	002722EE8057
1214	48	ant15077	ant15077	3	ant15077
1216	11	68725120E077	68725120E077	3	68725120E077
1144	11	6872514A495C	6872514A495C	3	6872514A495C
1145	48	ant15068	ant15068	3	ant15068
1218	5	802AA8A4C175	802AA8A4C175	1	802AA8A4C175
1221	1	F09FC246ED32	F09FC246ED32	1	F09FC246ED32
1225	3	F09FC25023CA	F09FC25023CA	1	F09FC25023CA
1227	3	F09FC250441A	F09FC250441A	1	F09FC250441A
1235	3	802AA824F680	802AA824F680	1	802AA824F680
1236	3	802AA824ED16	802AA824ED16	1	802AA824ED16
1237	3	F09FC2504227	F09FC2504227	1	F09FC2504227
1239	3	F09FC25042E8	F09FC25042E8	1	F09FC25042E8
1242	3	F09FC25042F0	F09FC25042F0	1	F09FC25042F0
1244	3	F09FC250426A	F09FC250426A	1	F09FC250426A
1217	48	ant15078	ant15078	3	ant15078
1279	3	F09FC250440B	F09FC250440B	1	F09FC250440B
1280	5	802AA8A4C389	802AA8A4C389	1	802AA8A4C389
1283	3	F09FC25022E4	F09FC25022E4	1	F09FC25022E4
1285	45	ant24089	ant24089	3	ant24089
1286	3	F09FC25023F1	F09FC25023F1	1	F09FC25023F1
1288	48	ant15082	ant15082	3	ant15082
1290	3	F09FC250221F	F09FC250221F	1	F09FC250221F
1293	5	802AA8A4CA46	802AA8A4CA46	1	802AA8A4CA46
1300	6	68725120339F	68725120339F	3	68725120339F
1259	1	F09FC246E824	F09FC246E824	1	F09FC246E824
1318	3	F09FC2504397	F09FC2504397	1	F09FC2504397
1272	15	6872515C1E9C	6872515C1E9C	2	6872515C1E9C
1269	1	F09FC246E2C3	F09FC246E2C3	1	F09FC246E2C3
1304	1	F09FC246E379	F09FC246E379	1	F09FC246E379
1274	15	24A43C747345	24A43C747345	3	24A43C747345
978	23	802AA81F54E3	802AA81F54E3	1	802AA81F54E3
1275	28	FTX1538B0SE	FTX1538B0SE	3	708105927012
1301	50	AM1327	AM1327	3	AM1327
1276	45	ant24090	ant24090	3	ant24090
1303	13	002722EE7F88	002722EE7F88	1	002722EE7F88
1311	3	F09FC25023DD	F09FC25023DD	1	F09FC25023DD
1312	3	F09FC250230E	F09FC250230E	1	F09FC250230E
1315	3	F09FC2502306	F09FC2502306	1	F09FC2502306
1321	3	F09FC250247B	F09FC250247B	1	F09FC250247B
1322	3	F09FC25023E6	F09FC25023E6	1	F09FC25023E6
1326	3	F09FC2502402	F09FC2502402	1	F09FC2502402
1328	5	802AA8A4CAEF	802AA8A4CAEF	1	802AA8A4CAEF
1332	3	F09FC250418B	F09FC250418B	1	F09FC250418B
1306	58	5G3102	5G3102	1	5G3102
1305	1	F09FC246E1BD	F09FC246E1BD	1	F09FC246E1BD
1027	50	AM1326	AM1326	1	AM1326
1219	6	68725166C4BF	68725166C4BF	1	68725166C4BF
1220	50	AM1324	AM1324	1	AM1324
1222	13	DC9FDBA67E81	DC9FDBA67E81	1	DC9FDBA67E81
1223	45	ant24087	ant24087	3	ant24087
1224	22	802AA8F1A65E	802AA8F1A65E	1	802AA8F1A65E
1226	15	68725124B0FA	68725124B0FA	3	68725124B0FA
1229	51	AM1512	AM1512	3	AM1512
1232	22	802AA8F1A68E	802AA8F1A68E	1	802AA8F1A68E
1233	6	68725166C36C	68725166C36C	1	68725166C36C
1234	50	AM1325	AM1325	3	AM1325
1230	11	68725120DD75	68725120DD75	3	68725120DD75
1231	45	ant24088	ant24088	3	ant24088
1240	11	68725164A969	68725164A969	2	68725164A969
1243	17	802AA86AEEDB	802AA86AEEDB	2	802AA86AEEDB
1241	48	ant15079	ant15079	3	ant15079
1260	11	68725164A9E0	68725164A9E0	2	68725164A9E0
1263	11	6872516688A9	6872516688A9	1	6872516688A9
1261	48	ant15080	ant15080	3	ant15080
1264	11	687251668875	687251668875	1	687251668875
1267	6	68725166C670	68725166C670	1	68725166C670
1268	51	AM1513	AM1513	3	AM1513
1270	22	802AA8F1AA05	802AA8F1AA05	1	802AA8F1AA05
1271	10	0418D6F4760E	0418D6F4760E	1	0418D6F4760E
1281	6	68725166C2EF	68725166C2EF	1	68725166C2EF
1278	56	AM5G2003	AM5G2003	1	AM5G2003
1282	51	AM1514	AM1514	3	AM1514
1287	11	68725166893F	68725166893F	1	68725166893F
1289	22	802AA8F1A45D	802AA8F1A45D	1	802AA8F1A45D
1291	6	68725166C330	68725166C330	1	68725166C330
1292	50	ant15083	ant15083	1	ant15083
1294	11	6872516688F5	6872516688F5	1	6872516688F5
1295	48	ant15084	ant15084	3	ant15084
1296	22	802AA8F1AA26	802AA8F1AA26	1	802AA8F1AA26
1297	11	6872514A49EF	6872514A49EF	3	6872514A49EF
1298	48	ant15085	ant15085	3	ant15085
1299	22	802AA8F1A662	802AA8F1A662	1	802AA8F1A662
1307	22	802AA8F1A5B6	802AA8F1A5B6	1	802AA8F1A5B6
1308	6	68725140CA4C	68725140CA4C	3	68725140CA4C
1309	50	AM1328	AM1328	3	AM1328
1313	6	6872514412CE	6872514412CE	3	6872514412CE
1310	22	802AA8F1A5A9	802AA8F1A5A9	1	802AA8F1A5A9
1314	50	AM1329	AM1329	1	AM1329
1316	11	68725164A94F	68725164A94F	2	68725164A94F
1317	48	ant15086	ant15086	3	ant15086
1319	11	68725164A94D	68725164A94D	2	68725164A94D
1320	48	ant15087	ant15087	3	ant15087
1324	48	ant15088	ant15088	3	ant15088
1325	48	ant15089	ant15089	3	ant15089
1327	11	687251668A21	687251668A21	1	687251668A21
1329	11	6872514A4A16	6872514A4A16	3	6872514A4A16
1330	48	ant15090	ant15090	3	ant15090
1331	22	802AA8F19A1B	802AA8F19A1B	1	802AA8F19A1B
1302	22	802AA8F1A6C0	802AA8F1A6C0	1	802AA8F1A6C0
1333	3	F09FC25041B0	F09FC25041B0	1	F09FC25041B0
1341	4	802AA864C396	802AA864C396	1	802AA864C396
1342	4	802AA8244DBC	802AA8244DBC	1	802AA8244DBC
1343	1	F09FC246E8A0	F09FC246E8A0	1	F09FC246E8A0
1345	4	802AA864C320	802AA864C320	1	802AA864C320
1348	4	802AA8244D22	802AA8244D22	1	802AA8244D22
1356	19	44D9E7CAF67E	44D9E7CAF67E	2	44D9E7CAF67E
1358	1	F09FC246E3EE	F09FC246E3EE	5	F09FC246E3EE
1421	29	71B90652E941	71B90652E941	5	6C3B6BAE8303
1422	1	F09FC246E57F	F09FC246E57F	1	F09FC246E57F
1273	15	24A43C74B571	24A43C74B571	3	24A43C74B571
1400	28	FTX1538B0CX	FTX1538B0CX	3	
1424	29	71a3061b7425/652	71a3061b7425/652	5	6c3b6bda0a22
1369	3	F09FC25023FC	F09FC25023FC	1	F09FC25023FC
1370	4	802AA82487A9	802AA82487A9	1	802AA82487A9
1373	4	802AA8248FB9	802AA8248FB9	1	802AA8248FB9
1379	3	F09FC2502234	F09FC2502234	1	F09FC2502234
1380	3	F09FC2502352	F09FC2502352	1	F09FC2502352
1383	3	F09FC2502326	F09FC2502326	1	F09FC2502326
1388	50	AM1330	AM1330	1	AM1330
1420	1	F09FC246E98F	F09FC246E98F	1	F09FC246E98F
1418	15	6872514a2d42	6872514a2d42	3	6872514a2d42
1406	45	ant24095	ant24095	3	ant24095
1404	48	ant15101	ant15101	3	ant15101
1392	1	802AA8BC253D	802AA8BC253D	5	802AA8BC253D
1393	29	71A3064CEC13	71A3064CEC13	5	6C3B6BD59124
1394	28	FTX1539B00U	FTX1539B00U	3	
1395	45	ant24092	ant24092	3	ant24092
1396	28	FTX15398026	FTX15398026	3	
1423	1	F09FC246E503	F09FC246E503	1	F09FC246E503
1419	1	f09fc246e563	f09fc246e563	1	f09fc246e563
1401	45	ant24094	ant24094	3	
1355	19	44D9E7CAFB91	44D9E7CAFB91	2	44D9E7CAFB91
1412	11	24A43CA62ECC	24A43CA62ECC	3	
1346	13	DC9FDB522189	DC9FDB522189	3	DC9FDB522189
1405	28	FTX1538B0V5	FTX1538B0V5	3	
1415	45	ant24093	ant24093	3	
1407	45	ant24096	ant24096	3	
1409	24	ftx1245u0th	ftx1245u0th	3	ftx1245u0th
1410	11	24A43CA4E52F	24A43CA4E52F	3	24A43CA4E52F
1416	45	ant24098	ant24098	3	
1411	11	687251226566	687251226566	3	
1413	28	ftx1539b02v	ftx1539b02v	3	
1414	45	ant24097	ant24097	3	
1402	24	FTX1539U089	FTX1539U089	3	7081053a7a20
1432	19	44D9E7CAF975	44D9E7CAF975	2	
1425	13	002722ee7e9a	002722ee7e9a	5	002722ee7e9a
1426	45	ant24099	ant24099	3	ant24099
1427	29	71a306a62f76	71a306a62f76	5	6c3b6bdc5fb3
1403	1	802AA8F878E2	802AA8F878E2	1	
1440	11	24A43CA6269E	24A43CA6269E	3	24A43CA6269E
1428	45	ant24013	ant24013	3	
1430	48	ant15001	ant15001	1	
1431	19	44D9E7CAF566	44D9E7CAF566	2	
1433	19	44D9E7CAF959	44D9E7CAF959	2	
1434	28	FTX1537B07X	FTX1537B07X	3	70810592704C
1435	45	ant24100	ant24100	3	
1386	51	AM1517	AM1517	1	AM1517
1357	29	71A30625CC0D	71A30625CC0D	4	71A30625CC0D
1417	48	ant15102	ant15102	3	ant15102
1437	45	ant24101	ant24101	3	
1438	28	FTX1537B07H	FTX1537B07H	3	7081059270CE
1359	29	71A306499663	71A306499663	4	6C3B6BDC6373
1436	11	24A43CA631D0	24A43CA631D0	3	24A43CA631D0
1347	48	ant15092	ant15092	3	ant15092
1334	13	DC9FDB5005FC	DC9FDB5005FC	3	DC9FDB5005FC
1335	48	ant15091	ant15091	3	ant15091
1336	23	802AA81F51CC	802AA81F51CC	1	802AA81F51CC
1337	7	687251207170	687251207170	1	687251207170
1339	7	687251207038	687251207038	1	687251207038
1344	19	802AA806D283	802AA806D283	1	802AA806D283
1340	51	AM1516	AM1516	1	AM1516
1338	51	AM1515	AM1515	1	AM1515
1349	13	002722EE7FDE	002722EE7FDE	1	002722EE7FDE
1350	48	ant15093	ant15093	3	ant15093
1360	13	002722E6ECB8	002722E6ECB8	3	002722E6ECB8
1361	45	ant24091	ant24091	3	ant24091
1362	48	ant15094	ant15094	3	ant15094
1363	13	002722E6EC2D	002722E6EC2D	3	002722E6EC2D
1364	48	ant15095	ant15095	3	ant15095
1365	19	802AA808E874	802AA808E874	1	802AA808E874
1366	13	DC9FDBA67DE3	DC9FDBA67DE3	3	DC9FDBA67DE3
1367	48	ant15096	ant15096	3	ant15096
1368	22	802AA8F1AAC7	802AA8F1AAC7	1	802AA8F1AAC7
1387	6	6872514412F1	6872514412F1	3	6872514412F1
1372	48	ant15097	ant15097	3	ant15097
1374	11	68725164A9C5	68725164A9C5	2	68725164A9C5
1375	48	ant15098	ant15098	3	ant15098
1376	22	802AA8F19AA2	802AA8F19AA2	1	802AA8F19AA2
1377	6	6872514412F0	6872514412F0	3	6872514412F0
1378	50	AM1331	AM1331	1	AM1331
1381	11	68725164A94C	68725164A94C	2	68725164A94C
1382	48	ant15099	ant15099	3	ant15099
1385	48	ant15100	ant15100	3	ant15100
1384	11	24A43CA631E8	24A43CA631E8	3	24A43CA631E8
1397	28	FTX153880VD	FTX153880VD	3	7081059272ec
1429	19	44D9E7CAF565	44D9E7CAF565	2	44D9E7CAF565
1441	45	ant24103	ant24103	3	
1442	45	ant24102	ant24102	3	
1443	32	2157764002020	2157764002020	1	2157764002020
1444	22	802AA88D561B	802AA88D561B	1	802AA88D561B
1445	5	802AA8A485AB	802AA8A485AB	1	802AA8A485AB
931	11	24A43CF89D95	24A43CF89D95	3	24A43CF89D95
1493	32	28505	28505	3	
1050	22	802AA84CD713	802AA84CD713	1	802AA84CD713
1057	22	802AA88D5538	802AA88D5538	1	802AA88D5538
1063	14	00272232129E	00272232129E	3	00272232129E
1073	19	DC9FDB4CB8C3	DC9FDB4CB8C3	4	DC9FDB4CB8C3
1086	22	802AA88D62BF	802AA88D62BF	1	802AA88D62BF
1096	16	6872515E2873	6872515E2873	2	6872515E2873
982	10	0418D6F6E1FE	0418D6F6E1FE	1	0418D6F6E1FE
1448	23	802AA81F5373	802AA81F5373	1	802AA81F5373
999	22	802AA8F1A676	802AA8F1A676	1	802AA8F1A676
1450	6	68725166C6E5	68725166C6E5	1	68725166C6E5
1005	23	802AA81F55E3	802AA81F55E3	1	802AA81F55E3
1451	51	UN-A-15-K-027	UN-A-15-K-027	3	UN-A-15-K-027
1452	48	UN-AO15-K-076	UN-AO15-K-076	3	UN-AO15-K-076
1454	12	687251229420	687251229420	3	687251229420
1017	11	6872514A48EE	6872514A48EE	3	6872514A48EE
1028	22	802AA88D565E	802AA88D565E	1	802AA88D565E
1039	11	6872514A49F7	6872514A49F7	3	6872514A49F7
1480	10	0418d6f4768f	0418d6f4768f	1	0418d6f4768f
1456	24	FTX1549U04C	FTX1549U04C	3	649ef30103c6
1469	13	DC9FDB50066A	DC9FDB50066A	3	DC9FDB50066A
937	6	68725166C3ED	68725166C3ED	1	68725166C3ED
1471	41	t11250000019	t11250000019	3	b89bc9f37fb8
949	22	802AA84CDC91	802AA84CDC91	1	802AA84CDC91
957	19	802AA808ECDB	802AA808ECDB	1	802AA808ECDB
1104	22	802AA88D61BA	802AA88D61BA	1	802AA88D61BA
1473	45	UN-A24-K-030	UN-A24-K-030	3	UN-A24-K-030
1107	24	649ef3010492	649ef3010492	3	649ef3010492
1115	6	68725166C2ED	68725166C2ED	1	68725166C2ED
1127	11	68725120DE79	68725120DE79	3	68725120DE79
1134	6	68725140C90B	68725140C90B	3	68725140C90B
1152	13	DC9FDB500605	DC9FDB500605	3	DC9FDB500605
1505	48	UN-AO15-K-078	UN-AO15-K-078	3	
1464	45	UN-A24-K-031	UN-A24-K-031	3	UN-A24-K-031
1474	45	UN-A24-K-029	UN-A24-K-029	3	UN-A24-K-029
1449	24	FTX1549U04A	FTX1549U04A	3	649ef30105ea
1475	45	UN-A24-K-028	UN-A24-K-028	3	UN-A24-K-028
1476	45	UN-A24-K-027	UN-A24-K-027	3	UN-A24-K-027
1162	6	68725144122F	68725144122F	3	68725144122F
1479	53	UN-RD2G24-K-021	UN-RD2G24-K-021	3	UN-RD2G24-K-021
1176	22	802AA8F1A4D3	802AA8F1A4D3	1	802AA8F1A4D3
1478	45	UN-A24-K-026	UN-A24-K-026	3	UN-A24-K-026
1468	6	68725128401E	68725128401E	3	68725128401E
1492	6	68725128401F	68725128401F	3	68725128401F
1472	48	UN-AO15-K-077	UN-AO15-K-077	3	UN-AO15-K-077
1470	13	DC9FDB50066B	DC9FDB50066B	3	DC9FDB50066B
1481	58	RD5G3103	RD5G3103	1	
965	131	802AA83CD2BD	802AA83CD2BD	2	802AA83CD2BD
1483	58	RD5G3104	RD5G3104	1	
1503	24	FTX1549405M	FTX1549405M	3	649ef3010466
1485	29	71b9062cbfd2	71b9062cbfd2	4	6c3b6bae8322
1486	42	E2423010343000872	E2423010343000872	3	
1502	45	UN-A24-K-032	UN-A24-K-032	3	
1487	11	68725120E078	68725120E078	3	68725120E078
1488	45	ant24104	ant24104	3	
1489	29	71A306D26E0D	71A306D26E0D	4	6C3B6BDA1946
889	22	802AA88D5604	802AA88D5604	1	802AA88D5604
904	16	6872515E2790	6872515E2790	2	6872515E2790
563	13	DC9FDB5005DE	DC9FDB5005DE	3	DC9FDB5005DE
917	13	DC9FDB50062D	DC9FDB50062D	1	DC9FDB50062D
1186	19	DC9FDB42B842	DC9FDB42B842	4	DC9FDB42B842
1194	51	AM1510	AM1510	3	AM1510
1206	3	F09FC2504315	F09FC2504315	1	F09FC2504315
1228	6	68725166C51E	68725166C51E	1	68725166C51E
1238	11	 68725164A9E9	 68725164A9E9	2	 68725164A9E9
1265	48	ant15081	ant15081	3	ant15081
1284	11	68725166887B	68725166887B	1	68725166887B
1323	11	6872512268F5	6872512268F5	3	6872512268F5
1371	11	68725164A8CA	68725164A8CA	2	68725164A8CA
1490	41	T11308003211	T11308003211	3	T11308003211
1491	1	0418D68A33E7	0418D68A33E7	3	0418D68A33E7
1494	6	687251284089	687251284089	3	687251284089
1495	53	UN-RD2G24-K-022	UN-RD2G24-K-022	3	UN-RD2G24-K-022
1496	6	68725140C9E1	68725140C9E1	3	68725140C9E1
1498	50	UN-A-13-K-017	UN-A-13-K-017	3	UN-A-13-K-017
1499	6	6872512840BC	6872512840BC	3	6872512840BC
1497	51	UN-A-15-K-028	UN-A-15-K-028	3	
1500	13	002722E6ED79	002722E6ED79	3	002722E6ED79
1506	45	UN-A24-K-033	UN-A24-K-033	3	UN-A24-K-033
1484	6	68725166c02d	68725166c02d	1	68725166c02d
1504	24	FTX1539U08D	FTX1539U08D	3	7081053a7970
141	22	802AA8F1A570	802AA8F1A570	1	802AA8F1A570
1501	53	rd2a05515	rd2a05515	3	
1277	3	802AA824ED1D	802AA824ED1D	1	802AA824ED1D
1482	10	0418d6f6e187	0418d6f6e187	1	0418d6f6e187
1460	24	ftx15494u06a	ftx15494u06a	3	649ef301063e
1453	25	FHK02722K4CP	FHK02722K4CP	3	000d2908e5eb
1102	28	ftx1538b0x6	ftx1538b0x6	3	70810592714c
1514	48	UN-AO15-K-080	UN-AO15-K-080	3	
1515	11	68725164AAA7	68725164AAA7	2	68725164AAA7
1516	45	UN-A24-K-039	UN-A24-K-039	3	
1518	48	UN-AO15-K-081	UN-AO15-K-081	3	
1521	24	FTX1539U086	FTX1539U086	3	7081053a7956
1508	49	UN-A15-K-003	UN-A15-K-003	3	UN-A15-K-003
1522	48	UN-AO15-K-082	UN-AO15-K-082	3	
1529	48	UN-AO15-K-079	UN-AO15-K-079	3	UN-AO15-K-079
1531	32	UN-S-K-053	UN-S-K-053	3	UN-S-K-053
1533	28	UN-C1242-K-006	UN-C1242-K-006	3	UN-C1242-K-006
1534	11	24A43CA631BD	24A43CA631BD	3	24A43CA631BD
1536	45	UN-A24-K-043	UN-A24-K-043	3	UN-A24-K-043
1539	22	802AA88D5623	802AA88D5623	1	802AA88D5623
1540	6	68725140C9F1	68725140C9F1	3	68725140C9F1
1541	50	UN-A-13-K-018	UN-A-13-K-018	3	UN-A-13-K-018
1548	6	6872514412DD	6872514412DD	3	6872514412DD
1550	50	UN-A-13-K-019	UN-A-13-K-019	3	
1545	48	UN-AO15-K-086	UN-AO15-K-086	3	UN-AO15-K-086
1517	24	649ef3010462	649ef3010462	3	649ef3010462
1554	48	UN-AO15-K-087	UN-AO15-K-087	3	
1556	58	UN-RD5G31-H-003	UN-RD5G31-H-003	1	UN-RD5G31-H-003
1560	58	UN-RD5G31-H-004	UN-RD5G31-H-004	1	
1561	45	UN-A24-K-047	UN-A24-K-047	3	UN-A24-K-047
1563	48	UN-AO15-K-088	UN-AO15-K-088	3	UN-AO15-K-088
1562	24	FTX1549U045	FTX1549U045	3	649ef3010684
1564	24	649ef30105cc	649ef30105cc	3	649ef30105cc
1565	45	UN-A24-K-050	UN-A24-K-050	3	UN-A24-K-050
1567	24	7081053a7734	7081053a7734	3	7081053a7734
1570	48	UN-AO15-K-093	UN-AO15-K-093	3	UN-AO15-K-093
1571	48	UN-AO15-K-089	UN-AO15-K-089	3	UN-AO15-K-089
1572	32	UN-S-K-056	UN-S-K-056	3	UN-S-K-056
1574	11	687251226567	687251226567	3	687251226567
1575	48	UN-AO15-K-091	UN-AO15-K-091	3	
1577	24	649ef30106a6	649ef30106a6	3	649ef30106a6
1576	22	802AA84CD817	802AA84CD817	1	802AA84CD817
1578	48	UN-AO15-K-092	UN-AO15-K-092	3	
1580	24	649ef301056a	649ef301056a	3	649ef301056a
1579	22	802AA8F1A44E	802AA8F1A44E	1	802AA8F1A44E
1581	45	UN-A24-K-049	UN-A24-K-049	3	
1583	6	68725166C306	68725166C306	1	68725166C306
1584	45	UN-A24-K-052	UN-A24-K-052	3	
1585	51	UN-A-15-K-029	UN-A-15-K-029	3	
1582	11	24a43ca62ef8	24a43ca62ef8	3	24a43ca62ef8
1587	24	7081053a7924	7081053a7924	3	7081053a7924
1589	10	0418D6F4D709	0418D6F4D709	1	0418D6F4D709
1590	45	UN-A24-K-053	UN-A24-K-053	3	
1591	58	UN-RD5G31-H-005	UN-RD5G31-H-005	1	
1592	28	7081059271c6	7081059271c6	3	7081059271c6
1593	45	UN-A24-K-054	UN-A24-K-054	3	
1594	10	0418D6F6E5B7	0418D6F6E5B7	1	0418D6F6E5B7
1595	45	UN-A24-K-055	UN-A24-K-055	3	
1596	58	UN-RD5G31-H-006	UN-RD5G31-H-006	1	
1597	11	68725164A8A2	68725164A8A2	2	68725164A8A2
1598	22	802AA8F1A442	802AA8F1A442	1	
1599	3	F09FC250222A	F09FC250222A	1	F09FC250222A
1600	24	649ef301049c	649ef301049c	3	649ef301049c
1601	48	UN-AO15-K-094	UN-AO15-K-094	3	
1602	48	UN-AO15-K-090	UN-AO15-K-090	3	
1603	32	UN-S-K-057	UN-S-K-057	3	
1604	3	F09FC250234F	F09FC250234F	1	F09FC250234F
1605	24	649ef3010270	649ef3010270	3	649ef3010270
1606	28	003a9a0c1960	003a9a0c1960	3	003a9a0c1960
1544	24	FTX1539U06B	FTX1539U06B	3	7081053a784c
1549	135	0321	UN-S-K-054	3	
1542	24	FTX1539U09D	FTX1539U09D	3	7081053a79a4
1551	11	24A43CA62E3B	24A43CA62E3B	3	24A43CA62E3B
1543	48	UN-AO15-K-085	UN-AO15-K-085	3	UN-AO15-K-085
1553	45	UN-A24-K-044	UN-A24-K-044	3	UN-A24-K-044
1530	24	FTX1539U08L	FTX1539U08L	3	7081053a79e8
1524	28	ftx1537b08x	ftx1537b08x	3	70810592707c
1532	45	UN-A24-K-038	UN-A24-K-038	3	
1527	45	UN-A24-K-037	UN-A24-K-037	3	
1546	11	24A43CA62DC2	24A43CA62DC2	3	24A43CA62DC2
1568	45	UN-A24-K-048	UN-A24-K-048	3	
1569	28	FTX1537B08K	FTX1537B08K	3	708105927108
1511	24	FTX1539U07k	FTX1539U07k	3	7081053a7842
1507	24	FTX1539U076	FTX1539U076	3	7081053a78d4
1526	28	ftx1538b0p4	ftx1538b0p4	3	7081052fc412
1523	28	ftx1538b0nr	ftx1538b0nr	3	708105926f48
1528	45	UN-A24-K-042	UN-A24-K-042	3	
1525	45	UN-A24-K-041	UN-A24-K-041	3	
1512	136	UN-A24-K-036	UN-A24-K-036	3	
1510	45	UN-A24-K-035	UN-A24-K-035	3	
1509	45	UN-A24-K-034	UN-A24-K-034	3	
1519	24	FTX1539U08B	FTX1539U08B	3	7081053a7a1a
1552	24	FTX1549U02V	FTX1549U02V	3	649ef3010254
1520	45	UN-A24-K-040	UN-A24-K-040	3	
1559	28	FTX1537B07E	FTX1537B07E	3	708105927034
1555	24	FTX1549U05L	FTX1549U05L	3	649ef301066a
1566	13	DC9FDB5005F8	DC9FDB5005F8	3	DC9FDB5005F8
1557	45	UN-A24-K-046	UN-A24-K-046	3	
1547	45	UN-A24-K-045	UN-A24-K-045	3	
1513	24	FTX1549U050	FTX1549U050	3	649ef3010678
1586	6	68725166C290	68725166C290	1	68725166C290
1538	49	UN-A15-K-005	UN-A15-K-005	3	
1537	28	FTX1538B0RR	FTX1538B0RR	3	708105926f30
1588	51	AM2A39079	AM2A39079	3	
1607	45	UN-A24-K-056	UN-A24-K-056	3	
1608	45	UN-A24-K-057	UN-A24-K-057	3	
1609	48	UN-AO15-K-095	UN-AO15-K-095	3	UN-AO15-K-095
1610	13	002722e6ed09	002722e6ed09	3	002722e6ed09
1611	45	UN-A24-K-058	UN-A24-K-058	3	
1612	24	649ef3010444	649ef3010444	3	649ef3010444
1613	24	7081053a79fc	7081053a79fc	3	7081053a79fc
1614	48	UN-AO15-K-097	UN-AO15-K-097	3	
1615	24	649ef301045e	649ef301045e	3	649ef301045e
1616	48	UN-AO15-K-096	UN-AO15-K-096	3	UN-AO15-K-096
1617	45	UN-A24-K-059	UN-A24-K-059	3	
1618	28	708105926a26	708105926a26	3	708105926a26
1619	24	7081053a7918	7081053a7918	3	7081053a7918
1620	48	UN-AO15-K-098	UN-AO15-K-098	3	
1621	45	UN-A24-K-060	UN-A24-K-060	3	
1622	24	649ef301067c	649ef301067c	3	649ef301067c
1623	45	UN-A24-K-064	UN-A24-K-064	3	
1625	15	6872515C2E54	6872515C2E54	1	6872515C2E54
1626	24	7081053a7852	7081053a7852	3	7081053a7852
1627	48	UN-AO15-K-099	UN-AO15-K-099	3	
1628	11	6872514A49B6	6872514A49B6	3	6872514A49B6
1629	45	UN-A24-K-063	UN-A24-K-063	3	
1630	11	24A43CA6324E	24A43CA6324E	3	24A43CA6324E
1624	24	649ef30105dc	649ef30105dc	3	649ef30105dc
1631	45	UN-A24-K-051	UN-A24-K-051	3	UN-A24-K-051
1632	32	UN-S-K-058	UN-S-K-058	3	UN-S-K-058
1633	11	24A43C9E1255	24A43C9E1255	3	24A43C9E1255
1634	45	UN-A24-K-065	UN-A24-K-065	3	
1635	24	649ef3010480	649ef3010480	3	649ef3010480
1636	48	UN-AO15-K-100	UN-AO15-K-100	3	
1637	28	708105926fda	708105926fda	3	708105926fda
1638	28	708105927194	708105927194	3	708105927194
1640	45	UN-A24-K-068	UN-A24-K-068	3	
1641	24	7081053a79c8	7081053a79c8	3	7081053a79c8
1642	45	UN-A24-K-067	UN-A24-K-067	3	UN-A24-K-067
1643	45	UN-A24-K-061	UN-A24-K-061	3	
1639	45	UN-A24-K-066	UN-A24-K-066	3	UN-A24-K-066
1644	24	7081053a7862	7081053a7862	3	7081053a7862
1645	45	UN-A24-K-062	UN-A24-K-062	3	
1646	48	UN-AO15-K-101	UN-AO15-K-101	3	UN-AO15-K-101
1647	41	T113080033196	T113080033196	3	T113080033196
1648	6	687251284047	687251284047	3	687251284047
1649	41	T11308003199	T11308003199	3	T11308003199
1650	53	UN-RD2G24-K-002	UN-RD2G24-K-002	3	UN-RD2G24-K-002
1651	6	6872512033DE	6872512033DE	3	6872512033DE
1652	53	UN-RD2G24-K-003	UN-RD2G24-K-003	3	UN-RD2G24-K-003
1653	10	0418D6A4CD99	0418D6A4CD99	2	0418D6A4CD99
1654	10	0418D6A4CC5C	0418D6A4CC5C	2	0418D6A4CC5C
1655	6	6872512035DE	6872512035DE	3	6872512035DE
1656	3	F09FC2502325	F09FC2502325	1	F09FC2502325
1657	51	UN-A-15-K-011	UN-A-15-K-011	3	UN-A-15-K-011
1658	6	687251284118	687251284118	3	687251284118
1659	53	UN-RD2G24-K-004	UN-RD2G24-K-004	3	UN-RD2G24-K-004
1660	6	687251203642	687251203642	3	687251203642
1662	51	UN-A-15-K-010	UN-A-15-K-010	3	
1661	41	T11308003201	T11308003201	3	T11308003201
1663	41	T11218000502	T11218000502	3	T11218000502
1664	3	F09FC2502233	F09FC2502233	1	F09FC2502233
1665	6	687251284048	687251284048	3	687251284048
1666	51	UN-A-15-K-026	UN-A-15-K-026	3	
1667	6	6872512840BE	6872512840BE	3	6872512840BE
1668	41	T11308003215	T11308003215	3	T11308003215
1669	6	6872512841CF	6872512841CF	3	6872512841CF
1670	50	UN-A-13-H-021	UN-A-13-H-021	1	UN-A-13-H-021
1671	53	UN-RD2G24-K-020	UN-RD2G24-K-020	3	UN-RD2G24-K-020
1672	6	68725128408F	68725128408F	3	68725128408F
1673	1	0418D68A31D5	0418D68A31D5	3	0418D68A31D5
1674	51	UN-A-15-K-025	UN-A-15-K-025	3	UN-A-15-K-025
1675	41	T11308003213	T11308003213	3	T11308003213
1676	6	6872512E8189	6872512E8189	3	6872512E8189
1677	41	T11308003197	T11308003197	3	T11308003197
1678	53	UN-RD2G24-K-018	UN-RD2G24-K-018	3	UN-RD2G24-K-018
1679	6	687251284009	687251284009	3	687251284009
1680	1	0418D68A31C1	0418D68A31C1	3	0418D68A31C1
1681	53	UN-RD2G24-K-019	UN-RD2G24-K-019	3	UN-RD2G24-K-019
1682	6	68725128404A	68725128404A	3	68725128404A
1683	6	6872512036A3	6872512036A3	3	6872512036A3
1684	51	UN-A-15-K-024	UN-A-15-K-024	3	UN-A-15-K-024
1685	51	UN-A-15-K-013	UN-A-15-K-013	3	UN-A-15-K-013
1686	41	T11308003210	T11308003210	3	T11308003210
1687	5	802AA8A4C22D	802AA8A4C22D	1	802AA8A4C22D
1688	41	T11308003198	T11308003198	3	T11308003198
1689	6	6872512840A5	6872512840A5	3	6872512840A5
1690	53	UN-RD2G24-K-017	UN-RD2G24-K-017	3	UN-RD2G24-K-017
1691	6	687251284123	687251284123	3	687251284123
1692	6	6872512841D4	6872512841D4	3	6872512841D4
1693	41	T11308003200	T11308003200	3	
1694	53	UN-RD2G24-K-005	UN-RD2G24-K-005	3	UN-RD2G24-K-005
1695	6	687251284070	687251284070	3	687251284070
1696	50	UN-A-13-H-024	UN-A-13-H-024	1	UN-A-13-H-024
1697	53	UN-RD2G24-K-007	UN-RD2G24-K-007	3	
1698	6	6872512840B3	6872512840B3	3	6872512840B3
1699	6	68725128408D	68725128408D	3	68725128408D
1700	41	T11308003203	T11308003203	3	T11308003203
1701	5	802AA8A4C28A	802AA8A4C28A	1	802AA8A4C28A
1702	51	UN-A-15-K-014	UN-A-15-K-014	3	UN-A-15-K-014
1703	51	UN-A-15-K-015	UN-A-15-K-015	3	
1704	5	802AA8A4C36C	802AA8A4C36C	1	802AA8A4C36C
1705	15	24A43C74747E	24A43C74747E	3	24A43C74747E
1706	30	416501A2E9AF	416501A2E9AF	4	416501A2E9AF
1707	41	T11250000020	T11250000020	3	
1708	6	6872512840B4	6872512840B4	3	6872512840B4
1709	6	687251284130	687251284130	3	687251284130
1710	6	6872512840A7	6872512840A7	3	6872512840A7
1711	53	UN-RD2G24-K-016	UN-RD2G24-K-016	3	UN-RD2G24-K-016
1712	53	UN-RD2G24-K-008	UN-RD2G24-K-008	3	
1713	53	UN-RD2G24-K-006	UN-RD2G24-K-006	3	UN-RD2G24-K-006
1714	6	687251284116	687251284116	3	687251284116
1715	6	68725128408E	68725128408E	3	68725128408E
1716	53	UN-RD2G24-K-009	UN-RD2G24-K-009	3	
1717	51	UN-A-15-K-023	UN-A-15-K-023	3	UN-A-15-K-023
1718	6	6872512033E3	6872512033E3	3	6872512033E3
1719	51	UN-A-15-K-016	UN-A-15-K-016	3	
1720	5	802AA8A4CA52	802AA8A4CA52	1	802AA8A4CA52
1721	41	T11308003205	T11308003205	3	T11308003205
1723	41	T11218000510	T11218000510	3	T11218000510
1724	53	UN-RD2G24-K-010	UN-RD2G24-K-010	3	UN-RD2G24-K-010
1725	6	6872512840EB	6872512840EB	3	6872512840EB
1722	6	687251203698	687251203698	3	687251203698
1726	53	UN-RD2G24-K-011	UN-RD2G24-K-011	3	UN-RD2G24-K-011
1727	134	0418D6A4B61E	0418D6A4B61E	2	0418D6A4B61E
1728	53	UN-RD2G24-K-015	UN-RD2G24-K-015	3	UN-RD2G24-K-015
1729	6	68725120347D	68725120347D	3	68725120347D
1730	6	68725128417E	68725128417E	3	68725128417E
1731	51	UN-A-15-K-017	UN-A-15-K-017	3	UN-A-15-K-017
1732	51	UN-A-15-K-022	UN-A-15-K-022	3	UN-A-15-K-022
1733	11	24A43CA62D9B	24A43CA62D9B	3	24A43CA62D9B
1734	41	T11250000016	T11250000016	3	T11250000016
1735	134	0418D6A4B1D2	0418D6A4B1D2	2	0418D6A4B1D2
1736	44	UN-A20-K-002	UN-A20-K-002	3	UN-A20-K-002
1737	6	6872512840B2	6872512840B2	3	6872512840B2
1738	50	UN-A-13-H-023	UN-A-13-H-023	1	UN-A-13-H-023
1739	32	UN-S-K-051	UN-S-K-051	3	UN-S-K-051
1740	30	416501A2E8C8	416501A2E8C8	4	416501A2E8C8
1741	1	0418D68A335F	0418D68A335F	3	0418D68A335F
1742	6	687251284049	687251284049	3	687251284049
1743	1	0418D68A32B2	0418D68A32B2	3	0418D68A32B2
1744	50	UN-A-13-H-022	UN-A-13-H-022	1	UN-A-13-H-022
1745	6	687251284153	687251284153	3	687251284153
1746	41	T11308003206	T11308003206	3	T11308003206
1747	6	687251284020	687251284020	3	687251284020
1748	51	UN-A-15-K-019	UN-A-15-K-019	3	UN-A-15-K-019
1749	53	UN-RD2G24-K-014	UN-RD2G24-K-014	3	UN-RD2G24-K-014
1750	1	0418D68A3307	0418D68A3307	3	0418D68A3307
1751	6	687251284039	687251284039	3	687251284039
1752	51	UN-A-15-K-021	UN-A-15-K-021	3	UN-A-15-K-021
1753	32	UN-S-K-050	UN-S-K-050	3	UN-S-K-050
1754	3	F09FC250221B	F09FC250221B	1	F09FC250221B
1755	6	687251284108	687251284108	3	687251284108
1756	6	687251203628	687251203628	3	687251203628
1757	51	UN-A-15-K-020	UN-A-15-K-020	3	UN-A-15-K-020
1758	50	UN-A-13-K-016	UN-A-13-K-016	3	UN-A-13-K-016
1759	6	6872512033D9	6872512033D9	3	6872512033D9
1760	3	F09FC25022FC	F09FC25022FC	1	F09FC25022FC
1761	53	UN-RD2G24-K-013	UN-RD2G24-K-013	3	UN-RD2G24-K-013
1762	1	0418D68A31F7	0418D68A31F7	3	0418D68A31F7
1763	1	0418D68A3438	0418D68A3438	3	0418D68A3438
1764	1	0418D68A332E	0418D68A332E	3	0418D68A332E
1766	53	UN-RD2G24-K-012	UN-RD2G24-K-012	3	UN-RD2G24-K-012
1767	6	6872512E8641	6872512E8641	3	6872512E8641
1768	6	68725128406C	68725128406C	3	68725128406C
1769	41	b89bc9f52bff	b89bc9f52bff	3	b89bc9f52bff
1770	3	802AA824ED07	802AA824ED07	1	802AA824ED07
1771	6	68725166BF96	68725166BF96	1	68725166BF96
1772	50	UN-A-13-K-011	UN-A-13-K-011	3	UN-A-13-K-011
1774	48	UN-AO15-K-037	UN-AO15-K-037	3	UN-AO15-K-037
1773	24	7081053a7900	7081053a7900	3	7081053a7900
1775	5	802AA8A485FC	802AA8A485FC	1	802AA8A485FC
1776	32	UN-S-K-001	UN-S-K-001	3	UN-S-K-001
1777	11	6872514A498C	6872514A498C	3	6872514A498C
1778	48	UN-AO15-K-038	UN-AO15-K-038	3	UN-AO15-K-038
1779	32	UN-S-K-030	UN-S-K-030	3	UN-S-K-030
1780	34	UN-S-Hnet-001	UN-S-Hnet-001	2	UN-S-Hnet-001
1781	3	F09FC25023E7	F09FC25023E7	1	F09FC25023E7
1782	11	6872514A4A0E	6872514A4A0E	3	6872514A4A0E
1783	32	UN-S-K-002	UN-S-K-002	3	UN-S-K-002
1784	48	UN-AO15-K-039	UN-AO15-K-039	3	UN-AO15-K-039
1785	32	UN-S-K-031	UN-S-K-031	3	UN-S-K-031
1786	37	UN-S-K-003	UN-S-K-003	3	UN-S-K-003
1787	23	802AA81F5195	802AA81F5195	1	802AA81F5195
1788	32	UN-S-K-004	UN-S-K-004	3	UN-S-K-004
1789	5	802AA8A4C219	802AA8A4C219	1	802AA8A4C219
1790	3	F09FC2502405	F09FC2502405	1	F09FC2502405
1791	32	UN-S-K-005	UN-S-K-005	3	UN-S-K-005
1792	6	68725166C0A1	68725166C0A1	1	68725166C0A1
1793	50	UN-A-13-K-012	UN-A-13-K-012	3	UN-A-13-K-012
1794	32	UN-S-K-006	UN-S-K-006	3	UN-S-K-006
1795	24	7081053a797c	7081053a797c	3	7081053a797c
1796	32	UN-S-K-007	UN-S-K-007	3	UN-S-K-007
1797	48	UN-AO15-K-040	UN-AO15-K-040	3	UN-AO15-K-040
1798	32	UN-S-K-008	UN-S-K-008	3	UN-S-K-008
1799	5	802AA8A4C112	802AA8A4C112	1	802AA8A4C112
1800	6	68725166C0D9	68725166C0D9	1	68725166C0D9
1801	50	UN-A-13-K-013	UN-A-13-K-013	3	UN-A-13-K-013
1802	3	F09FC25023E4	F09FC25023E4	1	F09FC25023E4
1803	11	6872516689AD	6872516689AD	1	6872516689AD
1804	32	UN-S-K-009	UN-S-K-009	3	UN-S-K-009
1805	48	UN-AO15-K-041	UN-AO15-K-041	3	UN-AO15-K-041
1806	28	70810592711a	70810592711a	3	70810592711a
1807	45	UN-A24-K-009	UN-A24-K-009	3	UN-A24-K-009
1808	32	UN-S-K-032	UN-S-K-032	3	UN-S-K-032
1809	32	UN-S-K-010	UN-S-K-010	3	UN-S-K-010
1810	22	802AA88D641E	802AA88D641E	1	802AA88D641E
1812	5	802AA8A4C314	802AA8A4C314	1	802AA8A4C314
1813	5	802AA8A48576	802AA8A48576	1	802AA8A48576
1814	32	UN-S-K-012	UN-S-K-012	3	UN-S-K-012
1815	32	UN-S-K-013	UN-S-K-013	3	UN-S-K-013
1816	45	UN-A24-K-010	UN-A24-K-010	3	UN-A24-K-010
1817	32	UN-S-K-014	UN-S-K-014	3	UN-S-K-014
1818	11	687251668870	687251668870	1	687251668870
1819	48	UN-AO15-K-042	UN-AO15-K-042	3	UN-AO15-K-042
1820	32	UN-S-K-015	UN-S-K-015	3	UN-S-K-015
1821	32	UN-S-K-017	UN-S-K-017	3	UN-S-K-017
1822	5	802AA8A4C15C	802AA8A4C15C	1	802AA8A4C15C
1823	32	UN-S-K-018	UN-S-K-018	3	UN-S-K-018
1824	6	68725166C0BC	68725166C0BC	1	68725166C0BC
1826	51	UN-A-15-H-009	UN-A-15-H-009	1	UN-A-15-H-009
1827	32	UN-S-K-020	UN-S-K-020	3	UN-S-K-020
1828	32	UN-S-K-033	UN-S-K-033	3	UN-S-K-033
1829	32	UN-S-K-021	UN-S-K-021	3	UN-S-K-021
1830	22	802AA88D5FA0	802AA88D5FA0	1	802AA88D5FA0
1831	6	68725166C098	68725166C098	1	68725166C098
1832	51	UN-A-15-H-010	UN-A-15-H-010	1	UN-A-15-H-010
1833	32	UN-S-K-022	UN-S-K-022	3	UN-S-K-022
1834	1	F09FC246E10D	F09FC246E10D	1	F09FC246E10D
1835	24	649ef3010672	649ef3010672	3	649ef3010672
1836	48	UN-AO15-K-043	UN-AO15-K-043	3	UN-AO15-K-043
1837	22	802AA88D55DD	802AA88D55DD	1	802AA88D55DD
1838	6	68725166BFA3	68725166BFA3	1	68725166BFA3
1839	32	UN-S-K-036	UN-S-K-036	3	UN-S-K-036
1840	51	UN-A-15-K-003	UN-A-15-K-003	3	UN-A-15-K-003
1841	23	802AA81F5342	802AA81F5342	1	802AA81F5342
1842	6	68725166BFDD	68725166BFDD	1	68725166BFDD
1843	32	UN-S-K-037	UN-S-K-037	3	UN-S-K-037
1844	6	68725166C14A	68725166C14A	1	68725166C14A
1845	6	68725166C537	68725166C537	1	68725166C537
1846	51	UN-A-15-H-011	UN-A-15-H-011	1	UN-A-15-H-011
1847	51	UN-A-15-H-012	UN-A-15-H-012	1	UN-A-15-H-012
1848	51	UN-A-15-H-013	UN-A-15-H-013	1	UN-A-15-H-013
1849	22	UN-S-K-038	UN-S-K-038	3	UN-S-K-038
1850	25	0009b78225c5	0009b78225c5	3	0009b78225c5
1851	48	UN-AO15-K-044	UN-AO15-K-044	3	UN-AO15-K-044
1852	32	UN-S-K-039	UN-S-K-039	3	UN-S-K-039
1853	5	802AA8A485C6	802AA8A485C6	1	802AA8A485C6
1854	5	802AA8A483E2	802AA8A483E2	1	802AA8A483E2
1855	32	UN-S-K-040	UN-S-K-040	3	UN-S-K-040
1857	32	UN-S-K-041	UN-S-K-041	3	UN-S-K-041
1858	51	UN-A-15-H-014	UN-A-15-H-014	1	
1859	22	802AA8F1A9A3	802AA8F1A9A3	1	802AA8F1A9A3
1860	32	UN-S-K-034	UN-S-K-034	3	
1861	32	UN-S-K-042	UN-S-K-042	3	UN-S-K-042
1862	32	UN-S-K-023	UN-S-K-023	3	UN-S-K-023
1864	32	UN-S-K-024	UN-S-K-024	3	UN-S-K-024
1865	32	UN-S-K-025	UN-S-K-025	3	UN-S-K-025
1867	32	UN-S-K-026	UN-S-K-026	3	UN-S-K-026
1868	32	UN-S-K-027	UN-S-K-027	3	UN-S-K-027
1869	28	708105926f84	708105926f84	3	708105926f84
1870	32	UN-S-K-028	UN-S-K-028	3	UN-S-K-028
1871	32	UN-S-K-029	UN-S-K-029	3	UN-S-K-029
1872	48	UN-AO15-K-046	UN-AO15-K-046	3	UN-AO15-K-046
1873	32	UN-S-K-043	UN-S-K-043	3	UN-S-K-043
1874	1	F09FC246E5BB	F09FC246E5BB	1	F09FC246E5BB
1875	32	UN-S-K-044	UN-S-K-044	3	UN-S-K-044
1876	1	F09FC246E961	F09FC246E961	1	F09FC246E961
1877	32	UN-S-K-045	UN-S-K-045	3	UN-S-K-045
1878	32	UN-S-K-016	UN-S-K-016	3	UN-S-K-016
1879	5	802AA8A4CAF0	802AA8A4CAF0	1	802AA8A4CAF0
1880	32	UN-S-K-046	UN-S-K-046	3	UN-S-K-046
1881	6	68725166C5A5	68725166C5A5	1	68725166C5A5
1882	32	UN-S-K-047	UN-S-K-047	3	UN-S-K-047
1883	32	UN-S-K-048	UN-S-K-048	3	UN-S-K-048
1884	51	UN-A-15-K-004	UN-A-15-K-004	3	UN-A-15-K-004
1885	32	UN-S-K-049	UN-S-K-049	3	UN-S-K-049
1886	13	DC9FDB5321DF	DC9FDB5321DF	1	DC9FDB5321DF
1887	30	UN-S-U-002	UN-S-U-002	4	UN-S-U-002
1888	45	UN-A24-K-012	UN-A24-K-012	3	UN-A24-K-012
1890	45	UN-A24-K-013	UN-A24-K-013	3	UN-A24-K-013
1893	32	UN-S-K-035	UN-S-K-035	3	UN-S-K-035
1895	48	UN-AO15-K-047	UN-AO15-K-047	3	UN-AO15-K-047
1896	11	6872514A49C4	6872514A49C4	3	6872514A49C4
1897	45	UN-A24-K-015	UN-A24-K-015	3	UN-A24-K-015
1898	24	7081053a784e	7081053a784e	3	7081053a784e
1899	48	UN-AO15-K-048	UN-AO15-K-048	3	UN-AO15-K-048
1900	22	802AA8F1AA82	802AA8F1AA82	1	802AA8F1AA82
1901	6	68725166C522	68725166C522	1	68725166C522
1902	51	UN-A-15-H-015	UN-A-15-H-015	1	UN-A-15-H-015
1903	1	F09FC246E41D	F09FC246E41D	1	F09FC246E41D
1811	33	11381206780	11381206780	3	
1825	32	11381205318	11381205318	3	
1904	24	649ef3010574	649ef3010574	3	649ef3010574
1905	48	UN-AO15-K-049	UN-AO15-K-049	3	UN-AO15-K-049
1906	24	7081059272d6	7081059272d6	3	7081059272d6
1907	45	UN-A24-K-016	UN-A24-K-016	3	UN-A24-K-016
1908	45	UN-A24-K-017	UN-A24-K-017	3	UN-A24-K-017
1909	22	802AA8F1A9B0	802AA8F1A9B0	1	802AA8F1A9B0
1910	11	687251668983	687251668983	1	687251668983
1911	48	UN-AO15-K-050	UN-AO15-K-050	3	UN-AO15-K-050
1912	28	001794eeebf8	001794eeebf8	3	001794eeebf8
1913	48	UN-AO15-K-051	UN-AO15-K-051	3	UN-AO15-K-051
1914	30	UN-S-U-001	UN-S-U-001	4	UN-S-U-001
1915	22	802AA8F1A469	802AA8F1A469	1	802AA8F1A469
1916	13	002722E6ECED	002722E6ECED	3	002722E6ECED
1973	1	F09FC246E50A	F09FC246E50A	1	F09FC246E50A
1918	22	802AA8F19A34	802AA8F19A34	1	802AA8F19A34
1919	28	UN-C1242-K-003	UN-C1242-K-003	3	UN-C1242-K-003
1920	45	UN-A24-K-020	UN-A24-K-020	3	UN-A24-K-020
1922	45	ant24105	ant24105	3	ant24105
1923	26	UN-C1230-K-001	UN-C1230-K-001	3	UN-C1230-K-001
1924	28	70810592723e	70810592723e	3	70810592723e
1917	45	UN-A24-K-019	UN-A24-K-019	3	UN-A24-K-019
1925	22	802AA8F1A773	802AA8F1A773	1	802AA8F1A773
1926	45	ant24106	ant24106	3	ant24106
1927	28	UN-C1242-K-001	UN-C1242-K-001	3	UN-C1242-K-001
1928	28	UN-C1242-K-004	UN-C1242-K-004	3	UN-C1242-K-004
1929	28	7081059272bc	7081059272bc	3	7081059272bc
1921	48	ant15103	ant15103	3	ant15103
1930	48	ant15104	ant15104	3	ant15104
1932	45	UN-A24-K-008	UN-A24-K-008	3	UN-A24-K-008
1933	11	68725120DD4E	68725120DD4E	3	68725120DD4E
1573	30	UN-S-U-003	UN-S-U-003	4	UN-S-U-003
1934	32	2159380014752	2159380014752	1	
1935	32	2159380015122	2159380015122	1	
1937	32	2159380014757		1	
1938	32	2159380014740	2159380014740	1	
1765	51	UN-A-15-K-018	UN-A-15-K-018	3	UN-A-15-K-018
1974	1	F09FC246E83B	F09FC246E83B	1	F09FC246E83B
496	11	24A43CA63359	24A43CA63359	3	24A43CA63359
1975	11	68725120DDF1	68725120DDF1	3	68725120DDF1
1976	1	F09FC246E572	F09FC246E572	1	F09FC246E572
1977	1	F09FC246E6AF	F09FC246E6AF	1	F09FC246E6AF
1939	6	68725120360A	68725120360A	3	68725120360A
1978	1	F09FC246E7DE	F09FC246E7DE	1	F09FC246E7DE
1979	1	F09FC246E502	F09FC246E502	1	F09FC246E502
1980	1	802AA8F87B3F	802AA8F87B3F	1	802AA8F87B3F
1981	19	44D9E7CA11E3	44D9E7CA11E3	1	44D9E7CA11E3
1982	19	802AA808ECB6	802AA808ECB6	1	802AA808ECB6
1983	1	F09FC246E8E1	F09FC246E8E1	1	F09FC246E8E1
1984	1	F09FC246E0A6	F09FC246E0A6	1	F09FC246E0A6
1936	32	2159380015140	2159380015140	1	
1940	33	456fccbrzzz0	456fccbrzzz0	3	
1941	22	802AA8F1A3D9	802AA8F1A3D9	1	802AA8F1A3D9
1942	19	44D9E7A6EBB7	44D9E7A6EBB7	1	44D9E7A6EBB7
1944	19	44D9E7A6ECF4	44D9E7A6ECF4	1	44D9E7A6ECF4
1945	19	802AA806CE0C	802AA806CE0C	1	802AA806CE0C
1946	20	802AA8AE8ED7	802AA8AE8ED7	2	802AA8AE8ED7
1947	19	802AA806AD5D	802AA806AD5D	1	802AA806AD5D
1948	19	802AA806CBEA	802AA806CBEA	1	802AA806CBEA
1949	19	802AA806CE78	802AA806CE78	1	802AA806CE78
1950	1	F09FC246E393	F09FC246E393	1	F09FC246E393
1951	19	802AA806AC39	802AA806AC39	1	802AA806AC39
1952	1	F09FC246E5CE	F09FC246E5CE	1	F09FC246E5CE
809	19	802AA806CB9D	802AA806CB9D	1	802AA806CB9D
1953	19	802AA806C6D4	802AA806C6D4	1	802AA806C6D4
1954	11	24A43CA63154	24A43CA63154	3	24A43CA63154
1955	19	44D9E7A6EEE6	44D9E7A6EEE6	1	44D9E7A6EEE6
1956	19	802AA806CFEA	802AA806CFEA	1	802AA806CFEA
1957	19	802AA806CFF2	802AA806CFF2	1	802AA806CFF2
1958	1	F09FC246E523	F09FC246E523	1	F09FC246E523
1959	1	802AA8F87FB1	802AA8F87FB1	1	802AA8F87FB1
1960	19	802AA806C4BA	802AA806C4BA	1	802AA806C4BA
1961	1	F09FC246E570	F09FC246E570	1	F09FC246E570
1962	1	802AA8F87FB3	802AA8F87FB3	1	802AA8F87FB3
1963	1	F09FC246E5E8	F09FC246E5E8	1	F09FC246E5E8
1964	1	F09FC246E7FC	F09FC246E7FC	1	F09FC246E7FC
1965	19	802AA806C992	802AA806C992	1	802AA806C992
1966	19	802AA806ACB6	802AA806ACB6	1	802AA806ACB6
1967	1	802AA8F87D31	802AA8F87D31	1	802AA8F87D31
1968	1	F09FC246E455	F09FC246E455	1	F09FC246E455
1969	1	F09FC246E55D	F09FC246E55D	1	F09FC246E55D
1970	1	F09FC246EAA8	F09FC246EAA8	1	F09FC246EAA8
1971	1	F09FC246E70C	F09FC246E70C	1	F09FC246E70C
1972	1	F09FC246E68D	F09FC246E68D	1	F09FC246E68D
1985	20	802AA8AE8D3A	802AA8AE8D3A	2	802AA8AE8D3A
1986	19	802AA806C38A	802AA806C38A	1	802AA806C38A
1987	19	802AA808F4B8  	802AA808F4B8	1	802AA808F4B8
1988	11	6872514A48ED	6872514A48ED	3	6872514A48ED
1990	45	UN-A24-K-069	UN-A24-K-069	3	
1992	13	DC9FDB5221E8	DC9FDB5221E8	3	DC9FDB5221E8
1994	48	UN-AO15-K-102	UN-AO15-K-102	3	
1995	11	24A43C9E132C	24A43C9E132C	3	24A43C9E132C
1996	19	44D9E7CA1031	44D9E7CA1031	1	44D9E7CA1031
1997	19	802AA806D15A	802AA806D15A	1	802AA806D15A
1998	1	F09FC246E5C1	F09FC246E5C1	1	F09FC246E5C1
1943	1	F09FC246E65B	F09FC246E65B	1	F09FC246E65B
1931	11	6872514A49BC	6872514A49BC	3	6872514A49BC
1999	19	802AA806CECF	802AA806CECF	1	802AA806CECF
2000	1	F09FC246E489	F09FC246E489	1	F09FC246E489
2001	19	802AA808F51A	802AA808F51A	1	802AA808F51A
2002	1	F09FC246E5CC	F09FC246E5CC	1	F09FC246E5CC
2003	1	F09FC246E441	F09FC246E441	1	F09FC246E441
2004	1	F09FC246E2BF	F09FC246E2BF	1	F09FC246E2BF
2005	1	F09FC246E4C2	F09FC246E4C2	1	F09FC246E4C2
2006	19	802AA808FCB4	802AA808FCB4	1	802AA808FCB4
2008	19	802AA808FCE4	802AA808FCE4	1	802AA808FCE4
2007	1	F09FC246E9DA	F09FC246E9DA	1	F09FC246E9DA
2009	1	F09FC246E7EA	F09FC246E7EA	1	F09FC246E7EA
2010	19	802AA808E920	802AA808E920	1	802AA808E920
2011	19	44D9E7CA12B4	44D9E7CA12B4	1	44D9E7CA12B4
2012	11	6872514A4A32	6872514A4A32	3	6872514A4A32
2013	19	44D9E7A6ECFD	44D9E7A6ECFD	1	44D9E7A6ECFD
2015	1	F09FC246E805	F09FC246E805	1	F09FC246E805
2016	19	802AA808F8B0	802AA808F8B0	1	802AA808F8B0
2017	1	F09FC246EA7C	F09FC246EA7C	1	F09FC246EA7C
2018	19	44D9E7A6ECC0	44D9E7A6ECC0	1	44D9E7A6ECC0
2019	1	F09FC246E632	F09FC246E632	1	F09FC246E632
2020	19	802AA808F1D9	802AA808F1D9	1	802AA808F1D9
2021	28	FTX1538B0W0	FTX1538B0W0	3	70810592731E
1535	48	UN-AO15-K-083	UN-AO15-K-083	3	
2031	45	UN-A24-K-073	UN-A24-K-073	3	
2023	45	UN-A24-K-070	UN-A24-K-070	3	
2024	45	UN-A24-K-071	UN-A24-K-071	3	
1558	32	2154209000893	2154209000893	3	2154209000893
1122	6	68725166C31D	68725166C31D	1	68725166C31D
2057	1	802AA8BC26AF	802AA8BC26AF	1	802AA8BC26AF
2058	1	F09FC246E63F	F09FC246E63F	1	F09FC246E63F
2059	1	F09FC246EDD9	F09FC246EDD9	1	F09FC246EDD9
2060	1	F09FC246EDDE	F09FC246EDDE	1	F09FC246EDDE
2061	1	F09FC246E48B	F09FC246E48B	1	F09FC246E48B
2062	19	DC9FDB42B84A	DC9FDB42B84A	1	DC9FDB42B84A
2033	48	UN-AO15-K-104	UN-AO15-K-104	3	
2030	27	FCZ1231Z0RM	FCZ1231Z0RM	3	002155FF4B83
2037	45	UN-A24-K-076	UN-A24-K-076	3	
2044	1	F09FC246E4F1	F09FC246E4F1	1	F09FC246E4F1
2032	27	FCZ1231Z0RZ	FCZ1231Z0RZ	3	002155FF46EA
2034	31	23210564626	23210564626	3	0023D302000C
2036	28	FTX1538B0EB	FTX1538B0EB	3	708105927174
2041	45	UN-A24-K-077	UN-A24-K-077	3	
2063	1	F09FC246E60D	F09FC246E60D	1	F09FC246E60D
2038	49	UN-A15-K-004	UN-A15-K-004	3	
2064	1	F09FC246E607	F09FC246E607	1	F09FC246E607
2065	1	802AA8BC21BE	802AA8BC21BE	1	802AA8BC21BE
2028	28	FTX1538B0XC	FTX1538B0XC	3	7081059272E4
2039	32	2165463005941	2165463005941	3	
2040	26	FHK0726J0C0	FHK0726J0C0	3	000D29A8A94B
2014	1	F09FC246E62B	F09FC246E62B	1	F09FC246E62B
2042	1	802AA8F87DA4	802AA8F87DA4	1	802AA8F87DA4
2043	1	F09FC246E650	F09FC246E650	1	F09FC246E650
2045	1	F09FC246E63D	F09FC246E63D	1	F09FC246E63D
2046	1	F09FC246E77A	F09FC246E77A	1	F09FC246E77A
2047	1	802AA8BC1E0F	802AA8BC1E0F	1	802AA8BC1E0F
2048	1	F09FC246E759	F09FC246E759	1	F09FC246E759
2049	1	F09FC246E77E	F09FC246E77E	1	F09FC246E77E
2050	1	F09FC246E6DA	F09FC246E6DA	1	F09FC246E6DA
2051	1	F09FC246E422	F09FC246E422	1	F09FC246E422
2052	1	F09FC246E643	F09FC246E643	1	F09FC246E643
2053	1	F09FC246E304	F09FC246E304	1	F09FC246E304
2054	1	F09FC246E50C	F09FC246E50C	1	F09FC246E50C
2055	1	F09FC246E4DC	F09FC246E4DC	1	F09FC246E4DC
2056	1	F09FC246E468	F09FC246E468	1	F09FC246E468
2066	1	F09FC246E56F	F09FC246E56F	1	F09FC246E56F
2067	1	F09FC246E433	F09FC246E433	1	F09FC246E433
2068	16	6872513CD010	6872513CD010	3	6872513CD010
2069	1	F09FC246E097	F09FC246E097	1	F09FC246E097
2070	1	F09FC246E6E1	F09FC246E6E1	1	F09FC246E6E1
2071	1	F09FC246E434	F09FC246E434	1	F09FC246E434
2072	3	F09FC2504323	F09FC2504323	1	F09FC2504323
2073	11	68725166893C	68725166893C	1	68725166893C
2074	3	F09FC2504446	F09FC2504446	1	F09FC2504446
2075	19	802AA806CC64	802AA806CC64	1	802AA806CC64
2076	1	F09FC246E464	F09FC246E464	1	F09FC246E464
2077	1	F09FC246E3FA	F09FC246E3FA	1	F09FC246E3FA
2078	1	F09FC246E2D4	F09FC246E2D4	1	F09FC246E2D4
2079	1	F09FC246E2F3	F09FC246E2F3	1	F09FC246E2F3
2080	1	F09FC246E0AE	F09FC246E0AE	1	F09FC246E0AE
2081	1	F09FC246E485	F09FC246E485	1	F09FC246E485
2082	15	6872515C180B	6872515C180B	2	6872515C180B
2083	1	F09FC246E3A9	F09FC246E3A9	1	F09FC246E3A9
2084	11	6872512264C5	6872512264C5	3	6872512264C5
2085	1	F09FC246E6E8	F09FC246E6E8	1	F09FC246E6E8
2086	1	F09FC246E35D	F09FC246E35D	1	F09FC246E35D
2087	1	F09FC246E388	F09FC246E388	1	F09FC246E388
2088	1	F09FC246E910	F09FC246E910	1	F09FC246E910
2089	1	F09FC246E475	F09FC246E475	1	F09FC246E475
2090	11	687251226304	687251226304	3	687251226304
2091	1	F09FC246E638	F09FC246E638	1	F09FC246E638
2092	11	68725164A981	68725164A981	2	68725164A981
2093	1	F09FC246E1AE	F09FC246E1AE	1	F09FC246E1AE
2094	1	F09FC246EC6B	F09FC246EC6B	1	F09FC246EC6B
2095	1	F09FC246E6D2	F09FC246E6D2	1	F09FC246E6D2
2035	45	UN-A24-K-075	UN-A24-K-075	3	
2027	45	UN-A24-K-072	UN-A24-K-072	3	
2096	13	002722E6EC85	002722E6EC85	3	002722E6EC85
2097	1	F09FC246EE56	F09FC246EE56	1	F09FC246EE56
2098	11	68725142114B	68725142114B	3	68725142114B
2099	19	802AA806D011	802AA806D011	1	802AA806D011
2100	1	F09FC246E569	F09FC246E569	1	F09FC246E569
2101	1	F09FC246E4CB	F09FC246E4CB	1	F09FC246E4CB
2102	1	F09FC246E24E	F09FC246E24E	1	F09FC246E24E
2103	11	24A43CA6319E	24A43CA6319E	3	24A43CA6319E
2104	1	F09FC246E5A9	F09FC246E5A9	1	F09FC246E5A9
2105	1	F09FC246E18E	F09FC246E18E	1	F09FC246E18E
2106	11	687251226C8A	687251226C8A	3	
2107	1	F09FC246EE06	F09FC246EE06	1	F09FC246EE06
2108	11	24A43CA632C0	24A43CA632C0	3	24A43CA632C0
2109	1	F09FC246E4A4	F09FC246E4A4	1	F09FC246E4A4
2110	1	F09FC246E5E9	F09FC246E5E9	1	F09FC246E5E9
2111	1	F09FC246E2BC	F09FC246E2BC	1	F09FC246E2BC
2112	1	F09FC246E6D9	F09FC246E6D9	1	F09FC246E6D9
2113	11	6872514A48A6	6872514A48A6	3	6872514A48A6
2114	1	F09FC246EC2E	F09FC246EC2E	1	F09FC246EC2E
2115	1	F09FC246E6E3	F09FC246E6E3	1	F09FC246E6E3
2116	11	24A43C9E1265	24A43C9E1265	3	24A43C9E1265
2117	1	F09FC246E2D8	F09FC246E2D8	1	F09FC246E2D8
2118	1	F09FC246E415	F09FC246E415	1	F09FC246E415
2119	1	F09FC246E353	F09FC246E353	1	F09FC246E353
2121	1	F09FC246E5C4	F09FC246E5C4	1	F09FC246E5C4
2122	1	F09FC246E389	F09FC246E389	1	F09FC246E389
2123	1	F09FC246E7B6	F09FC246E7B6	1	F09FC246E7B6
2124	1	F09FC246E708	F09FC246E708	1	F09FC246E708
2177	1	F09FC246E507	F09FC246E507	1	F09FC246E507
2022	11	24A43CA62E25	24A43CA62E25	3	24A43CA62E25
1989	28	FTX1538B0XA	FTX1538B0XA	3	70810592730E
2125	28	FTX1537B086	FTX1537B086	3	7081059270F4
2126	48	UN-AO15-K-103	UN-AO15-K-103	3	
2127	1	F09FC246E418	F09FC246E418	1	F09FC246E418
2128	1	F09FC246E74E	F09FC246E74E	1	F09FC246E74E
2129	1	F09FC246E4BE	F09FC246E4BE	1	F09FC246E4BE
2130	11	687251668943	687251668943	1	687251668943
2131	11	687251668877	687251668877	1	687251668877
2132	1	F09FC246E14E	F09FC246E14E	1	F09FC246E14E
2133	1	F09FC246E1EE	F09FC246E1EE	1	F09FC246E1EE
2134	1	F09FC246E6E0	F09FC246E6E0	1	F09FC246E6E0
2135	1	F09FC246E596	F09FC246E596	1	F09FC246E596
2136	1	802AA87AF97C	802AA87AF97C	1	802AA87AF97C
2137	1	F09FC246E5DF	F09FC246E5DF	1	F09FC246E5DF
2138	1	F09FC246E0B3	F09FC246E0B3	1	F09FC246E0B3
2140	1	F09FC246E816	F09FC246E816	1	F09FC246E816
2141	1	F09FC246E25B	F09FC246E25B	1	F09FC246E25B
2142	1	802AA8BC1DA7	802AA8BC1DA7	1	802AA8BC1DA7
2143	11	687251226564	687251226564	3	687251226564
2144	1	F09FC246E2E5	F09FC246E2E5	1	F09FC246E2E5
2145	1	F09FC246E394	F09FC246E394	3	F09FC246E394
2146	1	F09FC246E2D5	F09FC246E2D5	1	F09FC246E2D5
2147	1	F09FC246E306	F09FC246E306	1	F09FC246E306
2148	1	F09FC246E160	F09FC246E160	1	F09FC246E160
2149	1	F09FC246E4F5	F09FC246E4F5	1	F09FC246E4F5
2150	1	F09FC246E6B3	F09FC246E6B3	1	F09FC246E6B3
2151	1	F09FC246E706	F09FC246E706	1	F09FC246E706
2152	1	F09FC246E259	F09FC246E259	1	F09FC246E259
2153	11	6872514A49B4	6872514A49B4	3	6872514A49B4
2154	1	F09FC246E490	F09FC246E490	1	F09FC246E490
2155	1	F09FC246E5C9	F09FC246E5C9	1	F09FC246E5C9
2156	1	F09FC246E515	F09FC246E515	1	F09FC246E515
2157	1	F09FC246E198	F09FC246E198	1	F09FC246E198
2158	1	F09FC246E0C6	F09FC246E0C6	1	F09FC246E0C6
2159	1	F09FC246EA72	F09FC246EA72	1	F09FC246EA72
2160	1	F09FC246E206	F09FC246E206	1	F09FC246E206
2161	1	F09FC246E5A4	F09FC246E5A4	1	F09FC246E5A4
2162	1	F09FC246E4D4	F09FC246E4D4	1	F09FC246E4D4
2163	1	F09FC246E5D0	F09FC246E5D0	1	F09FC246E5D0
2164	1	F09FC246E52D	F09FC246E52D	1	F09FC246E52D
2165	1	F09FC246E55F	F09FC246E55F	1	F09FC246E55F
2166	1	F09FC246E4CC	F09FC246E4CC	1	F09FC246E4CC
2167	1	F09FC246E4B9	F09FC246E4B9	1	F09FC246E4B9
2168	1	F09FC246E4E9	F09FC246E4E9	1	F09FC246E4E9
2169	1	F09FC246E4DA	F09FC246E4DA	1	F09FC246E4DA
2170	1	F09FC246E3BC	F09FC246E3BC	1	F09FC246E3BC
2171	1	F09FC246E242	F09FC246E242	1	F09FC246E242
2172	1	F09FC246E891	F09FC246E891	1	F09FC246E891
2173	1	F09FC246E411	F09FC246E411	1	F09FC246E411
2174	1	F09FC246E737	F09FC246E737	1	F09FC246E737
2175	1	F09FC246E3BD	F09FC246E3BD	1	F09FC246E3BD
2176	1	F09FC246ED2D	F09FC246ED2D	1	F09FC246ED2D
2178	1	802AA8F87C4F	802AA8F87C4F	1	802AA8F87C4F
2179	1	F09FC246E2DD	F09FC246E2DD	1	F09FC246E2DD
2180	1	F09FC246E187	F09FC246E187	1	F09FC246E187
2181	11	6872514A4A0C	6872514A4A0C	3	6872514A4A0C
2182	11	68725120DFE1	68725120DFE1	3	68725120DFE1
2183	11	24A43CA63073	24A43CA63073	3	24A43CA63073
2184	13	002722EE7F87	002722EE7F87	3	002722EE7F87
2185	11	24A43CA62D57	24A43CA62D57	3	24A43CA62D57
2186	11	6872512263E5	6872512263E5	3	6872512263E5
2187	13	00156DEA1ED9	00156DEA1ED9	3	00156DEA1ED9
2188	11	24A43CA62EA6	24A43CA62EA6	3	24A43CA62EA6
2189	13	002722E6ED27	002722E6ED27	3	002722E6ED27
92	1	802AA8F88019	802AA8F88019	1	802AA8F88019
2139	1	F09FC246E134	F09FC246E134	1	F09FC246E134
2190	13	002722E6ED78	002722E6ED78	3	002722E6ED78
2191	13	DC9FDB52217F	DC9FDB52217F	3	DC9FDB52217F
2192	19	802AA808F3B9	802AA808F3B9	1	802AA808F3B9
2193	16	6872515E286C	6872515E286C	2	6872515E286C
2194	13	002722EE7EB7	002722EE7EB7	3	002722EE7EB7
2195	15	687251820C76	687251820C76	2	687251820C76
2196	16	6872513CBB00	6872513CBB00	3	6872513CBB00
2197	16	6872513CD091	6872513CD091	3	6872513CD091
2198	13	DC9FDB50058B	DC9FDB50058B	3	DC9FDB50058B
2199	1	F09FC246E695	F09FC246E695	1	F09FC246E695
2200	1	F09FC246E809	F09FC246E809	1	F09FC246E809
2201	1	F09FC246E349	F09FC246E349	1	F09FC246E349
2202	1	F09FC246E64C 	F09FC246E64C	1	
2203	1	802AA8F8735F	802AA8F8735F	1	802AA8F8735F
2205	1	F09FC246E2F8	F09FC246E2F8	1	F09FC246E2F8
2206	1	F09FC246E4A2	F09FC246E4A2	1	F09FC246E4A2
2207	1	F09FC246E7B3	F09FC246E7B3	1	F09FC246E7B3
2208	1	F09FC246E63B	F09FC246E63B	1	F09FC246E63B
2209	1	F09FC246E6BC	F09FC246E6BC	1	F09FC246E6BC
2210	1	802AA87AF9B5	802AA87AF9B5	1	802AA87AF9B5
2211	1	F09FC246E360	F09FC246E360	1	F09FC246E360
2212	1	F09FC246E828	F09FC246E828	1	F09FC246E828
2213	1	F09FC246E89C	F09FC246E89C	1	F09FC246E89C
2214	1	F09FC246E698	F09FC246E698	1	F09FC246E698
2215	1	F09FC246E374	F09FC246E374	1	F09FC246E374
2217	1	F09FC246E720	F09FC246E720	1	F09FC246E720
2216	1	802AA87AEE59	802AA87AEE59	1	802AA87AEE59
2218	1	F09FC246E367	F09FC246E367	1	F09FC246E367
2219	1	F09FC246E5B6	F09FC246E5B6	1	F09FC246E5B6
2220	1	F09FC246E47E	F09FC246E47E	1	F09FC246E47E
2221	1	802AA8F879F2	802AA8F879F2	1	802AA8F879F2
2222	1	F09FC246E717	F09FC246E717	1	F09FC246E717
2223	1	F09FC246E4AC	F09FC246E4AC	1	F09FC246E4AC
2224	11	687251226716	687251226716	3	687251226716
2225	11	24A43CA63240	24A43CA63240	3	24A43CA63240
2226	11	6872514A491F	6872514A491F	3	6872514A491F
2227	11	6872514A4938	6872514A4938	3	6872514A4938
2228	11	24A43C9E124C	24A43C9E124C	3	24A43C9E124C
1398	24	FTX1246U00Y	FTX1246U00Y	3	00235e2cc8de
2229	13	002722EE7FA2	002722EE7FA2	3	002722EE7FA2
2230	11	6872514A494E	6872514A494E	3	6872514A494E
2231	11	68725120DF53	68725120DF53	3	68725120DF53
2232	11	6872512265D4	6872512265D4	3	6872512265D4
2233	11	687251226571	687251226571	3	687251226571
2234	11	68725122635E	68725122635E	3	68725122635E
2235	11	687251226488	687251226488	3	687251226488
2236	11	24A43CA62CF3	24A43CA62CF3	3	24A43CA62CF3
2237	11	6872514A4A3A	6872514A4A3A	3	6872514A4A3A
2238	11	24A43CA63072	24A43CA63072	3	24A43CA63072
2239	11	68725120E19B	68725120E19B	3	68725120E19B
2240	11	24A43CA62E2C	24A43CA62E2C	3	24A43CA62E2C
2241	11	24A43CA4E523	24A43CA4E523	3	24A43CA4E523
2242	11	24A43CA63300	24A43CA63300	3	24A43CA63300
2243	11	24A43CF89BB1	24A43CF89BB1	3	24A43CF89BB1
2244	11	24A43CA6327D	24A43CA6327D	3	24A43CA6327D
2245	11	24A43C9E12B4	24A43C9E12B4	3	24A43C9E12B4
2246	11	6872514A4A09	6872514A4A09	3	6872514A4A09
2247	11	68725144DAB5	68725144DAB5	3	68725144DAB5
2248	11	68725120E1B1	68725120E1B1	3	68725120E1B1
2249	11	68725122681B	68725122681B	3	68725122681B
2252	13	DC9FDB5004FB	DC9FDB5004FB	3	DC9FDB5004FB
2253	13	DC9FDBA67F28	DC9FDBA67F28	3	DC9FDBA67F28
2254	13	002722E6ED2E	002722E6ED2E	3	002722E6ED2E
2255	13	DC9FDB500628	DC9FDB500628	3	DC9FDB500628
2256	19	44D9E7A80D42	44D9E7A80D42	1	44D9E7A80D42
2257	15	24A43CB4B1F3	24A43CB4B1F3	3	24A43CB4B1F3
2258	15	68725136CD94	68725136CD94	3	68725136CD94
2259	16	6872513CBA50	6872513CBA50	3	6872513CBA50
2260	15	24A43CB4B00C	24A43CB4B00C	3	24A43CB4B00C
2261	19	802AA806D216	802AA806D216	1	802AA806D216
2262	19	802AA806CC6A	802AA806CC6A	1	802AA806CC6A
2263	15	6872515C2C21	6872515C2C21	2	6872515C2C21
2264	19	802AA806CDEA	802AA806CDEA	1	802AA806CDEA
2265	15	24A43CB4B174	24A43CB4B174	3	24A43CB4B174
2266	19	802AA806CD81	802AA806CD81	1	802AA806CD81
2267	19	802AA806C9B7	802AA806C9B7	1	802AA806C9B7
2268	19	802AA806CF12	802AA806CF12	1	802AA806CF12
2269	11	68725120DDA1	68725120DDA1	3	68725120DDA1
2270	16	6872513ECBAF	6872513ECBAF	3	6872513ECBAF
2271	1	F09FC246E6D8	F09FC246E6D8	1	F09FC246E6D8
2272	11	68725120DE96	68725120DE96	3	68725120DE96
2273	11	68725120E196	68725120E196	3	68725120E196
2274	16	6872515E2874	6872515E2874	2	6872515E2874
2275	11	68725120DDAD	68725120DDAD	3	68725120DDAD
2276	15	687251307F21	687251307F21	3	687251307F21
2277	11	68725120DD79	68725120DD79	3	68725120DD79
2278	15	6872513080B5	6872513080B5	3	6872513080B5
2279	11	6872514A4A40	6872514A4A40	3	6872514A4A40
2280	11	68725120E1AA	68725120E1AA	3	68725120E1AA
2281	11	24A43CA62EAB	24A43CA62EAB	3	24A43CA62EAB
2282	11	687251226511	687251226511	3	687251226511
2283	11	68725120DE92	68725120DE92	3	68725120DE92
2284	11	68725120DD35	68725120DD35	3	68725120DD35
2285	11	68725120E197	68725120E197	3	68725120E197
2250	13	DC9FDB5005F3	DC9FDB5005F3	3	DC9FDB5005F3
2251	13	DC9FDB50056E	DC9FDB50056E	3	DC9FDB50056E
2286	11	68725120E18A	68725120E18A	3	68725120E18A
2287	11	68725120DDB8	68725120DDB8	3	68725120DDB8
2288	11	68725120DDA6	68725120DDA6	3	68725120DDA6
2289	1	F09FC246E7EB	F09FC246E7EB	1	F09FC246E7EB
2290	1	802AA8BA23CC	802AA8BA23CC	1	802AA8BA23CC
2291	1	F09FC246E4C1	F09FC246E4C1	1	F09FC246E4C1
2292	1	F09FC246E281	F09FC246E281	1	F09FC246E281
2293	11	68725120DFD2	68725120DFD2	3	68725120DFD2
2294	1	F09FC246E56E	F09FC246E56E	1	F09FC246E56E
2295	1	F09FC246E6EE	F09FC246E6EE	1	F09FC246E6EE
2296	1	F09FC246E1F8	F09FC246E1F8	1	F09FC246E1F8
2297	11	24A43CA62CFB	24A43CA62CFB	3	24A43CA62CFB
2298	11	6872514A4921	6872514A4921	3	6872514A4921
2299	1	F09FC246E351	F09FC246E351	1	F09FC246E351
2300	11	6872514A49FA	6872514A49FA	3	6872514A49FA
2301	19	44D9E7CA105D	44D9E7CA105D	1	44D9E7CA105D
2302	1	F09FC246E770	F09FC246E770	1	F09FC246E770
2303	11	6872514A4815	6872514A4815	3	6872514A4815
2304	1	F09FC246E73A	F09FC246E73A	1	F09FC246E73A
2305	1	F09FC246E371	F09FC246E371	1	F09FC246E371
2306	29	6c3b6bd58dd7	6c3b6bd58dd7	4	6c3b6bd58dd7
2307	29	71a306a4660a	71a306a4660a	4	6c3b6bd58ea3
2308	11	68725120DD85	68725120DD85	3	68725120DD85
2309	11	68725120DDA9	68725120DDA9	3	68725120DDA9
2310	11	68725120E1B2	68725120E1B2	3	68725120E1B2
2311	11	68725120DE90	68725120DE90	3	68725120DE90
2312	15	6872513080A4	6872513080A4	3	6872513080A4
2313	11	68725120E194	68725120E194	3	68725120E194
2314	11	68725120E131	68725120E131	3	68725120E131
2315	11	68725120E1B5	68725120E1B5	3	68725120E1B5
2316	29	71a3068ddd4e	71a3068ddd4e	4	6c3b6bda1f10
2318	29	71a30694643e	71a30694643e	4	6c3b6bd590dd
2319	11	68725120DE95	68725120DE95	3	68725120DE95
2320	11	24A43CA62C66	24A43CA62C66	3	24A43CA62C66
2321	15	687251307E80	687251307E80	3	687251307E80
2322	11	68725120DDAE	68725120DDAE	3	68725120DDAE
2323	11	68725120DEC5	68725120DEC5	3	68725120DEC5
2324	11	68725120DDA3	68725120DDA3	3	68725120DDA3
2325	11	68725120DDB4	68725120DDB4	3	68725120DDB4
2326	11	68725120E1A9	68725120E1A9	3	68725120E1A9
2328	11	68725120dd28	68725120dd28	3	68725120dd28
2333	1	F09FC246E6FC	F09FC246E6FC	1	F09FC246E6FC
2332	1	F09FC246E1B0	F09FC246E1B0	1	F09FC246E1B0
2330	1	F09FC246E44B	F09FC246E44B	1	F09FC246E44B
2329	1	F09FC246E470	F09FC246E470	1	F09FC246E470
2331	1	F09FC246ED2F	F09FC246ED2F	1	F09FC246ED2F
2334	1	F09FC246E405	F09FC246E405	1	F09FC246E405
2335	1	F09FC246E6AD	F09FC246E6AD	1	F09FC246E6AD
2336	1	F09FC246E11B	F09FC246E11B	1	F09FC246E11B
2337	1	F09FC246E3AF	F09FC246E3AF	1	F09FC246E3AF
2338	29	71A306885A79	71A306885A79	4	6C3B6BDA15F8
2339	1	F09FC246EDFF	F09FC246EDFF	1	F09FC246EDFF
2340	1	F09FC246E4ED	F09FC246E4ED	1	F09FC246E4ED
2341	1	F09FC246E97C	F09FC246E97C	1	F09FC246E97C
2342	1	F09FC246E45C	F09FC246E45C	1	F09FC246E45C
2343	1	F09FC246E35A	F09FC246E35A	1	F09FC246E35A
2344	1	F09FC246E74D	F09FC246E74D	1	F09FC246E74D
2345	1	F09FC246E2C6	F09FC246E2C6	1	F09FC246E2C6
2346	1	F09FC246E178	F09FC246E178	1	F09FC246E178
2347	1	F09FC246E66B	F09FC246E66B	1	F09FC246E66B
2348	1	F09FC246E2B0	F09FC246E2B0	1	F09FC246E2B0
2349	1	F09FC246E2D1	F09FC246E2D1	1	F09FC246E2D1
2350	11	6872514A49C8	6872514A49C8	3	6872514A49C8
2351	1	F09FC246E6DE	F09FC246E6DE	1	F09FC246E6DE
2352	1	F09FC246E392	F09FC246E392	1	F09FC246E392
2353	1	F09FC246E4F4	F09FC246E4F4	1	F09FC246E4F4
2354	1	F09FC246E5F3	F09FC246E5F3	1	F09FC246E5F3
2355	11	24A43CA62E42	24A43CA62E42	3	24A43CA62E42
2356	1	F09FC246E5AE	F09FC246E5AE	1	F09FC246E5AE
2357	1	F09FC246E2BB	F09FC246E2BB	1	F09FC246E2BB
2358	1	802AA8BA2503	802AA8BA2503	1	802AA8BA2503
2359	1	802AA8F87C6A	802AA8F87C6A	1	802AA8F87C6A
2360	11	24A43CA63302	24A43CA63302	3	24A43CA63302
2361	1	802AA87AFA5F	802AA87AFA5F	1	802AA87AFA5F
2362	1	802AA8F87351	802AA8F87351	1	802AA8F87351
2363	1	F09FC246E240	F09FC246E240	1	F09FC246E240
2364	1	802AA8BA1D0D	802AA8BA1D0D	1	802AA8BA1D0D
2365	1	802AA8F8773D	802AA8F8773D	1	802AA8F8773D
2366	1	F09FC246E5CA	F09FC246E5CA	1	F09FC246E5CA
2367	11	6872514A4A13	6872514A4A13	3	6872514A4A13
2368	1	F09FC246E5B9	F09FC246E5B9	1	F09FC246E5B9
2369	1	F09FC246E4EC	F09FC246E4EC	1	F09FC246E4EC
2370	1	F09FC246E56C	F09FC246E56C	1	F09FC246E56C
2371	11	24A43CA63179	24A43CA63179	3	24A43CA63179
2372	11	24A43CA631EF	24A43CA631EF	3	24A43CA631EF
2373	1	802AA8BA2256	802AA8BA2256	1	802AA8BA2256
2374	1	F09FC246E4F0	F09FC246E4F0	1	F09FC246E4F0
2375	1	802AA8BA2438	802AA8BA2438	1	802AA8BA2438
2376	1	F09FC246E5B0	F09FC246E5B0	1	F09FC246E5B0
2377	1	F09FC246E453	F09FC246E453	1	F09FC246E453
2378	11	6872514A4962	6872514A4962	3	6872514A4962
2379	11	6872512264D6	6872512264D6	3	6872512264D6
2380	1	F09FC246EC3E	F09FC246EC3E	1	F09FC246EC3E
2381	11	24A43CA632D5	24A43CA632D5	3	24A43CA632D5
2382	11	6872512263E3	6872512263E3	3	6872512263E3
2383	1	F09FC246E16C	F09FC246E16C	1	F09FC246E16C
2384	11	6872514A4A37	6872514A4A37	3	6872514A4A37
2385	15	24A43C74B609	24A43C74B609	3	24A43C74B609
2386	11	6872514A494D	6872514A494D	3	6872514A494D
2387	11	6872514A4A2A	6872514A4A2A	3	6872514A4A2A
2388	1	F09FC246EC62	F09FC246EC62	1	F09FC246EC62
2389	11	68725120E1A3	68725120E1A3	3	68725120E1A3
2390	11	68725164AA97	68725164AA97	2	68725164AA97
2391	11	24A43CA63157	24A43CA63157	3	24A43CA63157
2392	11	24A43CA631B8	24A43CA631B8	3	24A43CA631B8
2393	11	68725122655F	68725122655F	3	68725122655F
2394	11	68725164AB99	68725164AB99	2	68725164AB99
2395	15	6872514A2B86	6872514A2B86	3	6872514A2B86
2396	11	6872514A49D8	6872514A49D8	3	6872514A49D8
2397	15	68725136C7A8	68725136C7A8	3	68725136C7A8
2398	11	24A43CA62A1E	24A43CA62A1E	3	24A43CA62A1E
2399	19	802AA806CF8B	802AA806CF8B	1	802AA806CF8B
2400	11	6872514A4935	6872514A4935	3	6872514A4935
2401	11	68725164A947	68725164A947	2	68725164A947
2402	11	6872514A4A27	6872514A4A27	3	6872514A4A27
2403	11	68725164A959	68725164A959	2	68725164A959
2404	29	71A306F5C233	71A306F5C233	4	6C3B6BD58A3B
2405	11	68725164A979	68725164A979	2	68725164A979
2406	16	6872515E2814	6872515E2814	2	6872515E2814
2407	11	6872514A4A29	6872514A4A29	3	6872514A4A29
2409	21	F09FC24AB06F	F09FC24AB06F	2	F09FC24AB06F
2410	11	6872512269C8	6872512269C8	3	6872512269C8
2411	1	F09FC246E65A	F09FC246E65A	1	F09FC246E65A
2412	11	6872512263E6	6872512263E6	3	6872512263E6
2413	11	68725122660E	68725122660E	3	68725122660E
2414	19	802AA808E8E5	802AA808E8E5	4	802AA808E8E5
2417	13	002722EE8039	002722EE8039	3	002722EE8039
2418	13	DC9FDB52217D	DC9FDB52217D	3	DC9FDB52217D
2419	11	6872514A4964	6872514A4964	3	6872514A4964
2420	1	F09FC246E6A9	F09FC246E6A9	1	F09FC246E6A9
2421	11	24A43CA62DE6	24A43CA62DE6	3	24A43CA62DE6
2422	11	68725120E1A1	68725120E1A1	3	68725120E1A1
2423	1	F09FC246ECC0	F09FC246ECC0	1	F09FC246ECC0
2424	11	68725120DEC0	68725120DEC0	3	68725120DEC0
2425	1	F09FC246E2BE	F09FC246E2BE	1	F09FC246E2BE
2426	1	F09FC246E8C0	F09FC246E8C0	1	F09FC246E8C0
2427	11	24A43CA62E00	24A43CA62E00	3	24A43CA62E00
2428	11	687251668997	687251668997	1	687251668997
2429	15	68725124FA35	68725124FA35	3	68725124FA35
2430	15	24A43C74B5BC	24A43C74B5BC	3	24A43C74B5BC
2431	1	F09FC246E46D	F09FC246E46D	1	F09FC246E46D
2432	28	UN-C-24	UN-C-24	3	UN-C-24
2433	13	DC9FDB5221A5	DC9FDB5221A5	3	DC9FDB5221A5
2434	13	DC9FDBA67F33	DC9FDBA67F33	3	DC9FDBA67F33
2435	1	F09FC246E6CB	F09FC246E6CB	1	F09FC246E6CB
2436	1	F09FC246E7CC	F09FC246E7CC	1	F09FC246E7CC
2437	11	24A43CA632EA	24A43CA632EA	3	24A43CA632EA
2438	11	68725166887D	68725166887D	1	68725166887D
2439	11	6872514A4A2D	6872514A4A2D	3	6872514A4A2D
2440	11	24A43CA62E81	24A43CA62E81	3	24A43CA62E81
2441	1	F09FC246E66D	F09FC246E66D	1	F09FC246E66D
2442	11	68725120E06A	68725120E06A	3	68725120E06A
2443	11	24A43CA4E610	24A43CA4E610	3	24A43CA4E610
2444	11	687251668991	687251668991	1	687251668991
2445	1	F09FC246E204	F09FC246E204	1	
2446	11	68725164A960	68725164A960	2	68725164A960
2447	1	F09FC246E3D1	F09FC246E3D1	1	F09FC246E3D1
2448	11	24A43C9E1346	24A43C9E1346	3	24A43C9E1346
2449	19	44D9E7CA1706	44D9E7CA1706	1	44D9E7CA1706
2450	1	F09FC246E516	F09FC246E516	1	F09FC246E516
2451	13	DC9FDB500631	DC9FDB500631	3	DC9FDB500631
2452	1	F09FC246E958	F09FC246E958	1	F09FC246E958
2453	11	DC9FDBA67D0D	DC9FDBA67D0D	3	DC9FDBA67D0D
2454	1	F09FC246E223	F09FC246E223	1	F09FC246E223
2455	1	F09FC246E387	F09FC246E387	1	F09FC246E387
2456	1	F09FC246E9E1	F09FC246E9E1	1	F09FC246E9E1
2457	13	DC9FDBA67DEF	DC9FDBA67DEF	3	DC9FDBA67DEF
2458	11	6872514A493B	6872514A493B	3	6872514A493B
2459	11	68725164A93A	68725164A93A	2	68725164A93A
2460	1	F09FC246E4FB	F09FC246E4FB	1	F09FC246E4FB
2461	1	F09FC246E0A8	F09FC246E0A8	1	F09FC246E0A8
2462	1	F09FC246E827	F09FC246E827	1	F09FC246E827
2463	13	DC9FDBA67DEE	DC9FDBA67DEE	3	DC9FDBA67DEE
2464	1	802AA8BC1F73	802AA8BC1F73	1	802AA8BC1F73
2465	1	F09FC246E7F6	F09FC246E7F6	1	F09FC246E7F6
2466	13	DC9FDB5221E1	DC9FDB5221E1	3	DC9FDB5221E1
2467	1	24A43CE6EC4B	24A43CE6EC4B	1	24A43CE6EC4B
2468	1	F09FC246E30F	F09FC246E30F	1	F09FC246E30F
2469	1	F09FC246E476	F09FC246E476	1	F09FC246E476
2470	11	68725164A963	68725164A963	2	68725164A963
2471	1	24A43CF86295	24A43CF86295	3	24A43CF86295
2472	11	68725120E1A0	68725120E1A0	3	68725120E1A0
2473	1	F09FC246E461	F09FC246E461	1	F09FC246E461
2474	11	6872512265D3	6872512265D3	3	6872512265D3
2475	13	DC9FDBA67C3D	DC9FDBA67C3D	3	DC9FDBA67C3D
2476	1	F09FC246E6EF	F09FC246E6EF	1	F09FC246E6EF
2477	1	F09FC246E771	F09FC246E771	1	F09FC246E771
2478	11	6872514A4A3D	6872514A4A3D	3	6872514A4A3D
2479	1	F09FC246E625	F09FC246E625	1	F09FC246E625
2415	13	002722E6EC83	002722E6EC83	3	002722E6EC83
2416	11	6872514A49A4	6872514A49A4	3	6872514A49A4
2480	11	68725164a966	68725164a966	2	68725164a966
2481	15	6872515C3029	6872515C3029	2	6872515C3029
2482	1	F09FC246E3C8	F09FC246E3C8	1	F09FC246E3C8
2483	16	6872514A581C	6872514A581C	3	6872514A581C
2484	1	F09FC246E136	F09FC246E136	1	F09FC246E136
2485	17	802AA86AEE11	802AA86AEE11	2	802AA86AEE11
2486	15	24A43C74B588	24A43C74B588	3	24A43C74B588
2487	1	802AA8F876E2	802AA8F876E2	1	802AA8F876E2
2488	16	6872515E2789	6872515E2789	2	6872515E2789
2489	16	002722E25314	002722E25314	3	002722E25314
2490	1	F09FC246E5DE	F09FC246E5DE	1	F09FC246E5DE
2491	29	71A306A721AD1	71A306A721AD1	4	6C3B6BD7F15F
2492	1	F09FC246E6DB	F09FC246E6DB	1	F09FC246E6DB
2493	19	802AA806D10C	802AA806D10C	1	802AA806D10C
2494	1	802AA8F879BC	802AA8F879BC	1	802AA8F879BC
2495	19	44D9E7CA1229	44D9E7CA1229	1	44D9E7CA1229
2496	1	F09FC246E591	F09FC246E591	1	F09FC246E591
2497	11	6872514A4816	6872514A4816	3	6872514A4816
2498	11	687251668932	687251668932	1	687251668932
2499	1	F09FC246E6AC	F09FC246E6AC	1	F09FC246E6AC
2500	1	F09FC246E493	F09FC246E493	1	F09FC246E493
2501	1	F09FC246E6DD	F09FC246E6DD	1	F09FC246E6DD
2503	11	687251668A27	687251668A27	1	687251668A27
2502	1	F09FC246E6C8	F09FC246E6C8	1	F09FC246E6C8
2504	1	F09FC246EB55	F09FC246EB55	1	F09FC246EB55
2505	1	F09FC246E34B	F09FC246E34B	1	F09FC246E34B
2506	1	F09FC246E5E7	F09FC246E5E7	1	F09FC246E5E7
2507	19	802AA806B009	802AA806B009	1	802AA806B009
2508	13	DC9FDBA67D56	DC9FDBA67D56	3	DC9FDBA67D56
2509	1	F09FC246E68E	F09FC246E68E	1	F09FC246E68E
2510	1	F09FC246ED20	F09FC246ED20	1	F09FC246ED20
2511	1	F09FC246EC63	F09FC246EC63	1	F09FC246EC63
2512	1	F09FC246E885	F09FC246E885	1	F09FC246E885
2513	1	F09FC246EC8D	F09FC246EC8D	1	F09FC246EC8D
2514	1	F09FC246E725	F09FC246E725	1	F09FC246E725
2515	1	F09FC246EB0E	F09FC246EB0E	1	F09FC246EB0E
2516	1	F09FC246E9DB	F09FC246E9DB	1	F09FC246E9DB
2517	1	F09FC246E4AF	F09FC246E4AF	1	F09FC246E4AF
2518	1	F09FC246E662	F09FC246E662	1	F09FC246E662
2519	1	802AA8F87501	802AA8F87501	1	802AA8F87501
2520	1	F09FC246E7DB	F09FC246E7DB	1	F09FC246E7DB
2521	1	F09FC246E67E	F09FC246E67E	1	F09FC246E67E
2522	1	F09FC246E8B6	F09FC246E8B6	1	F09FC246E8B6
2523	1	F09FC246E9CF	F09FC246E9CF	1	F09FC246E9CF
2524	1	F09FC246E762	F09FC246E762	1	F09FC246E762
2525	1	802AA8F878C6	802AA8F878C6	1	802AA8F878C6
2526	1	F09FC246E9B2	F09FC246E9B2	1	F09FC246E9B2
2527	29	71A306BEA29E	71A306BEA29E	4	6C3B6BD7686F
2528	1	F09FC246E1EF	F09FC246E1EF	1	F09FC246E1EF
2529	1	F09FC246E2C8	F09FC246E2C8	1	F09FC246E2C8
2530	1	F09FC246E990	F09FC246E990	1	F09FC246E990
2531	1	F09FC246E566	F09FC246E566	1	F09FC246E566
2532	1	802AA8F87741	802AA8F87741	1	802AA8F87741
2533	1	F09FC246E425	F09FC246E425	1	F09FC246E425
2534	13	DC9FDB5221C4	DC9FDB5221C4	3	DC9FDB5221C4
2535	13	002722E6ED2C	002722E6ED2C	3	002722E6ED2C
2536	13	DC9FDB500669	DC9FDB500669	3	DC9FDB500669
2537	13	DC9FDB510604	DC9FDB510604	3	DC9FDB510604
2538	13	DC9FDBA67B27	DC9FDBA67B27	3	DC9FDBA67B27
2539	13	DC9FDBA67D00	DC9FDBA67D00	3	DC9FDBA67D00
2540	13	DC9FDB5105EA	DC9FDB5105EA	3	DC9FDB5105EA
2541	13	002722EE7FD3	002722EE7FD3	1	002722EE7FD3
2542	13	DC9FDBA67EEE	DC9FDBA67EEE	3	DC9FDBA67EEE
2543	29	71A30654E34A	71A30654E34A	4	6C3B6BDC6F56
2544	13	DC9FDBA67DAC	DC9FDBA67DAC	3	DC9FDBA67DAC
2545	13	DC9FDBA67D44	DC9FDBA67D44	3	DC9FDBA67D44
2546	11	68725120DD4D	68725120DD4D	3	68725120DD4D
2547	11	68725164A964	68725164A964	2	68725164A964
2548	11	687251226563	687251226563	3	687251226563
2549	11	24A43CF89DA7	24A43CF89DA7	3	24A43CF89DA7
2550	11	68725120E111	68725120E111	3	68725120E111
2551	11	6872514A498E	6872514A498E	3	6872514A498E
2552	11	6872514A4A2C	6872514A4A2C	3	6872514A4A2C
2553	11	6872514A4937	6872514A4937	3	6872514A4937
2554	11	6872514A4961	6872514A4961	3	6872514A4961
2555	11	68725164A8C3	68725164A8C3	2	68725164A8C3
2556	11	6872514A494C	6872514A494C	3	6872514A494C
2557	11	6872514A4933	6872514A4933	3	6872514A4933
2558	19	802AA806CFCC	802AA806CFCC	1	802AA806CFCC
2559	19	802AA806CFD2	802AA806CFD2	1	802AA806CFD2
2560	19	802AA806CE17	802AA806CE17	1	802AA806CE17
2561	29	71A306E0E98E	71A306E0E98E	4	6C3B6BDA103E
2562	29	71A3061EE4DF	71A3061EE4DF	4	6C3B6BDC6D88
2563	29	71A3068075F3	71A3068075F3	4	6c3b6bdc5fb4
2564	29	71a306090b0f	71a306090b0f	4	6c3b6bd5811c
2565	45	UN-A24-K-078	UN-A24-K-078	3	
2566	29	71A30612B431	71A30612B431	4	6C3B6BD75C2F
2567	29	71A3067517F1	71A3067517F1	4	6C3B6BD7FA4D
2568	29	71A306B1B1B8	71A306B1B1B8	4	6C3B6BDC6F44
2569	29	71A306D44487	71A306D44487	4	6C3B6BDC68DE
2570	29	71A30635AE85	71A30635AE85	4	6C3B6BDC6314
2571	29	71A306FDF8DD	71A306FDF8DD	4	6C3B6BDA1496
2572	29	71A306E838C2	71A306E838C2	4	6C3B6BD59833
2573	29	71A3062F4D18	71A3062F4D18	4	6C3B6BD75A73
2574	31	23210456415	23210456415	3	0023d301f5e7
2120	11	6872514A49BF	6872514A49BF	3	6872514A49BF
2575	45	UN-A24-K-079	UN-A24-K-079	3	
2576	28	FTX1538B0E5	FTX1538B0E5	3	708105927430
2577	45	UN-A24-K-080	UN-A24-K-080	3	
2578	27	FCZ1231Z0UC	FCZ1231Z0UC	3	002155FF4BD8
2579	45	UN-A24-K-081	UN-A24-K-081	3	
2580	29	71A306312306	71A306312306	4	6c3b6bd58182
2581	28	ftx1538b0qv	ftx1538b0qv	3	708105926fae
2582	45	UN-A24-K-082	UN-A24-K-082	3	
2408	13	002722E6EC97	002722E6EC97	3	002722E6EC97
2583	28	ftx1538b0pq	ftx1538b0pq	3	708105927384
2584	45	UN-A24-K-083	UN-A24-K-083	3	
2586	45	UN-A24-K-084	UN-A24-K-084	3	
2635	29	71a306c1f72f	71a306c1f72f	4	6c3b6bd581ad
2636	29	71a30642ed7c	71a30642ed7c	4	6c3b6bd7ecbb
2585	28	ftx1537b08c	ftx1537b08c	3	708105927052
2587	28	ftx1538b0xw	ftx1538b0xw	3	708105927218
2588	45	UN-A24-K-085	UN-A24-K-085	3	
2589	28	ftx1537b091	ftx1537b091	3	708105927086
2590	45	UN-A24-K-086	UN-A24-K-086	3	
2591	28	ftx1538b045	ftx1538b045	3	7081059271b0
2592	45	UN-A24-K-087	UN-A24-K-087	3	
2593	28	ftx1538b0pf	ftx1538b0pf	3	7081059273d2
2594	45	UN-A24-K-088	UN-A24-K-088	3	
2595	28	fcz1231z0qh	fcz1231z0qh	3	002155ff4b48
2596	45	UN-A24-K-089	UN-A24-K-089	3	
2597	28	ftx1020b0kg	ftx1020b0kg	3	
2598	45	UN-A24-K-090	UN-A24-K-090	3	
2599	29	71a3067c8a3d	71a3067c8a3d	4	6c3b6bd587fa
2600	29	71A306E305E9	71A306E305E9	4	6C3B6BDA0AD6
2601	29	71A306C4FE88	71A306C4FE88	4	6c3b6bda160a
2602	29	71a306d0c46d	6c3b6bd7520f	4	6c3b6bd7520f
2603	29	71A3069F2943	71A3069F2943	4	6c3b6bdc5d32
2604	29	71a306a418cc	71a306a418cc	4	6c3b6bda0fc1
2637	137	NBHDW17223000032	NBHDW17223000032	1	
2606	29	71a3069c6cbd	71a3069c6cbd	4	6c3b6bda0a3f
2607	29	71a3067ffc86	71a3067ffc86	4	6c3b6bdc57cd
2609	29	71a306da5a6b	71a306da5a6b	4	6c3b6bd7658f
2610	29	71a30644c150	71a30644c150	4	6c3b6bdc62f0
2611	29	71a306074d1c	71a306074d1c	4	6c3b6bdc62fc
2612	29	71a30660c73d	71a30660c73d	4	6c3b6bd7f651
2613	29	71a306505d8c	71a306505d8c	4	6c3b6bda0a0a
2614	29	71a306414cf1	71a306414cf1	4	6c3b6bd76787
2615	45	UN-A24-K-091	UN-A24-K-091	3	
2616	29	71a3068fe52c	71a3068fe52c	4	6c3b6bda1268
2617	29	71a3062e52a8	71a3062e52a8	4	6c3b6bd76613
2618	29	71a3064aa35b	71a3064aa35b	4	6c3b6bd7fa3b
2638	29	71A306B6E319	71A306B6E319	4	6C3B6BDA10F4
2621	29	71b906d20a97	71b906d20a97	4	6c3b6bafb438
2620	29	71a306245eac	71a306245eac	4	6c3b6bda17a2
2622	29	71a3062f5575	71a3062f5575	4	6c3b6bdc562a
2623	45	UN-A24-K-092	UN-A24-K-092	3	
2624	29	71A306F4D97C	71A306F4D97C	4	6c3b6bdc617c
2625	29	71a306d5a5f1	71a306d5a5f1	4	6c3b6bd596fb
2626	29	71a306cfed3c	71a306cfed3c	4	6c3b6bd75bdb
2627	29	71a30626dd2d	71a30626dd2d	4	6c3b6bdc6e24
2628	29	71b906088b22	71b906088b22	4	6c3b6bae82a3
2629	29	71b90640febc	71b90640febc	4	6c3b6bae538c
2630	29	71b9061aa357	71b9061aa357	4	6c3b6bae860a
2631	29	71a306ebd4a5	71a306ebd4a5	4	6c3b6bd582df
2633	11	6872514A495F	6872514A495F	3	6872514A495F
2644	137	NBHD17223000082	NBHD17223000082	1	
2634	29	71a306b8546c	71a306b8546c	4	6c3b6bd75041
2663	11	6872512264BF	6872512264BF	3	6872512264BF
2641	137	UN-3GM-003	UN-3GM-003	1	
2639	137	UN-3GM-001	UN-3GM-001	1	
2642	137	UN-3GM-004	UN-3GM-004	1	
2640	137	UN-3GM-002	UN-3GM-002	1	
2643	137	UN-3GM-005	UN-3GM-005	1	
2645	137	UN-3GM-007	UN-3GM-007	1	
2646	137	UN-3GM-008	UN-3GM-008	1	
2647	137	UN-3GM-009	UN-3GM-009	1	
2649	138	UN-3GM-011	UN-3GM-011	1	
2650	138	UN-3GM-012	UN-3GM-012	1	
2651	138	UN-3GM-013	UN-3GM-013	1	
2652	138	UN-3GM-014	UN-3GM-014	1	
2653	138	UN-3GM-015	UN-3GM-015	1	
2654	138	UN-3GM-016	UN-3GM-016	1	
2655	138	UN-3GM-017	UN-3GM-017	1	
2656	138	UN-3GM-018	UN-3GM-018	1	
2657	138	UN-3GM-019	UN-3GM-019	1	
2658	138	UN-3GM-020	UN-3GM-020	1	
2659	138	UN-3GM-021	UN-3GM-021	1	
2660	138	UN-3GM-022	UN-3GM-022	1	
2661	138	UN-3GM-023	UN-3GM-023	1	
2662	138	UN-3GM-024	UN-3GM-024	1	
2664	11	24A43CA62E23	24A43CA62E23	3	24A43CA62E23
2665	11	68725120E1A4	68725120E1A4	3	68725120E1A4
2666	11	6872514A491D	6872514A491D	3	6872514A491D
2667	11	24A43CA626AC	24A43CA626AC	3	24A43CA626AC
2668	13	002722E6ECBA	002722E6ECBA	3	002722E6ECBA
2669	11	8725120E185	68725120E185	3	68725120E185
2670	11	6872514A48A7	6872514A48A7	3	6872514A48A7
2671	11	6872512264D0	6872512264D0	3	6872512264D0
2673	11	68725144DBAC	68725144DBAC	3	68725144DBAC
2674	11	6872516689D8	6872516689D8	1	6872516689D8
2672	11	687251226568	687251226568	3	687251226568
2619	13	DC9FDB5005BB	DC9FDB5005BB	3	DC9FDB5005BB
1991	13	002722E6ECCA	002722E6ECCA	3	002722E6ECCA
2327	29	71a3061fd10f	71a3061fd10f	4	6c3b6bd759fb
2608	1	F09FC246E3F7	F09FC246E3F7	1	F09FC246E3F7
2675	13	DC9FDBA67D84	DC9FDBA67D84	3	DC9FDBA67D84
2676	16	6872513ED4D3	6872513ED4D3	3	6872513ED4D3
2677	1	F09FC246E335	F09FC246E335	1	F09FC246E335
2678	1	F09FC246E19D	F09FC246E19D	1	F09FC246E19D
2679	1	802AA87AF92D	802AA87AF92D	1	802AA87AF92D
2680	29	71a306185640	71a306185640	4	6c3b6bdc6f62
2681	29	71a306aacded	71a306aacded	4	6c3b6bda1568
2682	1	F09FC246EC89	F09FC246EC89	1	F09FC246EC89
2683	1	F09FC246E491	F09FC246E491	1	F09FC246E491
2684	1	F09FC246E33C	F09FC246E33C	1	F09FC246E33C
2685	29	71a3061318dc	71a3061318dc	4	6c3b6bd59851
2686	29	71a3063c9ebf	71a3063c9ebf	4	6c3b6bda1538
2687	29	71a3060cf4b0	71a3060cf4b0	4	6c3b6bd75815
2751	29	71A306F9398B	71A306F9398B	4	6C3B6BD74FDB
2689	29	71A306225740	71A306225740	4	6C3B6BD7F0E6
2690	29	71A3066FCCE6	71A3066FCCE6	4	6C3B6BDC6379
2691	29	71B9062C9C24	71B9062C9C24	4	6C3B6BAE84B3
2692	29	71A30649A7EF	71A30649A7EF	4	BC3B6BPC5PFD
2693	29	71A3060A01C3	71A3060A01C3	4	BC3B6BD755DE
2694	29	71A306B40412	71A306B40412	4	6C3B6BD7F0B6
2695	29	71a306772f03	71a306772f03	4	6c3b6bdc6662
2696	29	71a3067768ef	71a3067768ef	4	6c3b6bdc697a
2697	29	71a306d0ce7a	71a306d0ce7a	4	6c3b6bdc674c
2698	29	71b9065f4d83	71b9065f4d83	4	6c3b6b86ee33
2699	45	UN-A24-K-093	UN-A24-K-093	3	
2700	29	71a306f259ee	71a306f259ee	4	6c3b6bdc67dc
2701	45	UN-A24-K-094	UN-A24-K-094	3	
2702	29	71b90655120f	71b90655120f	4	6c3b6bafb420
2703	29	71a3062a8bc3	71a3062a8bc3	4	6c3b6b075f83
2704	29	71b9067f0388	71b9067f0388	4	6c3b6bafb318
2705	29	71a3067112d4	71a3067112d4	4	6c3b6bd7ebef
2706	29	71a306758f74	71a306758f74	4	6c3b6bda1868
2707	29	71a30677a6ed	71a30677a6ed	4	6c3b6bda16d6
2708	29	71b9067d3598	71b9067d3598	4	6c3b6bae519a
2709	45	UN-A24-K-095	UN-A24-K-095	3	
2710	29	71a306a530be	71a306a530be	4	6c3b6bd75fbf
2711	29	71a306cc5b6d	71a306cc5b6d	4	6c3b6bda162e
2712	29	71b906d35f38	71b906d35f38	4	6c3b6bae5266
2713	29	71b906a8f6f8	71b906a8f6f8	4	6c3b6bae83ac
2714	29	71a306a57dd5	71a306a57dd5	4	6c3b6bd7f4b3
2715	29	71a306173981	71a306173981	4	6c3b6bd7f2d3
2716	29	71a306c1f3d0	71a306c1f3d0	4	6c3b6bdc568f
2717	29	71a30623059b	71a30623059b	4	6c3b6bd76792
2718	29	71a306069e67	71a306069e67	4	6c3b6bd59898
2719	29	71a3062de1de	71a3062de1de	4	6c3b6bd7eeee
2648	138	G9W9K14807000166	G9W9K14807000166	1	
2720	29	71A3068DA8AF	71A3068DA8AF	4	6C3B6BDA1447
2721	138	g9w9k14807000150	g9w9k14807000150	1	
2688	29	71a306ec196f	71a306ec196f	4	
2722	29	71b906fa7565	71b906fa7565	4	6c3b6bafb2ab
2752	29	71a30684649a	71a30684649a	4	6C3B6BDA1988
2724	45	UN-A24-K-096	UN-A24-K-096	3	
2723	25	FCZ1231Z0UM	FCZ1231Z0UM	3	002155FF4B6F
2725	28	FTX1537B08H	FTX1537B08H	3	708105927110
2726	45	UN-A24-K-097	UN-A24-K-097	3	
2727	29	71A306145A3E	71A306145A3E	4	6C3B6BD7F60F
2728	29	71B9067BA974	71B9067BA974	4	6C3B6BAE8550
2729	29	71A306DA59EA	71A306DA59EA	4	6C3B6BD75F53
2730	29	71a3069cb572	71a3069cb572	4	6c3b6bda18d4
2731	29	71a3064333fe	71a3064333fe	4	6c3b6bd75f3b
2732	29	71b906b1eb26	71b906b1eb26	4	6c3b6b86ee93
2733	29	71b906bbb4aa	71b906bbb4aa	4	6c3b6baf8480
2734	29	71a3062fed17	71a3062fed17	4	6c3b6bda1808
2735	29	71a306978f27	71a306978f27	4	6c3b6bdc67ca
2736	29	71b90677859b	71b90677859b	4	6c3b6bafb4b0
2737	29	71a30656dc56	71a30656dc56	4	6c3b6bd58fd5
2738	29	71b906169e43	71b906169e43	4	6c3b6bafb431
2739	29	71b906fe1e65	71b906fe1e65	4	6c3b6b86edf7
2740	29	71a306f1c65e	71a306f1c65e	4	6c3b6bda18e6
2741	29	71a30641227d	71a30641227d	4	6c3b6bdc608c
2742	29	71a306694ce4	71a306694ce4	4	6c3b6bd7f483
2743	31	23210456420 	23210456420	3	0023d301f5f2
2744	45	UN-A24-K-098	UN-A24-K-098	3	
2753	29	71A3068F90CD	71A3068F90CD	4	6C3B6BDA193A
2204	1	F09FC246ECD7	F09FC246ECD7	1	F09FC246ECD7
2745	45	UN-A24-K-099	UN-A24-K-099	3	
2746	45	UN-A24-K-100	UN-A24-K-100	3	
2747	29	71a306c9184f	71a306c9184f	4	6c3b6bd75629
2749	29	71A3069CC635	71A3069CC635	4	6C3B6BD7EC55
2750	29	71A306402F27	71A306402F27	4	6C3B6BD7F4A1
2754	29	71B9069A728C	71B9069A728C	4	6C3B6BAFB486
2748	29	71a3065ef66b	71a3065ef66b	4	6c3b6bd591c1
2755	29	71a30645be05	71a30645be05	4	6c3b6bd58123
2756	29	71a30628c9d6	71a30628c9d6	4	6c3b6bdc5636
2757	29	71a306a2c807	71a306a2c807	4	6c3b6bd75737
2758	29	71b90661d715	71b90661d715	4	6c3b6b86ecb3
2759	29	71a3061dd1e7	71a3061dd1e7	4	6c3b6bd7f4dd
2760	29	71a306c8587e	71a306c8587e	4	6c3b6bdc6908
2761	29	71a30667070e	71a30667070e	4	6c3b6bd75e87
2762	29	71a3061e22bf	71a3061e22bf	4	6c3b6bdc5c06
2763	29	71b906b9a14c	71b906b9a14c	4	6c3b6bae518e
2765	29	71b906a0531d	71b906a0531d	4	6c3b6bae8388
2766	29	71b906a543c1	71b906a543c1	4	6c3b6b86eca7
2768	31	23210268665	23210268665	3	0023d301f23b
2767	13	002722ee7fab	002722ee7fab	1	002722ee7fab
2764	13	dc9fdb500668	dc9fdb500668	1	dc9fdb500668
2769	45	UN-A24-K-101	UN-A24-K-101	3	
2770	31	23210456378	23210456378	3	0023d301f59d
2771	45	UN-A24-K-102	UN-A24-K-102	3	
2772	31	23210456387	23210456387	3	0023d301f5af
2773	45	UN-A24-K-103	UN-A24-K-103	3	
2774	31	23210268659	23210268659	3	0023d301f230
2775	45	UN-A24-K-104	UN-A24-K-104	3	
2776	31	23210268658	23210268658	3	0023d301f22d
2777	45	UN-A24-K-105	UN-A24-K-105	3	
2778	29	71a3061e5f3c	71a3061e5f3c	4	6c3b6bda1976
2829	29	71a306d4200d	71a306d4200d	4	6c3b6bd7f11d
2780	31	23210268256	23210268256	3	0023d301ef08
2830	29	71a30600f2d9	71a30600f2d9	4	6c3b6bd7f43b
2781	45	UN-A24-K-106	UN-A24-K-106	3	
2831	29	71a306317878	71a306317878	4	6c3b6bd7551b
2782	31	23210456384	23210456384	3	0023d301f5a9
2783	45	UN-A24-K-107	UN-A24-K-107	3	
2784	31	23210268652	23210268652	3	
2785	28	FTX1538B0XX	FTX1538B0XX	3	708105927226
2786	31	23210268653	23210268653	3	0023d301f223
2832	29	71a306a65301	71a306a65301	4	6c3b6bd75b63
2833	29	71a306118b1e	 71a306118b1e	4	6c3b6bd7f039
2787	45	UN-A24-K-108	UN-A24-K-108	3	
2788	31	23210456328	23210456328	3	0023d301f538
2789	45	UN-A24-K-109	UN-A24-K-109	3	
2790	27	fcz1231z0p6	fcz1231z0p6	3	002155ff4c4f
2791	28	ftx1539b032	ftx1539b032	3	708105926a22
2834	29	71a306316983	71a306316983	4	6c3b6bd756dd
2793	28	ftx1539b035	ftx1539b035	3	708105926b2c
2835	29	71a306c385c8	71a306c385c8	4	6c3b6bd75b75
2795	24	ftx1539u07t	ftx1539u07t	3	7081053a77d2
2796	29	71a3061db6ec	71a3061db6ec	4	6c3b6bdc57c2
2797	45	UN-A24-K-112	UN-A24-K-112	3	
2798	29	71a306058550	71a306058550	4	6c3b6bd74fa5
2799	29	71a30676625b	71a30676625b	4	6c3b6bd581fb
2800	29	71a3069c09ef	71a3069c09ef	4	6c3b6bd581d1
2801	29	71a306ea24bb	71a306ea24bb	4	6c3b6bd7ee6b
2802	29	71a306c11184	71a306c11184	4	6c3b6bd74fb1
2803	29	71a306c99d10	71a306c99d10	4	6c3b6bd7ec0d
2804	29	71a3060678cc	71a3060678cc	4	6c3b6bd7568f
2805	29	71a306202249	71a306202249	4	6c3b6bd75695
2806	29	71b9064290c9	71b9064290c9	4	6c3b6bae522a
2807	29	71a3066f43ae	71a3066f43ae	4	6c3b6bd7ec13
2808	45	UN-A24-K-113	UN-A24-K-113	3	
2809	29	71a306a62cf7	71a306a62cf7	4	6c3b6bdc6572
2810	29	71a3061d7a27	71a3061d7a27	4	6c3b6bd591cd
2811	29	71a306054d64	71a306054d64	4	6c3b6bd75e8d
2812	29	71A3069E127B		4	6c3b6bd58b25
2813	29	71a306211709	71a306211709	4	6c3b6bd7f3b1
2814	29	71a306686248	71a306686248	4	6c3b6bdc6772
2815	45	UN-A24-K-114	UN-A24-K-114	3	
2816	29	71a306e111dd	71a306e111dd	4	6c3b6bd76139
2817	29	71a306904f84	71a306904f84	4	6c3b6bd75e4b
2818	29	71a3065d0c19	71a3065d0c19	4	6c3b6bd7f447
2819	29	71a3066464b1	71a3066464b1	4	6c3b6bd75a5b
2820	29	71a306cfb642	71a306cfb642	4	6c3b6bd58fbd
2821	45	UN-A24-K-115	UN-A24-K-115	3	
2822	29	71a30634d52f	71a30634d52f	4	6c3b6bdc57e0
2823	29	71a306d50897	71a306d50897	4	6c3b6bda0638
2824	29	71a3060fb778	71a3060fb778	4	6c3b6bd76199
2825	29	71A306E7A955	71A306E7A955	4	6C3B6BDC5690
2826	29	71A306CF98DB	71A306CF98DB	4	6C3B6BD75089
2794	45	UN-A24-K-111	UN-A24-K-111	3	
2792	45	UN-A24-K-110	UN-A24-K-110	3	
2827	29	71a306e2f4bc	71a306e2f4bc	4	6c3b6bd7e51d
2828	29	71a30671af4a	71a30671af4a	4	6c3b6bd58171
2836	29	71a3065afe27	71a3065afe27	4	6c3b6bd757db
2837	29	71a3068a382d	71a3068a382d	4	6c3b6bd74f99
2838	29	71a3062e073e	71a3062e073e	4	6c3b6bd75016
2317	29	71a3062a3c37	71a3062a3c37	4	6c3b6bda1e3e
2839	45	UN-A24-K-116	UN-A24-K-116	3	
2840	13	DC9FDB500670	DC9FDB500670	3	
2841	29	71A3061D6C32	71A3061D6C32	4	6C3B6BD7EEA7
2842	29	71B90695CE2D	71B90695CE2D	4	6C3B6B86ECE9
2843	29	71A306770CF5	71A306770CF5	4	6C3B6BDC61EE
2844	29	71a306ddba2f	71a306ddba2f	4	6c3b6bd7f009
2845	29	71A306246CA1	71A306246CA1	4	6C3B6BDA13E8
2846	29	71A306E87E66	71A306E87E66	4	6C3B6BDA1454
2847	48	UN-AO15-K-105	UN-AO15-K-105	3	
\.


--
-- Name: Item_Item_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Item_Item_ID_seq"', 2847, true);


--
-- Data for Name: Item_Mode; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Item_Mode" ("Item_Mode_ID", "Item_Mode_Name") FROM stdin;
1	AP
2	Client
3	P2P-Link
\.


--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Item_Mode_Item_Mode_ID_seq"', 5, true);


--
-- Data for Name: Item_Status; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Item_Status" ("Item_Status_ID", "Item_Status_Name") FROM stdin;
1	Աշխատում է
2	Չի աշխատում
3	Վերանորոգման
4	Դուրս գրված
7	Նոր
\.


--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Item_Status_Item_Status_ID_seq"', 7, true);


--
-- Data for Name: Item_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Item_Type" ("Item_Type_ID", "Item_Type_Name") FROM stdin;
1	Wireless Modem
2	Router
3	3G Router
4	Wireless Router
5	Antena
6	SDSL Modem
7	UPS
8	Switch
9	ADSL Router
11	DSL Pool
12	3G/4G Modem
\.


--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Item_Type_Item_Type_ID_seq"', 12, true);


--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Location" ("Location_ID", "Device_Name", "PhysicalConnected_Item_ID", "From_Site_ID", "To_Site_ID", "Item_Status_ID", "Start_Date", "End_Date", "Item_IP_Address", "Item_Mode_ID", "Item_SSID", "Technician_ID", "Assigner_ID", "Transfer_Status_ID", "Description", "Item_ID") FROM stdin;
1	geghadirkotayq	3	\N	478	1	2017-07-13	\N	10.205.140.200	2	DeghtsutRocket	9	3	2		1
2		1	\N	478	1	2017-07-13	\N		\N		9	3	2		3
6	Artimet	\N	\N	911	1	2017-07-13	\N	10.205.138.146	2	ZVTS_AP	8	3	2		6
8	Geghakert Dproc	\N	\N	926	1	2017-07-13	\N	10.205.133.47	2	HF_Aghavnatun	8	3	2		8
9	Geghakert Dproc	\N	\N	926	1	2017-07-13	\N	91.205.133.47	\N		8	3	2		9
10	Metsamor Vil	\N	\N	936	1	2017-07-13	\N	10.205.138.158	2	ZVTS_AP	8	3	2		10
11	Metsamor Vil	\N	\N	936	1	2017-07-13	\N	91.205.138.158	\N		8	3	2		11
12	Jrarat	\N	\N	942	1	2017-07-13	\N	10.205.138.134	2	Yerasxahun_Omni	8	3	2		12
13	Jrarat	\N	\N	942	1	2017-07-13	\N	91.205.138.134	\N		8	3	2		13
16		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		16
18		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		18
27		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		27
30		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		30
32		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		32
33		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		33
34		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		34
35		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		35
36		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		36
37		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		37
38		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		38
39		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		39
40		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		40
41		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		41
42		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		42
43		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		43
44		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		44
45		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		45
46		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		46
47		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		47
48		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		48
49		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		49
50		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		50
51		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		51
52		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		52
53		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		53
54		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		54
55		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		55
56		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		56
57		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		57
58		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		58
59		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		59
60		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		60
66		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		66
67		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		67
68		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		68
69		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		69
70		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		70
71		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		71
72		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		72
73		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		73
74		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		74
75		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		75
76		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		76
77		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		77
78		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		78
79		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		79
80		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		80
81		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		81
82		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		82
83		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		83
84		\N	\N	1664	\N	2017-07-17	2017-07-30		\N		5	3	2		84
91		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		91
86		\N	\N	1664	\N	2017-07-17	2017-09-02		\N		5	3	2		86
89		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		89
87		\N	\N	1664	\N	2017-07-17	2017-08-19		\N		5	3	2		87
85		\N	\N	1664	\N	2017-07-17	2017-09-02		\N		5	3	2		85
62		\N	\N	1664	\N	2017-07-17	2017-09-01		\N		5	3	2		62
96		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		96
94		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		94
93		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		93
97		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		97
63		\N	\N	1664	\N	2017-07-17	2017-09-18		\N		5	3	2		63
88		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		88
92		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		92
100		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		100
95		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		95
99		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		99
3	geghadirkotayq	\N	\N	478	1	2017-07-13	\N	91.205.140.200	\N		9	3	2		2
5	hacavan	\N	\N	486	1	2017-07-13	\N	91.205.140.203	\N		9	3	2		5
7	Artimet	\N	\N	911	1	2017-07-13	\N	91.205.138.146	\N		8	3	2		7
4	hacavan	\N	\N	486	1	2017-07-13	\N	10.20.140.203	2	Hf_Bardzrashen_sector	9	3	2		4
23		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		23
90		\N	\N	1664	1	2017-07-17	2017-10-12		\N		7	3	2		90
20		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		20
21		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		21
22		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		22
29		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		29
24		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		24
25		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		25
31		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		31
28		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		28
26		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		26
14		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		14
17		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		17
15		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		15
105		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		105
106		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		106
107		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		107
108		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		108
109		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		109
110		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		110
111		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		111
112		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		112
113		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		113
114		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		114
115		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		115
116		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		116
117		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		117
118		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		118
119		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		119
120		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		120
121		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		121
122		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		122
123		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		123
152		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		152
153		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		153
155		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		155
156		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		156
157		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		157
158		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		158
159		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		159
160		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		160
161		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		161
162		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		162
163		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		163
164		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		164
165		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		165
166		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		166
167		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		167
168		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		168
169		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		169
170		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		170
171		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		171
172		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		172
173		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		173
174		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		174
175		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		175
176		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		176
177		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		177
178		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		178
179		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		179
180		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		180
181		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		181
182		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		182
183		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		183
184		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		184
185		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		185
186		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		186
187		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		187
188		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		188
197		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		197
198		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		198
199		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		199
202		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		202
203		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		203
204		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		204
205		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		205
193		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		193
189		\N	\N	1664	\N	2017-07-16	2017-08-19		\N		5	3	2		189
124		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		124
195		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		195
192		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		192
139		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		139
102		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		102
206		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		206
207		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		207
196		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		196
141		\N	\N	1664	1	2017-07-16	2017-09-11		\N		5	3	2		141
194		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		194
191		\N	\N	1664	1	2017-07-16	2017-09-11		\N		5	3	2		191
144		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		144
147		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		147
145		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		145
190		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		190
138		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		138
135		\N	\N	1664	2	2017-07-17	\N		\N		5	3	2		135
126		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		126
132		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		132
134		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		134
143		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		143
140		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		140
137		\N	\N	1664	\N	2017-07-17	2017-09-24		\N		5	3	2		137
130		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		130
101		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		101
133		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		133
127		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		127
103		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		103
129		\N	\N	1664	\N	2017-07-17	2017-09-25		\N		5	3	2		129
136		\N	\N	1664	\N	2017-07-17	2017-10-05		\N		5	3	2		136
146		\N	\N	1664	\N	2017-07-17	2017-09-14		\N		5	3	2		146
125		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		125
148		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		148
150		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		150
154		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		154
151		\N	\N	1664	\N	2017-07-17	2017-10-27		\N		5	3	2		151
211		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		211
214		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		214
216		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		216
219		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		219
222		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		222
229		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		229
253		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		253
254		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		254
255		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		255
256		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		256
257		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		257
258		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		258
259		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		259
260		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		260
261		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		261
262		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		262
263		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		263
264		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		264
265		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		265
266		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		266
267		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		267
268		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		268
269		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		269
270		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		270
271		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		271
272		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		272
273		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		273
274		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		274
275		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		275
276		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		276
277		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		277
278		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		278
279		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		279
280		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		280
281		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		281
282		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		282
283		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		283
284		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		284
285		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		285
286		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		286
287		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		287
291		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		291
292		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		292
293		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		293
294		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		294
295		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		295
296		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		296
251		\N	\N	1664	\N	2017-08-24	2017-10-23		\N		5	3	2		251
209		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		209
245		\N	\N	1664	\N	2017-08-24	\N		\N		5	3	2		245
250		\N	\N	1664	\N	2017-08-24	\N		\N		5	3	2		250
208		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		208
299		\N	\N	1664	\N	2017-08-24	\N		\N		5	3	2		299
221		\N	\N	1664	\N	2017-07-17	2017-09-19		\N		5	3	2		221
224		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		224
300		\N	\N	1664	\N	2017-08-24	2017-09-12		\N		5	3	2		300
305		\N	\N	1664	\N	2017-08-24	\N		\N		5	3	2		305
223		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		223
311		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		311
210		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		210
234		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		234
213		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		213
212		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		212
312		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		312
289		\N	\N	1664	\N	2017-07-17	2017-09-06		\N		5	3	2		289
215		\N	\N	1664	\N	2017-07-17	2017-09-02		\N		5	3	2		215
314		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		314
217		\N	\N	1664	\N	2017-07-17	2017-09-06		\N		5	3	2		217
218		\N	\N	1664	\N	2017-07-17	2017-09-05		\N		5	3	2		218
220		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		220
288		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		288
297		\N	\N	1664	\N	2017-07-17	2017-09-24		\N		5	3	2		297
298		\N	\N	1664	\N	2017-07-17	2017-09-24		\N		5	3	2		298
306		\N	\N	1664	\N	2017-08-24	2017-09-11		\N		5	3	2		306
313		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		313
252		\N	\N	1664	\N	2017-08-24	2017-10-23		\N		5	3	2		252
303		\N	\N	1664	\N	2017-08-24	2017-09-12		\N		5	3	2		303
301		\N	\N	1664	\N	2017-08-24	2017-09-10		\N		5	3	2		301
290		\N	\N	1664	\N	2017-07-17	2017-09-10		\N		5	3	2		290
302		\N	\N	1664	\N	2017-08-24	2017-09-12		\N		5	3	2		302
304		\N	\N	1664	\N	2017-08-24	2017-09-12		\N		5	3	2		304
315		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		315
316		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		316
317		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		317
318		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		318
328		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		328
329		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		329
330		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		330
331		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		331
335		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		335
339		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		339
366		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		366
367		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		367
368		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		368
369		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		369
370		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		370
371		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		371
372		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		372
373		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		373
374		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		374
375		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		375
376		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		376
377		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		377
378		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		378
379		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		379
380		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		380
381		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		381
382		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		382
383		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		383
384		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		384
386		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		386
387		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		387
388		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		388
389		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		389
390		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		390
391		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		391
392		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		392
393		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		393
394		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		394
395		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		395
396		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		396
397		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		397
398		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		398
399		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		399
400		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		400
401		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		401
402		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		402
403		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		403
404		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		404
405		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		405
406		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		406
407		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		407
408		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		408
409		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		409
410		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		410
411		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		411
412		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		412
413		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		413
414		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		414
415		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		415
416		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		416
417		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		417
418		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		418
419		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		419
420		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		420
421		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		421
320		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		320
322		\N	\N	1664	\N	2017-07-17	2017-08-31		\N		5	3	2		322
355		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		355
359		\N	\N	1664	\N	2017-07-17	2017-10-19		\N		5	3	2		359
336		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		336
321		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		321
354		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		354
337		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		337
345		\N	\N	1664	\N	2017-07-17	2017-09-19		\N		5	3	2		345
348		\N	\N	1664	\N	2017-07-17	2017-09-21		\N		5	3	2		348
338		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		338
333		\N	\N	1664	1	2017-08-23	2017-09-11		\N		5	3	2		333
353		\N	\N	1664	1	2017-07-16	2017-10-19		\N		9	3	2		353
361		\N	\N	1664	1	2017-07-16	\N		\N		9	3	1		361
346		\N	\N	1664	1	2017-07-16	2017-10-13		\N		9	3	2		346
357		\N	\N	1664	1	2017-09-25	\N		\N		9	3	1		357
352		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		352
356		\N	\N	1664	\N	2017-07-17	2017-10-04		\N		5	3	2		356
342		\N	\N	1664	\N	2017-07-17	2017-10-05		\N		5	3	2		342
347		\N	\N	1664	\N	2017-07-17	2017-10-05		\N		5	3	2		347
334		\N	\N	1664	\N	2017-07-17	2017-10-09		\N		5	3	2		334
349		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		349
362		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		362
364		\N	\N	1664	1	2017-07-17	2017-10-12		\N		7	3	2		364
351		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		351
365		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		365
360		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		360
363		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		363
350		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		350
358		\N	\N	1664	\N	2017-07-17	2017-10-16		\N		5	3	2		358
332		\N	\N	1664	\N	2017-08-24	2017-10-18		\N		5	3	2		332
385		\N	\N	1664	\N	2017-07-17	2017-10-20		\N		5	3	2		385
422		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		422
423		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		423
424		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		424
425		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		425
430		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		430
431		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		431
432		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		432
433		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		433
434		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		434
435		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		435
436		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		436
437		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		437
438		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		438
443		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		443
444		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		444
445		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		445
446		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		446
447		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		447
448		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		448
449		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		449
450		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		450
451		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		451
452		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		452
453		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		453
454		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		454
455		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		455
456		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		456
457		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		457
458		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		458
459		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		459
464		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		464
465		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		465
483		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		483
490		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		490
497		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		497
498		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		498
499		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		499
500		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		500
501		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		501
502		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		502
503		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		503
504		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		504
505		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		505
506		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		506
507		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		507
509		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		509
510		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		510
511		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		511
512		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		512
513		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		513
514		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		514
515		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		515
516		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		516
517		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		517
519		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		519
521		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		521
522		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		522
525		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		525
526		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		526
528		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		528
428		\N	\N	1664	\N	2017-07-17	2017-08-30		\N		5	3	2		428
486		\N	\N	1664	\N	2017-07-17	2017-08-30		\N		5	3	2		486
485		\N	\N	1664	1	2017-07-16	2017-08-30		\N		5	3	2		485
427		\N	\N	1664	\N	2017-07-17	2017-09-06		\N		5	3	2		427
523		\N	\N	1664	\N	2017-07-17	2017-10-09		\N		5	3	2		523
466		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		466
491		\N	\N	1664	\N	2017-07-17	2017-09-10		\N		5	3	2		491
493		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		493
518		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		518
429		\N	\N	1664	\N	2017-07-17	2017-09-06		\N		5	3	2		429
524		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		524
489		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		489
477		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		477
426		\N	\N	1664	\N	2017-07-17	2017-10-02		\N		5	3	2		426
475		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		475
527		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		527
473		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		473
469		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		469
463		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		463
481		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		481
482		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		482
460		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		460
468		\N	\N	1664	\N	2017-07-17	2017-09-20		\N		5	3	2		468
496		\N	\N	1664	\N	2017-07-17	2017-09-20		\N		5	3	2		496
470		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		470
487		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		487
474		\N	\N	1664	\N	2017-07-17	2017-10-09		\N		5	3	2		474
520		\N	\N	1664	1	2017-07-17	2017-10-09		\N		5	3	2		520
484		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		484
467		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		467
479		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		479
472		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		472
492		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		492
494		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		494
461		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		461
495		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		495
471		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		471
478		\N	\N	1664	\N	2017-07-17	2017-10-26		\N		5	3	2		478
529		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		529
532		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		532
534		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		534
535		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		535
540		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		540
544		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		544
545		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		545
546		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		546
550		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		550
553		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		553
556		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		556
559		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		559
561		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		561
564		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		564
565		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		565
566		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		566
567		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		567
568		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		568
569		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		569
570		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		570
571		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		571
572		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		572
573		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		573
574		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		574
575		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		575
576		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		576
577		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		577
578		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		578
579		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		579
580		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		580
581		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		581
582		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		582
583		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		583
584		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		584
585		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		585
586		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		586
587		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		587
588		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		588
589		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		589
590		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		590
591		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		591
592		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		592
593		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		593
594		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		594
595		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		595
596		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		596
597		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		597
598		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		598
599		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		599
600		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		600
601		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		601
602		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		602
603		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		603
604		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		604
605		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		605
606		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		606
607		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		607
608		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		608
609		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		609
610		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		610
611		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		611
612		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		612
613		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		613
614		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		614
615		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		615
616		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		616
617		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		617
618		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		618
619		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		619
620		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		620
621		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		621
622		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		622
623		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		623
624		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		624
625		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		625
626		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		626
627		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		627
628		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		628
629		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		629
630		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		630
631		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		631
632		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		632
633		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		633
634		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		634
635		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		635
562		\N	\N	1664	\N	2017-07-17	2017-10-09		\N		5	3	2		562
560		\N	\N	1664	\N	2017-07-17	2017-08-22		\N		5	3	2		560
563		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		563
558		\N	\N	1664	\N	2017-07-17	2017-09-11		\N		5	3	2		558
543		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		543
538		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		538
541		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		541
530		\N	\N	1664	\N	2017-07-17	2017-09-13		\N		5	3	2		530
555		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		555
531		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		531
557		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		557
539		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		539
536		\N	\N	1664	1	2017-07-17	2017-10-09		\N		5	3	2		536
554		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		554
549		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		549
547		\N	\N	1664	\N	2017-07-17	2017-10-18		\N		5	3	2		547
537		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		537
639		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		639
640		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		640
641		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		641
642		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		642
643		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		643
644		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		644
645		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		645
646		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		646
647		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		647
648		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		648
649		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		649
650		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		650
651		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		651
652		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		652
653		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		653
654		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		654
655		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		655
656		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		656
657		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		657
658		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		658
659		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		659
660		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		660
661		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		661
662		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		662
663		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		663
664		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		664
665		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		665
666		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		666
667		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		667
668		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		668
669		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		669
670		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		670
671		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		671
672		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		672
673		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		673
677		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		677
678		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		678
679		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		679
680		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		680
681		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		681
682		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		682
683		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		683
684		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		684
685		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		685
687		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		687
688		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		688
689		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		689
690		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		690
691		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		691
692		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		692
693		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		693
694		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		694
695		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		695
696		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		696
697		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		697
698		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		698
699		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		699
700		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		700
701		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		701
702		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		702
703		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		703
704		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		704
705		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		705
706		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		706
707		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		707
708		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		708
709		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		709
710		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		710
711		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		711
712		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		712
713		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		713
714		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		714
715		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		715
716		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		716
717		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		717
718		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		718
719		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		719
720		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		720
721		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		721
722		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		722
723		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		723
724		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		724
725		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		725
726		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		726
727		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		727
728		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		728
729		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		729
730		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		730
731		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		731
732		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		732
733		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		733
734		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		734
735		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		735
736		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		736
737		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		737
738		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		738
739		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		739
740		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		740
741		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		741
742		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		742
637		\N	\N	1664	\N	2017-07-17	2017-09-02		\N		5	3	2		637
636		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		636
743		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		743
744		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		744
745		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		745
746		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		746
747		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		747
748		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		748
749		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		749
750		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		750
751		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		751
752		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		752
753		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		753
754		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		754
755		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		755
756		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		756
760		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		760
763		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		763
764		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		764
765		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		765
766		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		766
767		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		767
768		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		768
769		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		769
770		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		770
771		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		771
772		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		772
773		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		773
774		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		774
775		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		775
776		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		776
777		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		777
778		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		778
779		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		779
780		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		780
781		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		781
782	pyunik	\N	\N	460	1	2017-07-19	\N	10.205.140.55	2	MeghradzorOmni	9	3	2		782
783	pyunik	\N	\N	460	1	2017-07-19	\N	91.205.140.55	\N		9	3	2		783
784	Fantan Dproc	\N	\N	1303	1	2017-07-19	\N	10.207.133.171	2	HF_Fantan	9	3	2		784
785	Fantan Dproc	\N	\N	1303	1	2017-07-19	\N	91.207.133.171	\N		9	3	2		785
786	katnaaghbyur	\N	\N	483	1	2017-07-19	\N	91.205.140.12	\N		9	3	2		786
787		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		787
788		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		788
789		\N	\N	1664	\N	2017-07-17	\N		\N		5	3	2		789
757		\N	\N	1664	\N	2017-07-17	2017-08-18		\N		5	3	2		757
809	Aygevan	\N	\N	885	1	2017-08-02	\N	91.205.133.7	\N		7	3	2		810
812	shorja	\N	\N	375	1	2017-08-02	\N	10.205.141.44	2	TsovazardHF	9	3	2		813
813	shorja	\N	\N	375	1	2017-08-02	\N		\N		9	3	2		814
814	shorja	\N	\N	375	1	2017-08-02	\N	91.205.141.44	\N		9	3	2		815
815	Vahan	\N	\N	377	1	2017-08-01	\N	10.205.141.55	2	VahanOmni	9	3	2		816
816	Vahan	\N	\N	377	1	2017-08-01	\N	91.205.141.55	\N		9	3	2		817
798	Araks	\N	\N	886	1	\N	\N	10.205.133.9	2	Srdbad_AP2	7	3	2		800
800	Amasia(Armavir)	\N	\N	894	1	2017-08-02	\N	10.205.133.10	2	Srdbad_AP2	7	3	2		802
802	Artashar	\N	\N	876	1	2017-08-02	\N	10.205.133.23	2	Mmor_AP3	7	3	2		804
803	Artashar	\N	\N	876	1	2017-08-02	\N		\N		7	3	2		805
804	Artashar	\N	\N	876	1	2017-08-02	\N	91.205.133.23	\N		7	3	2		806
805	Arazap	\N	\N	873	1	2017-08-02	\N	10.205.138.155	2	Yerasxahun_Omni	7	3	2		807
806	Arazap	\N	\N	873	1	2017-08-02	\N	91.205.138.155	\N		7	3	2		808
807	Aygevan	\N	\N	885	1	2017-08-02	\N	10.205.133.7	2	Hf_Armavir_Ap2	7	3	2		809
823	vanevan	\N	\N	1030	1	2017-08-01	\N	91.205.134.81	\N		9	3	2		824
824	eranos1	\N	\N	989	1	2017-08-02	\N	10.205.134.30	2	MtuniSector2	9	3	2		825
825	eranos1	\N	\N	989	1	2017-08-02	\N	91.205.134.30	\N		9	3	2		826
826	geghaqar	\N	\N	336	1	2017-08-02	\N	10.205.134.87	2	AzpunkHF	9	3	2		827
827	geghaqar	\N	\N	336	1	2017-08-02	\N		\N		9	3	2		828
828	areguni	\N	\N	344	1	2017-08-03	\N	10.205.141.3	2	TsovinarBullet	9	3	2		829
829	areguni	\N	\N	344	1	2017-08-03	\N	91.205.141.3	\N		9	3	2		830
830	tsapatagh	\N	\N	345	1	2017-08-03	\N	10.205.134.54	2	ArtanishHF	9	3	2		831
831	eranos1	\N	\N	989	1	2017-08-02	\N		\N		9	3	2		832
832	areguni	\N	\N	344	1	2017-08-03	\N		\N		9	3	2		833
833	tsapatagh	\N	\N	345	1	2017-08-03	\N	91.205.134.54	\N		9	3	2		834
834	yeranos2	\N	\N	990	1	2017-08-03	\N	10.205.134.19	2	MtuniSector2	9	3	2		835
835	yeranos2	\N	\N	990	1	2017-08-03	\N	91.205.134.19	\N		9	3	2		836
836	dzoragyugh2	\N	\N	365	1	2017-08-03	\N	10.205.134.20	2	DzoragyughHF	9	3	2		837
837	dzoragyugh2	\N	\N	365	1	2017-08-03	\N	91.205.134.20	\N		9	3	2		838
838	martuni1	\N	\N	1000	1	2017-08-03	\N	91.205.134.26	\N		9	3	2		839
839	martuni1	\N	\N	1000	1	2017-08-03	\N	10.205.134.26	2	MtuniSector1	9	3	2		840
840	martuni2	\N	\N	1001	1	2017-08-03	\N	10.205.134.25	2	MtuniSector1	9	3	2		841
799	Araks	\N	\N	886	1	2017-08-01	\N	91.205.133.9	\N		7	3	2		801
758		\N	\N	1664	\N	2017-07-17	2017-09-19		\N		5	3	2		758
761		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		761
759		\N	\N	1664	\N	2017-07-17	2017-09-10		\N		5	3	2		759
822	vanevan	\N	\N	323	1	2017-07-31	\N	10.205.134.81	2	VardenisRocket	9	3	2		823
762		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		762
841	martuni2	\N	\N	1001	1	2017-08-03	\N	91.205.134.25	\N		9	3	2		842
898	Abovyan2AramusLink	\N	\N	222	1	2017-08-15	\N	10.207.136.199	2	Abovyan2AramusLink	9	3	2		897
843	veringetashen2	\N	\N	996	1	2017-08-03	\N	10.205.141.21	2	GetashenHF	9	3	2		843
844	veringetashen2	\N	\N	996	1	2017-08-03	\N	91.205.141.21	\N		9	3	2		844
900	Abovyan Omni2	\N	\N	222	1	2017-08-15	\N	10.207.136.201	1	AbovyanOmni2	9	3	2		899
901	Abovyan AP2	\N	\N	222	1	2017-08-15	\N		\N		9	3	2		900
845	vanevan	\N	\N	1664	2	2017-08-01	\N		\N		9	3	2		845
801	Amasia(Armavir)	\N	\N	894	1	2017-08-01	\N	91.205.133.10	\N		7	3	2		803
849	 Armavir Talin Ap Link	\N	\N	42	1	2017-08-14	\N	10.206.133.152	1	 HF_Talin_Link	8	3	2		848
848	 Armavir Sector 90	\N	\N	42	1	2017-08-13	\N	10.207.132.108	1	 Hf_Armavir_Ap2	8	3	2		847
851	 Armavir Sector 120	\N	\N	42	1	2017-08-14	\N	10.207.132.115	1	 Hf_Armavir_AP	8	3	2		850
852	 ArmavirSardarapatLink	\N	\N	42	1	2017-08-14	\N	10.206.133.124	2	 Srdbad5	8	3	2		851
853	ArmavirBagramyanLink	\N	\N	42	1	2017-08-14	\N	10.207.132.103	2	 Baghramyan school	8	3	2		852
854	Armavir build	\N	\N	42	1	2017-08-14	\N		\N		8	3	2		853
855	Armavir build	\N	\N	42	1	2017-08-14	\N		\N		8	3	2		854
857	Armavir build	\N	\N	42	1	2017-08-14	\N		\N		8	3	2		856
858	 SardarapatArmavirLink	\N	\N	197	1	2017-08-14	\N	10.206.133.123	1	 Srdbad5	8	3	2		857
859	 SardarapatRocketOmni	\N	\N	197	1	2017-08-14	\N	10.207.132.109	1	 Srdbad_AP2	8	3	2		858
860	Sardarapat build	\N	\N	197	1	2017-08-14	\N		\N		8	3	2		859
861	BagramyanArmavirLink	\N	\N	904	1	2017-08-14	\N	10.207.132.104	1	Baghramyan school	8	3	2		860
862	BaghramyanBullet	\N	\N	904	1	2017-08-14	\N	10.207.132.114	1	BaghramyanHF	8	3	2		861
863	Baghramyan School AP	\N	\N	904	1	2017-08-14	\N		\N		8	3	2		862
864	MetsamorSwitch	\N	\N	196	1	2017-08-14	\N	10.206.133.117	\N		8	3	2		863
865	 Metsamor_Mayisyan	\N	\N	196	1	2017-08-14	\N	10.207.132.113	1	Mmor_AP2	8	3	2		864
866	Metsamor Nano	\N	\N	196	1	2017-08-14	\N	10.206.133.119	1	Mmor_AP3	8	3	2		865
867	Metsamor Sector	\N	\N	196	1	2017-08-14	\N	10.207.132.110	1	 Hf_Mecamor_AP	8	3	2		866
868	Metsamor build	\N	\N	196	1	2017-08-14	\N		\N		8	3	2		867
869	MetsamorAghavnatun	\N	\N	196	1	2017-08-14	\N	10.206.133.112	1	Aghavnatun_HF	8	3	2		868
870	AghavnatunMetsamor	\N	\N	916	1	2017-08-14	\N	10.206.133.111	2	Aghavnatun_HF	8	3	2		869
871	Aghavnatun sector	\N	\N	916	1	2017-08-14	\N	10.207.132.111	1	HF_Aghavnatun	8	3	2		870
872	Aghavnatun school	\N	\N	916	1	2017-08-14	\N		\N		8	3	2		871
873	Aghavnatun Nano	\N	\N	916	1	2017-08-14	\N	10.206.133.110	1	AghavnatunAP2	8	3	2		872
874	 Vagharshapat  Omni Bullet	\N	\N	40	1	2017-08-14	\N	10.207.132.135	1	EchAP2	8	3	2		873
875	VagharshapatGriboedovLink	\N	\N	40	1	2017-08-14	\N	10.206.133.166	2	Griboedov_hf	8	3	2		874
876	Vagharshapat build	\N	\N	40	1	2017-08-14	\N		\N		8	3	2		875
877	GriboedovVagharshapatLink	\N	\N	927	1	2017-08-14	\N	10.206.133.167	1	Griboedov_hf	8	3	2		876
878	Gribaedov omni	\N	\N	927	1	2017-08-14	\N	10.206.133.168	1	ZVTS_AP	8	3	2		877
879	Griboedov School AP	\N	\N	927	1	2017-08-14	\N		\N		8	3	2		878
880	ZvartnotsSwitch	\N	\N	198	1	2017-08-14	\N	10.206.133.165	\N		8	3	2		879
881	ZvartnotsHF_Rocket	\N	\N	198	1	2017-08-14	\N	10.207.132.136	1	Zvartnots_AP2	8	3	2		880
882	Zvartnots build	\N	\N	198	1	2017-08-14	\N		\N		8	3	2		881
883	ZvartnocAP_Gay	\N	\N	198	1	2017-08-14	\N	10.207.132.142	1	HF_Zvartnoc_Gay	8	3	2		882
884	paraqar-sw	\N	\N	1666	1	2017-08-14	\N		\N		8	3	2		883
885	ParakarMerdzavan	\N	\N	1666	1	2017-08-14	\N	10.207.132.140	1	SiroRocketOmni	8	3	2		884
886	ParakarMusalerAP	\N	\N	1666	1	2017-08-14	\N	10.207.132.112	1	Musaler-Paraqar	8	3	2		885
887	yerashxahun-sw	\N	\N	878	1	2017-08-14	\N	10.207.132.138	\N		8	3	2		886
888	Yerasxahun Omni	\N	\N	878	1	2017-08-14	\N	10.207.132.137	1	 Yerasxahun_Omni	8	3	2		887
889	Yeraskhahun School AP	\N	\N	878	1	2017-08-14	\N		\N		8	3	2		888
890	abovyan1-sw	\N	\N	25	1	2017-08-15	\N	10.207.136.194	\N		9	3	2		889
891	Abovyan Sevaberd Link	\N	\N	25	1	2017-08-15	\N	10.206.135.77	2	AbovSevaberdlink	9	3	2		890
892	Abovyan1Kaputanclient	\N	\N	25	1	2017-08-15	\N	10.207.136.196	2	KaputanAbovyan1Link	9	3	2		891
893	Abovyan1ArtametClient	\N	\N	25	1	2017-08-15	\N	10.206.135.73	2	AbovyanArtametLink	9	3	2		892
894	Abovyan_Byur	\N	\N	25	1	2017-08-15	\N	10.206.135.81	2	AbovByurLink	9	3	2		893
895	Abovyan bullet Omni	\N	\N	25	1	2017-08-15	\N	10.206.135.82	1	ABOVBUL	9	3	2		894
896	Abovyan AP1	\N	\N	25	1	2017-08-15	\N		\N		9	3	2		895
897	abovyan2-sw	\N	\N	222	1	2017-08-15	\N	10.207.136.195	\N		9	3	2		896
906		\N	1664	96	1	2017-08-18	2017-09-07		\N		18	5	2		757
856	Armavir build	\N	\N	42	1	2017-08-14	2017-09-24		\N		8	3	2		855
542		\N	\N	1664	\N	2017-07-17	2017-08-19		\N		5	3	2		542
488		\N	\N	1664	\N	2017-07-17	2017-08-15		\N		5	3	2		488
899	AbovyanAP2_Zar	\N	\N	474	1	2017-08-15	\N	10.207.136.208	2	Zar_Link	9	3	2		898
907	Byureghavan_Abovyan	\N	\N	243	1	2017-08-20	\N	10.206.135.89	1	AbovByurLink	9	3	2		901
908	 ByureghavanAP	\N	\N	243	1	2017-08-20	\N	10.206.135.90	1	ByureghavanHF	9	3	2		902
909	Byureghavan Build	\N	\N	243	1	2017-08-20	\N		\N		9	3	2		903
910	ByurakanArzniAP	\N	\N	243	1	2017-08-20	\N	10.207.136.212	1	ArzniHF	9	3	2		904
850	 Armavir_Partizak_link	\N	\N	42	1	2017-08-14	2017-09-24	10.206.133.116	2	 partizaklink	8	3	2		849
904		\N	1664	1680	1	2017-08-19	\N		\N		\N	5	2		542
911	Zar_AbovyanAP2	\N	\N	1683	1	2017-08-20	\N	10.207.136.209	1	Zar_Link	9	3	2		905
912	Zar_AP	\N	\N	1683	1	2017-08-20	\N	10.207.136.210	1	Zar_HF	9	3	2		906
913	ArtametAbovyan1Link	\N	\N	27	1	2017-08-20	\N	10.206.135.76	1	AbovyanArtametLink	9	3	2		907
914	N.Artamet_RocketOmni	\N	\N	27	1	2017-08-20	\N	10.206.135.85	1	NArtamet_bul	9	3	2		908
915	Nor  Artamet Build AP	\N	\N	27	1	2017-08-20	\N		\N		9	3	2		909
916	Getamej_N.Artamet	\N	\N	28	1	2017-08-20	\N	10.206.135.75	2	NArtamet_bul	9	3	2		910
917	Getamej Build AP	\N	\N	28	1	2017-08-20	\N		\N		9	3	2		911
918	V.PtxniAP	\N	\N	493	1	2017-08-20	\N	10.206.135.87	2	Getargel_HF	9	3	2		912
919	Aramus Omni	\N	\N	474	1	2017-08-20	\N	10.206.135.67	1	AramusHF	9	3	2		913
920	AramusAbovyan2Link	\N	\N	474	1	2017-08-20	\N	10.207.136.200	1	Abovyan2AramusLink	9	3	2		914
921	Aramus School AP	\N	\N	474	1	2017-08-20	\N		\N		9	3	2		915
922	Sevaberd Abovyan Link	\N	\N	26	1	2017-08-20	\N	10.206.135.71	1	AbovSevaberdlink	9	3	2		916
923	Sevaberd Omni	\N	\N	26	1	2017-08-20	\N	10.206.135.70	1	SevaberdHF	9	3	2		917
925	Sevaberd New Tower	\N	\N	26	1	2017-08-20	\N		\N		9	3	2		918
926	KaputanAbovyan1Link	\N	\N	217	1	2017-08-20	\N	10.207.136.197	1	KaputanAbovyan1Link	9	3	2		919
927	KaputanOmni	\N	\N	217	1	2017-08-20	\N	10.207.136.198	1	KaputanOmni	9	3	2		920
928	Kaputan Build AP	\N	\N	217	1	2017-08-20	\N		\N		9	3	2		921
929	charentsavan_hp-sw	\N	\N	22	1	2017-08-20	\N	10.207.133.194	\N		9	3	2		922
930	CharentsavanLinkGyumush	\N	\N	22	1	2017-08-20	\N	10.207.133.197	2	CharentsavanGyumush	9	3	2		923
931	gyumush-sw	\N	\N	23	1	2017-08-20	\N	10.207.133.205	\N		9	3	2		924
932	GyumushCharentsavanLink	\N	\N	23	1	2017-08-20	\N	10.207.133.196	1	CharentsavanGyumush	9	3	2		925
933	GyumushArzakanLink	\N	\N	23	1	2017-08-20	\N	10.207.133.203	1	GyumushArzakanLink	9	3	2		926
934	GyumushBjniLink	\N	\N	23	1	2017-08-20	\N	10.207.133.200	1	BjniGyumushLink	9	3	2		927
935	GyumushOmni	\N	\N	23	1	2017-08-20	\N	10.207.133.198	1	GyumushOmni	9	3	2		928
936	Gyumush Build AP	\N	\N	23	1	2017-08-20	\N		\N		9	3	2		929
937	ArzakanGyumushLink	\N	\N	24	1	2017-08-20	\N	10.207.133.202	2	GyumushArzakanLink	9	3	2		930
938	ArzakanOmni	\N	\N	24	1	2017-08-20	\N	10.207.133.204	1	ArzakanOmni	9	3	2		931
939	Arzakan Build AP	\N	\N	24	1	2017-08-20	\N		\N		9	3	2		932
940	BjniGyumushLink	\N	\N	1684	1	2017-08-20	\N	10.207.133.199	2	BjniGyumushLink	9	3	2		933
941	BjniOmni	\N	\N	1684	1	2017-08-20	\N	10.207.133.201	1	BjniOmni	9	3	2		934
942	Bjni Build AP	\N	\N	1684	1	2017-08-20	\N		\N		9	3	2		935
943	hrazdan_hp-sw	\N	\N	18	1	2017-08-20	\N	10.207.133.162	\N		9	3	2		936
944	Hrazdan Omni Rocket	\N	\N	18	1	2017-08-20	\N	10.207.133.173	1	HrazdanRocket	9	3	2		937
945	HrazdanTV_Micro_Link	\N	\N	18	1	2017-08-20	\N	10.207.133.176	2	TV_Link	9	3	2		938
946	HrazadnTVHrazdanBuldClient	\N	\N	18	1	2017-08-20	\N	10.207.133.165	2	HrazdanBuildHrazdan	9	3	2		939
947	HrazdanTVFantan AP	\N	\N	18	1	2017-08-20	\N	10.207.133.170	1	HF_Fantan	9	3	2		940
948	Hrazdan TV	\N	\N	18	1	2017-08-20	\N		\N		9	3	2		941
949	Micro_LInk	\N	\N	244	1	2017-08-20	\N	10.207.133.175	1	TV_Link	9	3	2		942
950	HrazdanMicroOmni	\N	\N	244	1	2017-08-20	\N	10.207.133.174	1	MicroHF	9	3	2		943
951	Hrazdan Micro Buil AP	\N	\N	244	1	2017-08-20	\N		\N		9	3	2		944
952	HrazdanBuildHrazdanTVLink	\N	\N	19	1	2017-08-20	\N	10.207.133.166	1	HrazdanBuildHrazdan	9	3	2		945
953	HrazdanBuildOmni	\N	\N	19	1	2017-08-20	\N	10.207.133.167	1	HrazdanBuildOmni	9	3	2		946
954	Hrazdan Build AP	\N	\N	19	1	2017-08-20	\N		\N		9	3	2		947
955	HrazdanBuidAghavnadzorAP	\N	\N	19	1	2017-08-20	\N	10.207.133.178	1	Aghavnadzor_Link	9	3	2		948
956	meghradzor-sw	\N	\N	20	1	2017-08-20	\N	10.207.133.168	\N		9	3	2		949
957	MeghradzorArtavazLink	\N	\N	20	1	2017-08-20	\N	10.207.133.172	1	MeghradzorArtavaz	9	3	2		950
958	Meghradzor Omni	\N	\N	20	1	2017-08-20	\N	10.207.133.177	1	MeghradzorOmni	9	3	2		951
959	Meghradzor TV	\N	\N	20	1	2017-08-20	\N		\N		9	3	2		952
960	ArtavazMeghradzorLink	\N	\N	171	1	2017-08-20	\N	10.207.133.169	2	MeghradzorOmni	9	3	2		953
961	ArtavazAP	\N	\N	171	1	2017-08-20	\N	10.207.133.171	1	Artavaz	9	3	2		954
962	HF Qanaqer Switch	\N	\N	30	1	2017-08-20	\N	10.207.136.202	\N		9	3	2		955
963	Qanaqeravan Omni	\N	\N	30	1	2017-08-20	\N	10.207.136.203	1	QanaqeravanOmni	9	3	2		956
964	QanaqerArtashavanAP	\N	\N	30	1	2017-08-20	\N	10.206.135.86	1	HF_Artashavan_Link	9	3	2		957
978		\N	1664	1664	1	2017-07-30	\N		\N		9	5	1		676
980	GarniGeghardLink	\N	\N	477	1	2017-08-21	2017-09-06	10.207.136.35	2	GarniGeghard	9	3	2		959
968		\N	1664	1664	1	2017-07-31	\N		\N		9	5	1		61
981	GarniGoghtLink	\N	\N	477	1	2017-08-21	2017-09-07	10.207.136.37	2	GarniGoght	9	3	2		960
971		\N	1664	1664	1	2017-07-30	2017-09-24		\N		9	5	2		344
972		\N	1664	1664	1	2017-07-30	2017-09-25		\N		9	5	2		340
973		\N	1664	1664	1	2017-07-30	2017-09-25		\N		9	5	2		341
974		\N	1664	1664	1	2017-07-31	\N		\N		9	5	1		480
975		\N	1664	1664	1	2017-07-31	\N		\N		9	5	1		476
976		\N	1664	1664	1	2017-07-31	\N		\N		9	5	1		674
977		\N	1664	1664	1	2017-07-31	\N		\N		9	5	1		675
979	GarniAP_Switch	\N	\N	477	1	2017-08-21	2017-09-06	10.207.136.34	\N		9	3	2		958
982	GoghGarnitLink	\N	\N	191	1	2017-08-21	\N	10.207.136.38	1	GarniGoght	9	3	2		961
983	Goght Omni	\N	\N	191	1	2017-08-21	\N	10.207.136.40	1	Geghard_Ucom	9	3	2		962
984	Goght TV	\N	\N	191	1	2017-08-21	\N		\N		9	3	2		963
992	proshyan-sw	\N	\N	1587	1	2017-08-21	\N	10.207.132.141	\N		9	3	2		971
993	ProshyanAP	\N	\N	1587	1	2017-08-21	\N	10.207.132.143	1	HF_Proshyan_AP	9	3	2		972
994	Dzoraghbyur Omni	\N	\N	1686	1	2017-08-21	\N	10.206.135.80	1	DzoraghbyurOmni	9	3	2		973
995	Partizak_Armavir_link	\N	\N	39	1	2017-08-20	2017-09-23	10.206.133.115	1	partizaklink	12	3	2		974
996	PartizakOmni	\N	\N	39	1	2017-08-20	\N	10.207.132.107	1	PartizakRocket	12	3	2		975
997	Partizak Build Ap	\N	\N	39	1	2017-08-21	\N		\N		12	3	2		976
1038	VoskevazOshakanLink	\N	\N	707	1	2017-08-22	\N	10.207.133.233	2	OshakanVoskevaz	12	3	2		1015
902		\N	1664	1612	1	2017-08-15	2017-08-21		\N		8	5	2		488
1000		\N	1612	1664	1	2017-08-21	2017-08-31		\N		8	5	2		488
1002	TalinArmavirLink	\N	\N	55	1	2017-08-21	\N	10.206.133.151	2	 HF_Talin_Link	12	3	2		979
1003	TalinRocketOmni	\N	\N	55	1	2017-08-21	\N	10.206.133.137	1	OmniRocket	12	3	2		980
1004	TalinRocketSector	\N	\N	55	1	2017-08-21	\N	10.206.133.135	1	RocketTalinSector	12	3	2		981
1005	TalinSector5Link	\N	\N	55	1	2017-08-21	\N	10.206.133.134	1	TalinLink5Sector	12	3	2		982
1006	TalinDzitankovLink	\N	\N	55	1	2017-08-21	\N	10.206.133.155	2	TALINTITYANKOV	12	3	2		983
1007	TalinLanjikLink	\N	\N	55	1	2017-08-21	\N	10.206.133.153	1	TalinLanjik	12	3	2		984
1008	TalinAshnakLink	\N	\N	55	1	2017-08-21	\N	10.206.133.146	1	TalinAshnakLink	12	3	2		985
1009	TalinDdmasar	\N	\N	55	1	2017-08-21	\N	10.206.133.138	2	TalinDdmasarLink	12	3	2		986
1010	Talin TV	\N	\N	55	1	2017-08-21	\N		\N		12	3	2		987
1011	Talin TV	\N	\N	55	1	2017-08-21	\N		\N		12	3	2		988
1012	Talin TV	\N	\N	55	1	2017-08-21	\N		\N		12	3	2		989
1013	VosketasBuilTalinLink	\N	\N	1671	1	2017-08-21	\N	10.206.133.143	2	TalinLink5Sector	12	3	2		990
1014	VosketasBuilOmni	\N	\N	1671	1	2017-08-21	\N	10.206.133.148	1	 VosketasBuilOmni	12	3	2		991
1015	Vosketas Buil AP	\N	\N	1671	1	2017-08-21	\N		\N		12	3	2		992
1016	AshnakTalinLink	\N	\N	731	1	2017-08-21	\N	10.206.133.141	2	TalinAshnakLink	12	3	2		993
1017	AshnakOmni	\N	\N	731	1	2017-08-21	\N	10.206.133.142	1	AshnakOmni	12	5	2		994
1018	Ashnak School AP	\N	\N	731	1	2017-08-21	\N		\N		12	3	2		995
1019	DdmasarTalinLink	\N	\N	734	1	2017-08-21	\N	10.206.133.139	1	TalinDdmasarLink	12	3	2		996
1020	DdmasarOmni	\N	\N	734	1	2017-08-21	\N	10.206.133.140	1	DdmasarOmni	12	3	2		997
1021	Ddmasar School AP	\N	\N	734	1	2017-08-21	\N		\N		12	3	2		998
1022	ashtarak_hp-sw	\N	\N	203	1	2017-08-21	\N	10.207.133.226	\N		12	3	2		999
1023	AshtarakBuild.Omni	\N	\N	203	1	2017-08-21	\N	10.207.133.240	1	AshtarakBuild.Bullet	12	3	2		1000
1024	Ashtarak Build AP	\N	\N	203	1	2017-08-21	\N		\N		12	3	2		1001
1025	AshtarakOshakanLink	\N	\N	203	1	2017-08-21	\N	10.207.133.243	2	AshtarakOshakan	12	3	2		1002
1026	Ashtarak-Byurakan	\N	\N	203	1	2017-08-21	\N	10.207.133.229	2	AshtarakByurakan	12	3	2		1003
1027	Ashtarak Build AP	\N	\N	203	1	2017-08-21	\N		\N		12	5	2		1004
1028	oshakan-sw	\N	\N	50	1	2017-08-21	\N	10.207.133.245	\N		12	3	2		1005
1029	OshakanAshtarakLink	\N	\N	50	1	2017-08-21	\N	10.207.133.244	1	AshtarakOshakan	12	3	2		1006
1030	 OshakanTVOmni	\N	\N	50	1	2017-08-21	\N	10.207.133.251	1	Oshakan_AP	12	3	2		1007
1031	Oshakan TV 	\N	\N	50	1	2017-08-21	\N		\N		12	3	2		1008
1032	OshakanByurakanAP	\N	\N	50	1	2017-08-21	\N	10.207.133.253	1	HF_Oshakan	12	3	2		1009
1033	OshakanVoskevazLink	\N	\N	50	1	2017-08-21	\N	10.207.133.232	1	OshakanVoskevaz	12	3	2		1010
1034	OshakanAragatsotnLink	\N	\N	50	1	2017-08-21	\N	10.207.133.237	1	AragatsotnOshakan	12	3	2		1011
1035	AragatsotnOshakanLink	\N	\N	281	1	2017-08-21	\N	10.207.133.236	2	AragatsotnOshakan	12	3	2		1012
1036	AragatsotnOmni	\N	\N	281	1	2017-08-21	\N	10.207.133.242	1	AragatsotnBullet	12	3	2		1013
1037	Aragatsotn School AP	\N	\N	281	1	2017-08-21	\N		\N		12	3	2		1014
1039	VoskevazParpiLink	\N	\N	707	1	2017-08-22	\N	10.207.133.234	2	VoskevazParpi	\N	\N	\N		1016
1040	VoskevazOmni	\N	\N	707	1	2017-08-22	\N	10.207.133.239	1	VoskevazAP	\N	\N	\N		1017
1041	Voskevaz School AP	\N	\N	707	1	2017-08-22	\N		\N		12	3	2		1018
1042	ParpiVoskevazLink	\N	\N	53	1	2017-08-22	\N	10.207.133.235	1	VoskevazParpi	12	3	2		1019
1043	Parpi Omni	\N	\N	53	1	2017-08-22	\N	10.207.133.241	1	ParpiHF	12	3	2		1020
1044	Parpi TV	\N	\N	53	1	2017-08-22	\N		\N		12	3	2		1021
1045	ByurakanAshtarakLink	\N	\N	51	1	2017-08-22	\N	10.207.133.230	1	AshtarakByurakan	12	3	2		1022
1046	Byurakan Build AP	\N	\N	51	1	2017-08-22	\N		\N		12	3	2		1023
1047	Byurakan Build AP	\N	\N	51	1	2017-08-22	\N		\N		12	3	2		1024
1048	ashtarak-sw	\N	\N	247	1	2017-08-22	\N	10.207.133.238	\N		12	3	2		1025
1049	AshtarakTVOmni	\N	\N	247	1	2017-08-22	\N	10.207.133.250	1	Ashtarak_AP1	12	3	2		1026
998	Partizak Build Ap	\N	\N	39	1	2017-08-21	2017-09-23		\N		12	3	2		977
986	GeghardGarniLink	\N	\N	192	1	2017-08-21	2017-09-06	10.207.136.36	1	GarniGeghard	9	3	2		965
987	GeghardOmni	\N	\N	192	1	2017-08-21	2017-09-06	10.207.136.39	1	GeghardHF	9	3	2		966
985	geghard-sw	\N	\N	192	1	2017-08-21	2017-09-05	10.207.136.41	\N		9	3	2		964
991	GarniAmbulatorGehhardAP	\N	\N	1685	1	2017-08-21	2017-09-27	10.207.136.43 	2	Hf_GarniAmbulator	9	3	2		970
1050	Ashtarak TV	\N	\N	247	1	2017-08-22	\N		\N		12	3	2		1027
1051	quchak-sw	\N	\N	1687	1	2017-08-22	\N	10.206.135.120	\N		12	3	2		1028
1052	QuchakAragats1Link	\N	\N	1687	1	2017-08-22	\N	10.206.135.119	2	QuchakAragats1Link	12	3	2		1029
1053	Aragats1QuchakLink	\N	\N	720	1	2017-08-22	\N	10.206.135.118	1	QuchakAragats1Link	12	3	2		1030
1054	Aragats1Omni	\N	\N	720	1	2017-08-22	\N	10.206.135.117	1	Aragats1Omni	12	3	2		1031
1055	Aragats1 School AP	\N	\N	720	1	2017-08-22	\N		\N		12	3	2		1032
1056	 YernjatapOmni	\N	\N	299	1	2017-08-22	\N	10.206.135.103	1	YernjatapOmni	12	3	2		1033
1057	Yerinjatap School AP	\N	\N	299	1	2017-08-22	\N		\N		12	3	2		1034
1058	aparan-sw	\N	\N	43	1	2017-08-22	\N	10.206.135.100	\N		12	3	2		1035
1059	AparanShenkanLink	\N	\N	43	1	2017-08-22	\N	10.206.135.99	1	AparanShenkan	12	3	2		1036
1060	AparanSector	\N	\N	43	1	2017-08-22	\N	10.206.135.98	1	AparanSector	12	3	2		1037
1061	Aparan TV	\N	\N	43	1	2017-08-22	\N		\N		12	3	2		1038
1062	NigavanAP	\N	\N	43	1	2017-08-22	\N	10.206.135.109	1	NigavanAP	12	3	2		1039
1063	Aparan TV	\N	\N	43	1	2017-08-22	\N		\N		12	3	2		1040
1064	Chqnagh School AP	\N	\N	305	1	2017-08-22	\N		\N		12	3	2		1041
1065	Chknagh-ap	\N	\N	305	1	2017-08-22	\N	10.206.135.102	\N		12	3	2		1042
1066	ShenkanAparanLink	\N	\N	46	1	2017-08-22	\N	10.206.135.106	2	AparanShenkan	12	3	2		1043
1067	ShenkanSector	\N	\N	46	1	2017-08-22	\N	10.206.135.108	1	ShenkanSector	12	3	2		1044
1068	Shenkan new Tower AP	\N	\N	46	1	2017-08-22	\N		\N		12	3	2		1045
1069	geghadzor-sw	\N	\N	48	1	2017-08-22	\N	10.206.135.110	\N		12	3	2		1046
1070	 GeghadzorOmniRocket	\N	\N	48	1	2017-08-22	\N	10.206.135.111	1	GeghadzorOmniRocket	12	3	2		1047
1071	Geghadzor TV	\N	\N	48	1	2017-08-22	\N		\N		12	3	2		1048
1072	TlikAP	\N	\N	57	1	2017-08-22	\N	10.206.133.156	1	TlikHF	12	3	2		1049
1073	gukasavan-sw	\N	\N	836	1	2017-08-22	\N	10.207.132.72	\N		12	3	2		1050
1074	GukasavanOmni	\N	\N	836	1	2017-08-22	\N	10.207.132.73	1	GukasavanRocket	12	3	2		1051
1075	GukasavanDashtavanLink	\N	\N	836	1	2017-08-22	\N	10.207.132.75	1	GukasavanDashtavanLi	12	3	2		1052
1076	Gukasavan School AP	\N	\N	836	1	2017-08-22	\N		\N		12	3	2		1053
1077	DashtavanGukasavanClient	\N	\N	831	1	2017-08-22	\N	10.207.132.74	2	GukasavanDashtavanLi	7	3	2		1054
1078	DashtavanOmni	\N	\N	831	1	2017-08-22	\N	10.207.132.76	1	DashtavanRocket	7	3	2		1055
1079	Dashtavan School AP	\N	\N	831	1	2017-08-22	\N		\N		7	3	2		1056
1080	masis_hp-sw	\N	\N	185	1	2017-08-22	\N	10.207.132.66	\N		7	3	2		1057
1081	Masis Omni	\N	\N	185	1	2017-08-22	\N	10.206.133.30	1	Masis_AP	7	3	2		1058
1082	Masis Build AP	\N	\N	185	1	2017-08-22	\N		\N		7	3	2		1059
1083	MasisNoramargClient	\N	\N	185	1	2017-08-22	\N	10.207.132.69	2	MasisNoramargLink	7	7	2		1060
1084	MasisHayanist	\N	\N	185	1	2017-08-22	\N	10.206.133.25	2	Hay_link	7	3	2		1061
1085	Masis Build AP	\N	\N	185	1	2017-08-22	\N		\N		7	3	2		1062
1086	HayanistMasis	\N	\N	834	1	2017-08-22	\N	10.206.133.26	1	Hay_link	7	3	2		1063
1087	HayanistOmni	\N	\N	834	1	2017-08-22	\N	10.207.132.77	1	HayanistOmni	7	3	2		1064
1088	Hayanist School AP	\N	\N	834	1	2017-08-22	\N		\N		7	3	2		1065
1089	Hayanist School AP	\N	\N	834	1	2017-08-22	\N		\N		7	3	2		1066
1090	NoramargMasisLink	\N	\N	843	1	2017-08-22	\N	10.207.132.70	1	MasisNoramargLink	7	3	2		1067
1091	NoramargOmni	\N	\N	843	1	2017-08-22	\N	10.207.132.71	1	NoramargRocket	7	3	2		1068
1092	Noramarg School AP	\N	\N	843	1	2017-08-22	\N		\N		7	3	2		1069
1094	artashat-sw	\N	\N	187	1	2017-08-22	\N	10.207.136.226	\N		7	3	2		1070
1095	ArtashatDeghtsutClient	\N	\N	187	1	2017-08-22	\N	10.207.136.231	2	DeghtsutArtashatLink	7	3	2		1071
1096	ArtashatDvinClient	\N	\N	187	1	2017-08-22	\N	10.207.136.228	1	DvinArtashatLink	7	3	2		1072
1097	NarekArtashat	\N	\N	187	1	2017-08-22	\N	10.207.136.241	1	Narek_Link_HF	7	3	2		1073
1098	Artashat Bardzrashen Link	\N	\N	187	1	2017-08-22	\N	10.207.136.244	1	HF_Bardzrashen_Link	7	3	2		1074
1099	ArtashatQakhtsrashenAP	\N	\N	187	1	2017-08-22	\N	10.207.136.243	1	ArtashatRocket	7	3	2		1075
1100	DeghtsutArtashatLink	\N	\N	822	1	2017-08-22	\N	10.207.136.232	1	DeghtsutArtashatLink	7	3	2		1076
1101	Deghtsut Nano	\N	\N	822	1	2017-08-22	\N	10.207.136.233	1	DeghtsutRocket	7	3	2		1077
1102	Bardzrashen Artashat Link	\N	\N	309	1	2017-08-22	\N	10.207.136.235	2	HF_Bardzrashen_Link	7	3	2		1078
1103	Bardzrashen sector AC	\N	\N	309	1	2017-08-22	\N	10.207.136.236	1	HF_Bardzrashen_Sector	7	3	2		1079
1104	DvinArtashatLink	\N	\N	225	1	2017-08-22	\N	10.207.136.229	2	DvinArtashatLink	7	3	2		1080
1105	DvinOmni	\N	\N	225	1	2017-08-22	\N	10.207.136.230	1	DvinRocketOmni	7	3	2		1081
1106	N.Dvin School AP	\N	\N	225	1	2017-08-22	\N		\N		7	4	2		1082
1107	vosketap-sw	\N	\N	773	1	2017-08-22	\N	10.207.132.44	\N		7	3	2		1083
1108	Vosketap Omni	\N	\N	773	1	2017-08-22	\N	10.207.132.45	1	VediRocket	7	3	2		1084
1109	Vosketap#2 School AP	\N	\N	773	1	2017-08-22	\N		\N		7	3	2		1085
1110	vedi_hp-sw	\N	\N	183	1	2017-08-22	\N		\N		7	3	2		1086
1111	VediLushashogShaghapAP	\N	\N	183	1	2017-08-22	\N	10.207.132.42	1	HF_Lusashogh	7	3	2		1087
1112	VediDashtakarUrtsadzorAP	\N	\N	183	1	2017-08-22	\N	10.207.132.38	1	HF_Urtsadzor_Link	7	3	2		1088
1113	Vedi_Ararat_Client	\N	\N	183	1	2017-08-22	\N	10.207.132.53	1	Ararat_link	7	3	2		1089
1114	ZovashenSwitch	\N	\N	1673	1	2017-08-22	\N	10.207.132.50	\N		7	3	2		1090
1115	Zovashen Omni	\N	\N	1673	1	2017-08-22	\N	10.207.132.49	1	ZovashenHF	7	3	2		1091
1116	Zovashen TV	\N	\N	1673	1	2017-08-22	\N		\N		7	3	2		1092
1117	ZovashenZangagatun	\N	\N	1673	1	2017-08-22	\N	10.207.132.46	1	Zangakatun	7	3	2		1093
1118	ZovashenXachikLink	\N	\N	1673	1	2017-08-22	\N	10.210.140.31	1	ZovashenXachik	7	3	2		1094
1119	Zovashen TV	\N	\N	1673	1	2017-08-22	\N		\N		7	3	2		1095
1120	LanjarZovashenLink	\N	\N	246	1	2017-08-23	\N	10.207.132.48	2	ZovashenHF	7	3	2		1096
1121	LanjarAP	\N	\N	246	1	2017-08-23	\N	10.207.132.47	1	LanjarHF	7	3	2		1097
1122	TigranashenZovashenLink	\N	\N	1672	1	2017-08-23	\N	10.207.132.51	2	ZovashenHF	7	3	2		1098
1123	Tigranashen Build AP	\N	\N	1672	1	2017-08-23	\N		\N		7	3	2		1099
1124	TigranashenAP	\N	\N	1672	1	2017-08-23	\N	10.207.132.52	1	Tighranashen_HF	7	3	2		1100
1125	armash-sw	\N	\N	220	1	2017-08-23	\N	10.207.132.39	\N		7	3	2		1101
1127	Armash Build AP	\N	\N	220	1	2017-08-23	\N		\N		7	3	2		1103
1128	sevan_hp-sw	\N	\N	12	1	2017-08-23	\N	10.207.135.2	\N		7	3	2		1104
1129	SevanRocket	\N	\N	12	1	2017-08-23	\N	 SevanRocket	1	SevanRocket	9	3	2		1105
1130	Sevan TV	\N	\N	12	1	2017-08-23	\N		\N		9	3	2		1106
1131	SevanTV_OMNI	\N	\N	12	1	2017-08-23	\N	10.206.135.61	\N		9	3	2		1107
1132	Sevan TV	\N	\N	12	1	2017-08-23	\N		\N		9	3	2		1108
1133	semyonovka-sw	\N	\N	1675	1	2017-08-23	\N	10.207.135.8	\N		7	3	2		1109
1134	SemyonovkaOmniRocket	\N	\N	1675	1	2017-08-23	\N	10.207.135.10	1	SemyonovkaRocket	9	3	2		1110
1135	Semyonovka TV	\N	\N	1675	1	2017-08-23	\N		\N		9	3	2		1111
1136	Tsovazard_AP	\N	\N	14	1	2017-08-23	\N	10.207.135.11	1	TsovazardHF	7	3	2		1112
1137	Tsovazard School AP	\N	\N	14	1	2017-08-23	\N		\N		9	3	2		1113
1138	gavar_hp-sw	\N	\N	7	1	2017-08-23	\N	10.207.135.34	\N		7	3	2		1114
1139	 GavarRocketNoratus	\N	\N	7	1	2017-08-23	\N	10.207.135.41	1	RocketNoratus	9	3	2		1115
1140	GavarRocketGandzak	\N	\N	7	1	2017-08-23	\N	10.207.135.42	1	RocketGandzak	9	3	2		1116
1141	Gavar  TV	\N	\N	7	1	2017-08-23	\N		\N		9	3	2		1117
1142	Gavar  TV	\N	\N	7	1	2017-08-23	\N		\N		9	3	2		1118
1143	GavarLanjaghbyurLink	\N	\N	7	1	2017-08-23	\N	10.206.135.29	2	GavarLanjaghbyurLink	9	3	2		1119
1144	GavarJilLink	\N	\N	7	1	2017-08-23	\N	10.206.135.22	1	GavarJilLink	9	3	2		1120
1147	Lanjaghbyur Ucom  Vishka	\N	\N	1674	1	2017-08-23	\N		\N		9	3	2		1123
1148	JilGavarLink	\N	\N	10	1	2017-08-23	\N	10.206.135.24	2	GavarJilLink	9	3	2		1124
1149	JilArtanishLink	\N	\N	10	1	2017-08-23	\N	10.207.135.43	2	To_ArtanishHF	9	3	2		1125
1150	Jil Build AP	\N	\N	10	1	\N	\N		\N		9	3	2		1126
1151	Artanish_To_Jil	\N	\N	9	1	2017-08-23	\N	10.207.135.44	1	To_ArtanishHF	9	3	2		1127
1152	Artanish New Tower	\N	\N	9	1	2017-08-23	\N		\N		9	3	2		1128
1153	Artanish omni	\N	\N	9	1	2017-08-23	\N	10.206.135.23	1	ArtanishHF	9	3	2		1129
1154	Artanish New Tower	\N	\N	9	1	2017-08-23	\N		\N		9	3	2		1130
1155	martuni_sw_internet	\N	\N	15	1	2017-08-23	\N	10.207.135.69	\N		9	3	2		1131
1156	martuni_sw2	\N	\N	15	1	2017-08-23	\N	10.207.135.70	\N		9	3	2		1132
1157	MartuniTVSector1-V	\N	\N	15	1	2017-08-23	\N	10.207.135.71	1	MtuniSector1	9	3	2		1133
1158	MartuniTVSector2-G	\N	\N	15	1	2017-08-23	\N	10.207.135.72	1	MtuniSector2	9	3	2		1134
1160	Martuni TV	\N	\N	15	1	2017-08-23	\N		\N		9	3	2		1136
1161	MartuniDzoragyughLink	\N	\N	15	1	2017-08-23	\N	10.207.135.74	1	MartuniDzoragyugh	9	3	2		1137
1162	MartuniTsovinarLink	\N	\N	15	1	2017-08-23	\N	10.207.135.73	1	MartuniTsovinar	9	3	2		1138
1163	MartuniZolakarLink	\N	\N	15	1	2017-08-23	\N	10.207.135.81	2	MartuniZolakarLink	9	3	2		1139
1164	MartuniMadinaAP	\N	\N	15	1	2017-08-23	\N	10.207.135.79	1	MtuniMadina	9	3	2		1140
1165	Martuni TV	\N	\N	15	1	2017-08-23	\N		\N		9	3	2		1141
1166	MartuniTVGetashenAP	\N	\N	15	1	2017-08-23	\N	10.207.135.85	1	GetashenHF	9	3	2		1142
1167	DzoragyughMartuniLink	\N	\N	16	1	2017-08-23	\N	10.207.135.75	2	MartuniDzoragyugh	9	3	2		1143
1168	DzoragyughOmni	\N	\N	16	1	2017-08-23	\N	10.207.135.78	1	DzoragyughHF	9	3	2		1144
1169	Dzoragyugh h/d School AP	\N	\N	16	1	2017-08-23	\N		\N		9	3	2		1145
1170	ZolakarMartuniLink	\N	\N	992	1	2017-08-23	\N	10.207.135.82	1	MartuniZolakarLink	9	3	2		1146
1171	ZolakarOmni	\N	\N	992	1	2017-08-23	\N	10.207.135.83	1	MtuniSector1	9	3	2		1147
1172	Zolakar#1 School AP	\N	\N	992	1	2017-08-23	\N		\N		9	3	2		1148
1173	TsovinarMartuniLink	\N	\N	355	1	2017-08-23	\N	10.207.135.76	2	MartuniTsovinar	9	3	2		1149
1174	TsovinarOmni	\N	\N	355	1	2017-08-23	\N	10.207.135.80	1	TsovinarOmni	9	3	2		1150
1175	Tsovinar Prim. School AP	\N	\N	355	1	2017-08-23	\N		\N		9	3	2		1151
1176	TsovinarAreguniAP	\N	\N	355	1	2017-08-23	\N	10.206.135.43	1	TsovinarBullet	9	3	2		1152
1177	Tsovinar Prim. School AP	\N	\N	355	1	2017-08-23	\N		\N		9	3	2		1153
1178	TsovinarPambak AP	\N	\N	355	1	2017-08-23	\N	10.207.135.87	1	h_Ttsovinar	9	3	2		1154
999	talin-sw	\N	\N	55	1	2017-08-21	2017-08-23		\N		12	3	2		978
1179	talin-sw	\N	55	1664	2	2017-08-23	\N		\N		13	5	2		978
1182	TsovinarLchapLink	\N	\N	355	1	2017-08-23	\N	10.207.135.77	1	TsovinarLchavan	9	3	2		1155
1145	LanjaghbyurGavarLink	\N	\N	1674	1	2017-08-23	2017-09-07	10.206.135.25	1	GavarLanjaghbyurLink	9	3	2		1121
1093		\N	1664	55	1	2017-08-19	\N		\N		13	5	2		189
1183	Aknalich	\N	\N	959	1	2017-08-22	\N	10.205.140.242	2	Mmor_AP3	7	3	2		1156
1184	Aknalich	\N	\N	959	1	2017-08-22	\N	91.205.140.242	\N		7	3	2		1157
1185	LchavanTsovinarLink	\N	\N	17	1	2017-08-24	\N	10.207.135.86	2	TsovinarLchavan	9	3	2		1158
1186	Lchavan Omni	\N	\N	17	1	2017-08-24	\N	10.206.135.39	1	LtjavanOmni	9	3	2		1159
1187	Lchavan New Tower	\N	\N	17	1	2017-08-24	\N		\N		9	3	2		1160
1188	vardenis-sw	\N	\N	5	1	2017-08-24	\N	10.206.135.158	\N		9	3	2		1161
1180		\N	1664	1688	1	2017-08-22	\N		\N		14	5	2		560
1620		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1460
1126	Armash_AP	\N	\N	220	1	2017-08-23	2017-10-27	10.207.132.41	\N		7	3	2		1102
1146	LanjaghbyurRocket	\N	\N	1674	1	2017-08-23	2017-09-06	10.206.135.26	1	LandjaghbyurAP	9	3	2		1122
1189	VardenisRocketSector	\N	\N	5	1	2017-08-24	\N	10.206.135.152	1	VardenisRocket2	9	3	2		1162
1190	Vardenis TV	\N	\N	5	1	2017-08-24	\N		\N		9	3	2		1163
1191	VardenisPB_AP	\N	\N	5	1	2017-08-24	\N	10.206.135.154	1	VardenisRocket3	9	3	2		1164
1192	VardenisArpunkLink	\N	\N	5	1	2017-08-24	\N	10.206.135.147	1	VardenisArpunk	9	3	2		1165
1193	Vardenis TV	\N	\N	5	1	2017-08-24	\N	10.206.135.149	\N		9	3	2		1166
1194	Vardenis TV	\N	\N	5	1	2017-08-24	\N		\N		9	3	2		1167
1195	 ArpunkVardenisLink	\N	\N	6	1	2017-08-24	\N	10.206.135.148	2	VardenisArpunk	9	3	2		1168
1196	ArpunkHF	\N	\N	6	1	2017-08-24	\N	10.206.135.151	1	ArpunkHF	9	3	2		1169
1197	Arpunk School AP	\N	\N	6	1	2017-08-24	\N		\N		9	3	2		1170
1199	tchambarak-sw	\N	\N	1	1	2017-08-24	\N	10.206.135.14	\N		9	3	2		1171
1200	TchambarakVahanClient	\N	\N	1	1	2017-08-24	\N	10.206.135.4	2	TchambarakVahanLink	9	3	2		1172
1201	VahanTchambarakLink	\N	\N	11	1	2017-08-24	\N	10.206.135.6	1	TchambarakVahanLink	9	3	2		1173
1202	Vahan Omni	\N	\N	11	1	2017-08-24	\N	10.206.135.3	1	VahanOmni	9	3	2		1174
1203	Vahan Build AP (TV)	\N	\N	11	1	2017-08-24	\N		\N		9	3	2		1175
1204	ttujur-sw	\N	\N	2	1	2017-08-24	\N	10.206.135.8	\N		9	3	2		1176
1205	ThtujurGetikClient	\N	\N	2	1	2017-08-24	\N	10.206.135.5	2	ThtujurGetikLink	9	3	2		1177
1206	GetikThtujurLink	\N	\N	3	1	2017-08-24	\N	10.206.135.7	1	ThtujurGetikLink	9	3	2		1178
1207	GetikantaramejClient	\N	\N	3	1	2017-08-24	\N	10.206.135.10	2	Getikantaramej	9	3	2		1179
1208	GetikOmni	\N	\N	3	1	2017-08-24	\N	10.206.135.11	1	GetikHF	9	3	2		1180
1209	Getik TV	\N	\N	3	1	2017-08-24	\N		\N		9	3	2		1181
1210	AntaramejGetikLink	\N	\N	4	1	2017-08-24	\N	10.206.135.12	1	Getikantaramej	9	3	2		1182
1211	AntaramejOmni	\N	\N	4	1	2017-08-24	\N	10.206.135.13	1	AntaramejHF	9	3	2		1183
1212	Antaramej TV	\N	\N	4	1	2017-08-24	\N		\N		9	3	2		1184
1213	dilijan_hp-sw	\N	\N	78	1	2017-08-24	\N	10.207.135.162	\N		\N	3	2		1185
1214	Dilijan_Texut_client	\N	\N	78	1	2017-08-24	\N	10.207.135.166	2	Teghut_Link	\N	3	2		1186
1215	Texut_Dilijan_link	\N	\N	79	1	2017-08-24	\N	10.207.135.165	1	Teghut_Link	\N	3	2		1187
1216	TeghutHagharcinClient	\N	\N	79	1	2017-08-24	\N	10.207.135.174	2	 TeghutHagharcinLink	\N	3	2		1188
1217	HagharcinTeghutLink	\N	\N	80	2	2017-08-24	\N	10.207.135.175	1	TeghutHagharcinLink	\N	3	2		1189
1218	Hagharcin Omni	\N	\N	80	\N	2017-08-24	\N	10.207.135.176	1	Hagharcin Omni	\N	3	2		1190
1219	Hagharcin TV	\N	\N	80	\N	2017-08-24	\N		\N		\N	3	2		1191
1220	ijevan-sw	\N	\N	158	1	2017-08-24	\N	10.206.134.194	\N		\N	3	2		1192
1221	IjevanSectorRocket	\N	\N	158	1	2017-08-24	\N	10.206.134.196	1	IjevanOmniRocket	\N	3	2		1193
1222	Ijevan TV	\N	\N	158	1	2017-08-24	\N		\N		\N	3	2		1194
1223	IjevanTVAchajurAP	\N	\N	158	1	2017-08-24	\N	10.206.134.195	1	IjevanOmniBullet	\N	3	2		1195
1224	IjevanLusadzorClient	\N	\N	158	1	2017-08-24	\N	10.206.134.197	2	IjevanLusadzorLink	\N	3	2		1196
1225	Ijevan TV	\N	\N	158	1	2017-08-24	\N		\N		\N	3	2		1197
1227	LusadzorIjevanLink	\N	\N	1478	1	2017-08-23	\N	10.206.134.198	1	IjevanLusadzorLink	\N	3	2		1199
1228	Lusadzor Omni	\N	\N	1478	1	2017-08-24	\N	10.206.134.202	1	LusadzorOmni	\N	3	2		1200
1229	Lusadzor School AP	\N	\N	1478	1	2017-08-24	\N		\N		\N	3	2		1201
1230	sevqar-sw	\N	\N	160	1	2017-08-24	\N	10.206.134.204	\N		\N	3	2		1202
1231	SevqarRocketSector	\N	\N	160	1	2017-08-24	\N	10.206.134.211	1	SevqarOmni	\N	3	2		1203
1232	Sevqar TV	\N	\N	160	1	2017-08-24	\N		\N		\N	3	2		1204
1233	SevqarBaghanisClient	\N	\N	160	1	2017-08-24	\N	10.206.134.220	2	SevqarBaghanisLink	\N	3	2		1205
1234	SevqarVazashenClient	\N	\N	160	1	2017-08-24	\N	10.206.134.219	2	 SevqarVazashenLink	\N	3	2		1206
1235	SevqarDitavanClient	\N	\N	160	1	2017-08-24	\N	10.206.134.215	2	SevqarDitavanLink	\N	3	2		1207
1236	DitavanSevqarLink	\N	\N	1488	1	2017-08-24	\N	10.206.134.205	1	SevqarDitavanLink	\N	3	2		1212
1237	DitavanOmni	\N	\N	1488	1	2017-08-24	\N	10.206.134.207	1	DitavanHF	\N	3	2		1213
1238	Ditavan School AP	\N	\N	1488	1	2017-08-24	\N		\N		\N	3	2		1214
1239	VazashenSevqarLink	\N	\N	161	1	2017-08-24	\N	10.206.134.208	1	SevqarVazashenLink	\N	3	2		1215
1240	VazashenTVBullet	\N	\N	161	1	2017-08-24	\N	10.206.134.221	1	VazashenOmni	\N	3	2		1216
1241	Vazashen TV	\N	\N	161	1	2017-08-24	\N		\N		\N	3	2		1217
1242	BaghanisSevqarLink	\N	\N	162	1	2017-08-24	\N	10.206.134.213	1	SevqarBaghanisLink	\N	3	2		1218
1243	Baghanis Omni	\N	\N	162	1	2017-08-24	\N	10.206.134.218	1	BaghanisOmni	\N	3	2		1219
1244	Baghanis TV	\N	\N	162	1	2017-08-24	\N		\N		\N	3	2		1220
1245	BerqaberRepeater	\N	\N	1676	1	2017-08-24	\N	10.206.134.214	2	BaghanisOmni	\N	3	2		1221
1246	Berqaber_AP	\N	\N	1676	1	2017-08-24	\N	10.206.134.212	1	 Berqaber_AP	\N	3	2		1222
1247	Bergaber Build AP	\N	\N	1676	1	2017-08-24	\N		\N		\N	3	2		1223
1248	chinchin-sw	\N	\N	167	1	2017-08-24	\N	10.207.135.198	\N		\N	3	2		1224
1249	ChinchinTV(hin)ChinchinTV(new)Link	\N	\N	167	1	2017-08-24	\N	10.207.135.214	2	Chin2chin1Link	\N	3	2		1225
1250	ChinchinTV(hin)LocoAP	\N	\N	167	1	2017-08-24	\N	10.207.135.195	1	HF_Chin-chin	\N	3	2		1226
1251	ChinchinTV(new)ChinchinTV(old)Link	\N	\N	1677	1	2017-08-24	\N	10.207.135.215	1	Chin2chin1Link	\N	3	2		1227
1252	ChinchinTV(new)RocketSector	\N	\N	1677	1	2017-08-24	\N	10.207.135.197	1	ChinchinOmni	\N	3	2		1228
1253	ChinchinTV(new)	\N	\N	1677	1	2017-08-24	\N		\N		\N	3	2		1229
1254	Berd2Omni	\N	\N	1470	1	2017-08-24	\N	10.207.135.194	1	Berd#2Omni	\N	3	2		1230
1255	Berd#2SchoolAP	\N	\N	1470	1	2017-08-24	\N		\N		\N	3	2		1231
1256	berd_hp-sw	\N	\N	165	1	2017-08-24	\N	10.207.135.210	\N		\N	3	2		1232
1257	BerdTVRocketOmni	\N	\N	165	1	2017-08-24	\N	10.207.135.204	1	BerdOmni	\N	3	2		1233
1258	Berd TV	\N	\N	165	1	2017-08-24	\N		\N		\N	3	2		1234
1259	BerdItsaqarLink	\N	\N	165	1	2017-08-24	\N	10.207.135.222	1	BerdItsaqarLink	\N	3	2		1235
1260	BerdArtsvaberdClient	\N	\N	165	1	2017-08-24	\N	10.207.135.219	2	BerdArtsvaberdLink	\N	3	2		1236
1261	ItsaqarBerdLink	\N	\N	215	1	2017-08-24	\N	10.207.135.221	2	BerdItsaqarLink	\N	3	2		1237
1262	Itsaqar Omni	\N	\N	215	1	2017-08-24	\N	10.207.135.203	1	ItsaqarOmni	\N	3	2		1238
1263	ArtsvaberdBerdLink	\N	\N	157	1	2017-08-24	\N	10.207.135.213	1	BerdArtsvaberdLink	\N	3	2		1239
1264	Artsvaberd Omni	\N	\N	157	1	2017-08-24	\N	10.207.135.202	1	ArtsvaberdOmni	\N	3	2		1240
1265	Artsvaberd TV	\N	\N	157	1	2017-08-24	\N		\N		\N	3	2		1241
1266	ArtsvaberdAygedzorClient	\N	\N	157	1	2017-08-24	\N	10.207.135.200	2	AygedzorArtsvaberdLi	\N	3	2		1242
1267	ArtsvaberdTVChorotanAP	\N	\N	157	1	2017-08-24	\N	10.207.135.196	1	Chorotan_HF	\N	3	2		1243
1268	AygedzorArtsvaberdLink	\N	\N	155	1	2017-08-24	\N	10.207.135.201	1	AygedzorArtsvaberdLi	\N	3	2		1244
1311	LchkadzorAyrumLink	\N	\N	234	1	2017-08-28	\N	10.207.136.13	2	AyrumLink5Sector	13	3	2		1283
1312	lchkadzorOmni	\N	\N	234	1	2017-08-28	\N	10.207.136.15	1	LchkadzorOmni	13	3	2		1284
1276	Aygedzor Omni	\N	\N	155	1	2017-08-27	\N	10.207.135.199	1	AygedzorOmni	\N	3	2		1260
1313	Lchkadzor Buid AP	\N	\N	234	1	2017-08-28	\N		\N		13	3	2		1285
1314	QarkopAyrumLink	\N	\N	1679	1	2017-08-28	\N	10.207.136.16	2	AyrumLink5Sector	13	3	2		1286
1278	Aygedzor TV	\N	\N	155	1	2017-08-27	\N		\N		\N	3	2		1261
1280	AygedzorChinariLink	\N	\N	155	1	2017-08-27	\N	10.207.135.206	2	Chinari_Omni	\N	3	2		1263
1315	QarkopOmni	\N	\N	1679	1	2017-08-28	\N	10.207.136.18	1	QarkopOmni	13	3	2		1287
1316	Qarkop New Tower	\N	\N	1679	1	2017-08-28	\N		\N		13	3	2		1288
1282	Chinari Omni	\N	\N	1678	1	2017-08-27	\N	10.207.135.205	1	Chinari_Omni	\N	3	2		1264
1283	Chinari Ucom AP	\N	\N	1678	1	2017-08-27	\N		\N		\N	3	2		1265
1317	tchochkan-sw	\N	\N	405	1	2017-08-28	\N	10.207.136.27	\N		13	3	2		1289
1318	TchotchkanAyrumLink	\N	\N	405	1	2017-08-28	\N	10.207.136.22	2	TchotchkanAyrumLink	13	3	2		1290
1319	Tchotchkan Omni	\N	\N	405	1	2017-08-28	\N	10.207.136.14	1	 TchotchkanOmni	13	3	2		1291
1320	Tchotchkan School AP	\N	\N	405	1	2017-08-28	\N		\N		13	3	2		1292
1321	BagratashenAyrumClient	\N	\N	81	1	2017-08-28	\N	10.207.136.4	2	BagratashenLink	13	3	2		1293
1287	NoyemberyanTVRocketSector	\N	\N	77	\N	2017-08-27	\N	10.207.135.231	1	Noyemberyan_Omni	\N	3	2		1267
1288	Noyemberyan TV	\N	\N	77	1	2017-08-27	\N		\N		\N	3	2		1268
1289	NoyemberyanPB_AP	\N	\N	77	1	2017-08-27	\N	10.207.135.232	1	HF_PB400	\N	3	2		1269
1290	Ayrum_Switch	\N	\N	71	1	2017-08-27	\N	10.207.136.10	\N		\N	3	2		1270
1291	AyrumSector5Link	\N	\N	71	1	2017-08-27	\N	10.207.136.21	1	AyrumLink5Sector	\N	3	2		1271
1292	Ayrum	\N	\N	666	1	2017-08-27	2017-08-27	10.205.141.106	2	AyrumRocket	15	3	2		1272
1590		\N	1664	138	1	2017-06-20	2017-09-11		\N		23	3	2		1449
1298	Neghots	\N	\N	423	1	2017-08-25	2017-08-26		\N		15	3	2		1275
1322	Bagratashen Omni	\N	\N	81	1	2017-08-28	\N	10.207.136.20	1	BagratashenOmni	13	3	2		1294
1299	Neghots	\N	423	1664	1	2017-08-26	\N		\N		15	5	2		1275
1323	Bagratashen New Tower	\N	\N	81	1	2017-08-28	\N		\N		13	3	2		1295
1324	koti-sw	\N	\N	163	1	2017-08-28	\N	10.206.134.209	\N		13	3	2		1296
1325	KotiOmni	\N	\N	163	1	2017-08-28	\N	10.206.134.210	1	KotiOmni	13	3	2		1297
1326	Koti Ucom AP	\N	\N	163	1	2017-08-28	\N		\N		13	3	2		1298
1295	NeghotsBldLoco	\N	423	1664	1	2017-08-24	2017-08-30	10.207.136.7	2	AkhtalaHF	15	5	2		1273
1337	Talin TV	\N	\N	55	1	2017-08-29	\N		\N		7	3	2		1306
1303	NanoStation Loco M2	\N	423	1664	1	2017-08-26	2017-08-30	10.205.141.104	2		15	5	2		1274
1294	NeghotsBldLoco	\N	1664	423	1	2017-08-15	2017-08-24		\N		15	3	2		1273
989	GeghardAPGarniAmbulatorAP	\N	\N	192	1	2017-08-20	2017-09-06	10.207.136.42 	1	Hf_GarniAmbulator	9	3	2		968
1304	PambakVanadzorBuild	\N	\N	84	1	2017-08-28	2017-08-28	10.207.136.71	1	hf_Pambak	15	3	2		1277
1300	Neghots	\N	1664	1691	1	2017-08-24	2017-08-25		\N		15	3	2		1276
1306	Ayrum TV	\N	\N	71	1	2017-08-28	\N		\N		13	3	2		1278
1307	AyrumTchotchkanLink	\N	\N	71	1	2017-08-28	\N	10.207.136.24	1	TchotchkanAyrumLink	13	3	2		1279
1308	AyrumBagratashenLink	\N	\N	71	1	2017-08-28	\N	10.207.136.23	1	BagratashenLink	13	3	2		1280
1309	AyrumTVRocketSector	\N	\N	71	1	2017-08-28	\N	10.207.136.11	1	AyrumRocket	13	3	2		1281
1310	Ayrum TV	\N	\N	71	1	2017-08-28	\N		\N		13	3	2		1282
1338	Vanevan	\N	1664	1030	1	2017-07-30	\N	10.205.134.81	2	VardenisRocket2	9	5	2		84
1302	NanoStation Loco M2	\N	1664	423	1	2017-08-24	2017-08-26	10.205.141.104	2	Neghots_HF	15	3	2		1274
1649		\N	\N	138	1	2017-05-22	2017-09-11		\N		23	3	2		1472
1305	PambakVanadzorBuild	\N	84	1664	1	2017-08-28	2017-09-12		\N		3	5	2		1277
1641		\N	130	138	1	2017-05-10	2017-09-25		\N		23	3	2		1468
1275	Aghvorik	\N	\N	516	1	2017-08-27	\N	10.205.141.243	2	AMASIA_AP3	\N	3	2		1259
1293	Ayrum	\N	666	1664	1	2017-08-27	2017-09-27		\N		15	5	2		1272
1643		\N	1664	138	1	2017-06-06	2017-09-12		\N		23	3	2		1469
1644		\N	138	1664	1	2017-09-11	2017-06-06		\N		13	3	2		1469
1645		\N	1664	138	1	2017-05-17	2017-09-12		\N		23	3	2		1470
1646		\N	138	1664	1	2017-09-11	2017-05-17		\N		13	3	2		1470
1647		\N	1664	138	1	2017-06-19	2017-09-12		\N		23	3	2		1471
1648		\N	138	1664	1	2017-09-11	2017-06-19		\N		13	3	2		1471
1635		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1449
1327	gyumri-sw	\N	\N	96	1	2017-08-27	\N	10.207.136.108	\N		\N	3	2		1299
1329	GyumriTV	\N	\N	96	1	2017-08-28	\N		\N		\N	3	2		1301
1330	gala-sw	\N	\N	1680	1	2017-08-20	\N	10.206.134.39	\N		\N	3	2		1302
1339	gyumri_ani-sw	\N	\N	204	1	2017-08-29	\N	10.207.136.168	\N		\N	3	2		1307
1340	GyumriAniBuldOmni	\N	\N	204	1	2017-08-29	\N	10.206.134.46	1	GyumriAni	\N	3	2		1308
1341	GyumriANI buil AP	\N	\N	204	1	2017-08-29	\N		\N		\N	3	2		1309
1343	Gyumri6YerazgavorsLink	\N	\N	1394	1	2017-08-29	\N	10.207.136.163	2	Gyumri6Yerazgavors	\N	3	2		1311
1344	Gyumri#6ShirakavanLink	\N	\N	1394	1	2017-08-29	\N	10.206.134.35	2	GyumriShirakavanLink	\N	3	2		1312
1345	Gyumri#6Omni	\N	\N	1394	1	2017-08-29	\N	10.207.136.165	1	Gyumri#6Omni	\N	3	2		1313
1346	Gyumri#6 School AP	\N	\N	1394	1	2017-08-29	\N		\N		\N	3	2		1314
1347	 YerazgavorsGyumri6Link	\N	\N	1338	1	2017-08-29	\N	10.207.136.164	1	 Gyumri6Yerazgavors	\N	3	2		1315
1348	Yerazgavorsi Omni	\N	\N	1338	1	2017-08-29	\N	10.207.136.166	1	 Erazgavorsk_AP	\N	3	2		1316
1349	Yerazgavors School AP	\N	\N	1338	1	2017-08-29	\N		\N		\N	3	2		1317
1350	ShirakavanGyumriLink	\N	\N	107	1	2017-08-29	\N	10.206.134.36	1	GyumriShirakavanLink	\N	3	2		1318
1351	ShirakavanOmni	\N	\N	107	1	2017-08-29	\N	ShirakavanOmni	1	ShirakavanOmni	\N	3	2		1319
1352	Shirakavan new Tower	\N	\N	107	1	2017-08-29	\N		\N		\N	3	2		1320
1353	ShirakavanJrapiLink	\N	\N	107	1	2017-08-29	\N	10.206.134.38	2	ShirakavanOmni	\N	3	2		1321
1354	JrapiShirakavanLink	\N	\N	115	1	2017-08-29	\N	10.206.134.41	1	ShirakavanJrapiLink	\N	3	2		1322
1355	JrapOmni	\N	\N	115	1	2017-08-29	\N	10.206.134.42	1	 JrapiOmni	\N	3	2		1323
1356	Jrapi Ucom AP	\N	\N	115	1	2017-08-29	\N		\N		\N	3	2		1324
1357	Keti School AP	\N	\N	1354	1	2017-08-29	\N		\N		\N	3	2		1325
1358	DzitankovTalinLink	\N	\N	60	1	2017-08-29	\N	10.206.133.154	1	TALINTITYANKOV	\N	3	2		1326
1362	Lanjik TV	\N	\N	59	1	2017-08-29	\N		\N		\N	3	2		1330
1342	gyumri6-sw	\N	\N	1394	1	2017-08-28	\N	10.207.136.162	\N		18	3	2		1310
1331	GalaOmni	\N	1664	1680	1	2017-05-30	2017-08-19	10.207.136.171	1	GalaOmni	18	3	2		1303
1328	GyumriTVRocketOmni	\N	\N	96	1	2017-08-28	2017-09-05	10.206.134.5	1	 HFAP5	\N	3	2		1300
1335	BasenJrarat	\N	1680	1680	1	2017-05-30	2017-08-20		\N		18	5	2		1305
905		\N	1664	1680	1	2017-08-19	2017-10-10		\N		\N	5	2		87
1359	DzitankovOmni	\N	\N	60	1	2017-08-29	\N	10.206.133.145	1	DzitankovOmni	\N	3	2		1327
1360	LanjikTalinLink	\N	\N	59	1	2017-08-29	\N	10.206.133.130	2	TalinLanjik	\N	3	2		1328
1361	LanjikOmni	\N	\N	59	1	2017-08-29	\N	10.206.133.144	1	LanjikOmni	\N	3	2		1329
1363	akhuryan-sw	\N	\N	210	1	2017-08-29	\N	10.207.136.172	\N		\N	3	2		1331
1365	JajurAkhuryan	\N	\N	1351	1	2017-08-29	\N	10.206.134.50	2	AkhuryanJajur	\N	3	2		1333
1366	Jajur_Omni	\N	\N	1351	1	2017-08-29	\N	10.206.134.44	1	JajurOmni	\N	3	2		1334
1367	Jajur School AP	\N	\N	1351	1	2017-08-29	\N		\N		\N	3	2		1335
1368	amasis-sw	\N	\N	100	1	2017-08-29	\N	10.206.134.6	\N		\N	3	2		1336
1369	 Amasiya Rocket 1	\N	\N	100	1	2017-08-29	\N	10.206.134.11	1	 AMASIA_AP3	\N	3	2		1337
1370	Amasia TV	\N	\N	100	1	2017-08-29	\N		\N		\N	3	2		1338
1371	 Amasiya Rocket 2	\N	\N	100	1	2017-08-29	\N	10.206.134.10	1	AMASIA_AP1	\N	3	2		1339
1372	Amasia TV	\N	\N	100	1	2017-08-29	\N		\N		\N	3	2		1340
1373	Amasia Garnarich Link	\N	\N	100	1	2017-08-29	\N	10.206.134.23	1	HF_Garnarich_Link	\N	3	2		1341
1374	AmasiyaTV DzorashenLink	\N	\N	100	1	2017-08-29	\N	10.206.134.22	1	HF_Dzorashen_Link	\N	3	2		1342
1375	AmasiaTVKarmravanAP	\N	\N	100	1	2017-08-29	\N	10.206.134.4	1	HF_Karmravan_Link	\N	3	2		1343
1376	AmasiyaTVTorosAP_Link	\N	\N	100	1	2017-08-29	\N	10.206.134.25	1	HF_Toros_Link	\N	3	2		1344
1377	GarnarichAPAmasiaTVLInk	\N	\N	519	1	2017-08-29	\N	10.206.134.21	2	HF_Garnarich_Link	\N	3	2		1345
1378	GarnarichOmni	\N	\N	519	1	2017-08-29	\N	10.206.134.20	1	Garnarich_Omni	\N	3	2		1346
1379	Garnarich School AP	\N	\N	519	1	2017-08-29	\N		\N		\N	3	2		1347
1380	DzorashenAmasiaTVLink	\N	\N	102	1	2017-08-29	\N	10.206.134.19	2	HF_Dzorashen_Link	\N	3	2		1348
1381	dzorashenomni	\N	\N	102	1	2017-08-29	\N	10.206.134.7	1	Dzorashen_Omni	\N	3	2		1349
1382	Dzorashen TV	\N	\N	102	1	2017-08-29	\N		\N		\N	3	2		1350
1364	AkhuryanJajur	\N	\N	210	1	2017-08-29	\N	10.206.134.43	1	AkhuryanJajur	3	\N	2		1332
1388		\N	\N	1664	1	2017-08-30	\N		\N		1	3	2		1356
1387		\N	\N	1664	1	2017-08-30	2017-08-30		\N		1	3	2		1355
1392	Ardvi	\N	1664	417	1	2017-08-30	\N		\N		8	3	2		1274
1389	QarinjChkalovLink	\N	1664	1681	1	2017-08-30	\N		\N		7	3	2		1355
1396	Mghart	\N	1664	415	1	2017-08-31	\N		\N		8	3	2		124
1404	ChkalovBulletOmni	\N	1664	68	1	2017-08-31	\N		\N		8	8	2		234
1397	Dsegh	\N	1664	403	1	2017-08-31	\N		\N		8	3	2		89
1391	Qarinj	\N	1664	411	1	2017-08-30	\N		\N		7	3	2		1273
1394	DzoragetChkalovLink	\N	1664	70	1	2017-08-30	\N		\N		8	3	2		486
1412	Lanjazat	\N	1664	311	1	2017-05-31	2017-09-05	10.205.140.196	2	DeghtsutRocket	24	3	2		1358
1395	Yeghegnut	\N	1664	392	1	2017-08-31	\N		\N		8	3	2		488
1390	QarinjBulletOmni	\N	1664	1681	1	2017-08-30	2017-09-20		\N		7	3	2		485
1410	Lanjazat	\N	1664	311	1	2017-05-31	2017-09-06	91.205.140.196	\N		24	3	2		1359
1405	ChkalovSectorD	\N	1664	68	1	2017-08-31	\N		\N		8	3	2		213
1406		\N	1664	68	1	2017-08-31	\N		\N		8	3	2		320
1407		\N	1664	68	1	2017-08-31	\N		\N		8	3	2		322
1414	Lanjazat	\N	1664	311	1	2017-09-01	\N	91.205.140.196	\N		9	5	2		343
1427	MaralikHarichLink	\N	\N	109	1	2017-09-01	\N	10.206.133.196	2	MaralikHarichLink	18	3	2		1370
1428	MaralikOmni	\N	\N	109	1	2017-09-01	\N	10.207.136.137	1	MaralikOmni	18	3	2		1371
1417	KAQAVASARCLIENT	\N	\N	108	1	2017-08-31	\N	10.206.134.15	2	Dzorashen_Omni	18	3	2		1360
966		\N	1664	311	1	2017-09-01	\N	10.205.140.196	2	DeghtsutRocket	9	5	2		62
1418	Kaqavasar New Tower	\N	\N	108	1	2017-08-31	\N		\N		18	3	2		1361
1419	Kaqavasar New Tower	\N	\N	108	1	2017-09-01	\N		\N		18	3	2		1362
1420	KarmravanOmni	\N	\N	564	1	2017-09-01	\N	10.207.136.105	1	Karmravan_Omni	18	3	2		1363
1421	Karmravan Shool AP	\N	\N	564	1	2017-09-01	\N		\N		18	3	2		1364
1422	TorosAPAmasiaTVLink	\N	\N	101	1	2017-09-01	\N	10.206.134.2	2	HF_Toros_Link	18	3	2		1365
1423	 Toros Omni	\N	\N	101	1	2017-09-01	\N	10.206.134.3	1	Toros_Omni	18	3	2		1366
1424	Toros New Tower (Orange Tower)	\N	\N	101	1	2017-09-01	\N		\N		18	3	2		1367
1425	saratak-sw	\N	\N	113	1	2017-09-01	\N	10.207.136.140	\N		18	3	2		1368
1426	MaralikLernakertLink	\N	\N	109	1	2017-09-01	\N	10.206.133.195	2	MaralikLernakertLink	18	3	2		1369
1429	Maralik Build AP	\N	\N	109	1	2017-09-01	\N		\N		18	3	2		1372
1430	HarichMaralikLink	\N	\N	545	1	2017-09-01	\N	10.206.133.197	1	MaralikHarichLink	18	3	2		1373
1431	Harichi Omni	\N	\N	545	1	2017-09-01	\N	10.207.136.131	1	HarichOmni	18	3	2		1374
1432	Harich School AP	\N	\N	545	1	2017-09-01	\N		\N		18	3	2		1375
1433	mantash-sw	\N	\N	551	1	2017-09-01	\N		\N		18	3	2		1376
1434	MantashOmni	\N	\N	551	1	2017-09-01	\N	10.207.136.135	1	MantashOmni	18	3	2		1377
1435	Pokr Mantash School AP	\N	\N	551	1	2017-09-01	\N		\N		18	3	2		1378
1436	LernakertMaralikLink	\N	\N	540	1	2017-09-01	\N	10.206.133.199	1	MaralikLernakertLink	18	3	2		1379
1437	LernakertGeghanistLink	\N	\N	540	1	2017-09-01	\N	10.206.133.203	2	LernakertGeghanistLi	18	3	2		1380
1438	Lernakerti Omni	\N	\N	540	1	2017-09-01	\N	10.207.136.130	1	LernakertOmni	18	3	2		1381
1439	Lernakert School AP	\N	\N	540	1	2017-09-01	\N		\N		18	3	2		1382
1440	GeghanistLernakertLink	\N	\N	542	1	2017-09-01	\N	10.206.133.204	1	LernakertGeghanistLi	18	3	2		1383
1441	GeghanistShirakOmni	\N	\N	542	1	2017-09-01	\N	10.207.136.132	1	GeghanistOmni	18	3	2		1384
1442	Geghanist(Shirak)  School AP	\N	\N	542	1	2017-09-01	\N		\N		18	3	2		1385
1443	Martuni TV	\N	\N	15	1	2017-09-03	\N		\N		9	3	2		1386
1445	Saratak TV	\N	\N	113	1	2017-09-03	\N		\N		18	3	2		1388
1444	SaratakTVOmni	\N	\N	113	1	2017-09-02	\N	10.207.136.138	1	SaratakTVOmni	18	3	2		1387
1475		\N	411	1664	1	2017-09-04	\N		\N		7	3	2		1401
1476	qarinjbuild	\N	\N	1681	1	2017-05-31	2017-09-04		\N		15	3	2		1402
1508	GyumriTVRocketOmni	\N	1664	96	1	2017-09-05	\N	10.206.134.5	1	HFAP5	18	5	2		218
1446	GarniRocketOmni	\N	1664	1690	1	2017-09-02	\N	10.207.136.39	1	GeghardHF	13	5	2		215
1447	Garni TV	\N	1664	1690	1	2017-09-02	\N		\N		13	5	2		637
1448		\N	1664	477	1	2017-09-02	\N		2		13	5	2		86
1477		\N	1681	1664	1	2017-09-04	\N		\N		7	3	2		1402
1449		\N	1664	479	1	2017-09-02	\N		2		13	5	2		85
1500	Mghart	\N	\N	415	1	2017-06-03	2017-09-04		\N		15	3	2		1413
1457	Vazashen	\N	\N	655	1	2017-09-05	\N	10.205.142.2	2	VazashenOmni	22	3	2		1392
1458	Vazashen	\N	\N	655	1	2017-09-05	\N	91.205.142.2	\N		22	3	2		1393
1459		\N	1664	1664	1	2017-06-20	\N		\N		5	3	2		508
1393	Hovtamej	\N	1664	935	1	2017-08-30	\N	91.205.133.61	\N		8	5	2		428
1460	dsegh	\N	\N	403	1	2017-05-31	2017-09-04		\N		15	3	2		1394
1461		\N	403	1664	1	2017-09-04	\N		\N		7	5	2		1394
1462	dsegh	\N	\N	403	1	2017-05-31	2017-09-04		\N		15	3	2		1395
1463		\N	403	1664	1	2017-09-04	\N		\N		7	3	2		1395
1464	yeghegnut	\N	\N	392	1	2017-05-31	2017-09-04		\N		15	3	2		1396
1465		\N	392	1664	1	2017-09-04	\N		\N		7	3	2		1396
1466	aygehat	\N	\N	416	1	2017-05-31	2017-09-04		\N		15	3	2		1397
1467		\N	416	1664	1	2017-09-04	\N		\N		7	3	2		1397
1468	dzoraget	\N	\N	70	1	2017-05-31	2017-09-04		\N		15	3	2		1398
1469		\N	70	1664	1	2017-09-04	\N		\N		8	3	2		1398
1472	qarinj	\N	\N	411	1	2017-05-31	2017-09-04		\N		15	3	2		1400
1473		\N	411	1664	1	2017-09-04	\N		\N		7	3	2		1400
1474	qarinj	\N	\N	411	1	2017-05-31	2017-09-04		\N		15	3	2		1401
1478	qajirnjbld	\N	\N	1681	1	2017-05-31	2017-09-04		\N		15	3	2		1403
1515		\N	192	1664	1	2017-09-06	2017-09-12		\N		9	5	2		966
1479	Chkalov AP	\N	\N	68	1	2017-06-30	2017-09-04		\N		15	3	2		1404
1481		\N	68	1664	1	2017-09-04	\N		\N		7	3	2		1404
1482	ardvi	\N	\N	417	1	2017-05-31	2017-09-04		\N		15	3	2		1405
1484		\N	417	1664	1	2017-09-04	\N		\N		8	3	2		1405
1483	Chkalov TV	\N	\N	68	1	2017-06-30	2017-09-04		\N		15	3	2		1406
1485		\N	68	1664	1	2017-09-04	\N		\N		7	3	2		1406
1501		\N	415	1664	1	2017-09-04	\N		\N		7	3	2		1413
1486	ardvi	\N	\N	417	1	2017-05-31	2017-09-04		\N		15	3	2		1407
1487		\N	417	1664	1	2017-09-04	\N		\N		8	3	2		1407
1502		\N	\N	415	1	2017-07-01	2017-09-05		\N		15	3	2		1414
1490	Sardarapat Build AP	\N	\N	197	1	2017-05-31	2017-09-04		\N		7	3	2		1409
1491		\N	197	1664	1	2017-09-04	\N		\N		7	3	2		1409
1493		\N	\N	68	1	2017-05-31	2017-09-04		\N		15	3	2		1410
1514		\N	192	1664	1	2017-09-06	2017-09-11		\N		9	5	2		965
1503		\N	415	1664	1	2017-09-05	\N		\N		7	3	2		1414
1498		\N	68	1664	1	2017-09-04	2017-09-20		\N		7	3	2		1412
1495		\N	\N	68	1	2017-05-31	2017-09-04		\N		15	3	2		1411
1497		\N	\N	68	1	2017-05-31	2017-09-04		\N		15	3	2		1412
1494		\N	68	1664	1	2017-09-04	2017-09-20		\N		7	3	2		1410
1496		\N	68	1664	1	2017-09-04	2017-10-23		\N		7	3	2		1411
1504		\N	\N	70	1	2017-05-30	2017-09-04		\N		15	3	2		1415
1505		\N	70	1664	1	2017-09-04	\N		\N		7	3	2		1415
1506		\N	\N	68	1	2017-05-31	2017-09-04		\N		15	3	2		1416
1507		\N	68	1664	1	2017-09-04	\N		\N		7	3	2		1416
1512		\N	311	1664	2	2017-09-05	\N		\N		9	3	2		1358
1513		\N	311	1664	2	2017-09-06	\N		\N		9	3	2		1359
1509		\N	96	1664	2	2017-09-05	\N		\N		18	3	2		1300
1480		\N	1681	1664	1	2017-09-04	2017-09-13		\N		7	3	2		1403
1510	hovtamej	\N	1664	935	1	2017-06-30	2017-09-04		\N		24	3	2		1357
1517	Geghard new Tower	\N	\N	192	1	2017-06-30	2017-09-06		\N		9	3	2		1417
1518		\N	192	1664	1	2017-09-06	\N		\N		9	5	2		1417
1516		\N	192	1664	1	2017-09-06	2017-09-27		\N		9	5	2		968
1519		\N	477	1664	1	2017-09-06	2017-09-11		\N		9	5	2		959
1499	Lanjaghbyur-sw	\N	192	1674	1	2017-09-05	\N		\N		9	3	2		964
1523		\N	1674	1664	2	2017-09-07	\N		\N		9	5	2		1121
1524	Lanjaghbyur	\N	\N	343	1	2017-05-30	2017-09-07		2		9	3	2		1419
1520	Garni School AP	\N	1664	479	1	2017-06-29	2017-09-06		\N		9	3	2		1418
1526	aralez	\N	\N	763	1	2017-09-06	\N	10.205.134.123	2	VediRocket	24	3	2		1420
1527	aralez	\N	\N	763	1	2017-09-06	\N	91.205.134.123	\N		24	3	2		1421
1528	zolaqar2	\N	\N	991	1	2017-09-07	\N	10.205.141.25	2	MtuniSector1	9	3	2		1422
1525		\N	343	1664	2	2017-09-07	\N		\N		9	5	2		1419
1628		\N	138	1664	1	2017-09-11	2017-07-01		\N		13	3	2		1464
1511		\N	935	1664	2	2017-09-04	\N		\N		8	5	2		1357
1522	 LanjaghbyurGavarLink	\N	1664	1674	1	2017-09-06	\N	10.206.135.25	1	 GavarLanjaghbyurLink	9	5	2		289
1530	norashen-geghar	\N	\N	371	1	2017-09-06	\N	10.205.141.40	2	SevanRocket	9	3	2		1423
1531	norashen-geghar	\N	\N	371	1	2017-09-06	\N	91.205.141.33	\N		9	3	2		1424
1532	caghkashen	\N	\N	970	1	2017-09-06	\N	10.205.134.34	2	SevanRocket	9	3	2		1425
1533	caghkashen	\N	\N	970	1	2017-09-06	\N		\N		9	3	2		1426
1534	gegharquniq	\N	\N	343	1	2017-09-06	\N	91.205.134.56	\N		9	3	2		1427
1589		\N	\N	138	1	2017-06-14	\N		\N		23	3	2		1448
1567		\N	\N	786	1	2017-07-18	2017-09-07		\N		17	3	2		1440
1579		\N	1680	1664	2	2017-08-20	\N		\N		18	3	2		1305
1569		\N	\N	786	1	2017-07-18	2017-09-07		\N		17	3	2		1441
1570		\N	786	1664	1	2017-09-07	\N		\N		17	3	2		1441
1571		\N	\N	246	1	2017-08-08	2017-09-07		\N		17	3	2		1442
1572		\N	246	1664	1	2017-09-07	\N		\N		17	3	2		1442
1541		\N	\N	1664	1	2017-06-30	2017-08-21		\N		5	3	2		1428
1542		\N	1664	1612	1	2017-08-21	2017-08-22		\N		8	3	2		1428
1543		\N	1612	1664	1	2017-08-22	\N		\N		8	3	2		1428
1529	 LanjaghbyurRocket	\N	1664	1674	1	2017-09-06	\N	10.206.135.26	1	LandjaghbyurAP	9	5	2		217
1545		\N	\N	1664	1	2017-08-30	2017-09-01		\N		1	3	2		1429
1546	Aygehat-chkalov	\N	1664	416	1	2017-09-01	\N		\N		8	3	2		1429
1547		\N	\N	1664	1	2017-05-31	2017-08-24		\N		5	3	2		1430
1548		\N	1664	1688	1	2017-08-24	\N		\N		14	1	2		1430
1549		\N	\N	1664	1	2017-08-29	2017-09-01		\N		1	3	2		1431
1550	ChkalovMartsLink	\N	1664	68	1	2017-09-01	\N		\N		8	3	2		1431
1538		\N	1664	1141	1	2017-09-06	\N		\N		6	3	2		427
1551		\N	\N	1664	1	2017-08-29	2017-09-01		\N		1	3	2		1432
1552		\N	1664	68	1	2017-09-01	\N		\N		8	3	2		1432
1553		\N	\N	1664	1	2017-08-29	2017-09-01		\N		1	3	2		1433
1554		\N	1664	68	1	2017-09-01	\N		\N		8	3	2		1433
1555		\N	\N	778	1	2017-07-11	2017-09-07		\N		24	3	2		1434
1556		\N	778	1664	1	2017-09-07	\N		\N		17	3	2		1434
1557		\N	\N	778	1	2017-07-17	2017-09-07		\N		24	3	2		1435
1558		\N	778	1664	1	2017-09-07	\N		\N		17	3	2		1435
1559		\N	\N	773	1	2017-07-09	2017-09-07		\N		24	3	2		1436
1561		\N	\N	773	1	2017-07-16	2017-09-07		\N		24	3	2		1437
1562		\N	773	1664	1	2017-09-07	\N		\N		17	3	2		1437
1563		\N	\N	246	1	2017-07-18	2017-09-07		\N		17	3	2		1438
1564		\N	246	1664	1	2017-09-07	\N		\N		17	3	2		1438
1573		\N	477	1690	1	2017-09-06	\N		\N		8	3	2		958
1574		\N	477	1690	1	2017-09-07	\N		\N		8	3	2		960
1580	BasenJrarat	\N	1680	1680	1	2017-08-27	2017-09-18		\N	BasenJrarat	18	3	2		1304
1576		\N	\N	1664	1	2017-09-06	2017-09-08		\N		5	3	2		1443
1577		\N	1664	96	1	2017-09-08	\N		\N		18	3	2		1443
1591		\N	\N	138	1	2017-07-17	\N		\N		23	3	2		1450
1609		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		212
1610		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		207
1611		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		312
1581	saralanj-sw	\N	\N	37	1	2017-08-10	\N		\N		5	3	2		1444
1582	 SaralanjGeghasarLink	\N	\N	37	1	2017-08-26	\N		\N		5	3	2		1445
1584		\N	1664	1664	1	2017-07-30	\N		\N		9	5	1		104
1585		\N	1664	1664	1	2017-07-16	\N		\N		9	3	1		65
1592		\N	\N	138	1	2017-06-11	\N		\N		23	3	2		1451
1613		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		314
1586	gegharquniq	\N	343	343	1	2017-09-07	\N		\N		9	5	2		64
1226	SevqarIjevan Link	\N	\N	158	1	2017-08-23	2017-09-11	10.206.134.199	2	 ubnt	\N	3	2		1198
1587		\N	158	1664	1	2017-09-11	\N		\N		22	3	1		1198
1593		\N	\N	138	1	2017-05-23	\N		\N		23	3	2		1452
1595		\N	\N	138	1	2017-06-19	\N		\N		23	3	2		1454
1614		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		288
1616		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		193
1617		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		195
1605		\N	1664	138	1	2017-07-01	2017-09-12		\N		23	3	2		1464
1544		\N	1674	1664	2	2017-09-06	\N		\N		20	3	2		1122
1619		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		139
1612		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1453
1601		\N	1664	138	1	2017-06-14	2017-09-11		\N		23	3	2		1460
1560		\N	773	1664	1	2017-09-07	2017-10-11		\N		17	3	2		1436
1594		\N	\N	138	1	2017-07-12	2017-09-11		\N		23	3	2		1453
1615		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1456
1597		\N	\N	138	1	2017-07-19	2017-09-11		\N		23	3	2		1456
1618		\N	1664	138	1	2017-09-11	\N		\N		13	3	2		192
1537		\N	1664	1093	1	2017-09-06	\N		\N		6	3	2		429
1568		\N	786	1664	1	2017-09-07	2017-09-12		\N		17	3	2		1440
1578		\N	1680	1664	2	2017-08-19	\N		\N		18	3	2		1303
1575		\N	96	1664	2	2017-09-07	\N		\N		18	3	2		757
1722		\N	1664	575	1	2017-09-12	\N		\N		23	3	2		338
1651		\N	\N	138	1	2017-06-11	2017-09-11		\N		23	3	2		1473
1655		\N	1664	138	1	2017-07-17	2017-09-12		\N		23	3	2		1475
1653		\N	1664	138	1	2017-06-12	2017-09-12		\N		23	3	2		1474
1657		\N	1664	138	1	2017-09-12	2017-09-11		\N		23	3	2		1476
1656		\N	138	1664	1	2017-09-11	2017-07-17		\N		13	3	2		1475
1693		\N	\N	448	1	2017-07-19	\N		\N		5	3	2		1487
1694		\N	\N	448	1	2017-07-12	\N		\N		5	3	2		1488
1740		\N	\N	146	1	2017-07-16	2017-09-18		\N		23	3	2		1493
1660		\N	1664	138	1	2017-09-12	2017-09-12		\N		23	3	2		1478
1695		\N	\N	448	1	2017-07-12	\N		\N		5	3	2		1489
1665		\N	1664	151	1	2017-09-11	\N		\N		23	3	2		206
1658		\N	138	1664	1	2017-09-10	2017-09-12		\N		13	3	2		1476
1661		\N	138	1664	1	2017-09-11	2017-09-12		\N		13	3	2		1478
1667		\N	1664	151	1	2017-09-11	\N		\N		23	3	2		321
1664		\N	1664	151	1	2017-09-11	\N		\N		23	3	2		196
1650		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1472
1662		\N	130	138	1	2017-06-19	2017-09-25		\N		23	3	2		1479
1703		\N	1664	137	1	2017-09-12	\N		\N		23	3	2		966
1670		\N	1664	148	1	2017-09-11	\N		\N		21	3	2		965
1671		\N	1664	148	1	2017-09-11	\N		\N		21	3	2		558
1669		\N	1664	148	1	2017-09-11	\N		\N		21	3	2		306
1707		\N	1664	1424	1	2017-09-12	\N		\N		23	3	2		303
1666		\N	1664	151	1	2017-09-11	\N		\N		23	3	2		138
1673		\N	1664	1693	1	2017-09-10	\N		\N		23	3	2		1418
1732		\N	1664	573	1	2017-09-13	\N		\N		21	3	2		489
1676		\N	1664	147	1	2017-09-11	\N		\N		21	3	2		191
1677		\N	1664	147	1	2017-09-11	\N		\N		21	3	2		959
1678		\N	1664	147	1	2017-09-11	\N		\N		21	3	2		333
1719		\N	1664	1459	1	2017-09-12	2017-10-05		\N		21	3	2		336
1728		\N	1664	581	1	2017-09-13	2017-10-17		\N		23	3	2		530
1679		\N	\N	1664	1	2017-01-12	2017-07-10		\N		5	3	2		1480
1700		\N	1664	1460	1	2017-09-10	\N		\N		23	3	2		301
1681		\N	129	1664	1	2017-04-11	2017-07-11		\N		5	3	2		1481
1696		\N	1664	143	1	2017-09-12	\N		\N		23	3	2		145
1683		\N	\N	1664	1	2017-03-14	2017-07-10		\N		5	3	2		1482
1697		\N	1664	143	1	2017-09-12	\N		\N		23	3	2		302
1685		\N	143	1664	1	2017-03-16	2017-07-11		\N		5	3	2		1483
1689		\N	1664	1269	1	2017-04-10	2017-09-12		\N		5	3	2		1485
1687		\N	1664	1269	1	2017-04-13	2017-09-12		\N		5	3	2		1484
1691		\N	1664	1269	1	2017-04-11	2017-09-12		\N		5	3	2		1486
1690		\N	1269	1664	2	2017-09-11	2017-04-10		\N		16	3	2		1485
1710		\N	1664	592	1	2017-09-12	\N		\N		23	3	2		143
1692		\N	1269	1664	2	2017-09-11	2017-04-11		\N		16	3	2		1486
1709		\N	1664	149	1	2017-09-12	\N		\N		21	3	2		147
1712		\N	1664	149	1	2017-09-12	\N		\N		21	3	2		304
1739		\N	\N	145	1	2017-06-19	2017-09-25		\N		23	3	2		1492
1675		\N	1664	147	1	2017-09-11	\N		\N		21	3	2		141
1699		\N	1664	1460	1	2017-09-10	\N		\N		23	3	2		290
1684		\N	1664	143	1	2017-07-10	\N		\N		23	3	2		1482
1701		\N	1664	153	1	2017-09-12	\N		\N		23	3	2		493
1706		\N	1664	139	1	2017-09-12	\N		\N		23	3	2		1277
1688		\N	1269	1664	2	2017-09-11	2017-04-13		\N		16	3	2		1484
1702		\N	1664	153	1	2017-09-12	\N		\N		23	3	2		466
1708		\N	1664	1424	1	2017-09-12	\N		\N		23	3	2		470
1715		\N	1664	1424	1	2017-09-12	\N		\N		23	3	2		762
1716		\N	1664	149	1	2017-09-12	\N		\N		21	3	2		311
1711		\N	1664	592	1	2017-09-12	\N		\N		23	3	2		300
1713		\N	1664	592	1	2017-09-12	\N		\N		23	3	2		223
1717		\N	1664	149	1	2017-09-12	\N		\N		21	3	2		210
1714		\N	1664	592	1	2017-09-12	\N		\N		23	3	2		313
1680		\N	1664	129	1	2017-07-10	\N		\N		23	3	2		1480
142		\N	1460	1664	1	2017-07-16	2017-09-10		\N		5	3	2		142
1674		\N	1664	1693	1	2017-09-10	\N		\N		23	3	2		759
1652		\N	138	1664	1	2017-09-11	\N		\N		13	3	2		1473
1668		\N	1664	148	1	2017-09-11	\N		\N		21	3	2		140
1704		\N	1664	139	1	2017-09-12	\N		\N		23	3	2		144
1736		\N	1664	625	1	2017-09-13	\N		\N		23	3	2		337
1735		\N	1664	1458	1	2017-09-13	\N		\N		23	3	2		477
1734		\N	1664	1450	1	2017-09-13	\N		\N		23	3	2		132
1725		\N	1664	583	1	2017-09-13	\N		\N		23	3	2		524
1730		\N	1664	574	1	2017-09-12	\N		\N		21	3	2		1440
1724		\N	1664	584	1	2017-09-13	\N		\N		23	3	2		1403
1731		\N	1664	593	1	2017-09-13	\N		\N		23	3	2		94
1729		\N	1664	1692	1	2017-09-12	\N		\N		23	3	2		131
1721		\N	1664	595	1	2017-09-13	\N		\N		23	3	2		538
131		\N	\N	1664	\N	2017-07-17	2017-09-12		\N		5	3	2		131
1727		\N	1664	585	1	2017-09-13	\N		\N		23	3	2		96
1733		\N	1664	594	1	2017-09-13	\N		\N		23	3	2		93
1720		\N	1664	597	1	2017-09-13	\N		\N		23	3	2		543
1718		\N	1664	140	1	2017-09-12	2017-10-11		\N		23	3	2		539
1726		\N	1664	582	1	2017-09-13	\N		\N		23	3	2		541
1737		\N	\N	145	1	2017-06-19	\N		\N		23	3	2		1490
1738		\N	\N	146	1	2017-06-12	\N		\N		23	3	2		1491
1682		\N	1664	129	1	2017-07-10	2017-04-11		\N		23	3	2		1481
1686		\N	1664	143	1	2017-07-10	2017-03-16		\N		23	3	2		1483
1654		\N	138	1664	1	2017-09-11	2017-06-12		\N		13	3	2		1474
1741		\N	\N	146	1	2017-06-12	\N		\N		23	3	2		1494
1742		\N	\N	145	1	2017-06-19	\N		\N		23	3	2		1495
1743		\N	\N	145	1	2017-06-19	\N		\N		23	3	2		1496
1744		\N	\N	146	1	2017-07-07	\N		\N		23	3	2		1497
1745		\N	\N	145	1	2017-06-19	\N		\N		23	3	2		1498
1746		\N	\N	145	1	2017-06-19	\N		\N		23	3	2		1499
1773		\N	\N	1460	1	2017-06-22	2017-09-25		\N		23	3	2		1526
1821		\N	\N	117	1	2017-07-07	\N		\N		23	3	2		1574
1822		\N	\N	117	1	2017-06-26	\N		\N		23	3	2		1575
1672		\N	1664	1693	1	2017-09-10	\N		\N		23	3	2		491
1762		\N	\N	140	1	2017-06-24	\N		\N		23	3	2		1515
1763		\N	\N	140	1	2017-06-15	\N		\N		23	3	2		1516
1765		\N	\N	140	1	2017-06-28	\N		\N		23	3	2		1518
1755		\N	\N	1693	1	2017-07-16	2017-09-25		\N		23	3	2		1508
1753		\N	\N	1693	1	2017-06-17	\N		\N		23	3	2		1506
1751		\N	\N	151	1	2017-06-05	2017-09-25		\N		23	3	2		1504
1769		\N	\N	139	1	2017-06-18	\N		\N		23	3	2		1522
1776		\N	\N	148	1	2017-07-17	\N		\N		23	3	2		1529
1778		\N	\N	1460	1	2017-07-20	\N		\N		23	3	2		1531
1780		\N	\N	1692	1	2017-06-12	\N		\N		23	3	2		1533
1781		\N	\N	137	1	2017-07-09	\N		\N		23	3	2		1534
1783		\N	\N	137	1	2017-07-10	\N		\N		23	3	2		1536
1786		\N	\N	129	1	2017-06-19	\N		\N		23	3	2		1539
1787		\N	\N	129	1	2017-06-19	\N		\N		23	3	2		1540
1788		\N	\N	129	1	2017-06-12	\N		\N		23	3	2		1541
1795		\N	\N	143	1	2017-06-25	\N		\N		23	3	2		1548
1797		\N	\N	143	1	2017-07-15	\N		\N		23	3	2		1550
1801		\N	\N	143	1	2017-06-30	\N		\N		23	3	2		1554
1803		\N	\N	129	1	2017-06-11	\N		\N		23	3	2		1556
1807		\N	\N	143	1	2017-06-21	\N		\N		23	3	2		1560
1808		\N	\N	153	1	2017-07-17	\N		\N		23	3	2		1561
1810		\N	\N	153	1	2017-07-09	\N		\N		23	3	2		1563
1811		\N	\N	120	1	2017-06-12	\N		\N		23	3	2		1564
1812		\N	\N	120	1	2017-07-17	\N		\N		23	3	2		1565
1814		\N	\N	120	1	2017-07-17	\N		\N		23	3	2		1567
1817		\N	\N	120	1	2017-07-10	\N		\N		23	3	2		1570
1818		\N	\N	1424	1	2017-07-19	\N		\N		23	3	2		1571
1819		\N	\N	1424	1	2017-06-05	\N		\N		23	3	2		1572
1820		\N	\N	117	1	2017-07-21	\N		\N		23	3	2		1573
1824		\N	\N	117	1	2017-07-14	\N		\N		23	3	2		1577
1825		\N	130	1664	2	2017-10-05	\N		\N		13	3	2		1576
1826		\N	\N	117	1	2017-06-21	\N		\N		23	3	2		1578
1828		\N	\N	117	1	2017-06-08	\N		\N		23	3	2		1580
1827		\N	130	1664	1	2017-05-15	2017-09-14		\N		5	3	2		1579
1823		\N	\N	130	1	2017-03-21	2017-10-05		\N		23	3	2		1576
1830		\N	\N	117	1	2017-07-14	\N		\N		23	3	2		1581
1832		\N	\N	130	1	2017-06-12	\N		\N		23	3	2		1583
1833		\N	\N	133	1	2017-07-07	\N		\N		23	3	2		1584
1796		\N	\N	129	1	2017-06-20	2017-09-25		\N		23	3	2		1549
1831		\N	\N	133	1	2017-06-28	\N		\N		23	3	2		1582
1782		\N	\N	592	1	2017-06-09	2017-09-25		\N		23	3	2		1535
1791		\N	\N	129	1	2017-06-19	2017-09-25		\N		23	3	2		1544
1789		\N	\N	129	1	2017-06-20	2017-09-25		\N		23	3	2		1542
1798		\N	\N	129	1	2017-07-09	2017-09-25		\N		23	3	2		1551
1792		\N	\N	129	1	2017-06-19	2017-09-25		\N		23	3	2		1545
1790		\N	\N	129	1	2017-07-17	2017-09-25		\N		23	3	2		1543
1800		\N	\N	129	1	2017-06-12	2017-09-25		\N		23	3	2		1553
1764		\N	\N	140	1	2017-06-20	2017-09-25		\N		23	3	2		1517
1771		\N	\N	148	1	2017-06-12	2017-09-25		\N		23	3	2		1524
1777		\N	\N	148	1	2017-06-19	2017-09-25		\N		23	3	2		1530
1779		\N	\N	148	1	2017-07-17	2017-09-25		\N		23	3	2		1532
1774		\N	\N	148	1	2017-06-18	2017-09-25		\N		23	3	2		1527
1813		\N	\N	1424	1	2017-06-08	2017-09-25		\N		23	3	2		1566
1816		\N	\N	1424	1	2017-07-07	2017-09-25		\N		23	3	2		1569
1815		\N	\N	1424	1	2017-06-10	2017-09-25		\N		23	3	2		1568
1754		\N	\N	147	1	2017-06-18	2017-09-25		\N		23	3	2		1507
1770		\N	\N	1460	1	2017-06-21	2017-09-25		\N		23	3	2		1523
1775		\N	\N	1460	1	2017-07-05	2017-09-25		\N		23	3	2		1528
1772		\N	\N	1460	1	2017-06-16	2017-09-25		\N		23	3	2		1525
1759		\N	\N	147	1	2017-06-12	2017-09-25		\N		23	3	2		1512
1757		\N	\N	147	1	2017-06-19	2017-09-25		\N		23	3	2		1510
1756		\N	\N	147	1	2017-06-17	2017-09-25		\N		23	3	2		1509
1748		\N	\N	145	1	2017-06-18	2017-09-25		\N		23	3	2		1501
1766		\N	\N	139	1	2017-07-14	2017-09-25		\N		23	3	2		1519
1768		\N	\N	139	1	2017-06-09	2017-09-25		\N		23	3	2		1521
1767		\N	\N	139	1	2017-06-24	2017-09-25		\N		23	3	2		1520
1799		\N	\N	143	1	2017-06-02	2017-09-25		\N		23	3	2		1552
1806		\N	\N	153	1	2017-07-09	2017-09-25		\N		23	3	2		1559
1809		\N	\N	153	1	2017-06-12	2017-09-25		\N		23	3	2		1562
1802		\N	\N	143	1	2017-07-25	2017-09-25		\N		23	3	2		1555
1793		\N	\N	143	1	2017-06-04	2017-09-25		\N		23	3	2		1546
1804		\N	\N	143	1	2017-06-05	2017-09-25		\N		23	3	2		1557
1794		\N	\N	143	1	2017-06-21	2017-09-25		\N		23	3	2		1547
1805		\N	\N	143	1	2017-07-14	2017-09-25		\N		23	3	2		1558
1760		\N	\N	149	1	2017-06-07	2017-09-25		\N		23	3	2		1513
1750		\N	\N	1693	1	2017-06-09	2017-09-25		\N		4	3	2		1503
1747		\N	\N	151	1	2017-06-04	2017-09-25		\N		23	3	2		1500
1752		\N	\N	151	1	2017-06-05	2017-09-25		\N		23	3	2		1505
1749		\N	\N	151	1	2017-07-17	2017-09-25		\N		23	3	2		1502
1784		\N	\N	137	1	2017-07-10	2017-09-25		\N		23	3	2		1537
1785		\N	\N	137	1	2017-07-09	2017-09-25		\N		23	3	2		1538
1835		\N	\N	130	1	2017-05-16	\N		\N		23	3	2		1585
1837		\N	\N	133	1	2017-06-05	\N		\N		23	3	2		1587
1839		\N	\N	130	1	2017-04-12	\N		\N		23	3	2		1589
1840		\N	\N	133	1	2017-06-04	\N		\N		23	3	2		1590
1841		\N	\N	130	1	2017-05-09	\N		\N		23	3	2		1591
1842		\N	\N	212	1	2017-06-09	\N		\N		23	3	2		1592
1843		\N	\N	212	1	2017-07-13	\N		\N		23	3	2		1593
1844		\N	\N	131	1	2017-05-16	\N		\N		23	3	2		1594
1845		\N	\N	212	1	2017-07-02	\N		\N		23	3	2		1595
1846		\N	\N	131	1	2017-05-17	\N		\N		23	3	2		1596
1847		\N	\N	131	1	2017-05-15	\N		\N		23	3	2		1597
1848		\N	\N	118	1	2017-07-04	\N		\N		23	3	2		1598
1849		\N	\N	118	1	2017-07-02	\N		\N		23	3	2		1599
1850		\N	\N	118	1	2017-07-04	\N		\N		23	3	2		1600
1851		\N	\N	118	1	2017-07-04	\N		\N		23	3	2		1601
1852		\N	\N	131	1	2017-06-13	\N		\N		23	3	2		1602
1853		\N	\N	131	1	2017-05-23	\N		\N		23	3	2		1603
1854		\N	\N	119	1	2017-07-09	\N		\N		23	3	2		1604
1855		\N	\N	119	1	2017-07-09	\N		\N		23	3	2		1605
1856		\N	\N	1695	1	2017-07-11	\N		\N		23	3	2		1606
1857		\N	\N	1695	1	2017-05-29	\N		\N		23	3	2		1607
1858		\N	\N	1695	1	2017-07-04	\N		\N		23	3	2		1608
1859		\N	\N	119	1	2017-07-17	\N		\N		23	3	2		1609
1860		\N	\N	211	1	2017-07-06	\N		\N		23	3	2		1610
1861		\N	\N	211	1	2017-07-12	\N		\N		23	3	2		1611
1862		\N	\N	125	1	2017-07-04	\N		\N		23	3	2		1612
1863		\N	\N	122	1	2017-07-02	\N		\N		23	3	2		1613
1864		\N	\N	125	1	2017-07-04	\N		\N		23	3	2		1614
1865		\N	\N	132	1	2017-04-18	\N		\N		23	3	2		1615
1866		\N	\N	122	1	2017-06-19	\N		\N		23	3	2		1616
1867		\N	\N	132	1	2017-06-12	\N		\N		23	3	2		1617
1868		\N	\N	616	1	2017-07-09	\N		\N		23	3	2		1618
1869		\N	\N	132	1	2017-04-10	\N		\N		23	3	2		1619
1870		\N	\N	132	1	2017-06-12	\N		\N		23	3	2		1620
1871		\N	\N	616	1	2017-07-03	\N		\N		23	3	2		1621
1872		\N	\N	134	1	2017-06-12	\N		\N		23	3	2		1622
1873		\N	\N	134	1	2017-07-10	\N		\N		23	3	2		1623
1875		\N	\N	1696	1	2017-07-10	\N		\N		23	3	2		1625
1876		\N	\N	134	1	2017-07-04	\N		\N		23	3	2		1626
1877		\N	\N	134	1	2017-07-10	\N		\N		23	3	2		1627
1878		\N	\N	1696	1	2017-07-04	\N		\N		23	3	2		1628
1879		\N	\N	1446	1	2017-06-05	\N		\N		23	3	2		1629
1880		\N	\N	134	1	2017-07-10	\N		\N		23	3	2		1630
1874		\N	\N	1446	1	2017-06-11	\N		\N		23	3	2		1624
1881		\N	\N	1696	1	2017-07-11	\N		\N		23	3	2		1631
1882		\N	\N	134	1	2017-07-11	\N		\N		23	3	2		1632
1883		\N	\N	135	1	2017-07-11	\N		\N		23	3	2		1633
1884		\N	\N	135	1	2017-07-11	\N		\N		23	3	2		1634
1885		\N	\N	135	1	2017-07-11	\N		\N		23	3	2		1635
1886		\N	\N	135	1	2017-07-10	\N		\N		23	3	2		1636
1887		\N	\N	128	1	2017-07-17	\N		\N		23	3	2		1637
1888		\N	\N	136	1	2017-07-10	\N		\N		23	3	2		1638
1890		\N	\N	136	1	2017-07-10	\N		\N		23	3	2		1640
1891		\N	\N	1697	1	2017-05-15	\N		\N		23	3	2		1641
1892		\N	\N	128	1	2017-07-10	\N		\N		23	3	2		1642
1893		\N	\N	1697	1	2017-06-20	\N		\N		23	3	2		1643
1889		\N	\N	128	1	2017-07-09	\N		\N		23	3	2		1639
1894		\N	\N	136	1	2017-06-08	\N		\N		23	3	2		1644
1895		\N	\N	1697	1	2017-06-05	\N		\N		23	3	2		1645
1896		\N	\N	136	1	2017-06-01	\N		\N		23	3	2		1646
1897		\N	\N	173	1	2017-06-01	\N		\N		23	3	2		1647
1898		\N	\N	173	1	2017-06-01	\N		\N		23	3	2		1648
1899		\N	\N	236	1	2017-07-03	\N		\N		23	3	2		1649
1900		\N	\N	173	1	2017-06-13	\N		\N		23	3	2		1650
1901		\N	\N	173	1	2017-07-10	\N		\N		23	3	2		1651
1902		\N	\N	173	1	2017-07-09	\N		\N		23	3	2		1652
1903		\N	\N	236	1	2017-07-11	\N		\N		23	3	2		1653
1904		\N	\N	173	1	2017-07-09	\N		\N		23	3	2		1654
1905		\N	\N	236	1	2017-07-10	\N		\N		23	3	2		1655
1906		\N	\N	173	1	2017-06-12	\N		\N		23	3	2		1656
1907		\N	\N	236	1	2017-07-10	\N		\N		23	3	2		1657
1908		\N	\N	173	1	2017-07-08	\N		\N		23	3	2		1658
1909		\N	\N	173	1	2017-07-02	\N		\N		23	3	2		1659
1910		\N	\N	173	1	2017-06-11	\N		\N		23	3	2		1660
1912		\N	\N	173	1	2017-07-02	\N		\N		23	3	2		1662
1911		\N	\N	235	1	2017-07-09	\N		\N		23	3	2		1661
1913		\N	\N	242	1	2017-07-01	\N		\N		23	3	2		1663
1914		\N	\N	235	1	2017-07-09	\N		\N		23	3	2		1664
1915		\N	\N	242	1	2017-07-11	\N		\N		23	3	2		1665
1916		\N	\N	242	1	2017-07-10	\N		\N		23	3	2		1666
1917		\N	\N	235	1	2017-07-09	\N		\N		23	3	2		1667
1918		\N	\N	241	1	2017-06-11	\N		\N		23	3	2		1668
1919		\N	\N	241	1	2017-07-10	\N		\N		23	3	2		1669
1920		\N	\N	235	1	2017-07-09	\N		\N		23	3	2		1670
1921		\N	\N	241	1	2017-07-08	\N		\N		23	3	2		1671
1922		\N	\N	241	1	2017-07-10	\N		\N		23	3	2		1672
1923		\N	\N	235	1	2017-07-10	\N		\N		23	3	2		1673
1924		\N	\N	241	1	2017-06-20	\N		\N		23	3	2		1674
1925		\N	\N	180	1	2017-07-11	\N		\N		23	3	2		1675
1926		\N	\N	180	1	2017-07-04	\N		\N		23	3	2		1676
1927		\N	\N	175	1	2017-07-11	\N		\N		23	3	2		1677
1928		\N	\N	180	1	2017-07-10	\N		\N		23	3	2		1678
1929		\N	\N	180	1	2017-07-10	\N		\N		23	3	2		1679
1930		\N	\N	175	1	2017-07-10	\N		\N		23	3	2		1680
1931		\N	\N	180	1	2017-07-10	\N		\N		23	3	2		1681
1838		\N	\N	130	1	2017-04-11	2017-09-25		\N		23	3	2		1588
1932		\N	\N	180	1	2017-06-03	\N		\N		23	3	2		1682
1933		\N	\N	175	1	2017-06-12	\N		\N		23	3	2		1683
1934		\N	\N	180	1	2017-07-05	\N		\N		23	3	2		1684
1935		\N	\N	175	1	2017-07-09	\N		\N		23	3	2		1685
1936		\N	\N	216	1	2017-06-04	\N		\N		23	3	2		1686
1937		\N	\N	216	1	2017-07-11	\N		\N		23	3	2		1687
1938		\N	\N	169	1	2017-07-01	\N		\N		23	3	2		1688
1939		\N	\N	216	1	2017-07-01	\N		\N		23	3	2		1689
1940		\N	\N	216	1	2017-07-09	\N		\N		23	3	2		1690
1941		\N	\N	169	1	2017-07-09	\N		\N		23	3	2		1691
1942		\N	\N	216	1	2017-06-06	\N		\N		23	3	2		1692
1943		\N	\N	170	1	2017-06-19	\N		\N		23	3	2		1693
1944		\N	\N	169	1	2017-07-10	\N		\N		23	3	2		1694
1945		\N	\N	170	1	2017-06-20	\N		\N		23	3	2		1695
1946		\N	\N	216	1	2017-07-02	\N		\N		23	3	2		1696
1947		\N	\N	170	1	2017-06-19	\N		\N		23	3	2		1697
1948		\N	\N	169	1	2017-07-10	\N		\N		23	3	2		1698
1949		\N	\N	170	1	2017-06-20	\N		\N		23	3	2		1699
1950		\N	\N	648	1	2017-07-04	\N		\N		23	3	2		1700
1951		\N	\N	648	1	2017-07-05	\N		\N		23	3	2		1701
1952		\N	\N	169	1	2017-07-10	\N		\N		23	3	2		1702
1953		\N	\N	170	1	2017-06-04	\N		\N		23	3	2		1703
1954		\N	\N	648	1	2017-07-04	\N		\N		23	3	2		1704
1955		\N	\N	169	1	2017-07-10	\N		\N		23	3	2		1705
1956		\N	\N	178	1	2017-07-11	\N		\N		23	3	2		1706
1957		\N	\N	237	1	2017-06-19	\N		\N		23	3	2		1707
1958		\N	\N	169	1	2017-07-11	\N		\N		23	3	2		1708
1959		\N	\N	178	1	2017-07-04	\N		\N		23	3	2		1709
1960		\N	\N	237	1	2017-06-07	\N		\N		23	3	2		1710
1961		\N	\N	178	1	2017-07-04	\N		\N		23	3	2		1711
1962		\N	\N	237	1	2017-06-13	\N		\N		23	3	2		1712
1963		\N	\N	169	1	2017-07-02	\N		\N		23	3	2		1713
1964		\N	\N	178	1	2017-07-11	\N		\N		23	3	2		1714
1965		\N	\N	237	1	2017-06-05	\N		\N		23	3	2		1715
1966		\N	\N	237	1	2017-05-16	\N		\N		23	3	2		1716
1967		\N	\N	178	1	2017-07-03	\N		\N		23	3	2		1717
1968		\N	\N	237	1	2017-05-22	\N		\N		23	3	2		1718
1969		\N	\N	237	1	2017-06-13	\N		\N		23	3	2		1719
1970		\N	\N	178	1	2017-07-10	\N		\N		23	3	2		1720
1971		\N	\N	172	1	2017-07-02	\N		\N		23	3	2		1721
1972		\N	\N	172	1	2017-06-26	\N		\N		23	3	2		1722
1973		\N	\N	177	1	2017-07-03	\N		\N		23	3	2		1723
1974		\N	\N	172	1	2017-06-11	\N		\N		23	3	2		1724
1975		\N	\N	177	1	2017-07-03	\N		\N		23	3	2		1725
1976		\N	\N	172	1	2017-07-11	\N		\N		23	3	2		1726
1977		\N	\N	177	1	2017-07-03	\N		\N		23	3	2		1727
1978		\N	\N	177	1	2017-07-10	\N		\N		23	3	2		1728
1979		\N	\N	172	1	2017-07-03	\N		\N		23	3	2		1729
1980		\N	\N	177	1	2017-07-04	\N		\N		23	3	2		1730
1981		\N	\N	172	1	2017-07-03	\N		\N		23	3	2		1731
1982		\N	\N	177	1	2017-07-17	\N		\N		23	3	2		1732
1983		\N	\N	172	1	2017-07-03	\N		\N		23	3	2		1733
1984		\N	\N	223	1	2017-06-10	\N		\N		23	3	2		1734
1985		\N	\N	223	1	2017-07-11	\N		\N		23	3	2		1735
1986		\N	\N	172	1	2017-07-10	\N		\N		23	3	2		1736
1987		\N	\N	223	1	2017-07-03	\N		\N		23	3	2		1737
1988		\N	\N	223	1	2017-07-09	\N		\N		23	3	2		1738
1989		\N	\N	238	1	2017-07-09	\N		\N		23	3	2		1739
1990		\N	\N	239	1	2017-07-03	\N		\N		23	3	2		1740
1991		\N	\N	238	1	2017-07-18	\N		\N		23	3	2		1741
1992		\N	\N	238	1	2017-07-09	\N		\N		23	3	2		1742
1993		\N	\N	239	1	2017-07-03	\N		\N		23	3	2		1743
1994		\N	\N	238	1	2017-07-09	\N		\N		23	3	2		1744
1995		\N	\N	239	1	2017-07-02	\N		\N		23	3	2		1745
1996		\N	\N	181	1	2017-07-09	\N		\N		23	3	2		1746
1997		\N	\N	181	1	2017-07-02	\N		\N		23	3	2		1747
1998		\N	\N	239	1	2017-07-10	\N		\N		23	3	2		1748
1999		\N	\N	181	1	2017-07-10	\N		\N		23	3	2		1749
2000		\N	\N	181	1	2017-07-03	\N		\N		23	3	2		1750
2001		\N	\N	181	1	2017-07-03	\N		\N		23	3	2		1751
2002		\N	\N	181	1	2017-07-03	\N		\N		23	3	2		1752
2003		\N	\N	240	1	2017-07-02	\N		\N		23	3	2		1753
2004		\N	\N	176	1	2017-06-27	\N		\N		23	3	2		1754
2005		\N	\N	240	1	2017-07-18	\N		\N		23	3	2		1755
2006		\N	\N	176	1	2017-07-02	\N		\N		23	3	2		1756
2007		\N	\N	240	1	2017-07-10	\N		\N		23	3	2		1757
2008		\N	\N	176	1	2017-07-10	\N		\N		23	3	2		1758
2009		\N	\N	176	1	2017-07-02	\N		\N		23	3	2		1759
2010		\N	\N	638	1	2017-07-02	\N		\N		23	3	2		1760
2011		\N	\N	176	1	2017-07-02	\N		\N		23	3	2		1761
2012		\N	\N	240	2	2017-06-05	\N		\N		23	3	2		1762
2013		\N	\N	174	1	2017-07-09	\N		\N		23	3	2		1763
2014		\N	\N	174	1	2017-07-03	\N		\N		23	3	2		1764
2015		\N	\N	174	1	2017-07-09	\N		\N		23	3	2		1765
2016		\N	\N	174	1	2017-07-03	\N		\N		23	3	2		1766
2017		\N	\N	174	1	2017-07-03	\N		\N		23	3	2		1767
2018		\N	\N	174	1	2017-07-02	\N		\N		23	3	2		1768
2019		\N	\N	174	1	2017-05-15	\N		\N		23	3	2		1769
2020		\N	\N	37	1	2017-07-10	\N		\N		5	3	2		1770
2021		\N	\N	37	1	2017-07-10	\N		\N		5	3	2		1771
2022		\N	\N	37	1	2017-07-13	\N		\N		5	3	2		1772
2023		\N	\N	37	1	2017-06-05	\N		\N		5	3	2		1773
2024		\N	\N	37	1	2017-06-13	\N		\N		5	3	2		1774
2025		\N	\N	433	1	2017-06-05	\N		\N		5	3	2		1775
2026	switch	\N	\N	904	1	2017-05-31	\N		\N		8	3	2		1776
2027		\N	\N	433	1	2017-07-10	\N		\N		5	3	2		1777
2028		\N	\N	433	1	2017-07-18	\N		\N		5	3	2		1778
2029		\N	\N	433	1	2017-07-10	\N		\N		5	3	2		1779
2030	Switch	\N	\N	42	1	2017-05-31	\N		\N		7	3	2		1780
2031		\N	\N	443	1	2017-07-09	\N		\N		5	3	2		1781
2032		\N	\N	443	1	2017-07-18	\N		\N		5	3	2		1782
2033		\N	\N	916	1	2017-05-31	\N		\N		7	3	2		1783
2034		\N	\N	443	1	2017-07-11	\N		\N		5	3	2		1784
2035		\N	\N	443	1	2017-07-11	\N		\N		5	3	2		1785
2036	Switch	\N	\N	40	1	2017-06-01	\N		\N		8	3	2		1786
2037		\N	\N	31	1	2017-07-11	\N		\N		5	3	2		1787
2038	Switch	\N	\N	927	1	2017-05-31	\N		\N		7	3	2		1788
2039		\N	\N	31	1	2017-07-10	\N		\N		5	3	2		1789
2040		\N	\N	31	1	2017-07-10	\N		\N		5	3	2		1790
2041	Switch	\N	\N	831	1	2017-05-31	\N		\N		24	3	2		1791
2042		\N	\N	31	1	2017-07-10	\N		\N		5	3	2		1792
2043		\N	\N	31	1	2017-06-12	\N		\N		5	3	2		1793
2044	Switch	\N	\N	834	1	2017-05-31	\N		\N		24	3	2		1794
2045		\N	\N	31	1	2017-07-10	\N		\N		5	3	2		1795
2046	Switch	\N	\N	843	1	2017-05-31	\N		\N		24	3	2		1796
2047		\N	\N	31	1	2017-07-11	\N		\N		5	3	2		1797
2048	Switch	\N	\N	822	1	2017-05-31	\N		\N		24	3	2		1798
2049		\N	\N	32	1	2017-06-12	\N		\N		5	3	2		1799
2050		\N	\N	32	1	2017-07-11	\N		\N		5	3	2		1800
2051		\N	\N	32	1	2017-07-18	\N		\N		5	3	2		1801
2052		\N	\N	33	1	2017-07-10	\N		\N		5	3	2		1802
2053		\N	\N	33	1	2017-07-12	\N		\N		5	3	2		1803
2054	Switch	\N	\N	309	1	2017-05-31	\N		\N		24	3	2		1804
2055		\N	\N	33	1	2017-07-10	\N		\N		5	3	2		1805
2056		\N	\N	438	1	2017-07-10	\N		\N		5	3	2		1806
2057		\N	\N	438	1	2017-07-11	\N		\N		5	3	2		1807
2058		\N	\N	438	1	2017-07-10	\N		\N		5	3	2		1808
2059	Switch	\N	\N	225	1	2017-05-31	\N		\N		24	3	2		1809
2060		\N	\N	89	1	2017-07-11	\N		\N		5	3	2		1810
2062		\N	\N	89	1	2017-07-10	\N		\N		5	3	2		1812
2063		\N	\N	89	1	2017-07-10	\N		\N		5	3	2		1813
2064	Switch	\N	\N	55	1	2017-05-31	\N		\N		12	3	2		1814
2065	Switch	\N	\N	731	1	2017-05-31	\N		\N		12	3	2		1815
2066		\N	\N	89	1	2017-07-04	\N		\N		5	3	2		1816
2067	Switch	\N	\N	734	1	2017-05-31	\N		\N		12	3	2		1817
2068		\N	\N	89	1	2017-07-17	\N		\N		5	3	2		1818
2069		\N	\N	89	1	2017-07-02	\N		\N		5	3	2		1819
2070	Switch	\N	\N	281	1	2017-05-31	\N		\N		12	3	2		1820
2071	Switch	\N	\N	707	1	2017-05-31	\N		\N		12	3	2		1821
2072		\N	\N	1205	1	2017-07-10	\N		\N		5	3	2		1822
2073	Switch	\N	\N	720	1	2017-05-31	\N		\N		12	3	2		1823
2074		\N	\N	1205	1	2017-07-10	\N		\N		5	3	2		1824
2076		\N	\N	1205	1	2017-06-06	\N		\N		5	3	2		1826
2077	Switch	\N	\N	269	1	2017-05-31	\N		\N		12	3	2		1827
2078		\N	\N	1205	1	2017-06-11	\N		\N		5	3	2		1828
2079	Switch	\N	\N	57	1	2017-05-31	\N		\N		12	3	2		1829
2080		\N	\N	84	1	2017-07-09	\N		\N		5	3	2		1830
2081		\N	\N	84	1	2017-07-02	\N		\N		5	3	2		1831
2082		\N	\N	84	1	2017-07-18	\N		\N		5	3	2		1832
2083	Switch	\N	\N	25	1	2017-05-31	\N		\N		9	3	2		1833
2084		\N	\N	93	1	2017-07-10	\N		\N		5	3	2		1834
2085		\N	\N	93	1	2017-07-02	\N		\N		5	3	2		1835
2086		\N	\N	93	1	2017-07-11	\N		\N		5	3	2		1836
2087		\N	\N	94	1	2017-06-12	\N		\N		5	3	2		1837
2088		\N	\N	94	1	2017-06-12	\N		\N		5	3	2		1838
2089	Switch	\N	\N	1338	1	2017-05-31	\N		\N		18	3	2		1839
2090		\N	\N	94	1	2017-06-11	\N		\N		5	3	2		1840
2091		\N	\N	85	1	2017-06-20	\N		\N		5	3	2		1841
2092		\N	\N	85	1	2017-06-13	\N		\N		5	3	2		1842
2093	Switch	\N	\N	107	1	2017-05-31	\N		\N		18	3	2		1843
2094		\N	\N	85	1	2017-06-21	\N		\N		5	3	2		1844
2095		\N	\N	85	1	2017-06-12	\N		\N		5	3	2		1845
2096		\N	\N	85	1	2017-06-20	\N		\N		5	3	2		1846
2097		\N	\N	85	1	2017-07-11	\N		\N		5	3	2		1847
2098		\N	\N	85	1	2017-06-13	\N		\N		5	3	2		1848
2099	Switch	\N	\N	1354	1	2017-05-31	\N		\N		18	3	2		1849
2100		\N	\N	85	1	2017-06-12	\N		\N		5	3	2		1850
2101		\N	\N	85	1	2017-06-14	\N		\N		5	3	2		1851
2102	Switch	\N	\N	1351	1	2017-05-31	\N		\N		18	3	2		1852
2103		\N	\N	85	1	2017-06-13	\N		\N		5	3	2		1853
2104		\N	\N	1269	1	2017-05-15	\N		\N		5	3	2		1854
2105	Switch	\N	\N	519	1	2017-05-31	\N		\N		18	3	2		1855
2107	Switch	\N	\N	564	1	2017-05-31	\N		\N		18	3	2		1857
2108		\N	\N	1269	1	2017-05-16	\N		\N		5	3	2		1858
2109		\N	\N	68	1	2017-06-12	\N		\N		5	3	2		1859
2110		\N	\N	1269	1	2017-05-23	\N		\N		5	3	2		1860
2111	Switch	\N	\N	545	1	2017-05-31	\N		\N		18	3	2		1861
2112	Switch	\N	\N	27	1	2017-05-31	\N		\N		7	3	2		1862
2114	Switch	\N	\N	474	1	2017-05-31	\N		\N		9	3	2		1864
2115	Switch	\N	\N	16	1	2017-05-31	\N		\N		9	3	2		1865
2117	Switch	\N	\N	992	1	2017-05-28	\N		\N		9	3	2		1867
2118	Switch	\N	\N	355	1	2017-05-28	\N		\N		9	3	2		1868
2119		\N	\N	68	1	2017-06-19	\N		\N		5	3	2		1869
2120	Switch	\N	\N	6	1	2017-05-31	\N		\N		9	3	2		1870
2121	Switch	\N	\N	3	1	2017-05-28	\N		\N		9	3	2		1871
2122		\N	\N	68	1	2017-06-13	\N		\N		5	3	2		1872
2123	Switch	\N	\N	540	1	2017-05-31	\N		\N		18	3	2		1873
2124		\N	\N	68	1	2017-06-20	\N		\N		5	3	2		1874
2125	Switch	\N	\N	542	1	2017-05-31	\N		\N		18	3	2		1875
2126		\N	\N	1682	1	2017-06-20	\N		\N		5	3	2		1876
2075	Switch	\N	\N	305	1	2017-05-31	2017-10-24		\N		12	3	2		1825
2061	Switch	\N	\N	39	1	2017-05-31	2017-09-24		\N		12	3	2		1811
2127	Switch	\N	\N	1478	1	2017-05-31	\N		\N		22	3	2		1877
2128	Switch	\N	\N	61	1	2017-05-30	\N		\N		12	3	2		1878
2129		\N	\N	91	1	2017-06-20	\N		\N		5	3	2		1879
2130	Switch	\N	\N	1488	1	2017-05-31	\N		\N		22	3	2		1880
2131		\N	\N	91	1	2017-06-20	\N		\N		5	3	2		1881
2132	Switch	\N	\N	1676	1	2017-05-31	\N		\N		22	3	2		1882
2133	Switch	\N	\N	157	1	2017-05-31	\N		\N		22	3	2		1883
2134		\N	\N	91	1	2017-06-12	\N		\N		5	3	2		1884
2135	Switch	\N	\N	155	1	2017-05-31	\N		\N		22	3	2		1885
2136		\N	\N	70	1	2017-06-12	\N		\N		5	3	2		1886
2137	switch	\N	\N	77	1	2017-05-31	\N		\N		15	3	2		1887
2138		\N	\N	70	1	2017-06-13	\N		\N		5	3	2		1888
2140		\N	\N	70	1	2017-06-13	\N		\N		5	3	2		1890
2143		\N	\N	416	1	2017-06-13	\N		\N		5	3	2		1893
2145		\N	\N	1681	1	2017-06-12	\N		\N		5	3	2		1895
2146		\N	\N	67	1	2017-06-13	\N		\N		5	3	2		1896
2147		\N	\N	67	1	2017-06-20	\N		\N		5	3	2		1897
2148		\N	\N	67	1	2017-06-12	\N		\N		5	3	2		1898
2149		\N	\N	67	1	2017-06-12	\N		\N		5	3	2		1899
2150		\N	\N	66	1	2017-06-12	\N		\N		5	3	2		1900
2151		\N	\N	66	1	2017-06-12	\N		\N		5	3	2		1901
2152		\N	\N	66	1	2017-06-13	\N		\N		5	3	2		1902
2153		\N	\N	66	1	2017-06-12	\N		\N		5	3	2		1903
2154		\N	\N	66	1	2017-06-13	\N		\N		5	3	2		1904
2155		\N	\N	66	1	2017-06-13	\N		\N		5	3	2		1905
2156		\N	\N	65	1	2017-06-12	\N		\N		5	3	2		1906
2157		\N	\N	65	1	2017-06-12	\N		\N		5	3	2		1907
2158		\N	\N	65	1	2017-06-12	\N		\N		5	3	2		1908
2159		\N	\N	64	1	2017-06-13	\N		\N		5	3	2		1909
2160		\N	\N	64	1	2017-06-12	\N		\N		5	3	2		1910
2161		\N	\N	64	1	2017-06-13	\N		\N		5	3	2		1911
2162		\N	\N	72	1	2017-06-20	\N		\N		5	3	2		1912
2163		\N	\N	72	1	2017-05-15	\N		\N		5	3	2		1913
2164		\N	\N	72	1	2017-06-12	\N		\N		5	3	2		1914
2165		\N	\N	74	1	2017-06-11	\N		\N		5	3	2		1915
2166		\N	\N	74	1	2017-06-12	\N		\N		5	3	2		1916
2167		\N	\N	74	1	2017-06-12	\N		\N		5	3	2		1917
2168		\N	\N	404	1	2017-06-12	\N		\N		5	3	2		1918
2169		\N	\N	404	1	2017-06-13	\N		\N		5	3	2		1919
2170		\N	\N	404	1	2017-07-10	\N		\N		5	3	2		1920
2171		\N	\N	61	1	2017-05-31	\N		\N		12	3	2		1921
2172	Antena	\N	\N	61	1	2017-05-31	\N		\N		12	3	2		1922
2173	Cisco1230	\N	\N	51	1	2017-05-31	\N		\N		12	3	2		1923
2174	Cisco1242	\N	\N	28	1	2017-05-31	\N		\N		9	3	2		1924
2175		\N	\N	109	1	2017-05-31	\N		\N		18	3	2		1925
2176		\N	\N	1354	1	2017-05-31	\N		\N		18	3	2		1926
2177		\N	\N	269	1	2017-05-29	\N		\N		12	3	2		1927
2178		\N	\N	1354	1	2017-05-31	\N		\N		18	3	2		1928
2179		\N	\N	108	1	2017-05-31	\N		\N		18	3	2		1929
2180		\N	\N	269	1	2017-05-31	\N		\N		12	3	2		1930
2181		\N	1664	1664	2	2017-06-12	\N		\N		5	3	2		552
2211		\N	1664	1582	1	2017-09-21	\N		\N		20	3	2		355
551		\N	\N	1664	2	2017-07-16	\N		\N		5	3	2		551
2184		\N	\N	434	1	2017-05-21	\N		\N		5	3	2		1932
2185		\N	\N	89	1	2017-04-11	\N		\N		5	3	2		1933
2186		\N	1691	1664	1	2017-08-25	\N		\N		15	3	2		1276
2188		\N	1664	1269	1	2017-09-19	\N		\N		16	3	2		758
2190		\N	1664	1269	1	2017-09-19	\N		\N		16	3	2		345
2200		\N	\N	172	1	2017-06-30	\N		\N		7	3	2		1939
2189		\N	1664	1680	1	2017-09-18	\N		\N		16	3	2		63
2204		\N	1681	1664	1	2017-09-20	2017-10-16		\N		15	3	2		485
2206		\N	1681	1664	2	2017-09-20	\N		\N		15	3	2		1940
2183		\N	\N	434	1	2017-04-09	2017-10-24		\N		5	3	2		1931
2218		\N	\N	204	1	2017-04-19	2017-10-09		\N		16	3	2		1943
2193		\N	\N	1664	7	2017-09-19	\N		\N		5	3	2	Dolphin 20.09.2017	1934
2194		\N	\N	1664	1	2017-09-19	\N		\N		5	3	2	Dolphin 20.09.2017	1935
2196		\N	\N	1664	1	2017-09-19	\N		\N		5	3	2	Dolphin 20.09.2017	1937
2197		\N	\N	1664	1	2017-09-19	\N		\N		5	3	2	Dolphin 20.09.2017	1938
2198		\N	1664	1681	1	2017-09-20	\N		\N		15	3	1		496
2205		\N	\N	1681	1	2017-06-04	2017-09-20		\N		15	3	2		1940
2191		\N	1680	1664	2	2017-09-18	\N		\N		16	3	2	աշխատում է պրոբլեմներով	1304
2195		\N	1681	1664	1	2017-09-20	2017-09-20		\N		5	3	2	Dolphin 20.09.2017	1936
2207		\N	1664	1698	1	2017-09-20	\N		\N		23	3	1		1412
2203		\N	1664	1681	1	2017-09-20	\N		\N		15	3	1		1936
2208		\N	1664	1698	1	2017-09-20	\N		\N		23	3	1		1410
2209		\N	1664	1698	1	2017-09-20	\N		\N		23	3	1		468
2210		\N	\N	176	1	2017-05-14	\N		\N		23	3	2		1941
2215		\N	1664	1031	1	2017-09-21	\N		\N		20	3	2		100
2216		\N	1664	341	1	2017-09-21	\N		\N		20	3	2		97
2212		\N	1664	1314	1	2017-09-21	\N		\N		20	3	2		348
2213		\N	1664	1314	1	2017-09-21	\N		\N		20	3	2		88
2214		\N	1664	1021	1	2017-09-21	\N		\N		20	3	2		102
2192		\N	146	140	1	2017-09-18	\N		\N		13	3	2		1493
2217	Lukashin	\N	\N	855	1	2017-05-31	\N		\N		7	3	2		1942
2219	Khanjyan	\N	\N	856	1	2017-05-31	\N		\N		7	3	2		1944
2220	Haykavan	\N	\N	857	1	2017-05-31	\N		\N		7	3	2		1945
2221	Norapat	\N	\N	858	1	2017-05-31	\N		\N		7	3	2		1946
2222	Alashkert	\N	\N	859	1	2017-05-31	\N		\N		7	3	2		1947
2187		\N	1664	1269	1	2017-09-19	\N		\N		16	3	2		221
2223	Aygeshat	\N	\N	872	1	2017-05-31	\N		\N		7	3	2		1948
2224	Arevik	\N	\N	874	1	2017-06-01	\N		\N		7	3	2		1949
2225	Eghegnut	\N	\N	877	1	2017-05-31	\N		\N		7	3	2		1950
2226	Zartonq	\N	\N	879	1	2017-05-31	\N		\N		7	3	2		1951
2227	Mayisyan	\N	\N	880	1	2017-05-31	\N		\N		7	3	2		1952
2228	Bambakashat	\N	\N	888	1	2017-05-31	\N		\N		7	3	2		1953
2229	Getashen	\N	\N	889	1	2017-05-31	\N		\N		7	3	2		1954
2230	Lenughi	\N	\N	890	1	2017-05-31	\N		\N		7	3	2		1955
2231	Mrgashat	\N	\N	891	1	2017-05-31	\N		\N		7	3	2		1956
2232	Mrgashat	\N	\N	892	1	2017-05-31	\N		\N		7	3	2		1957
2233	Nalbandyan	\N	\N	893	1	2017-05-31	\N		\N		7	3	2		1958
2234	Nor Armavir	\N	\N	895	1	2017-05-31	\N		\N		7	3	2		1959
2235	Nor Artagers	\N	\N	896	1	2017-05-31	\N		\N		7	3	2		1960
2236	Nor Kesaria	\N	\N	897	1	2017-05-31	\N		\N		7	3	2		1961
2237	Shenavan	\N	\N	898	1	2017-05-31	\N		\N		7	3	2		1962
2238	Janfida	\N	\N	899	1	2017-05-31	\N		\N		7	3	2		1963
2239	Jrashen	\N	\N	900	1	2017-05-31	\N		\N		7	3	2		1964
2240	Sardarapat	\N	\N	901	1	2017-05-31	\N		\N		7	3	2		1965
2241	Tandzut	\N	\N	902	1	2017-05-31	\N		\N		7	3	2		1966
2242	Pshatavan	\N	\N	903	1	2017-05-31	\N		\N		7	3	2		1967
2243	Artamet	\N	\N	905	1	2017-05-31	\N		\N		7	3	2		1968
2244	Myasnikyan	\N	\N	906	1	2017-05-31	\N		\N		7	3	2		1969
2245	Shenik	\N	\N	907	1	2017-05-31	\N		\N		7	3	2		1970
2246	Lernagog	\N	\N	908	1	2017-05-31	\N		\N		7	3	2		1971
2247	Qarakert	\N	\N	909	1	2017-05-31	\N		\N		7	3	2		1972
2248	Arevadasht	\N	\N	910	1	2017-05-31	\N		\N		7	3	2		1973
2249	Hushakert	\N	\N	912	1	2017-05-31	\N		\N		7	3	2		1974
2250	Vanand	\N	\N	913	1	2017-05-31	\N		\N		7	3	2		1975
2251	Talvorik	\N	\N	914	1	2017-05-31	\N		\N		7	3	2		1976
2252	Dalarik	\N	\N	915	1	2017-05-31	\N		\N		7	3	2		1977
2253	Aknashen	\N	\N	917	1	2017-05-31	\N		\N		7	3	2		1978
2254	Aygek	\N	\N	918	1	2017-05-31	\N		\N		7	3	2		1979
2255	Aygeshat	\N	\N	919	1	2017-05-31	\N		\N		8	3	2		1980
2256	Aratashen	\N	\N	920	1	2017-05-31	\N		\N		8	3	2		1981
2257	Aragats	\N	\N	921	1	2017-05-31	\N		\N		7	3	2		1982
2258	Araqs	\N	\N	922	1	2017-05-31	\N		\N		8	3	2		1983
2259	Arevashat	\N	\N	923	1	2017-05-31	\N		\N		8	3	2		1984
2260	Baghramyan	\N	\N	924	1	2017-05-31	\N		\N		8	3	2		1985
2261	Gay	\N	\N	925	1	2017-05-31	\N		\N		8	3	2		1986
2262	Doghs	\N	\N	928	1	2017-05-30	\N		\N		8	3	2		1987
2263	Lernamerdz	\N	\N	930	1	2017-05-31	\N		\N		8	3	2		1988
2314		\N	1664	42	1	2017-09-24	\N		\N		7	3	2		297
2264		\N	\N	259	1	2017-07-09	2017-09-22		\N		12	3	2		1989
2268		\N	\N	1664	1	2017-06-12	2017-10-09		\N		17	3	2		1991
2269		\N	\N	1664	1	2017-07-09	2017-10-11		\N		17	3	2		1992
2271		\N	\N	1664	1	2017-06-19	\N		\N		17	3	2		1994
2272	Xoronq	\N	\N	931	1	2017-05-31	\N		\N		8	3	2		1995
2273	Tsaxkalanj	\N	\N	932	1	2017-05-31	\N		\N		8	3	2		1996
2274	Tsiatsan	\N	\N	933	1	2017-05-31	\N		\N		8	3	2		1997
2275	Haykashen	\N	\N	934	1	2017-05-31	\N		\N		8	3	2		1998
2276	Hovtamej	\N	\N	935	1	2017-05-31	\N		\N		8	3	2		1999
2277	Musaler	\N	\N	937	1	2017-05-31	\N		\N		8	3	2		2000
2278	Mrgastan	\N	\N	938	1	2017-05-31	\N		\N		8	3	2		2001
2279	Norakert	\N	\N	326	1	2017-05-31	\N		\N		8	3	2		2002
2280	Voskehat	\N	\N	940	1	2017-05-31	\N		\N		8	3	2		2003
2281	Amberd	\N	\N	960	1	2017-05-31	\N		\N		8	3	2		2004
2282	Apaga	\N	\N	961	1	2017-05-31	\N		\N		8	3	2		2005
2283	Arshaluys	\N	\N	962	1	2017-05-31	\N		\N		8	3	2		2006
2285	Haytagh	\N	\N	964	1	2017-05-31	\N		\N		8	3	2		2008
2284	Lusagyugh	\N	\N	963	1	2017-05-30	\N		\N		8	3	2		2007
2286	Jrarbi	\N	\N	965	1	2017-05-31	\N		\N		8	3	2		2009
2287	Taronik	\N	\N	966	1	2017-05-31	\N		\N		8	3	2		2010
2288	Ferik	\N	\N	967	1	2017-05-31	\N		\N		8	3	2		2011
2289	Berqashat	\N	\N	325	1	2017-05-31	\N		\N		8	3	2		2012
2290	Noravan	\N	\N	939	1	2017-05-31	\N		\N		8	3	2		2013
2292	Qarakert	\N	\N	330	1	2017-05-31	\N		\N		8	3	2		2015
2293	Shahumyan	\N	\N	331	1	2017-05-31	\N		\N		8	3	2		2016
2294	Dasht	\N	\N	333	1	2017-05-31	\N		\N		8	3	2		2017
2295	Hacik	\N	\N	865	1	2017-05-31	\N		\N		8	3	2		2018
2296	Merdzavan	\N	\N	334	1	2017-05-31	\N		\N		8	3	2		2019
2297	Armavir	\N	\N	875	1	2017-05-30	\N		\N		7	3	2		2020
2298		\N	\N	592	1	2017-04-12	2017-09-25		\N		23	3	2		2021
2299		\N	592	1664	1	2017-09-25	\N		\N		23	3	2		2021
2300		\N	592	1664	1	2017-09-25	\N		\N		23	3	2		1535
2301		\N	\N	129	1	2017-05-15	2017-09-25		\N		23	3	2		2022
2306		\N	129	1664	1	2017-09-25	2017-09-27		\N		23	3	2		1551
2303		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1549
2304		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1544
2305		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1542
2265		\N	259	1664	1	2017-09-22	\N		\N		12	3	2		1989
2307		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1545
2308		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1543
2309		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		1553
2310		\N	\N	129	1	2017-06-12	2017-09-25		\N		23	3	2		2023
2311		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		2023
2312		\N	\N	129	1	2017-05-23	2017-09-25		\N		23	3	2		2024
2313		\N	129	1664	1	2017-09-25	\N		\N		23	3	2		2024
2291	Argina	\N	\N	329	1	2017-05-31	2017-10-12		\N		8	3	2		2014
2302		\N	129	1664	1	2017-09-25	2017-09-27		\N		23	3	2		2022
2408		\N	826	1664	1	2017-09-27	2017-10-09		\N		9	3	2		2041
2318		\N	39	1664	1	2017-09-23	\N		\N		8	3	2		974
2369		\N	1664	18	1	2017-09-25	\N		\N		20	3	2		129
2320		\N	39	1664	1	2017-09-23	\N		\N		8	3	2		977
2317		\N	42	1664	1	2017-09-24	\N		\N		7	3	2		849
2321		\N	39	1664	1	2017-09-24	2017-09-27		\N		7	3	2		1811
2322		\N	140	1664	1	2017-09-25	\N		\N		23	3	2		1517
2323		\N	148	1664	1	2017-09-25	\N		\N		21	3	2		1524
2324		\N	148	1664	1	2017-09-25	\N		\N		21	3	2		1530
2325		\N	148	1664	1	2017-09-25	\N		\N		21	3	2		1532
2326		\N	148	1664	1	2017-09-25	\N		\N		21	3	2		1527
2385		\N	1314	1664	1	2017-09-26	\N		\N		20	3	2		2035
2328		\N	1424	1664	1	2017-09-25	\N		\N		23	3	2		1569
2329		\N	1424	1664	1	2017-09-25	\N		\N		23	3	2		1568
1758		\N	\N	147	1	2017-06-12	2017-09-25		\N		23	3	2		1511
2330		\N	147	1664	1	2017-09-25	\N		\N		21	3	2		1511
1761		\N	\N	149	1	2017-06-02	2017-09-25		\N		23	3	2		1514
2358		\N	149	1664	1	2017-09-25	\N		\N		21	3	2		1514
2335		\N	1664	1460	1	2017-09-10	\N		\N		23	3	2		142
2336		\N	147	1664	1	2017-09-25	\N		\N		21	3	2		1507
2337		\N	1460	1664	1	2017-09-25	\N		\N		13	3	2		1526
2338		\N	1460	1664	1	2017-09-25	\N		\N		13	3	2		1523
2339		\N	1460	1664	1	2017-09-25	\N		\N		13	3	2		1528
2340		\N	1460	1664	1	2017-09-25	\N		\N		13	3	2		1525
2341		\N	147	1664	1	2017-09-25	\N		\N		21	3	2		1512
2342		\N	147	1664	1	2017-09-25	\N		\N		21	3	2		1510
2343		\N	147	1664	1	2017-09-25	\N		\N		21	3	2		1509
2344		\N	145	1664	1	2017-09-25	\N		\N		13	3	2		1492
2345		\N	145	1664	1	2017-09-25	\N		\N		13	3	2		1501
2182		\N	1664	139	1	2017-09-11	\N		\N		23	3	2		518
2346		\N	139	1664	1	2017-09-25	\N		\N		23	3	2		1519
2347		\N	139	1664	1	2017-09-25	\N		\N		23	3	2		1521
2348		\N	139	1664	1	2017-09-25	\N		\N		23	3	2		1520
1521		\N	479	1664	1	2017-09-06	2017-09-10		\N		9	5	2		1418
2350		\N	153	1664	1	2017-09-25	\N		\N		23	3	2		1562
2349		\N	153	1664	1	2017-09-25	\N		\N		23	3	2		1559
2351		\N	143	1664	1	2017-09-25	\N		\N		23	3	2		1552
2352		\N	143	1664	1	2017-09-25	\N		\N		23	3	2		1555
2319		\N	42	1664	1	2017-09-24	\N		\N		7	3	2		855
2354		\N	143	1664	1	2017-09-25	\N		\N		23	3	2		1557
2355		\N	143	1664	1	2017-09-25	\N		\N		23	3	2		1547
2356		\N	143	1664	1	2017-09-25	\N		\N		23	3	2		1558
2357		\N	149	1664	1	2017-09-25	\N		\N		21	3	2		1513
2359		\N	1693	1664	1	2017-09-25	\N		\N		23	3	2		1503
2360		\N	1693	1664	1	2017-09-25	\N		\N		23	3	2		1508
2361		\N	151	1664	1	2017-09-25	\N		\N		23	3	2		1504
2362		\N	151	1664	1	2017-09-25	\N		\N		23	3	2		1500
2403		\N	1664	146	1	2017-09-14	\N		\N		23	3	2		146
2363		\N	151	1664	1	2017-09-25	2017-10-09		\N		23	3	2		1505
2366		\N	\N	575	1	2017-06-04	2017-09-25		\N		23	3	2		2028
2315		\N	1664	39	1	2017-09-24	\N		\N		7	3	2		298
2379		\N	\N	1021	1	2017-07-10	2017-09-26		\N		20	3	2		2033
2389		\N	341	1664	1	2017-09-26	2017-10-09		\N		20	3	2		2037
2378		\N	\N	1021	1	2017-06-04	2017-09-26		\N		20	3	2		2032
2365		\N	\N	149	1	2017-06-13	2017-09-25		\N		21	3	2		2027
2327		\N	1424	1664	1	2017-09-25	2017-10-11		\N		23	3	2		1566
2374		\N	\N	1031	1	2017-07-02	2017-09-26		\N		20	3	2		2030
2375		\N	1031	1664	1	2017-09-26	\N		\N		20	3	2		2030
2376		\N	\N	1031	1	2017-06-11	2017-09-26		\N		20	3	2		2031
2364		\N	151	1664	1	2017-09-25	2017-10-09		\N		23	3	2		1502
2381		\N	1021	1664	1	2017-09-26	\N		\N		20	3	2		2032
2382		\N	\N	1314	1	2017-07-02	2017-09-26		\N		20	3	2		2034
2383		\N	1314	1664	1	2017-09-26	\N		\N		20	3	2		2034
2384		\N	\N	1314	1	2017-06-11	2017-09-26		\N		20	3	2		2035
2398		\N	130	1664	1	2017-09-25	2017-10-23		\N		13	3	2		1588
2386		\N	\N	341	1	2017-06-12	2017-09-26		\N		20	3	2		2036
2387		\N	341	1664	1	2017-09-26	\N		\N		20	3	2		2036
2388		\N	\N	341	1	2017-06-14	2017-09-26		\N		20	3	2		2037
2404		\N	1685	1664	1	2017-09-27	2017-10-10		\N		9	3	2		970
2396		\N	138	130	1	2017-09-25	\N		\N		13	3	2		1479
2391		\N	\N	575	1	2017-06-11	2017-09-25		\N		23	3	2		2038
2392		\N	575	1664	1	2017-09-25	\N		\N		23	3	2		2038
2394		\N	137	1664	1	2017-09-25	\N		\N		23	3	2		1538
2393		\N	137	1664	1	2017-09-25	\N		\N		23	3	2		1537
2397		\N	138	130	1	2017-09-25	\N		\N		13	3	2		1468
2390		\N	575	1664	1	2017-09-25	\N		\N		23	3	2		2028
1836		\N	\N	130	1	2017-05-08	2017-09-25		\N		23	3	2		1586
2395		\N	130	1664	2	2017-09-25	\N		\N		13	3	2		1586
2399		\N	1664	130	1	2017-09-14	\N		\N		23	3	2		1579
2400		\N	\N	130	1	2017-06-12	2017-09-25		\N		13	3	2		2039
2401		\N	130	1664	1	2017-09-25	\N		\N		13	3	2		2039
2373		\N	149	1664	1	2017-09-25	2017-10-11		\N		21	3	2		2027
2405		\N	\N	826	1	2017-06-12	2017-09-27		\N		9	3	2		2040
2406		\N	826	1664	1	2017-09-27	\N		\N		9	3	2		2040
2407		\N	\N	826	1	2017-07-09	2017-09-27		\N		9	3	2		2041
2380		\N	1021	1664	1	2017-09-26	2017-10-09		\N		20	3	2		2033
2410		\N	1664	1063	1	2017-09-24	\N		\N		9	3	2		344
2409		\N	1664	839	1	2017-09-25	\N		\N		9	3	2		340
2353		\N	143	1664	1	2017-09-25	2017-09-27		\N		23	3	2		1546
2316		\N	1664	39	1	2017-09-24	\N		\N		7	3	2		137
2411		\N	1664	826	1	2017-09-25	\N		\N		9	3	2		341
2416		\N	\N	767	1	2017-07-09	2017-10-17		\N		24	3	2		2044
2413		\N	1664	408	1	2017-09-27	\N		\N		15	3	1		354
2414		\N	\N	765	1	2017-06-12	\N		\N		24	3	2		2042
2415		\N	\N	766	1	2017-07-09	\N		\N		24	3	2		2043
2417		\N	\N	768	1	2017-07-10	\N		\N		24	3	2		2045
2418		\N	\N	769	1	2017-07-09	\N		\N		24	3	2		2046
2419		\N	\N	771	1	2017-07-09	\N		\N		24	3	2		2047
2420		\N	\N	774	1	2017-06-19	\N		\N		24	3	2		2048
2421		\N	\N	777	1	2017-06-11	\N		\N		24	3	2		2049
2422		\N	\N	779	1	2017-06-11	\N		\N		24	3	2		2050
2423		\N	\N	789	1	2017-06-11	\N		\N		24	3	2		2051
2424		\N	\N	790	1	2017-07-11	\N		\N		24	3	2		2052
2425		\N	\N	794	1	2017-06-14	\N		\N		24	3	2		2053
2426		\N	\N	796	1	2017-07-12	\N		\N		24	3	2		2054
2427		\N	\N	797	1	2017-06-15	\N		\N		24	3	2		2055
2428		\N	\N	799	1	2017-06-15	\N		\N		24	3	2		2056
2429		\N	\N	800	1	2017-07-09	\N		\N		24	3	2		2057
2430		\N	\N	801	1	2017-07-02	\N		\N		24	3	2		2058
2431		\N	\N	809	1	2017-07-10	\N		\N		24	3	2		2059
2432		\N	\N	810	1	2017-06-12	\N		\N		24	3	2		2060
2433		\N	\N	811	1	2017-06-04	\N		\N		24	3	2		2061
2434		\N	\N	815	1	2017-06-14	\N		\N		24	3	2		2062
2435		\N	\N	816	1	2017-06-08	\N		\N		24	3	2		2063
2436		\N	\N	817	1	2017-06-12	\N		\N		24	3	2		2064
2437		\N	\N	818	1	2017-06-11	\N		\N		24	3	2		2065
2438		\N	\N	820	1	2017-06-07	\N		\N		24	3	2		2066
2439		\N	\N	821	1	2017-07-11	\N		\N		24	3	2		2067
2440		\N	\N	823	1	2017-06-06	\N		\N		24	3	2		2068
2441		\N	\N	824	1	2017-07-04	\N		\N		24	3	2		2069
2442		\N	\N	825	1	2017-06-12	\N		\N		24	3	2		2070
2443		\N	\N	316	1	2017-06-14	\N		\N		24	3	2		2071
2444		\N	\N	317	1	2017-06-07	\N		\N		24	3	2		2072
2445		\N	\N	318	1	2017-06-05	\N		\N		24	3	2		2073
2446		\N	\N	319	1	2017-06-07	\N		\N		24	3	2		2074
2447	Byurakan	\N	\N	702	1	2017-07-04	\N		\N		12	3	2		2075
2448		\N	\N	828	1	2017-06-05	\N		\N		24	3	2		2076
2449		\N	\N	832	1	2017-06-08	\N		\N		24	24	2		2077
2450	Karin	\N	\N	704	1	2017-07-04	\N		\N		12	3	2		2078
2451		\N	\N	320	1	2017-07-10	\N		\N		24	3	2		2079
2452		\N	\N	321	1	2017-06-04	\N		\N		24	3	2		2080
2453	Ghazaravan	\N	\N	705	1	2017-07-04	\N		\N		12	3	2		2081
2454		\N	\N	1640	1	2017-07-09	\N		\N		24	3	2		2082
2455	Voskehat	\N	\N	706	1	2017-07-04	\N		\N		12	3	2		2083
2456	Sasunik	\N	\N	708	1	2017-07-04	\N		\N		12	3	2		2084
2457	Parpi	\N	\N	709	1	2017-07-04	\N		\N		12	3	2		2085
2458	Oshakan	\N	\N	710	1	2017-07-04	\N		\N		12	3	2		2086
2459	Orgov	\N	\N	711	1	2017-07-04	\N		\N		12	3	2		2087
2460	Aghdziq	\N	\N	718	1	2017-07-04	\N		\N		12	3	2		2088
2461	Aragats	\N	\N	296	1	2017-07-04	\N		\N		12	3	2		2089
2462	Eghipatrush	\N	\N	721	1	2017-07-04	\N		\N		12	3	2		2090
2463	Tsaghkashen	\N	\N	722	1	2017-07-04	\N		\N		12	3	2		2091
2464	Quchak	\N	\N	724	1	2017-07-04	\N		\N		12	3	2		2092
2465	Shenavan	\N	\N	727	1	2017-07-04	\N		\N		12	3	2		2093
2466	Verin Bazmaberd	\N	\N	728	1	2017-07-04	\N		\N		12	3	2		2094
2467	V. Agarak	\N	\N	729	1	2017-07-04	\N		\N		12	3	2		2095
2468	Kanch	\N	\N	739	1	2017-07-04	\N		\N		12	3	2		2096
2469	Mastara	\N	\N	743	1	2017-07-04	\N		\N		12	3	2		2097
2470	Suser	\N	\N	745	1	2017-07-04	\N		\N		12	3	2		2098
2471	Avtona	\N	\N	748	1	2017-07-04	\N		\N		12	3	2		2099
2472	Aragatsavan	\N	\N	749	1	2017-07-04	\N		\N		12	3	2		2100
2473	Aragatsavan	\N	\N	750	1	2017-07-05	\N		\N		12	3	2		2101
2474	Arteni	\N	\N	752	1	2017-07-04	\N		\N		12	3	2		2102
2475		\N	\N	788	1	2017-06-06	\N		\N		24	3	2		2103
2476		\N	\N	791	1	2017-06-15	\N		\N		24	3	2		2104
2477	Aragatsavan	\N	\N	258	1	2017-07-04	\N		\N		12	3	2		2105
2478		\N	\N	830	1	2017-07-05	\N		\N		24	3	2		2106
2479	Katnaghbyur	\N	\N	754	1	2017-07-04	\N		\N		12	3	2		2107
2480	Nor Artik	\N	\N	755	1	2017-07-04	\N		\N		12	3	2		2108
2481	Sorik	\N	\N	756	1	2017-07-04	\N		\N		12	3	2		2109
2482	Tsaghkahovit	\N	\N	1497	1	2017-07-04	\N		\N		12	3	2		2110
2483	Tsaghkahovit	\N	\N	270	1	2017-07-04	\N		\N		12	3	2		2111
2484	Norashen	\N	\N	1498	1	2017-07-04	\N		\N		12	3	2		2112
2485	Rya Taza	\N	\N	1499	1	2017-07-04	\N		\N		12	3	2		2113
2486	Nerqin Sasnashen	\N	\N	1500	1	2017-07-04	\N		\N		12	3	2		2114
2487	Garnahovit	\N	\N	249	1	2017-07-04	\N		\N		12	3	2		2115
2488	Getap	\N	\N	250	1	2017-07-04	\N		\N		12	3	2		2116
2489	Charinja	\N	\N	251	1	2017-07-04	\N		\N		12	3	2		2117
2490	Kaqavadzor	\N	\N	252	1	2017-07-04	\N		\N		12	3	2		2118
2491	Nerqin Bazmaberd	\N	\N	253	1	2017-07-04	\N		\N		12	3	2		2119
2493	Vosketas	\N	\N	257	1	2017-07-04	\N		\N		12	3	2		2121
2494	Amre Taza	\N	\N	260	1	2017-07-04	\N		\N		12	3	2		2122
2499		\N	1664	735	1	2017-09-27	\N		\N		12	3	2		92
2496	Geghadir	\N	\N	262	1	2017-07-04	\N		\N		12	3	2		2123
2497	Geghadzor	\N	\N	263	1	2017-07-04	\N		\N		12	3	2		2124
2502		\N	1664	753	1	2017-09-27	\N		\N		12	3	2		2022
2501		\N	1664	740	1	2017-09-27	\N		\N		12	3	2		99
2498		\N	1664	746	1	2017-09-27	\N		\N		12	3	2		101
2500		\N	1664	741	1	2017-09-27	\N		\N		12	3	2		95
2503		\N	1664	57	1	2017-09-27	\N		\N		12	3	2		1811
2492	Dian	\N	\N	255	1	2017-07-04	2017-10-03		\N		12	12	2		2120
2495		\N	1664	738	1	2017-09-27	\N		\N		12	3	2		130
128		\N	\N	1664	\N	2017-07-17	2017-09-27		\N		5	3	2		128
2511		\N	1664	742	1	2017-09-27	\N		\N		12	3	2		103
2506		\N	1664	256	1	2017-09-27	\N		\N		12	3	2		1551
2512		\N	1664	733	1	2017-09-27	\N		\N		12	3	2		968
2504		\N	1664	259	1	2017-09-27	\N		\N		12	3	2		128
2508		\N	1664	747	1	2017-09-27	\N		\N		12	3	2		133
2509		\N	1664	254	1	2017-09-27	\N		\N		12	3	2		1272
2507		\N	1664	57	1	2017-09-27	\N		\N		12	3	2		1546
2266		\N	1664	259	1	2017-07-08	2017-09-23		\N		12	3	2		1990
2267		\N	259	1664	1	2017-09-22	2017-07-08		\N		12	3	2		1990
2513		\N	\N	42	1	2017-06-12	2017-09-27		\N		7	3	2		2125
2514		\N	42	1664	1	2017-09-27	\N		\N		7	3	2		2125
2515		\N	\N	42	1	2017-06-07	2017-09-27		\N		7	3	2		2126
2516		\N	42	1664	1	2017-09-27	\N		\N		7	3	2		2126
2517		\N	\N	833	1	2017-06-05	\N		\N		24	3	2		2127
2518		\N	\N	835	1	2017-06-14	\N		\N		24	3	2		2128
2519		\N	\N	838	1	2017-06-05	\N		\N		24	3	2		2129
2520		\N	\N	61	1	2017-06-12	\N		\N		12	3	2		2130
2521		\N	\N	61	1	2017-06-05	\N		\N		12	3	2		2131
2522		\N	\N	291	1	2017-06-06	\N		\N		12	3	2		2132
2523		\N	\N	841	1	2017-06-05	\N		\N		24	3	2		2133
2524		\N	\N	842	1	2017-05-31	\N		\N		24	3	2		2134
2525		\N	\N	844	1	2017-07-05	\N		\N		24	3	2		2135
2526		\N	\N	845	1	2017-06-07	\N		\N		24	3	2		2136
2527		\N	\N	846	1	2017-06-12	\N		\N		24	3	2		2137
2528		\N	\N	310	1	2017-06-19	\N		\N		24	3	2		2138
2530		\N	\N	315	1	2017-06-26	\N		\N		24	3	2		2140
2531		\N	\N	322	1	2017-06-14	\N		\N		24	3	2		2141
2532		\N	\N	324	1	2017-06-19	\N		\N		24	3	2		2142
2533		\N	\N	1699	1	2017-06-05	\N		\N		9	3	2		2143
2534		\N	\N	1002	1	2017-06-12	\N		\N		9	3	2		2144
2535		\N	\N	968	1	2017-06-13	\N		\N		9	3	2		2145
2536		\N	\N	969	1	2017-06-20	\N		\N		9	3	2		2146
2537		\N	\N	971	1	2017-06-19	\N		\N		9	3	2		2147
2538		\N	\N	972	1	2017-06-21	\N		\N		9	3	2		2148
2539		\N	\N	973	1	2017-06-23	\N		\N		9	3	2		2149
2540		\N	\N	974	1	2017-06-09	\N		\N		9	3	2		2150
2541		\N	\N	975	1	2017-06-08	\N		\N		9	3	2		2151
2542		\N	\N	976	1	2017-06-14	\N		\N		9	3	2		2152
2543		\N	\N	977	1	2017-06-12	\N		\N		9	3	2		2153
2544		\N	\N	1019	1	2017-06-08	\N		\N		9	3	2		2154
2545		\N	\N	1022	1	2017-06-09	\N		\N		9	3	2		2155
2546		\N	\N	1023	1	2017-06-20	\N		\N		9	3	2		2156
2547		\N	\N	995	1	2017-06-07	\N		\N		9	3	2		2157
2548		\N	\N	997	1	2017-08-09	\N		\N		9	3	2		2158
2549		\N	\N	998	1	2017-06-09	\N		\N		9	3	2		2159
2550		\N	\N	1005	1	2017-06-19	\N		\N		20	3	2		2160
2551		\N	\N	1007	1	2017-06-20	\N		\N		20	3	2		2161
2552		\N	\N	1017	1	2017-06-14	\N		\N		9	3	2		2162
2553		\N	\N	335	1	2017-07-10	\N		\N		9	3	2		2163
2554		\N	\N	337	1	2017-06-21	\N		\N		9	3	2		2164
2555		\N	\N	339	1	2017-06-11	\N		\N		9	3	2		2165
2556		\N	\N	350	1	2017-06-12	\N		\N		9	3	2		2166
2557		\N	\N	351	1	2017-07-24	\N		\N		9	3	2		2167
2558		\N	\N	352	1	2017-07-04	\N		\N		20	3	2		2168
2559		\N	\N	354	1	2017-06-19	\N		\N		20	3	2		2169
2560		\N	\N	360	1	2017-07-11	\N		\N		20	3	2		2170
2561		\N	\N	361	1	2017-06-21	\N		\N		20	3	2		2171
2562		\N	\N	362	1	2017-05-31	\N		\N		20	3	2		2172
2563		\N	\N	363	1	2017-07-10	\N		\N		20	3	2		2173
2564		\N	\N	364	1	2017-06-07	\N		\N		20	3	2		2174
2565		\N	\N	369	1	2017-06-08	\N		\N		20	3	2		2175
2566		\N	\N	370	1	2017-06-20	\N		\N		20	3	2		2176
2567		\N	\N	372	1	2017-06-07	\N		\N		20	3	2		2177
2568		\N	\N	373	1	2017-05-29	\N		\N		20	3	2		2178
2569		\N	\N	8	1	2017-07-10	\N		\N		20	3	2		2179
2570		\N	\N	978	1	2017-07-19	\N		\N		20	3	2		2180
2571		\N	\N	1003	1	2017-07-10	\N		\N		20	3	2		2181
2572		\N	\N	1018	1	2017-07-05	\N		\N		20	3	2		2182
2573		\N	\N	1028	1	2017-07-10	\N		\N		20	3	2		2183
2574		\N	\N	338	1	2017-07-16	\N		\N		20	3	2		2184
2575		\N	\N	374	1	2017-07-17	\N		\N		20	3	2		2185
2576		\N	\N	376	1	2017-07-17	\N		\N		20	3	2		2186
2577		\N	\N	381	1	2017-07-09	\N		\N		9	3	2		2187
2578		\N	\N	382	1	2017-07-09	\N		\N		20	3	2		2188
2579		\N	\N	383	1	2017-07-10	\N		\N		20	3	2		2189
2580		\N	\N	384	1	2017-07-09	\N		\N		20	3	2		2190
2581		\N	\N	386	1	2017-07-17	\N		\N		20	3	2		2191
2582		\N	\N	349	1	2017-07-11	\N		\N		20	3	2		2192
2583		\N	\N	340	1	2017-06-20	\N		\N		20	3	2		2193
2584		\N	\N	1501	1	2017-06-13	\N		\N		20	3	2		2194
2585		\N	\N	1026	1	2017-06-19	\N		\N		20	3	2		2195
2586		\N	\N	1004	1	2017-07-03	\N		\N		20	3	2		2196
2587		\N	\N	1006	1	2017-07-04	\N		\N		20	3	2		2197
2588		\N	\N	1014	1	2017-07-10	\N		\N		20	3	2		2198
2589		\N	\N	1202	1	2017-06-12	\N		\N		15	3	2		2199
2590		\N	\N	1216	1	2017-06-19	\N		\N		15	3	2		2200
2591		\N	\N	1223	1	2017-07-17	\N		\N		15	3	2		2201
2592		\N	\N	1228	1	2017-07-10	\N		\N		15	3	2		2202
2593		\N	\N	1270	1	2017-06-18	\N		\N		15	3	2		2203
2595		\N	\N	1275	1	2017-06-13	\N		\N		15	3	2		2205
2596		\N	\N	389	1	2017-06-06	\N		\N		15	3	2		2206
2594		\N	\N	1274	1	2017-06-20	2017-10-18		\N		15	3	2		2204
2510		\N	1664	744	1	2017-09-27	\N		\N		12	3	2		127
2505		\N	1664	259	1	2017-09-27	\N		\N		12	3	2		352
2597		\N	\N	391	1	2017-06-05	\N		\N		15	3	2		2207
2598		\N	\N	401	1	2017-07-09	\N		\N		15	3	2		2208
2599		\N	\N	402	1	2017-06-14	\N		\N		15	3	2		2209
2600		\N	\N	408	1	2017-07-10	\N		\N		15	3	2		2210
2601		\N	\N	409	1	2017-06-08	\N		\N		15	3	2		2211
2602		\N	\N	410	1	2017-06-06	\N		\N		15	3	2		2212
2603		\N	\N	414	1	2017-07-17	\N		\N		15	3	2		2213
2604		\N	\N	416	1	2017-06-20	\N		\N		15	3	2		2214
2605		\N	\N	428	1	2017-07-10	\N		\N		15	3	2		2215
2606		\N	\N	429	1	2017-06-12	\N		\N		15	3	2		2216
2607		\N	\N	430	1	2017-06-13	\N		\N		15	3	2		2217
2608		\N	\N	431	1	2017-07-03	\N		\N		15	3	2		2218
2609		\N	\N	432	1	2017-06-12	\N		\N		15	3	2		2219
2610		\N	\N	435	1	2017-07-09	\N		\N		15	3	2		2220
2611		\N	\N	436	1	2017-07-03	\N		\N		15	3	2		2221
2612		\N	\N	446	1	2017-06-04	\N		\N		15	3	2		2222
2613		\N	\N	447	1	2017-06-09	\N		\N		15	3	2		2223
2614		\N	\N	1196	1	2017-06-07	\N		\N		15	3	2		2224
2615		\N	\N	1206	1	2017-06-05	\N		\N		15	3	2		2225
2616		\N	\N	1207	1	2017-06-08	\N		\N		15	3	2		2226
2617		\N	\N	1218	1	2017-06-11	\N		\N		15	15	2		2227
2618		\N	\N	1220	1	2017-06-20	\N		\N		15	3	2		2228
2619		\N	\N	1015	1	2017-07-04	\N		\N		15	3	2		2229
2620		\N	\N	1225	1	2017-06-07	\N		\N		15	3	2		2230
2621		\N	\N	1273	1	2017-06-14	\N		\N		15	3	2		2231
2622		\N	\N	1567	1	2017-07-10	\N		\N		15	3	2		2232
2623		\N	\N	1568	1	2017-07-12	\N		\N		15	3	2		2233
2624		\N	\N	1570	1	2017-07-10	\N		\N		15	3	2		2234
2625		\N	\N	1571	1	2017-06-19	\N		\N		15	3	2		2235
2626		\N	\N	387	1	2017-07-12	\N		\N		15	3	2		2236
2627		\N	\N	388	1	2017-07-14	\N		\N		15	3	2		2237
2628		\N	\N	395	1	2017-07-11	\N		\N		15	3	2		2238
2629		\N	\N	396	1	2017-06-19	\N		\N		15	3	2		2239
2630		\N	\N	398	1	2017-07-12	\N		\N		15	3	2		2240
2631		\N	\N	420	1	2017-07-10	\N		\N		15	3	2		2241
2632		\N	\N	427	1	2017-07-12	\N		\N		15	3	2		2242
2633		\N	\N	438	1	2017-07-02	\N		\N		15	3	2		2243
2634		\N	\N	442	1	2017-06-18	\N		\N		15	3	2		2244
2635		\N	\N	449	1	2017-07-17	\N		\N		15	3	2		2245
2636		\N	\N	450	1	2017-07-14	\N		\N		15	3	2		2246
2637		\N	\N	1644	1	2017-06-27	\N		\N		15	3	2		2247
2638		\N	\N	1215	1	2017-07-05	\N		\N		15	3	2		2248
2639		\N	\N	407	1	2017-06-18	\N		\N		15	3	2		2249
2642		\N	\N	1268	1	2017-06-18	\N		\N		15	3	2		2252
2643		\N	\N	1272	1	2017-07-06	\N		\N		15	3	2		2253
2644		\N	\N	418	1	2017-07-16	\N		\N		15	3	2		2254
2645		\N	\N	1217	1	2017-06-15	\N		\N		15	3	2		2255
2646		\N	\N	1565	1	2017-06-15	\N		\N		15	3	2		2256
2647		\N	\N	1221	1	2017-06-21	\N		\N		15	3	2		2257
2648		\N	\N	1226	1	2017-07-12	\N		\N		15	3	2		2258
2649		\N	\N	1279	1	2017-06-23	\N		\N		15	3	2		2259
2650		\N	\N	393	1	2017-06-19	\N		\N		15	3	2		2260
2651		\N	\N	394	1	2017-06-20	\N		\N		15	3	2		2261
2652		\N	\N	397	1	2017-07-10	\N		\N		15	3	2		2262
2653		\N	\N	419	1	2017-07-10	\N		\N		15	3	2		2263
2654		\N	\N	421	1	2017-07-11	\N		\N		15	3	2		2264
2655		\N	\N	424	1	2017-07-16	\N		\N		15	3	2		2265
2656		\N	\N	445	1	2017-07-10	\N		\N		15	3	2		2266
2657		\N	\N	1641	1	2017-07-10	\N		\N		15	3	2		2267
2658		\N	\N	1646	1	2017-07-10	\N		\N		15	3	2		2268
2659		\N	\N	1621	1	2017-07-09	\N		\N		15	3	2		2269
2660		\N	\N	1610	1	2017-07-09	\N		\N		15	3	2		2270
2661		\N	\N	1611	1	2017-07-10	\N		\N		15	3	2		2271
2662		\N	\N	1613	1	2017-06-04	\N		\N		23	3	2		2272
2663		\N	\N	1614	1	2017-06-08	\N		\N		23	3	2		2273
2664		\N	\N	1618	1	2017-07-11	\N		\N		23	3	2		2274
2665		\N	\N	1619	1	2017-07-09	\N		\N		23	3	2		2275
2666		\N	\N	1656	1	2017-06-11	\N		\N		23	23	2		2276
2667		\N	\N	1657	1	2017-07-11	\N		\N		23	3	2		2277
2668		\N	\N	1663	1	2017-07-10	\N		\N		23	3	2		2278
2669		\N	\N	1609	1	2017-07-10	\N		\N		23	3	2		2279
2670		\N	\N	1615	1	2017-06-11	\N		\N		23	3	2		2280
2671		\N	\N	628	1	2017-07-12	\N		\N		23	3	2		2281
2672		\N	\N	629	1	2017-07-11	\N		\N		23	3	2		2282
2673		\N	\N	630	1	2017-07-12	\N		\N		23	3	2		2283
2674		\N	\N	632	1	2017-07-10	\N		\N		23	3	2		2284
2675		\N	\N	633	1	2017-07-12	\N		\N		23	3	2		2285
2676		\N	\N	634	1	2017-06-13	\N		\N		23	3	2		2286
2677		\N	\N	635	1	2017-07-03	\N		\N		23	3	2		2287
2678		\N	\N	636	1	2017-06-13	\N		\N		23	3	2		2288
2679	Gegharot	\N	\N	264	1	2017-07-04	\N		\N		12	3	2		2289
2680	Lernapar	\N	\N	266	1	2017-07-04	\N		\N		12	3	2		2290
2681	Jamshlu	\N	\N	267	1	2017-07-04	\N		\N		12	3	2		2291
2682	Sangyar	\N	\N	268	1	2017-07-04	\N		\N		12	3	2		2292
2683	Sipan	\N	\N	269	1	2017-07-04	\N		\N		12	3	2		2293
2684	Tsilqar	\N	\N	271	1	2017-07-04	\N		\N		12	3	2		2294
2685	Meliqgyugh	\N	\N	273	1	2017-07-04	\N		\N		12	3	2		2295
2686	Shenkan	\N	\N	274	1	2017-07-04	\N		\N		12	3	2		2296
2687	Vardablur	\N	\N	275	1	2017-07-04	\N		\N		12	3	2		2297
2688	Berqarat	\N	\N	277	1	2017-07-04	\N		\N		12	3	2		2298
2689	Antarut	\N	\N	279	1	2017-07-04	\N		\N		12	3	2		2299
2690	Avan	\N	\N	280	1	2017-07-04	\N		\N		12	3	2		2300
2691	Artashavan	\N	\N	282	1	2017-07-04	\N		\N		12	3	2		2301
2692	Bazmaghbyur	\N	\N	284	1	2017-07-04	\N		\N		12	3	2		2302
2641		\N	\N	1222	1	2017-07-16	2017-10-20		\N		15	3	2		2251
2693	Lernarot	\N	\N	285	1	2017-07-04	\N		\N		12	3	2		2303
2694	Kosh	\N	\N	286	1	2017-07-04	\N		\N		12	3	2		2304
2695	Nor Amanos	\N	\N	287	1	2017-07-04	\N		\N		12	3	2		2305
2696		\N	\N	254	1	2017-07-10	\N		\N		12	3	2		2306
2697		\N	\N	915	1	2017-07-11	\N		\N		7	3	2		2307
2698		\N	\N	637	1	2017-07-10	\N		\N		23	3	2		2308
2699		\N	\N	639	1	2017-06-12	\N		\N		23	3	2		2309
2700		\N	\N	640	1	2017-07-17	\N		\N		23	3	2		2310
2701		\N	\N	641	1	2017-06-19	\N		\N		23	3	2		2311
2702		\N	\N	642	1	2017-07-17	\N		\N		23	3	2		2312
2703		\N	\N	643	1	2017-07-11	\N		\N		23	3	2		2313
2704		\N	\N	644	1	2017-07-10	\N		\N		23	3	2		2314
2705		\N	\N	645	1	2017-07-17	\N		\N		23	3	2		2315
2706		\N	\N	909	1	2017-06-20	\N		\N		7	3	2		2316
2708		\N	\N	330	1	2017-07-18	\N		\N		7	3	2		2318
2709		\N	\N	646	1	2017-07-17	\N		\N		23	3	2		2319
2710		\N	\N	647	1	2017-07-12	\N		\N		23	3	2		2320
2711		\N	\N	649	1	2017-07-11	\N		\N		23	3	2		2321
2712		\N	\N	650	1	2017-06-22	\N		\N		23	3	2		2322
2713		\N	\N	651	1	2017-06-19	\N		\N		23	3	2		2323
2714		\N	\N	652	1	2017-07-12	\N		\N		23	3	2		2324
2715		\N	\N	653	1	2017-06-14	\N		\N		23	3	2		2325
2716		\N	\N	654	1	2017-07-10	\N		\N		23	3	2		2326
2718		\N	\N	1612	1	2017-06-15	\N		\N		23	3	2		2328
2723		\N	\N	1321	1	2017-06-14	\N		\N		20	3	2		2333
2722		\N	\N	1315	1	2017-06-04	\N		\N		20	3	2		2332
2720		\N	\N	1287	1	2017-06-05	\N		\N		20	3	2		2330
2719		\N	\N	1286	1	2017-07-10	\N		\N		20	3	2		2329
2721		\N	\N	1296	1	2017-06-06	\N		\N		20	3	2		2331
2724		\N	\N	1324	1	2017-06-13	\N		\N		20	3	2		2334
2725		\N	\N	1585	1	2017-07-12	\N		\N		20	3	2		2335
2726	Nor edesia	\N	\N	288	1	2017-07-04	\N		\N		12	3	2		2336
2727	Shamiram	\N	\N	289	1	2017-07-04	\N		\N		12	3	2		2337
2728		\N	\N	744	1	2017-06-07	\N		\N		12	3	2		2338
2729		\N	\N	290	1	2017-07-04	\N		\N		12	3	2		2339
2730		\N	\N	466	1	2017-06-12	\N		\N		20	3	2		2340
2731		\N	\N	293	1	2017-07-04	\N		\N		12	3	2		2341
2732		\N	\N	1575	1	2017-06-07	\N		\N		20	3	2		2342
2733		\N	\N	1578	1	2017-06-12	\N		\N		20	3	2		2343
2734		\N	\N	295	1	2017-07-04	\N		\N		12	3	2		2344
2735		\N	\N	454	1	2017-07-11	\N		\N		20	3	2		2345
2736		\N	\N	456	1	2017-06-20	\N		\N		20	3	2		2346
2737		\N	\N	457	1	2017-07-11	\N		\N		20	3	2		2347
2738		\N	\N	297	1	2017-07-04	\N		\N		12	3	2		2348
2739		\N	\N	458	1	2017-07-09	\N		\N		20	3	2		2349
2740	Apna	\N	\N	298	1	2017-07-04	\N		\N		12	3	2		2350
2741		\N	\N	459	1	2017-07-02	\N		\N		20	3	2		2351
2742	Ernjatap	\N	\N	299	1	2017-07-04	\N		\N		12	3	2		2352
2743		\N	\N	462	1	2017-06-12	\N		\N		20	3	2		2353
2744		\N	\N	463	1	2017-07-18	\N		\N		20	3	2		2354
2745	TTUJUR	\N	\N	300	1	2017-07-04	\N		\N		12	3	2		2355
2746		\N	\N	467	1	2017-06-13	\N		\N		20	3	2		2356
2747		\N	\N	470	1	2017-07-10	\N		\N		20	3	2		2357
2748	Lusagyugh	\N	\N	301	1	2017-07-04	\N		\N		12	3	2		2358
2749		\N	\N	471	1	2017-05-15	\N		\N		20	3	2		2359
2750	Dzoraglux	\N	\N	302	1	2017-07-04	\N		\N		12	3	2		2360
2751		\N	\N	473	1	2017-06-13	\N		\N		20	3	2		2361
2752		\N	\N	475	1	2017-06-21	\N		\N		20	3	2		2362
2753		\N	\N	476	1	2017-07-05	\N		\N		20	3	2		2363
2754	Mulq ( Kayq)	\N	\N	303	1	2017-07-04	\N		\N		12	3	2		2364
2755		\N	\N	480	1	2017-07-04	\N		\N		20	3	2		2365
2756		\N	\N	484	1	2017-07-10	\N		\N		20	3	2		2366
2757	Nigavan	\N	\N	304	1	2017-07-04	\N		\N		12	3	2		2367
2758		\N	\N	487	1	2017-06-13	\N		\N		20	3	2		2368
2759		\N	\N	488	1	2017-07-02	\N		\N		20	3	2		2369
2760		\N	\N	491	1	2017-07-10	\N		\N		20	3	2		2370
2761	Chqnagh	\N	\N	305	1	2017-07-04	\N		\N		12	3	2		2371
2762		\N	\N	1288	1	2017-07-12	\N		\N		20	3	2		2372
2763	Saralanj	\N	\N	306	1	2017-07-04	\N		\N		12	3	2		2373
2764	Vardenis	\N	\N	307	1	2017-07-04	\N		\N		12	3	2		2374
2765	Vardenut	\N	\N	308	1	2017-07-04	\N		\N		12	12	2		2375
2766	Hnaberd	\N	\N	272	1	2017-07-04	\N		\N		12	3	2		2376
2767	Miraq	\N	\N	278	1	2017-07-04	\N		\N		12	3	2		2377
2768		\N	\N	1295	1	2017-07-11	\N		\N		20	3	2		2378
2769		\N	\N	1301	1	2017-07-11	\N		\N		20	3	2		2379
2770	Akner	\N	\N	1415	1	2017-07-04	\N		\N		23	3	2		2380
2771		\N	\N	1302	1	2017-07-10	\N		\N		20	3	2		2381
2772		\N	\N	1323	1	2017-06-13	\N		\N		20	3	2		2382
2773	Hartashen	\N	\N	1416	1	2017-07-04	\N		\N		23	3	2		2383
2774		\N	\N	492	1	2017-06-07	\N		\N		20	3	2		2384
2775	Bardzravan	\N	\N	1694	1	2017-07-04	\N		\N		23	3	2		2385
2776		\N	\N	485	1	2017-07-06	\N		\N		20	3	2		2386
2777		\N	\N	482	1	2017-07-04	\N		\N		20	3	2		2387
2778	Xot	\N	\N	1425	1	2017-07-04	\N		\N		23	3	2		2388
2779		\N	\N	455	1	2017-07-05	\N		\N		20	3	2		2389
2780	Shinuhayr	\N	\N	1427	1	2017-07-04	\N		\N		23	3	2		2390
2781		\N	\N	1327	1	2017-07-05	\N		\N		20	3	2		2391
2782	Artsvanik	\N	\N	1443	1	2017-07-04	\N		\N		23	3	2		2392
2783		\N	\N	1586	1	2017-07-03	\N		\N		20	3	2		2393
2784		\N	\N	1579	1	2017-07-11	\N		\N		20	3	2		2394
2785	Syuniq	\N	\N	1444	1	2017-07-04	\N		\N		23	3	2		2395
2786		\N	\N	1574	1	2017-07-04	\N		\N		20	3	2		2396
2787		\N	\N	1300	1	2017-07-11	\N		\N		20	3	2		2397
2707		\N	\N	908	1	2017-06-19	2017-10-11		\N		7	3	2		2317
2788	Gorayq	\N	\N	1449	1	2017-07-04	\N		\N		23	3	2		2398
2789		\N	\N	464	1	2017-07-11	\N		\N		20	3	2		2399
2790	Akhlatyan	\N	\N	1451	1	2017-07-04	\N		\N		23	3	2		2400
2791	Angeghakot	\N	\N	1452	1	2017-07-04	\N		\N		23	3	2		2401
2792	Bnunis	\N	\N	1453	1	2017-07-04	\N		\N		21	3	2		2402
2793	Brnakot	\N	\N	1454	1	2017-07-04	\N		\N		21	3	2		2403
2794		\N	\N	735	1	2017-06-11	\N		\N		12	3	2		2404
2795	Ishxanasar	\N	\N	1455	1	2017-07-04	\N		\N		21	3	2		2405
2796		\N	\N	481	1	2017-07-12	\N		\N		20	3	2		2406
2797	Uyts	\N	\N	1457	1	2017-07-04	\N		\N		21	3	2		2407
2799		\N	\N	489	1	2017-07-11	\N		\N		20	3	2		2409
2800	Kxndzoresk	\N	\N	1598	1	2017-07-04	\N		\N		23	3	2		2410
2801	Kornidzor	\N	\N	1599	1	2017-07-04	\N		\N		21	3	2		2411
2802	Tatev	\N	\N	1601	1	2017-07-04	\N		\N		21	3	2		2412
2803	Շաղաթ	\N	\N	1606	1	2017-07-04	\N		\N		21	3	2		2413
2804	Noravan	\N	\N	1605	1	2017-07-04	\N		\N		23	3	2		2414
2806	Qarashen	\N	\N	576	1	2017-07-04	\N		\N		23	3	2		2416
2807		\N	\N	1473	1	2017-06-08	\N		\N		22	3	2		2417
2808		\N	\N	1474	1	2017-07-04	\N		\N		22	3	2		2418
2809	Vorotan (Goris)	\N	\N	580	1	2017-07-04	\N		\N		23	3	2		2419
2810		\N	\N	1475	1	2017-07-11	\N		\N		22	3	2		2420
2811		\N	\N	1476	1	2017-07-12	\N		\N		22	3	2		2421
2812	Shenatagh	\N	\N	586	1	2017-07-04	\N		\N		23	3	2		2422
2813		\N	\N	1477	1	2017-07-18	\N		\N		22	3	2		2423
2814	Svaranc	\N	\N	587	1	2017-07-04	\N		\N		23	3	2		2424
2815		\N	\N	1479	1	2017-06-13	\N		\N		22	3	2		2425
2816		\N	\N	1489	1	2017-06-12	\N		\N		22	3	2		2426
2817	Tandztap	\N	\N	588	1	2017-07-04	\N		\N		21	3	2		2427
2818		\N	\N	1490	1	2017-06-06	\N		\N		22	3	2		2428
2819		\N	\N	1491	1	2017-06-05	\N		\N		22	3	2		2429
2820		\N	\N	1492	1	2017-07-04	\N		\N		22	3	2		2430
2821		\N	\N	1629	1	2017-06-07	\N		\N		15	3	2		2431
2822	Hacavan	\N	\N	593	1	2017-07-04	\N		\N		21	3	2		2432
2823	Vardavanq	\N	\N	604	1	2017-07-04	\N		\N		21	3	2		2433
2824	Verin Xotanan	\N	\N	612	1	2017-07-04	\N		\N		23	3	2		2434
2825		\N	\N	1631	1	2017-06-08	\N		\N		15	3	2		2435
2826		\N	\N	1632	1	2017-06-12	\N		\N		15	3	2		2436
2827		\N	\N	1633	1	2017-06-14	\N		\N		15	3	2		2437
2828	Azatan	\N	\N	1328	1	2017-07-04	\N		\N		19	3	2		2438
2829	Akhurik	\N	\N	1329	1	2017-07-04	\N		\N		19	3	2		2439
2830	Aygabac	\N	\N	1333	1	2017-07-04	\N		\N		19	3	2		2440
2831	Arevik	\N	\N	1335	1	2017-07-04	\N		\N		19	3	2		2441
2832	Getq	\N	\N	1337	1	2017-07-04	\N		\N		19	3	2		2442
2833	Kamo	\N	\N	1339	1	2017-07-04	\N		\N		19	3	2		2443
2834	Kaps	\N	\N	1340	1	2017-07-04	\N		\N		19	3	2		2444
2835		\N	\N	1637	1	2017-06-06	\N		\N		15	3	2		2445
2836	Haykavan	\N	\N	1342	1	2017-07-04	\N		\N		19	3	2		2446
2837		\N	\N	679	1	2017-07-13	\N		\N		15	3	2		2447
2838	Hacik	\N	\N	1343	1	2017-07-04	\N		\N		19	3	2		2448
2839		\N	\N	1625	1	2017-07-10	\N		\N		22	3	2		2449
2840		\N	\N	1628	1	2017-07-10	\N		\N		15	3	2		2450
2841	Hovit	\N	\N	1344	1	2017-07-04	\N		\N		19	3	2		2451
2842		\N	\N	656	1	2017-07-09	\N		\N		22	3	2		2452
2843		\N	\N	657	1	2017-07-12	\N		\N		22	3	2		2453
2844	Hovuni	\N	\N	1345	1	2017-07-04	\N		\N		19	3	2		2454
2845		\N	\N	658	1	2017-06-14	\N		\N		22	3	2		2455
2846		\N	\N	659	1	2017-07-10	\N		\N		22	3	2		2456
2847	Gharibjanyan	\N	\N	1346	1	2017-07-04	\N		\N		19	3	2		2457
2848		\N	\N	660	1	2017-07-06	\N		\N		22	3	2		2458
2849	Marmarashen	\N	\N	1348	1	2017-07-04	\N		\N		19	3	2		2459
2850		\N	\N	661	1	2017-06-15	\N		\N		22	3	2		2460
2851		\N	\N	662	1	2017-06-12	\N		\N		22	3	2		2461
2852		\N	\N	664	1	2017-07-04	\N		\N		22	3	2		2462
2853	Nor Akhuryan	\N	\N	1349	1	2017-07-04	\N		\N		19	3	2		2463
2854	Shirak	\N	\N	1350	1	2017-07-04	\N		\N		19	3	2		2464
2855		\N	\N	667	1	2017-07-10	\N		\N		15	3	2		2465
2856	Jajur	\N	\N	512	1	2017-07-04	\N		\N		19	3	2		2466
2857		\N	\N	668	1	2017-07-12	\N		\N		15	3	2		2467
2858		\N	\N	669	1	2017-07-27	\N		\N		15	3	2		2468
2859		\N	\N	670	1	2017-07-06	\N		\N		15	3	2		2469
2860	Jrarat	\N	\N	1352	1	2017-07-04	\N		\N		19	3	2		2470
2861		\N	\N	671	1	2017-07-26	\N		\N		15	3	2		2471
2862	Vahramaberd	\N	\N	1353	1	2017-07-04	\N		\N		19	3	2		2472
2863		\N	\N	672	1	2017-07-11	\N		\N		15	3	2		2473
2864	Qeti	\N	\N	1354	1	2017-07-04	\N		\N		19	3	2		2474
2865	Byurakn	\N	\N	1355	1	2017-07-04	\N		\N		19	3	2		2475
2866	Meghrashat	\N	\N	1356	1	2017-07-04	\N		\N		19	3	2		2476
2867		\N	\N	673	1	2017-07-11	\N		\N		15	3	2		2477
2868	Anipemza	\N	\N	1358	1	2017-07-04	\N		\N		19	3	2		2478
2869		\N	\N	675	1	2017-07-16	\N		\N		15	3	2		2479
2870	Isahakyan	\N	\N	1360	1	2017-07-04	\N		\N		19	3	2		2480
2871		\N	\N	676	1	2017-06-11	\N		\N		15	3	2		2481
2872		\N	\N	677	1	2017-07-17	\N		\N		15	3	2		2482
2873		\N	\N	678	1	2017-07-05	\N		\N		15	3	2		2483
2874		\N	\N	680	1	2017-07-25	\N		\N		15	3	2		2484
2875		\N	\N	681	1	2017-07-19	\N		\N		15	3	2		2485
2876		\N	\N	683	1	2017-07-14	\N		\N		15	3	2		2486
2877		\N	\N	684	1	2017-07-16	\N		\N		15	3	2		2487
2878		\N	\N	685	1	2017-07-07	\N		\N		15	3	2		2488
2879		\N	\N	686	1	2017-07-07	\N		\N		15	3	2		2489
2880		\N	\N	687	1	2017-07-18	\N		\N		15	3	2		2490
2881		\N	\N	250	1	2017-06-18	\N		\N		12	3	2		2491
2882		\N	\N	688	1	2017-07-14	\N		\N		15	3	2		2492
2805	Spandaryan	\N	\N	573	1	2017-07-04	2017-10-05		\N		21	3	2		2415
2883		\N	\N	1658	1	2017-07-15	\N		\N		22	3	2		2493
2884		\N	\N	1361	1	2017-07-23	\N		\N		19	3	2		2494
2885		\N	\N	1363	1	2017-07-18	\N		\N		19	3	2		2495
2886		\N	\N	1364	1	2017-07-21	\N		\N		19	3	2		2496
2887		\N	\N	1593	1	2017-07-23	\N		\N		18	3	2		2497
2888		\N	\N	498	1	2017-07-23	\N		\N		16	3	2		2498
2889		\N	\N	499	1	2017-07-23	\N		\N		19	3	2		2499
2890		\N	\N	500	1	2017-07-26	\N		\N		19	3	2		2500
2891		\N	\N	501	1	2017-07-07	\N		\N		19	3	2		2501
2893		\N	\N	503	1	2017-07-07	\N		\N		16	3	2		2503
2892		\N	\N	502	1	2017-07-06	\N		\N		19	3	2		2502
2894		\N	\N	504	1	2017-07-14	\N		\N		19	3	2		2504
2895		\N	\N	506	1	2017-07-07	\N		\N		16	3	2		2505
2896		\N	\N	507	1	2017-07-19	\N		\N		19	3	2		2506
2897		\N	\N	508	1	2017-07-18	\N		\N		16	3	2		2507
2898		\N	\N	509	1	2017-07-07	\N		\N		16	3	2		2508
2899		\N	\N	529	1	2017-07-25	\N		\N		18	3	2		2509
2900		\N	\N	531	1	2017-07-27	\N		\N		19	3	2		2510
2901		\N	\N	532	1	2017-07-27	\N		\N		19	3	2		2511
2902		\N	\N	533	1	2017-07-25	\N		\N		19	3	2		2512
2903		\N	\N	534	1	2017-07-25	\N		\N		19	3	2		2513
2904		\N	\N	535	1	2017-07-19	\N		\N		19	3	2		2514
2905		\N	\N	536	1	2017-07-18	\N		\N		19	3	2		2515
2906		\N	\N	537	1	2017-07-28	\N		\N		19	3	2		2516
2907		\N	\N	538	1	2017-07-27	\N		\N		19	3	2		2517
2908		\N	\N	539	1	2017-07-28	\N		\N		19	3	2		2518
2909		\N	\N	541	1	2017-07-27	\N		\N		19	3	2		2519
2910		\N	\N	543	1	2017-07-27	\N		\N		19	3	2		2520
2911		\N	\N	544	1	2017-07-23	\N		\N		19	3	2		2521
2912		\N	\N	547	1	2017-07-24	\N		\N		19	3	2		2522
2913		\N	\N	548	1	2017-07-23	\N		\N		19	3	2		2523
2914		\N	\N	550	1	2017-07-26	\N		\N		19	3	2		2524
2915		\N	\N	563	1	2017-07-24	\N		\N		18	3	2		2525
2917		\N	\N	564	1	2017-07-27	\N		\N		18	3	2		2526
2918		\N	\N	939	1	2017-06-26	\N		\N		7	3	2		2527
2919		\N	\N	565	1	2017-07-25	\N		\N		18	3	2		2528
2920		\N	\N	566	1	2017-06-29	\N		\N		18	3	2		2529
2921		\N	\N	1594	1	2017-07-16	\N		\N		19	3	2		2530
2922		\N	\N	523	1	2017-07-17	\N		\N		18	3	2		2531
2923		\N	\N	524	1	2017-07-23	\N		\N		18	3	2		2532
2924		\N	\N	525	1	2017-06-30	\N		\N		18	3	2		2533
2925		\N	\N	510	1	2017-07-11	\N		\N		16	3	2		2534
2926		\N	\N	520	1	2017-07-21	\N		\N		18	3	2		2535
2927		\N	\N	521	1	2017-07-03	\N		\N		18	3	2		2536
2928		\N	\N	522	1	2017-07-21	\N		\N		18	3	2		2537
2929		\N	\N	527	1	2017-07-07	\N		\N		18	3	2		2538
2930		\N	\N	552	1	2017-07-24	\N		\N		18	3	2		2539
2931		\N	\N	553	1	2017-07-20	\N		\N		18	3	2		2540
2932		\N	\N	555	1	2017-07-04	\N		\N		18	3	2		2541
2933		\N	\N	557	1	2017-07-18	\N		\N		18	3	2		2542
2934		\N	\N	855	1	2017-07-13	\N		\N		7	3	2		2543
2935		\N	\N	558	1	2017-07-06	\N		\N		18	3	2		2544
2936		\N	\N	559	1	2017-07-21	\N		\N		18	3	2		2545
2937		\N	\N	511	1	2017-07-07	\N		\N		16	3	2		2546
2938		\N	\N	514	1	2017-07-19	\N		\N		16	3	2		2547
2939		\N	\N	515	1	2017-07-18	\N		\N		18	3	2		2548
2940		\N	\N	517	1	2017-07-09	\N		\N		18	3	2		2549
2941		\N	\N	526	1	2017-07-09	\N		\N		18	3	2		2550
2942		\N	\N	528	1	2017-07-24	\N		\N		18	3	2		2551
2943		\N	\N	554	1	2017-07-12	\N		\N		18	3	2		2552
2944		\N	\N	556	1	2017-07-27	\N		\N		18	3	2		2553
2945		\N	\N	561	1	2017-07-19	\N		\N		18	3	2		2554
2946		\N	\N	562	1	2017-07-14	\N		\N		18	3	2		2555
2947		\N	\N	567	1	2017-07-02	\N		\N		18	3	2		2556
2948		\N	\N	568	1	2017-07-19	\N		\N		18	3	2		2557
2949		\N	\N	571	1	2017-06-30	\N		\N		16	3	2		2558
2950		\N	\N	1591	1	2017-07-07	\N		\N		16	3	2		2559
2951		\N	\N	1649	1	2017-07-09	\N		\N		19	3	2		2560
2952		\N	\N	940	1	2017-07-11	\N		\N		8	3	2		2561
2953		\N	\N	856	1	2017-07-13	\N		\N		7	3	2		2562
2954		\N	\N	729	1	2017-07-20	\N		\N		12	3	2		2563
2957		\N	255	1664	2	2017-10-03	\N		\N		12	3	2		2564
2956		\N	\N	255	1	2017-07-06	2017-10-03		\N		12	3	2		2564
2959		\N	1664	255	1	2017-07-06	\N		\N		12	3	2		2565
2962		\N	\N	865	1	2017-07-11	\N		\N		7	3	2		2567
2963		\N	\N	906	1	2017-07-13	\N		\N		7	3	2		2568
2974		\N	1459	1664	4	2017-10-05	\N		\N		23	3	2		336
2961		\N	\N	741	1	2017-07-14	\N		\N		12	3	2		2566
2964		\N	\N	880	1	2017-07-21	\N		\N		7	3	2		2569
2973		\N	1664	19	1	2017-10-05	\N		\N		20	3	2		136
2966		\N	\N	879	1	2017-07-04	\N		\N		7	3	2		2570
2967		\N	\N	892	1	2017-07-18	\N		\N		7	3	2		2571
2968		\N	\N	891	1	2017-07-17	\N		\N		7	3	2		2572
2955		\N	255	1664	2	2017-10-03	\N		\N		12	3	2		2120
2970		\N	1664	1416	1	2017-10-05	\N		\N		23	3	1		347
2971		\N	\N	859	1	2017-07-10	\N		\N		7	3	2		2573
2916		\N	1664	453	1	2017-10-02	2017-10-05		\N		20	3	2		426
2972		\N	453	1664	2	2017-10-05	\N		\N		20	3	2		426
2969		\N	1664	453	1	2017-10-05	\N		\N		20	3	2		342
2975		\N	\N	1459	1	2017-07-04	2017-10-05		\N		23	3	2		2574
2976		\N	1459	1664	1	2017-10-05	\N		\N		23	3	2		2574
2977		\N	\N	1459	1	2017-06-05	2017-10-05		\N		23	3	2		2575
2965		\N	1664	761	1	2017-10-04	\N		\N		17	3	2		356
2978		\N	1459	1664	1	2017-10-05	\N		\N		23	3	1		2575
2979		\N	\N	581	1	2017-07-14	2017-10-05		\N		23	3	2		2576
2980		\N	581	1664	1	2017-10-05	\N		\N		23	3	2		2576
2981		\N	\N	581	1	2017-07-03	2017-10-05		\N		23	3	2		2577
2982		\N	581	1664	1	2017-10-05	\N		\N		23	3	1		2577
2983		\N	\N	1450	1	2017-07-19	2017-10-05		\N		23	3	2		2578
2984		\N	1450	1664	1	2017-10-05	\N		\N		23	3	2		2578
2985		\N	1450	1664	1	2017-10-05	\N		\N		23	3	1		2579
2986		\N	\N	1450	1	2017-07-12	2017-10-05		\N		23	3	2		2579
2987		\N	\N	1664	2	2017-10-05	\N		\N		23	3	2		2580
2988		\N	\N	595	1	2017-07-10	2017-10-05		\N		23	3	2		2581
2989		\N	595	1664	1	2017-10-05	\N		\N		23	3	2		2581
2990		\N	595	1664	1	2017-10-05	\N		\N		23	3	1		2582
2991		\N	\N	595	1	2017-07-11	2017-10-05		\N		23	3	2		2582
3019		\N	\N	625	1	2017-08-10	2017-10-05		\N		23	3	2		2595
2992		\N	1458	1664	1	2017-10-05	\N		\N		23	3	2		2408
2798	Sarnakunq	\N	\N	1458	1	2017-07-04	2017-10-05		\N		21	3	2		2408
2993		\N	573	1664	1	2017-10-05	\N		\N		23	3	2		2415
2994		\N	\N	583	1	2017-08-10	2017-10-05		\N		23	3	2		2583
2995		\N	583	1664	1	2017-10-05	\N		\N		23	3	2		2583
2996		\N	583	1664	1	2017-10-05	\N		\N		23	3	1		2584
2997		\N	\N	583	1	2017-08-10	2017-10-05		\N		23	3	2		2584
3020		\N	625	1664	1	2017-10-05	\N		\N		23	3	2		2595
3000		\N	584	1664	1	2017-10-05	\N		\N		23	3	1		2586
3001		\N	\N	584	1	2017-08-10	2017-10-05		\N		23	3	2		2586
2999		\N	\N	584	1	2017-07-06	2017-10-05		\N		23	3	2		2585
3021		\N	\N	625	1	2017-08-10	2017-10-05		\N		23	3	2		2596
3002		\N	584	1664	1	2017-10-05	\N		\N		23	3	2		2585
3003		\N	\N	574	1	2017-08-10	2017-10-05		\N		23	3	2		2587
3004		\N	574	1664	1	2017-10-05	\N		\N		23	3	2		2587
3005		\N	\N	574	1	2017-08-10	2017-10-05		\N		23	3	2		2588
3006		\N	574	1664	1	2017-10-05	\N		\N		23	3	1		2588
3007		\N	\N	585	1	2017-08-10	2017-10-05		\N		23	3	2		2589
3008		\N	585	1664	1	2017-10-05	\N		\N		23	3	2		2589
3009		\N	\N	585	1	2017-08-10	2017-10-05		\N		23	3	2		2590
3010		\N	585	1664	1	2017-10-05	\N		\N		23	3	1		2590
3011		\N	\N	1692	1	2017-08-10	2017-10-05		\N		23	3	2		2591
3012		\N	1692	1664	1	2017-10-05	\N		\N		23	3	2		2591
3013		\N	\N	1692	1	2017-08-10	2017-10-05		\N		23	3	2		2592
3014		\N	1692	1664	1	2017-10-05	\N		\N		23	3	1		2592
3015		\N	\N	597	1	2017-08-10	2017-10-05		\N		23	3	2		2593
3016		\N	597	1664	1	2017-10-05	\N		\N		23	3	2		2593
3017		\N	\N	597	1	2017-08-10	2017-10-05		\N		23	3	2		2594
3018		\N	597	1664	1	2017-10-05	\N		\N		23	3	1		2594
3022		\N	625	1664	1	2017-10-05	\N		\N		23	3	1		2596
3023		\N	\N	582	1	2017-08-10	2017-10-05		\N		23	3	2		2597
3024		\N	582	1664	1	2017-10-05	\N		\N		23	3	2		2597
3025		\N	\N	582	1	2017-08-10	2017-10-05		\N		23	3	2		2598
3026		\N	582	1664	1	2017-10-05	\N		\N		23	3	1		2598
3027		\N	\N	326	1	2017-08-10	\N		\N		8	3	2		2599
3028		\N	\N	1416	1	2017-07-11	2017-10-06		\N		23	3	2		2600
3029		\N	1416	1664	2	2017-10-06	\N		\N		23	3	1		2600
3031		\N	\N	256	1	2017-07-11	\N		\N		12	3	2		2601
3032		\N	\N	498	1	2017-05-16	\N		\N		16	3	2		2602
3033		\N	\N	1360	1	2017-04-11	\N		\N		16	3	2		2603
3034		\N	\N	963	1	2017-07-13	\N		\N		8	3	2		2604
3035		\N	1664	314	1	2017-10-09	\N		\N		24	4	1		523
3054		\N	1664	878	1	2017-10-10	\N		\N		8	3	1		970
3055		\N	\N	901	1	2017-07-17	\N		\N		7	3	2		2609
3056		\N	\N	874	1	2017-07-17	\N		\N		7	3	2		2610
3042		\N	1664	776	1	2017-10-09	\N		\N		24	4	2		2033
3043		\N	1664	767	1	2017-10-09	\N		\N		24	4	2		520
3044		\N	1664	767	1	2017-10-09	\N		\N		24	4	2		2031
2377		\N	1031	1664	1	2017-09-26	2017-10-09		\N		20	3	2		2031
3045		\N	1664	1701	1	2017-10-09	\N		\N		24	4	1		562
3046		\N	1664	1701	1	2017-10-09	\N		\N		24	4	1		2037
3047		\N	1664	314	1	2017-10-09	\N		\N		24	4	1		1502
3049		\N	1664	220	1	2017-10-09	\N		\N		24	4	2		1505
3041		\N	1664	776	1	2017-10-09	\N		\N		24	4	2		536
3040		\N	1664	1702	1	2017-10-09	\N		\N		24	3	1		2041
3039		\N	1664	1702	1	2017-10-09	\N		\N		24	4	1		334
3038		\N	1664	1702	1	2017-10-09	\N		\N		24	4	1		474
3050		\N	\N	961	1	2017-07-14	\N		\N		8	3	2		2606
3051		\N	\N	1356	1	2017-07-19	\N		\N		19	3	2		2607
3052		\N	204	1664	1	2017-10-09	\N		\N		16	4	1		1943
3057		\N	\N	877	1	2017-07-19	\N		\N		7	3	2		2611
3058		\N	\N	878	1	2017-07-13	\N		\N		7	3	2		2612
3059		\N	\N	1295	1	2017-07-20	\N		\N		7	3	2		2613
3060		\N	\N	890	1	2017-07-19	\N		\N		7	3	2		2614
2412		\N	1664	162	1	2017-09-27	\N		\N		15	3	2		134
3061		\N	\N	1295	1	2017-07-17	\N		\N		9	3	2		2615
3062		\N	\N	474	1	2017-07-10	\N		\N		9	3	2		2616
3063		\N	\N	912	1	2017-07-11	\N		\N		7	3	2		2617
3064		\N	\N	897	1	2017-07-18	\N		\N		7	3	2		2618
3065		\N	\N	1341	1	2017-07-11	2017-10-10		\N		16	3	2		2619
3053		\N	\N	776	1	2017-07-10	2017-10-17		\N		24	3	2		2608
3067		\N	1680	1664	1	2017-10-10	\N		\N		16	3	1		87
3069		\N	\N	471	1	2017-07-17	\N		\N		9	3	2		2621
3068		\N	\N	464	1	2017-07-11	\N		\N		9	3	2		2620
3070		\N	\N	463	1	2017-07-12	\N		\N		9	3	2		2622
3071		\N	\N	325	1	2017-07-07	\N		\N		7	3	2		2623
3048		\N	1664	220	1	2017-10-09	\N		\N		24	4	2		1991
3072		\N	\N	325	1	2017-07-07	\N		\N		7	3	2		2624
3073		\N	\N	898	1	2017-07-10	\N		\N		7	3	2		2625
3074		\N	\N	1284	1	2017-07-20	\N		\N		9	3	2		2626
3075		\N	\N	889	1	2017-07-18	\N		\N		7	3	2		2627
3097		\N	1664	908	1	2017-10-11	\N		\N		7	3	2		349
3077		\N	1664	1224	1	2017-10-11	2017-10-18		\N		25	3	2		2027
3078		\N	1664	602	1	2017-10-11	\N		\N		23	3	1		554
3079		\N	1664	601	1	2017-10-11	\N		\N		23	3	1		1992
3080		\N	1664	1219	1	2017-10-11	\N		\N		25	3	1		484
3081		\N	1664	1214	1	2017-10-11	\N		\N		25	3	1		467
3082		\N	1664	1227	1	2017-10-11	\N		\N		25	3	1		479
3083		\N	1664	1222	1	2017-10-11	\N		\N		25	3	1		1436
3084		\N	1664	1268	1	2017-10-11	\N		\N		25	3	1		472
3115		\N	1664	1664	1	2017-10-12	\N		\N		16	3	1		350
3086		\N	1664	1272	1	2017-10-11	\N		\N		25	3	1		494
3116		\N	1664	1664	1	2017-10-12	\N		\N		16	3	1		29
149		\N	\N	1664	\N	2017-07-17	2017-10-11		\N		5	3	2		149
3117		\N	\N	485	1	2017-07-10	\N		\N		9	3	2		2634
3090		\N	1664	140	1	2017-10-11	\N		\N		23	3	1		1566
3091		\N	140	1664	2	2017-10-11	\N		\N		23	3	1		539
3092		\N	\N	948	1	2017-07-04	\N		\N		8	3	2		2628
3093		\N	\N	1589	1	2017-07-17	\N		\N		9	3	2		2629
3094		\N	\N	1283	1	2017-07-19	\N		\N		9	3	2		2630
3118		\N	\N	487	1	2017-07-19	\N		\N		9	3	2		2635
3087		\N	1664	120	1	2017-10-11	\N		\N		23	3	1		461
3089		\N	1664	120	1	2017-10-11	\N		\N		23	3	1		149
3088		\N	1664	120	1	2017-10-11	\N		\N		23	3	1		549
3095		\N	\N	1357	1	2017-07-13	\N		\N		16	3	2		2631
3119		\N	\N	1648	1	2017-07-10	\N		\N		9	3	2		2636
3120		\N	\N	1648	1	2017-07-18	\N		\N		9	3	2		2637
3096		\N	1664	1217	1	2017-10-11	\N		\N		25	3	1		495
3100		\N	1664	329	1	2017-10-12	\N		\N		7	3	2		90
3099		\N	\N	1664	2	2017-07-17	\N		\N		5	3	2		2633
3102		\N	1664	329	1	2017-10-12	\N		\N		7	3	2		364
3103		\N	329	1664	2	2017-10-12	\N		\N		7	3	2		2327
3101		\N	329	1664	2	2017-10-12	\N		\N		7	3	2		2014
2717		\N	\N	329	1	2017-06-13	2017-10-12		\N		23	3	2		2327
533		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		533
3104		\N	1664	1341	1	2017-10-12	\N		\N		16	3	1		533
3105		\N	1664	1664	1	2017-10-12	\N		\N		15	3	1		23
3066		\N	1341	1664	4	2017-10-10	\N		\N		16	3	2		2619
3107		\N	1664	1664	1	2017-10-12	\N		\N		22	3	1		21
19		\N	\N	1664	\N	2017-07-17	2017-10-12		\N		5	3	2		19
3108		\N	1664	1664	1	2017-10-12	\N		\N		22	3	1		19
3109		\N	1664	1664	1	2017-10-12	\N		\N		22	3	1		362
3110		\N	1664	1664	1	2017-10-12	\N		\N		22	3	1		351
3111		\N	1664	1664	1	2017-10-12	\N		\N		15	3	1		365
3112		\N	1664	1664	1	2017-10-12	\N		\N		15	3	1		360
3113		\N	1664	1664	1	2017-10-12	\N		\N		16	3	1		22
3114		\N	1664	1664	1	2017-10-12	\N		\N		16	3	1		363
3121		\N	\N	764	1	2017-07-04	\N		\N		24	3	2		2638
3122		\N	\N	1647	1	2017-05-24	\N		\N		15	3	2		2639
3124		\N	\N	1655	1	2017-05-24	\N		\N		23	3	2		2641
3125		\N	\N	1650	1	2017-05-24	\N		\N		21	3	2		2642
3123		\N	\N	1648	1	2017-05-24	\N		\N		20	3	2		2640
3126		\N	\N	1651	1	2017-05-24	\N		\N		23	3	2		2643
3127		\N	\N	1659	1	2017-05-24	\N		\N		15	3	2		2644
3128		\N	\N	1643	1	2017-05-24	\N		\N		15	3	2		2645
3129		\N	\N	1642	1	2017-05-24	\N		\N		15	3	2		2646
3130		\N	\N	618	1	2017-06-05	\N		\N		4	3	2		2647
3131		\N	\N	327	1	2017-05-18	\N		\N		7	3	2		2648
3132		\N	\N	591	1	2017-05-18	\N		\N		7	3	2		2649
3133		\N	\N	988	1	2017-05-18	\N		\N		20	3	2		2650
3134		\N	\N	412	1	2017-05-18	\N		\N		15	3	2		2651
3135		\N	\N	451	1	2017-05-18	\N		\N		15	3	2		2652
3136		\N	\N	406	1	2017-05-18	\N		\N		15	3	2		2653
3137		\N	\N	691	1	2017-05-18	\N		\N		22	3	2		2654
3138		\N	\N	689	1	2017-05-18	\N		\N		22	3	2		2655
3139		\N	\N	617	1	2017-05-18	\N		\N		23	3	2		2656
3140		\N	\N	1653	1	2017-05-18	\N		\N		23	3	2		2657
3141		\N	\N	385	1	2017-05-18	\N		\N		20	3	2		2658
3142		\N	\N	1660	1	2017-05-18	\N		\N		20	3	2		2659
3143		\N	\N	1636	1	2017-05-18	\N		\N		15	3	2		2660
3144		\N	\N	690	1	2017-05-18	\N		\N		22	3	2		2661
3145		\N	\N	1645	1	2017-05-18	\N		\N		15	3	2		2662
3146		\N	\N	1334	1	2017-07-11	\N		\N		16	3	2		2663
3147		\N	\N	1341	1	2017-07-19	\N		\N		16	3	2		2664
3148		\N	\N	1347	1	2017-06-14	\N		\N		18	3	2		2665
3149		\N	\N	1359	1	2017-07-20	\N		\N		16	3	2		2666
3150		\N	\N	505	1	2017-07-07	\N		\N		16	3	2		2667
3151		\N	\N	1214	1	2017-07-20	2017-10-11		\N		15	3	2		2668
3152		\N	1214	1664	1	2017-10-11	\N		\N		25	3	1		2668
3153		\N	\N	1271	1	2017-07-21	\N		\N		15	3	2		2669
3154		\N	\N	483	1	2017-07-19	\N		\N		20	3	2		2670
3155		\N	\N	1602	1	2017-07-28	\N		\N		23	3	2		2671
3156		\N	\N	578	1	2017-07-18	\N		\N		23	3	2		2672
3157		\N	\N	579	1	2017-07-18	\N		\N		23	3	2		2673
3158		\N	\N	589	1	2017-07-20	\N		\N		23	3	2		2674
3159		\N	\N	596	1	2017-07-21	\N		\N		21	3	2		2675
3160		\N	\N	1336	1	2017-07-14	\N		\N		16	3	2		2676
3161		\N	\N	549	1	2017-07-12	\N		\N		19	3	2		2677
3162		\N	\N	723	1	2017-07-19	\N		\N		8	3	2		2678
3163		\N	\N	437	1	2017-07-12	\N		\N		15	3	2		2679
3164		\N	\N	893	1	2017-07-13	\N		\N		7	3	2		2680
3165		\N	\N	896	1	2017-07-20	\N		\N		7	3	2		2681
3166		\N	\N	1426	1	2017-07-12	\N		\N		23	3	2		2682
3167		\N	\N	682	1	2017-07-13	\N		\N		22	3	2		2683
3168		\N	\N	1357	1	2017-07-20	\N		\N		16	3	2		2684
3169		\N	\N	895	1	2017-07-20	\N		\N		7	3	2		2685
3170		\N	\N	900	1	2017-07-19	\N		\N		7	3	2		2686
3171		\N	\N	481	1	2017-07-05	\N		\N		9	3	2		2687
3172		\N	\N	492	1	2017-07-11	2017-10-13		\N		9	3	2		2688
3227		\N	\N	676	1	2017-07-11	\N		\N		15	3	2		2729
3174		\N	1664	492	1	2017-10-13	\N		\N		9	3	2		346
3175		\N	\N	782	1	2017-05-18	\N		\N		24	3	2		2689
3176		\N	\N	781	1	2017-07-12	\N		\N		24	3	2		2690
3177		\N	\N	760	1	2017-07-21	\N		\N		24	3	2		2691
3178		\N	\N	313	1	2017-07-20	\N		\N		24	3	2		2692
3179		\N	\N	787	1	2017-07-15	\N		\N		24	3	2		2693
3180		\N	\N	786	1	2017-07-20	\N		\N		24	3	2		2694
3223		\N	776	1664	1	2017-10-17	\N		\N		17	3	2		2608
3182		\N	\N	1634	1	2017-07-20	\N		\N		15	3	2		2695
3183		\N	\N	1635	1	2017-07-07	\N		\N		15	3	2		2696
3184		\N	\N	1631	1	2017-07-07	\N		\N		15	3	2		2697
3185		\N	\N	1301	1	2017-07-14	\N		\N		20	3	2		2698
3186		\N	\N	1301	1	2017-07-20	\N		\N		20	3	2		2699
3187		\N	\N	1630	1	2017-07-12	\N		\N		15	3	2		2700
3188		\N	\N	1302	1	2017-07-13	\N		\N		20	3	2		2701
3189		\N	\N	1302	1	2017-07-13	\N		\N		20	3	2		2702
3190		\N	\N	1629	1	2017-07-14	\N		\N		15	3	2		2703
3191		\N	\N	1305	1	2017-07-13	\N		\N		20	3	2		2704
3192		\N	\N	1306	1	2017-07-12	\N		\N		20	3	2		2705
3193		\N	\N	670	1	2017-07-12	\N		\N		15	3	2		2706
3194		\N	\N	1505	1	2017-07-14	\N		\N		9	3	2		2707
3195		\N	\N	1309	1	2017-06-20	\N		\N		20	3	2		2708
3196		\N	\N	1633	1	2017-07-06	\N		\N		15	3	2		2709
3197		\N	\N	1633	1	2017-07-20	\N		\N		15	3	2		2710
3198		\N	\N	1527	1	2017-07-19	\N		\N		9	3	2		2711
3199		\N	\N	1304	1	2017-06-14	\N		\N		20	3	2		2712
3200		\N	\N	1312	1	2017-07-20	\N		\N		20	3	2		2713
3201		\N	\N	677	1	2017-07-19	\N		\N		15	3	2		2714
3202		\N	\N	1042	1	2017-06-27	\N		\N		9	3	2		2715
3204		\N	1664	255	1	2017-10-16	\N		\N		12	3	2		358
3076		\N	1664	1224	1	2017-10-11	2017-10-24		\N		25	3	2		487
3205		\N	\N	905	1	2017-07-12	\N		\N		7	3	2		2716
3206		\N	\N	914	1	2017-07-13	\N		\N		12	3	2		2717
3207		\N	\N	913	1	2017-06-20	\N		\N		7	3	2		2718
3208		\N	\N	327	1	2017-07-20	\N		\N		7	3	2		2719
3209		\N	\N	328	1	2017-06-12	\N		\N		7	3	2		2720
3210		\N	\N	328	1	2017-06-06	\N		\N		7	3	2		2721
3173		\N	492	1664	2	2017-10-13	\N		\N		9	3	2		2688
3211		\N	\N	1227	1	2017-07-06	\N		\N		25	3	2		2722
3228		\N	1664	1459	1	2017-10-18	\N		\N		23	3	1		332
3214		\N	\N	1305	1	2017-06-13	2017-10-16		\N		20	3	2		2724
3215		\N	1305	1664	1	2017-10-16	\N		\N		20	3	1		2724
3213		\N	1305	1664	1	2017-10-16	\N		\N		20	3	1		2723
3212		\N	\N	1305	1	2017-06-13	2017-10-16		\N		20	3	2		2723
3216		\N	\N	1309	1	2017-07-12	2017-10-16		\N		20	3	2		2725
3217		\N	1309	1664	1	2017-10-16	\N		\N		20	3	1		2725
3218		\N	\N	1309	1	2017-07-12	2017-10-16		\N		20	3	2		2726
3219		\N	1309	1664	1	2017-10-16	\N		\N		20	3	1		2726
3106		\N	1664	1664	1	2017-10-12	2017-10-17		\N		15	3	2		20
3220		\N	1664	674	1	2017-10-17	\N		\N		15	3	1		20
3221		\N	581	1664	2	2017-10-17	\N		\N		21	3	1		530
2529		\N	\N	314	1	2017-06-18	2017-10-17		\N		24	3	2		2139
3224		\N	767	1664	1	2017-10-17	\N		\N		17	3	2		2044
3222		\N	314	1664	1	2017-10-17	\N		\N		17	3	2		2139
3225		\N	\N	666	1	2017-07-19	\N		\N		15	3	2		2727
3226		\N	\N	480	1	2017-07-11	\N		\N		9	3	2		2728
3245		\N	\N	1579	1	2017-07-13	\N		\N		20	3	2		2742
3230		\N	\N	1174	1	2017-07-05	\N		\N		9	3	2		2730
3231		\N	\N	667	1	2017-07-19	\N		\N		15	3	2		2731
3232		\N	\N	475	1	2017-07-18	\N		\N		9	3	2		2732
3233		\N	\N	479	1	2017-06-13	\N		\N		9	3	2		2733
3234		\N	\N	668	1	2017-07-11	\N		\N		15	3	2		2734
3236		\N	\N	455	1	2017-07-11	\N		\N		20	3	2		2735
3237		\N	\N	477	1	2017-07-11	\N		\N		9	3	2		2736
3238		\N	\N	476	1	2017-07-12	\N		\N		9	3	2		2737
3239		\N	\N	459	1	2017-06-07	\N		\N		20	3	2		2738
3240		\N	\N	457	1	2017-07-12	\N		\N		20	3	2		2739
3241		\N	\N	678	1	2017-06-14	\N		\N		15	3	2		2740
3242		\N	\N	1664	2	2017-07-17	\N		\N		5	3	2		548
3243		\N	1664	581	1	2017-10-18	\N		\N		23	3	1		547
3244		\N	\N	489	1	2017-07-13	\N		\N		9	3	2		2741
3246		\N	1224	1664	1	2017-10-18	\N		\N		25	3	1		2027
3181		\N	908	1664	2	2017-10-11	\N		\N		7	3	2		2317
3248		\N	\N	1224	1	2017-07-06	2017-10-18		\N		15	3	2		2743
3249		\N	1224	1664	1	2017-10-18	\N		\N		25	3	1		2743
3250		\N	\N	1224	1	2017-06-14	2017-10-18		\N		15	3	2		2744
3251		\N	1224	1664	1	2017-10-18	\N		\N		25	3	1		2744
3252		\N	1274	1224	1	2017-10-18	\N		\N		25	3	2		2204
3253		\N	\N	1579	1	2017-07-11	\N		\N		20	3	2		2745
3254		\N	\N	455	1	2017-06-13	\N		\N		20	3	2		2746
3255		\N	\N	1325	1	2017-07-12	\N		\N		9	3	2		2747
3256		\N	\N	1215	1	2017-07-13	\N		\N		15	3	2		2748
3203		\N	1664	255	1	2017-10-16	\N		\N		12	3	2		485
3257		\N	1664	1322	1	2017-10-19	\N		\N		9	3	2		353
3258		\N	\N	1659	1	2017-07-12	\N		\N		15	3	2		2749
3259		\N	\N	669	1	2017-07-04	\N		\N		15	3	2		2750
3260		\N	\N	1326	1	2017-07-13	\N		\N		9	3	2		2751
3261		\N	\N	1216	1	2017-07-12	\N		\N		25	3	2		2752
3262		\N	\N	1632	1	2017-07-12	\N		\N		15	3	2		2753
3263		\N	\N	1590	1	2017-07-13	\N		\N		9	3	2		2754
3264		\N	\N	466	1	2017-06-14	\N		\N		9	3	2		2755
3265		\N	\N	1586	1	2017-07-04	\N		\N		9	3	2		2756
3266		\N	\N	672	1	2017-07-05	\N		\N		15	3	2		2757
3267		\N	\N	1219	1	2017-07-12	\N		\N		25	3	2		2758
2640		\N	\N	1219	1	2017-06-09	2017-10-19		\N		15	3	2		2250
3268		\N	1219	1664	1	2017-10-19	\N		\N		25	3	1		2250
3269		\N	\N	1571	1	2017-07-12	\N		\N		15	3	2		2759
3270		\N	1664	1664	1	2017-10-19	\N		\N		9	3	1		359
3271		\N	\N	673	1	2017-07-12	\N		\N		15	3	2		2760
3334		\N	254	1664	1	2017-10-20	2017-10-26		\N		12	3	2		2794
3273		\N	\N	675	1	2017-07-12	\N		\N		15	3	2		2761
3274		\N	\N	458	1	2017-07-12	\N		\N		20	3	2		2762
3275		\N	\N	1300	1	2017-07-18	\N		\N		20	3	2		2763
3277		\N	\N	1313	1	2017-07-13	\N		\N		20	3	2		2765
3278		\N	1222	1664	1	2017-10-20	\N		\N		25	3	1		2251
3279		\N	\N	1222	1	2017-07-13	\N		\N		15	3	2		2766
3281		\N	\N	738	1	2017-07-20	2017-10-20		\N		12	3	2		2768
3282		\N	738	1664	1	2017-10-20	\N		\N		12	3	2		2768
3283		\N	\N	738	1	2017-07-12	2017-10-20		\N		12	3	2		2769
3284		\N	738	1664	1	2017-10-20	\N		\N		12	3	2		2769
3285		\N	\N	735	1	2017-06-07	2017-10-20		\N		12	3	2		2770
3286		\N	735	1664	1	2017-10-20	\N		\N		12	3	2		2770
3287		\N	\N	735	1	2017-07-13	2017-10-20		\N		12	3	2		2771
3288		\N	735	1664	1	2017-10-20	\N		\N		12	3	2		2771
3289		\N	\N	740	1	2017-07-14	2017-10-20		\N		12	3	2		2772
3290		\N	740	1664	1	2017-10-20	\N		\N		12	3	2		2772
3291		\N	\N	740	1	2017-06-14	2017-10-20		\N		12	3	2		2773
3292		\N	740	1664	1	2017-10-20	\N		\N		12	3	2		2773
3293		\N	\N	741	1	2017-05-17	2017-10-20		\N		12	3	2		2774
3294		\N	741	1664	1	2017-10-20	\N		\N		12	3	2		2774
3295		\N	\N	741	1	2017-07-12	2017-10-20		\N		12	3	2		2775
3296		\N	741	1664	1	2017-10-20	\N		\N		12	3	2		2775
3297		\N	\N	744	1	2017-07-13	2017-10-20		\N		12	3	2		2776
3298		\N	744	1664	1	2017-10-20	\N		\N		12	3	2		2776
3299		\N	\N	744	1	2017-06-16	2017-10-20		\N		12	3	2		2777
3300		\N	744	1664	1	2017-10-20	\N		\N		12	3	2		2777
3301		\N	\N	1270	1	2017-06-15	\N		\N		25	3	2		2778
3308		\N	\N	733	1	2017-07-13	2017-10-20		\N		12	3	2		2782
3309		\N	733	1664	1	2017-10-20	\N		\N		12	3	2		2782
3304		\N	\N	747	1	2017-07-12	2017-10-20		\N		12	3	2		2780
3305		\N	747	1664	1	2017-10-20	\N		\N		12	3	2		2780
3310		\N	\N	733	1	2017-07-14	2017-10-20		\N		12	3	2		2783
3311		\N	733	1664	1	2017-10-20	\N		\N		12	3	2		2783
3306		\N	\N	747	1	2017-06-13	2017-10-20		\N		12	3	2		2781
3307		\N	747	1664	1	2017-10-20	\N		\N		12	3	2		2781
3312		\N	\N	57	1	2017-07-20	2017-10-20		\N		12	3	2		2784
3313		\N	57	1664	1	2017-10-20	\N		\N		12	3	2		2784
3314		\N	\N	256	1	2017-06-08	2017-10-20		\N		12	3	2		2785
3315		\N	256	1664	1	2017-10-20	\N		\N		12	3	2		2785
3316		\N	\N	742	1	2017-07-10	2017-10-20		\N		12	3	2		2786
3317		\N	742	1664	1	2017-10-20	\N		\N		12	3	2		2786
3318		\N	\N	742	1	2017-07-14	2017-10-20		\N		12	3	2		2787
3325		\N	\N	753	1	2017-07-14	2017-10-20		\N		12	3	2		2790
3320		\N	742	1664	1	2017-10-20	\N		\N		12	3	2		2787
3321		\N	\N	746	1	2017-07-12	2017-10-20		\N		12	3	2		2788
3322		\N	746	1664	1	2017-10-20	\N		\N		12	3	2		2788
3323		\N	\N	746	1	2017-05-20	2017-10-20		\N		12	3	2		2789
3324		\N	746	1664	1	2017-10-20	\N		\N		12	3	2		2789
3326		\N	753	1664	1	2017-10-20	\N		\N		12	3	2		2790
3327		\N	\N	305	1	2017-06-13	2017-10-20		\N		12	3	2		2791
3328		\N	305	1664	1	2017-10-20	\N		\N		12	3	2		2791
3329		\N	\N	305	1	2017-07-19	2017-10-20		\N		12	3	2		2792
3331		\N	\N	254	1	2017-07-12	2017-10-20		\N		12	3	2		2793
3332		\N	254	1664	1	2017-10-20	\N		\N		12	3	2		2793
3333		\N	\N	254	1	2017-06-23	2017-10-20		\N		12	3	2		2794
3330		\N	305	1664	1	2017-10-20	2017-10-26		\N		12	3	2		2792
3335		\N	\N	39	1	2017-07-20	2017-10-20		\N		12	3	2		2795
3336		\N	39	1664	1	2017-10-20	\N		\N		12	3	2		2795
3276		\N	\N	1664	1	2017-06-13	2017-10-23		\N		16	3	2		2764
3280		\N	\N	1664	1	2017-07-13	2017-10-23		\N		16	3	2		2767
3337		\N	1664	560	1	2017-10-23	\N		\N		16	3	1		2767
3340		\N	1664	606	1	2017-10-23	\N		\N		23	3	1		1411
3338		\N	1664	570	1	2017-10-23	\N		\N		16	3	1		2764
3339		\N	1664	108	1	2017-10-23	\N		\N		16	3	1		537
3341		\N	1664	607	1	2017-10-23	\N		\N		23	3	1		492
3342		\N	1664	611	1	2017-10-23	\N		\N		23	3	1		24
3343		\N	1664	609	1	2017-10-23	\N		\N		23	3	1		25
3344		\N	1664	610	1	2017-10-23	\N		\N		23	3	1		126
3345		\N	1664	1695	1	2017-10-23	\N		\N		23	3	1		125
3346		\N	1664	1695	1	2017-10-23	\N		\N		23	3	1		252
3347		\N	1664	1695	1	2017-10-23	\N		\N		23	3	1		148
3348		\N	1664	603	1	2017-10-23	\N		\N		23	3	1		251
3349		\N	1664	619	1	2017-10-23	\N		\N		23	3	1		31
3350		\N	1664	590	1	2017-10-23	\N		\N		23	3	1		28
3272		\N	1664	1187	1	2017-10-20	\N		\N		6	3	2		385
98		\N	\N	1664	\N	2017-07-17	2017-10-23		\N		5	3	2		98
3351		\N	1664	614	1	2017-10-23	\N		\N		23	3	1		98
3414		\N	\N	885	1	2017-06-07	2017-10-27		\N		7	3	2		2840
3352		\N	1664	613	1	2017-10-23	\N		\N		23	3	1		26
3353		\N	1664	119	1	2017-10-23	\N		\N		23	3	1		209
3354		\N	1664	119	1	2017-10-23	\N		\N		23	3	1		1588
3355		\N	1664	119	1	2017-10-23	\N		\N		23	3	1		150
3356		\N	1664	118	1	2017-10-23	\N		\N		23	3	1		208
3357		\N	1664	118	1	2017-10-23	\N		\N		23	3	1		636
3358		\N	\N	1358	1	2017-07-13	\N		\N		16	3	2		2796
3359		\N	\N	1358	1	2017-07-20	\N		\N		16	3	2		2797
3360		\N	\N	581	1	2017-07-12	\N		\N		21	3	2		2798
3361		\N	\N	1459	1	2017-07-13	\N		\N		21	3	2		2799
3362		\N	\N	1605	1	2017-06-09	\N		\N		21	3	2		2800
3363		\N	\N	473	1	2017-06-09	\N		\N		9	3	2		2801
3364		\N	\N	1286	1	2017-06-08	\N		\N		9	3	2		2802
3365		\N	\N	947	1	2017-07-06	\N		\N		8	3	2		2803
3366		\N	\N	951	1	2017-07-13	\N		\N		8	3	2		2804
3367		\N	\N	955	1	2017-06-15	\N		\N		8	3	2		2805
3368		\N	\N	958	1	2017-07-07	\N		\N		8	3	2		2806
3369		\N	\N	933	1	2017-07-14	\N		\N		8	3	2		2807
3370		\N	\N	1271	1	2017-07-14	\N		\N		25	3	2		2808
3371		\N	\N	445	1	2017-07-07	\N		\N		25	3	2		2809
3372		\N	\N	1271	1	2017-07-05	\N		\N		15	3	2		2810
3373		\N	1224	434	1	2017-10-24	\N		\N		25	3	1		487
3374		\N	\N	1651	1	2017-07-06	\N		\N		23	3	2		2811
3375		\N	\N	954	1	2017-08-15	\N		\N		8	3	2		2812
3376		\N	\N	404	1	2017-07-06	\N		\N		15	3	2		2813
3377		\N	\N	423	1	2017-07-05	\N		\N		15	3	2		2814
3378		\N	\N	420	1	2017-06-15	\N		\N		15	3	2		2815
3379		\N	\N	420	1	2017-07-06	\N		\N		15	3	2		2816
3380		\N	\N	1203	1	2017-07-07	\N		\N		15	3	2		2817
3381		\N	\N	1195	1	2017-07-06	\N		\N		15	3	2		2818
3382		\N	\N	289	1	2017-07-06	\N		\N		12	3	2		2819
3383		\N	\N	1052	1	2017-07-05	\N		\N		9	3	2		2820
3384		\N	\N	1329	1	2017-07-06	\N		\N		16	3	2		2821
3385		\N	\N	1329	1	2017-07-06	\N		\N		16	3	2		2822
3386		\N	\N	1336	1	2017-06-08	\N		\N		16	3	2		2823
3387		\N	\N	419	1	2017-07-13	\N		\N		15	3	2		2824
3388		\N	1664	130	1	2017-10-26	\N		\N		23	3	1		154
3389		\N	\N	576	1	2017-06-20	\N		\N		23	3	2		2825
3390		\N	\N	1598	1	2017-06-14	\N		\N		23	3	2		2826
3391		\N	434	1664	1	2017-10-24	\N		\N		25	3	1	գողացված է, տնօրենը խոստացել է գտնել	1931
3392		\N	1664	751	1	2017-10-26	\N		\N		12	3	1		14
3393		\N	1664	732	1	2017-10-26	\N		\N		12	3	1		17
3394		\N	1664	55	1	2017-10-26	\N		\N		12	3	1		15
3395		\N	1664	736	1	2017-10-26	\N		\N		12	3	1		471
3396		\N	1664	736	1	2017-10-26	\N		\N		12	3	1		2794
3397		\N	1664	730	1	2017-10-26	\N		\N		12	3	1		478
3398		\N	1664	730	1	2017-10-26	\N		\N		12	3	1		2792
3399		\N	\N	750	1	2017-07-06	\N		\N		12	3	2		2827
3400		\N	\N	749	1	2017-07-06	\N		\N		12	3	2		2828
3401		\N	\N	405	1	2017-07-07	\N		\N		15	3	2		2829
3402		\N	\N	409	1	2017-07-12	\N		\N		15	3	2		2830
3403		\N	\N	805	1	2017-07-06	\N		\N		24	3	2		2831
3404		\N	\N	815	1	2017-06-08	\N		\N		17	3	2		2832
3405		\N	\N	801	1	2017-07-05	\N		\N		17	3	2		2833
3406		\N	\N	788	1	2017-06-08	\N		\N		17	3	2		2834
3407		\N	\N	789	1	2017-06-07	\N		\N		17	3	2		2835
3408		\N	\N	315	1	2017-07-07	\N		\N		17	3	2		2836
3409		\N	\N	817	1	2017-07-06	\N		\N		17	3	2		2837
3410		\N	\N	821	1	2017-06-15	\N		\N		17	3	2		2838
3411		\N	1664	80	1	2017-10-27	\N		\N		7	3	1		151
3412		\N	\N	897	1	2017-06-07	2017-10-27		\N		7	3	2		2839
3413		\N	897	1664	1	2017-10-27	\N		\N		7	3	2		2839
3415		\N	885	1664	1	2017-10-27	\N		\N		7	3	2		2840
3416		\N	\N	946	1	2017-07-20	\N		\N		8	3	2		2841
3417		\N	\N	1580	1	2017-07-13	\N		\N		20	3	2		2842
3418		\N	\N	705	1	2017-10-27	\N		\N		12	3	2		2843
3419		\N	\N	707	1	2017-07-06	\N		\N		12	3	2		2844
3420		\N	\N	710	1	2017-07-11	\N		\N		12	3	2		2845
3421		\N	\N	293	1	2017-06-13	\N		\N		12	3	2		2846
3422		\N	220	1664	1	2017-10-27	\N		\N		17	3	2		1102
3423		\N	\N	220	1	2017-06-15	2017-10-27		\N		24	3	2		2847
3424		\N	220	1664	1	2017-10-27	\N		\N		24	3	1		2847
3425		\N	305	61	1	2017-10-24	\N		\N		12	3	1		1825
\.


--
-- Name: Location_Location_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Location_Location_ID_seq"', 3425, true);


--
-- Data for Name: Manufacturer; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Manufacturer" ("Manufacturer_ID", "Manufacturer_Name") FROM stdin;
1	Ubiquity
2	Cisco
3	Mikrotik
5	D-Link
6	SMC
7	HP
8	ADC
9	Planet
10	Tenda
11	Mercury
12	TP-Link
13	C-Net
14	Mercury
4	AirLink
0	3Com
15	Unknown
49	HUAWEI
\.


--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Manufacturer_Manufacturer_ID_seq"', 49, true);


--
-- Data for Name: Model; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Model" ("Model_ID", "Model_Name", "Manufacturer_ID", "Power", "Frequency_ID", "Item_Type_ID") FROM stdin;
1	PowerBeam M2 400	1	600	1	1
2	PowerBeam PBE-5AC-400-ISO 	1	600	2	1
3	PowerBeam PBE-5AC-400	1	600	2	1
4	PowerBeam M5 AC 500-ISO	1	600	2	1
5	PowerBeam M5 AC 500	1	600	2	1
6	Rocket M2 Airmax	1	600	1	1
7	Rocket M2 Titanium	1	600	1	1
8	Rocket M5 Airmax	1	600	2	1
9	Rocket M5 Titanium	1	600	2	1
10	Rocket M5 AC Light	1	600	1	1
11	Bullet M2	1	600	1	1
12	Bullet M2 Titanium	1	600	1	1
13	Bullet 2HP	1	600	1	1
14	Bullet M5	1	600	2	1
15	Nanostation Loco M2	1	600	1	1
16	Nanostation M2	1	600	1	1
17	Nanostation Loco M5	1	600	2	1
18	Nanostation M5	1	600	2	1
19	AirGrid M5 HP	1	600	2	1
20	LightBeam M5	1	600	2	1
21	LightBeam M5 AC	1	600	2	1
22	TOUGHSwitch PoE 5 port	1		\N	8
23	TOUGHSwitch PoE PRO 8 port	1		\N	8
24	Cisco 1310	2	100	1	1
25	Cisco 1220	2	50	1	1
26	Cisco 1230	2	50	1	1
27	Cisco 1232	2	50	1	1
28	Cisco 1242	2	100	1	1
29	RB/951Ui-2nD hAP	3		\N	2
30	RB/260GS	3		\N	8
31	AirLink Router W11	4	400	1	1
32	TP-Link TL-SF1005D	12		\N	8
33	TP-Link TL-SF1008D	12		\N	8
34	TP-Link TL-SF1016D	12		\N	8
35	TP-Link TL-MR3220	12		\N	3
36	TP-Link TL-WR842MD	12		\N	4
37	D-Link DES-1005A	5		\N	8
38	D-Link DGS-1008D	5		\N	8
39	300 S	8		\N	6
40	GRT-101	9		\N	6
41	SMCGS10C-Smart	6		\N	8
42	S5	10		\N	8
43	Elit 1000 Pro	11		\N	7
46	2.4Ghz, 15dbi, 120-Sector	15		1	5
47	2.4Ghz, 19dbi, 120-Sector	15		1	5
48	2.4Ghz, 15dbi, OMNI	15		1	5
51	AirMax 15dBi 2.4GHz 120-Sector	1		1	5
52	AirMax 16dBi 2.4GHz 90-Sector	1		1	5
53	RocketDish 2G 24 AC	1		1	5
56	AirMax 19dBi 5 GHz 90-Sector	15		2	5
57	AirMax 20dBi 5 GHz 120-Sector	15		2	5
59	Dir-100	5		\N	2
60	ADSL router DSL-2500	5		\N	9
61	CNet  18-1sgh800cfh	13		\N	8
62	Elite 1000 Pro	11		\N	7
45	2.4Ghz, 24dbi	15		1	5
55	5Ghz, 31dbi	15		2	5
49	2.4Ghz, 15dbi, YAGI	15		1	5
50	AirMax 13dBi 2.4GHz DualOmni	1		1	5
54	5Ghz, 26dbi	15		2	5
44	2.4Ghz, 20dbi	15		1	5
129	Repare Part for IPAM-1600	15		\N	11
0	FSD-1605	9		\N	8
130	3C17304A	0		\N	8
131	 PowerBeam M5 400	1		2	1
58	RocketDish 5G 31 AC	1		2	5
134	PowerBeam 5AC 620	1	600	2	1
135	Planet GSD-503	9		\N	8
136	2.4GHz, 7dBi (бабочка)	15		1	5
137	B310s-22 (U!Box)	49		\N	12
138	B68A - V100R001	49		\N	12
\.


--
-- Name: Model_Model_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Model_Model_ID_seq"', 138, true);


--
-- Data for Name: Owner; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Owner" ("Owner_ID", "Owner_Name") FROM stdin;
1	HF
2	Fastnet
3	KTAK
4	UCOM
5	Other
\.


--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Owner_Owner_ID_seq"', 9, true);


--
-- Data for Name: Region; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Region" ("Region_ID", "Region_Name") FROM stdin;
1	Արագածոտն
2	Արարատ
3	Արմավիր
4	Գեղարքունիք
5	Երևան
6	Լոռի
7	Կոտայք
8	Շիրակ
9	Սյունիք
10	Վայոց Ձոր
11	Տավուշ
\.


--
-- Name: Region_Region_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Region_Region_ID_seq"', 13, true);


--
-- Data for Name: Site; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Site" ("Site_ID", "Site_Name", "Site_Type_ID", "Region_ID", "Address", "Latitude", "Longitude", "Responsive_Person_ID", "Connection_Type_ID", "Head_Name", "Head_Phone_1", "Head_Phone_2", "Head_Phone_3", "Operator_Name", "Operator_Phone_1", "Operator_Phone_2", "Operator_Phone_3", "Description", "Connected_Comp_Count", "School_Comp_Count") FROM stdin;
1	Ճամբարակ	1	4		\N	\N	3	1										\N	\N
2	Թթուջուրի մ/դ	3	4	գ. Թթուջուր	\N	\N	3	1	Սարիբեկյան Վարդան	98334424	95007385		Գրիգորյան Վահագն	77173975				\N	\N
71	Այրում	1	11		\N	\N	3	\N										\N	\N
59	Լանջիկ	1	8		\N	\N	3	\N										\N	\N
64	Սանահին	1	6		\N	\N	3	\N										\N	\N
74	Թեղուտ  (Լոռի)	1	6		\N	\N	3	\N										\N	\N
66	Օձուն	1	6		\N	\N	3	\N										\N	\N
67	Լորուտ	1	6		\N	\N	3	\N										\N	\N
57	Թլիկի հմ/դ	3	1		\N	\N	3	\N										\N	\N
46	Շենկան	2	1		\N	\N	3	\N										\N	\N
48	Գեղաձոր	1	1		\N	\N	3	\N										\N	\N
43	Ապարան	1	1		\N	\N	3	\N										\N	\N
50	Օշական	1	1		\N	\N	3	\N										\N	\N
68	Չկալով	1	6		\N	\N	3	\N										\N	\N
30	Քանաքեռ	4	5		\N	\N	3	\N										\N	\N
70	Ձորագետ	2	6		\N	\N	3	\N										\N	\N
53	Փարպի	1	1		\N	\N	3	\N										\N	\N
55	Թալին	1	1		\N	\N	3	\N										\N	\N
61	Ուջան	4	1		\N	\N	3	\N										\N	\N
51	Բյուրական	4	1		\N	\N	3	\N										\N	\N
40	Վաղարշապատ 	4	3	Ք. Վաղարշապատ, Նար-Դոսի 3	40.1642790000000005	44.2923919999999995	3	1	Արտյոմ	93601717	95601717							0	0
42	Արմավիր 	4	3	Ք. Արմավիր, Երևանյան 22ա	40.1473670000000027	44.0319670000000016	3	1	Տիգրան Ցականյան	77447210								0	0
20	Մեղրաձոր	1	7		\N	\N	3	\N										\N	\N
21	Արտավազ	4	7		\N	\N	3	\N										\N	\N
22	Չարենցավան	4	7		\N	\N	3	\N										\N	\N
23	Գյումուշ	4	7		\N	\N	3	\N										\N	\N
25	Աբովյան	4	7		\N	\N	3	\N										\N	\N
26	Սևաբերդ	2	7		\N	\N	3	\N										\N	\N
28	Գետամեջ	4	7		\N	\N	3	\N										\N	\N
29	Զովունի	4	7		\N	\N	3	\N										\N	\N
18	Հրազդան	1	7		\N	\N	3	\N										\N	\N
17	Լճավան	2	4		\N	\N	3	\N										\N	\N
3	Գետիկ	1	4		\N	\N	3	\N										\N	\N
4	Անտառամեջ	2	4		\N	\N	3	\N										\N	\N
5	Վարդենիս	1	4		\N	\N	3	\N										\N	\N
7	Գավառ	1	4		\N	\N	3	\N										\N	\N
9	Արտանիշ	2	4		\N	\N	3	\N										\N	\N
10	Ջիլ	4	4		\N	\N	3	\N										\N	\N
11	Վահան	4	4		\N	\N	3	\N										\N	\N
12	Սևան	1	4		\N	\N	3	\N										\N	\N
60	Ձիթհանքով	1	8		\N	\N	3	\N										\N	\N
15	Մարտունի	1	4		\N	\N	3	\N										\N	\N
14	Ծովազարդի մ/դ	3	4	գ. Ծովազարդ	\N	\N	3	\N	Գալստյան Նվեր	95009767	93896296							\N	\N
31	Սպիտակ	1	6		\N	\N	3	\N										\N	\N
32	Սարամեջ	1	6		\N	\N	3	\N										\N	\N
33	Արևաշող	2	6		\N	\N	3	\N										\N	\N
37	Սարալանջ	1	6		\N	\N	3	\N										\N	\N
72	Ախթալա	1	6		\N	\N	3	\N										\N	\N
19	Հրազդան	4	7		40.5484750000000034	44.7717469999999977	3	\N										\N	\N
24	Արզական	4	7		\N	\N	3	\N	Աղվան Նավասարդյան	43100468								\N	\N
65	Հագվի	2	6		\N	\N	3	\N										\N	\N
76	Քարկոփ	2	11		\N	\N	3	\N										\N	\N
27	Նոր Արտամետ	4	7		\N	\N	3	\N										\N	\N
8	Լանջաղբյուրի մ/դ	8	4	գ. Լանջաղբույր	\N	\N	3	\N	Ավետիսյան Սերգե	95007612	94915404	95111999	Դավթյան Սամվել	93777216				\N	\N
16	Ձորագյուղի  հմ/դ	3	4	գ. Ձորագյուղ	\N	\N	3	\N	Սարգսյան Սարգիս	95009764	93810648		Ասատրյան Ռուզաննա	93287303				\N	\N
6	Արփունքի մ/դ	3	4	գ. Արփունք	\N	\N	3	\N	Վարդանյան Նելա	95007479	77536775		Վարդանյան Անի	94436243				\N	\N
77	Նոյեմբերյան	1	11		\N	\N	3	\N										\N	\N
79	Թեղուտ (Տավուշ)	2	11		\N	\N	3	\N										\N	\N
115	Ջրափ	5	8		\N	\N	3	\N										\N	\N
80	Հաղարծին	1	11		\N	\N	3	\N										\N	\N
81	Բագրատաշեն	2	11		\N	\N	3	\N										\N	\N
78	Դիլիջան	1	11		40.7416059999999973	44.8568110000000004	3	\N										\N	\N
109	Մարալիկ	4	8		\N	\N	3	\N										\N	\N
155	Այգեձոր	2	11		\N	\N	3	\N										\N	\N
96	Գյումրի	1	8		\N	\N	3	\N										\N	\N
100	Ամասիա	1	8		\N	\N	3	\N										\N	\N
101	Թորոսգյուղ	2	8		\N	\N	3	\N										\N	\N
102	Ձորաշեն	1	8		\N	\N	3	\N										\N	\N
107	Շիրակավան	2	8		\N	\N	3	\N										\N	\N
108	Կաքավասար	2	8		\N	\N	3	\N										\N	\N
113	Սարատակ	1	8		\N	\N	3	\N										\N	\N
117	Կապան	1	9		\N	\N	3	\N										\N	\N
119	Անտառաշատ	1	9		\N	\N	3	\N										\N	\N
120	Ճակատեն	2	9		\N	\N	3	\N										\N	\N
121	Խալաջ (Աճանան)	4	9		\N	\N	3	\N										\N	\N
122	Շիկահող	2	9		\N	\N	3	\N										\N	\N
123	Շիկահող 2	2	9		\N	\N	3	\N										\N	\N
124	Ներքին Հանդ	2	9		\N	\N	3	\N										\N	\N
125	Ծավ	1	9		\N	\N	3	\N										\N	\N
126	Ճակատեն 1	4	9		\N	\N	3	\N										\N	\N
128	Լիճք	4	9		\N	\N	3	\N										\N	\N
129	Գորիս	1	9		\N	\N	3	\N										\N	\N
130	Կատար (Գորիս)	1	9		\N	\N	3	\N										\N	\N
132	Քաջարան	1	9		\N	\N	3	\N										\N	\N
133	Զեյվա (Դավիթ Բեկ)	2	9		\N	\N	3	\N										\N	\N
134	Ագարակ	1	9		\N	\N	3	\N										\N	\N
135	Վարդանիձոր	1	9		\N	\N	3	\N										\N	\N
136	Լեհվազ	2	9		\N	\N	3	\N										\N	\N
137	Սպանդարյան՝ Աղիտու 	4	9		\N	\N	3	\N										\N	\N
138	Սիսիան	1	9		\N	\N	3	\N										\N	\N
140	Որոտան	2	9		\N	\N	3	\N										\N	\N
139	Դաստակերտ	2	9		\N	\N	3	\N										\N	\N
142	Սալվարդ	2	9		\N	\N	3	\N										\N	\N
143	Եռաբլուր	1	9		\N	\N	3	\N										\N	\N
145	Գորհայք	1	9		\N	\N	3	\N										\N	\N
147	Վաղատին	2	9		\N	\N	3	\N										\N	\N
148	Լծեն	2	9		\N	\N	3	\N										\N	\N
149	Դարբաս	1	9		\N	\N	3	\N										\N	\N
151	Շաղատ	2	9		\N	\N	3	\N										\N	\N
152	Հալիձոր	4	9		\N	\N	3	\N										\N	\N
84	Վանաձորի շինություն (կառույց)	4	6		\N	\N	3	\N										\N	\N
85	Ստեփանավան	1	6		\N	\N	3	\N										\N	\N
89	Վանաձոր	1	6		\N	\N	3	\N										\N	\N
91	Լերմոնտովո	5	6		\N	\N	3	\N										\N	\N
93	Փամբակ	1	6		\N	\N	3	\N										\N	\N
94	Պուշկին (Պուշկինո)	1	6		\N	\N	3	\N										\N	\N
153	Շինուհայր	4	9		\N	\N	3	\N										\N	\N
146	Թերփ (Սարավան)	1	10		\N	\N	3	\N										\N	\N
118	Եղվարդ	1	9		\N	\N	3	1										\N	\N
131	Տեղի թիվ 2 մ/դ	3	9		\N	\N	3	\N	Ջհանգիրյան Գյուլնարա	95001927	93645022		Իրինա Գալստյան	77363458				\N	\N
201	Չարենցավան GNC	4	7		\N	\N	3	\N										\N	\N
202	Աբովյան GNC	4	7		\N	\N	3	\N										\N	\N
203	Աշտարակ GNC	4	1		\N	\N	3	\N										\N	\N
206	Քաջարան GNC	4	9		\N	\N	3	\N										\N	\N
207	Ագարակ GNC	4	9		\N	\N	3	\N										\N	\N
191	Գողթ	1	7	գյուղ Գողթ	40.1363759999999985	44.7761110000000002	3	2	Հովսեփյան Հովսեփ  	94466357								\N	\N
187	Արտաշատ	4	2		\N	\N	3	\N										\N	\N
157	Արծվաբերդ	1	11		\N	\N	3	\N										\N	\N
158	Իջևան	1	11		\N	\N	3	\N										\N	\N
160	Սևքար	1	11		\N	\N	3	\N										\N	\N
177	Վայք	1	10		\N	\N	3	\N										\N	\N
215	Իծաքար	1	11		\N	\N	3	\N										\N	\N
178	Ազատեկ	2	10		\N	\N	3	\N										\N	\N
210	Ախուրյան	4	8		\N	\N	3	\N										\N	\N
196	Մեծամոր 	4	3	Ք. Մեծամոր, 1-ին թաղ.,  5բ1	40.1470860000000016	44.1186080000000018	3	1										0	0
197	Սարդարապատ	4	3	գ. Արաքս	40.0898669999999981	43.9562099999999987	3	2	Կարեն Արիստակեսյան	94582098								0	0
198	Զվարթնոց	4	3	Ք. Վաղարշապատ, Զվարթնոց թաղամաս 11 շենք	40.1666820000000016	44.3303030000000007	3	1	Արտուշ Մարգարյան	55033747								0	0
192	Գեղարդ	2	7	գյուղ Գեղարդ	40.156922999999999	44.8050110000000004	3	2	Թառոյան Վիգեն	93753299								\N	\N
217	Կապուտան	4	7		\N	\N	3	\N										\N	\N
222	Աբովյանի ԱՀԿ` Աբովյան, 4-րդ միկրոշրջան	4	7		\N	\N	3	\N										\N	\N
171	Արտավազ	1	7		\N	\N	3	\N										\N	\N
183	Վեդի	1	2		\N	\N	3	\N										\N	\N
204	Գյումրի Անի	4	8		\N	\N	3	\N										\N	\N
161	Վազաշեն	1	11		\N	\N	3	\N										\N	\N
162	Բաղանիս	1	11		\N	\N	3	\N										\N	\N
165	Բերդի հեռուստաաշտարակ	1	11		\N	\N	3	\N										\N	\N
163	Կոթի	5	11		\N	\N	3	\N										\N	\N
180	Սերս	2	10		\N	\N	3	\N										\N	\N
167	Չինչին	1	11		\N	\N	3	\N										\N	\N
211	Սրաշեն	1	9		\N	\N	3	\N										\N	\N
199	Սիսիան	4	9		\N	\N	3	\N										\N	\N
212	Դավիթ Բեկ	4	9		\N	\N	3	\N										\N	\N
169	Եղեգնաձոր 2	1	10		\N	\N	3	\N										\N	\N
170	Մոզրով	1	10		\N	\N	3	\N										\N	\N
172	Զեդեա	2	10		\N	\N	3	\N										\N	\N
173	Եղեգնաձոր 1	1	10		\N	\N	3	\N										\N	\N
174	Սալլի	2	10		\N	\N	3	\N										\N	\N
175	Ելփին	1	10		\N	\N	3	\N										\N	\N
176	Սմբատաբերդ	2	10		\N	\N	3	\N										\N	\N
181	Հերմոն	2	10		\N	\N	3	\N										\N	\N
216	Մարտիրոս	1	10		\N	\N	3	\N										\N	\N
223	Մալիշկա	4	10		\N	\N	3	\N										\N	\N
220	Արմաշ	4	2		\N	\N	3	1	093386801									\N	\N
225	Դվինի Լ. Ազգալդյանի անվ. մ/դ	3	2		\N	\N	3	\N	Լաուրա Բաբայան 	099082200	095005153		Աիդա Խուդոյան	098680655	095680655			\N	\N
185	Մասիս	4	2		\N	\N	3	\N	Սամվել	096000060								\N	\N
248	Թալինի վարժարան (ՀՀ ԿԳՆ Արագածոտնի տարածաշրջանային պետական քոլեջ)	8	1	ք. Թալին, Խանջյան 16	\N	\N	3	\N	Գաբրիել Ավետիսյան	91343950	95008986		Լալա Խուրշուդյան	093 87-94-48				\N	\N
250	Գետափի մ/դ	8	1	գ. Գետափ	\N	\N	3	\N	Ռադիկ Կարապետյան	93484696	95008991							\N	\N
251	Զարինջայի մ/դ	8	1	գ. Զարինջա	\N	\N	3	\N	Ստեփանյան Շողիկ	93458170								\N	\N
252	Կաքավաձորի մ/դ	8	1	գ. Կաքավաձոր	\N	\N	3	\N					Խաչատրրան Է.					\N	\N
253	Ներքին Բազմաբերդի մ/դ	8	1	գ. Ներքին Բազմաբերդ	\N	\N	3	\N	Պետրոսյան Անդրանիկ	99973299								\N	\N
254	Պարտիզակի մ/դ	8	1	գ. Պարտիզակ	\N	\N	3	\N	Թորոսյան Սամվել	91828309	95008714							\N	\N
255	Դիանի հմ/դ	8	1	գ. Դիան	\N	\N	3	\N	Պողոսյան Պավլիկ	94909579	24962121							\N	\N
257	Ոսկեթասի մ/դ	8	1	գ. Ոսկեթաս	\N	\N	3	\N	Տիգրան Գևորգյան	77782563			Հերմինե Գևորգյան	93416972				\N	\N
259	Ալագյազի մ/դ	8	1	գ. Ալագյազ	\N	\N	3	\N	Ավդալյան Վազիր	93360219	95006431		Արամ Խուդոյան	094 54-01-08	095 57-43-23			\N	\N
260	Ամրե Թազայի (Սադունցի հմ/դ) հմ/դ	8	1	գ. Ամրե Թազա (Սադունց)	\N	\N	3	\N	Կիրակոսյան Գուրգեն	93388101	95006429							\N	\N
261	Ավշենի հմ/դ	8	1	գ. Ավշեն	\N	\N	3	\N	Ալոյան Մալխաս	55575341	95006427							\N	\N
262	Գեղադիրի մ/դ	8	1	գ. Գեղադիր	\N	\N	3	\N	Խաչատրյան Արամ	93364926	95006426		Մարաբյասն Էլբիրա					\N	\N
263	Գեղաձորի մ/դ	8	1	գ. Գեղաձոր	\N	\N	3	\N	Մխիթարյան Մ.	93757247	95006425							\N	\N
265	Դերեկի մ/դ	8	1	գ. Ճարճակիս (Դերեկ)	\N	\N	3	\N	Մարգարյան Ա.-Նախկիին, Հռիփսիմե Ավետիսյան	95006423	94429138	93817900	Սադեյան Թերեզա,	Դերեկի գյուղապետ-Թալաբան 077550411				\N	\N
266	Լեռնապարի մ/դ	8	1	գ. Լեռնապար	\N	\N	3	\N										\N	\N
267	Ջամշլուի հմ/դ	8	1	գ. Ջամշլու	\N	\N	3	\N	Խուդոյան Թեմուր	93574323	95006419		Խուդոյան Բագրատ	55574323				\N	\N
268	Սանգյառի (Կանիաշիր) հմ/դ	8	1	գ. Սանգյառ (Կանիաշիր)	\N	\N	3	\N	Բոյաջյան Անահիտ	93558903	95006418		Տիգրանուհի Խաչատրյան	095 89-77-21				\N	\N
270	Ծաղկահովիտի Արագածի արհեստագործական ուսումնարան	8	1	գ. Ծաղկահովիտ	\N	\N	3	\N	կիրակոսյան վարդգես	95006416	93333317		Շահնազարյան Տաթևիկ					\N	\N
271	Ծիլքարի մ/դ	8	1	գ. Ծիլքար	\N	\N	3	\N	Հովհաննիսյան Արման	93683241	95006415	55933363						\N	\N
272	Հնաբերդի մ/դ	8	1	գ. Հնաբերդ	\N	\N	3	\N	Բաղդասարյան Արշալույս-նախկին տնօրեն	95006414	93778701		Բաղդասարյան Կարինե					\N	\N
273	Մելիքգյուղի մ/դ	8	1	գ. Մելիքգյուղ	\N	\N	3	\N	Ղևոնդյան Արթուր	93356790	95006428		Գրիգորյան Սուսաննա					\N	\N
274	Շենկանի հմ/դ	8	1	գ. Շենկան	\N	\N	3	\N	Չոլոյան Սերյոժա	95006413	98021601							\N	\N
275	Վարդաբլուրի մ/դ	8	1	գ. Վարդաբլուր	\N	\N	3	\N	Նազարեթյան Ռոբերտ	93286739	95006412		Մկրտչյան Հերմինե					\N	\N
277	Բերքառատի մ/դ	8	1	գ. Բերքառատ	\N	\N	3	\N	Ալեքսանյան Ալեքսան	55195158	95006364		Ալեքսանյան Մելանյա					\N	\N
278	Միրաքի հմ/դ	8	1	գ. Միրաք	\N	\N	3	\N	Արշակյան Ժ.	95777057	95006365							\N	\N
279	Անտառուտի մ/դ	8	1	գ. Անտառուտ	\N	\N	3	\N	Շմավոնյան Սուրիկ	93445565	95006398		Դանիելյան Գայանե	93202276				\N	\N
280	Ավանի մ/դ	8	1	գ. Ավան	\N	\N	3	\N										\N	\N
282	Արտաշավանի մ/դ	8	1	գ. Արտաշավան	\N	\N	3	\N	Ռուզաննա Մարտիրոսյան	93256541								\N	\N
283	Արուճի մ/դ	8	1	գ. Արուճ	\N	\N	3	\N	Գրիգորյան Սեդա	93 93-52-09	95006438		Ղումաշյան Լուսաբեր	094 07-92-94				\N	\N
243	Բյուրեղավան /նոր/ 	4	7		\N	\N	3	\N										\N	\N
264	Գեղարոտի մ/դ	8	1	գ. Գեղարոտ	\N	\N	3	\N	Սևակ Մուրադյան	093240406			Գայանե Լանջյան	098505442				3	4
247	Աշտարակ /նոր/	1	1		\N	\N	3	\N										\N	\N
276	Օրթաճյայի (Միջնատուն) հմ/դ	8	1	գ. Օրթաճյա (Միջնատուն)	\N	\N	3	\N	Գրիգորյան Էդիկ	094579554	95006362							\N	\N
234	Լճկաձոր	4	11		\N	\N	3	\N										\N	\N
235	Արենի /նոր/	1	10		\N	\N	3	\N										\N	\N
236	Արփի /նոր/	1	10		\N	\N	3	\N										\N	\N
237	Գոմք /նոր/	2	10		\N	\N	3	\N										\N	\N
238	Գողթանիկ /նոր/	2	10		\N	\N	3	\N										\N	\N
239	Հորս /նոր, արևային/	2	10		\N	\N	3	\N										\N	\N
240	Քարագլուխ /նոր/	1	10		\N	\N	3	\N										\N	\N
241	Խնձորուտ /նոր/	1	10		\N	\N	3	\N										\N	\N
242	Ջերմուկ /նոր/	4	10		\N	\N	3	\N										\N	\N
244	Հրազդան /նոր/ միկրո	4	7		40.5453639999999993	44.7782610000000005	3	\N										\N	\N
256	Լուսակնի հմ/դ	8	1	գ. Լուսակն	\N	\N	3	\N	Մնացականյան Տաթևիկ	98692530	95008996							2	2
249	Գառնահովիտի մ/դ	8	1	գ. Գառնահովիտ	\N	\N	3	\N	Սրապ Գրիգորյան	99302550			Սիրուն Զոհրաբյան					2	10
246	Լանջառ /նոր/	4	2		\N	\N	3	2	Պետիկ Մարգարյան	093092876								\N	\N
258	Արտենիի թիվ 2 հմ/դ	8	1	գ. Արտենի	\N	\N	3	\N	Թագուհի Միրաքյան	98325654			Դավթյան Մարջան	94394313	95008693			1	5
284	Բազմաղբյուրի մ/դ	8	1	գ. Բազմաղբյուր	\N	\N	3	\N	Ղազարյան Մարիեն	94826202	95006439	23296253	Շուշանիկ Հովհաննիսյան	98529797				\N	\N
285	Լեռնարոտի մ/դ	8	1	գ. Լեռնարոտ	\N	\N	3	\N	Մնացականյան Արուս	93641635	95006441			093 04-88-71				\N	\N
286	Կոշի մ/դ	8	1	գ. Կոշ	\N	\N	3	\N	Տոնոյան Ռուզաննա	93332641	95006442			093 60-13-48				\N	\N
287	Նոր Ամանոսի մ/դ	8	1	գ. Նոր-Ամանոս	\N	\N	3	\N	Աբգարյան Մամիկոն	091/341543	23261062							\N	\N
288	Նոր Եդեսիայի մ/դ	8	1	գ. Նոր Եդեսիա	\N	\N	3	\N	Հարությունյան Սոնա	93 60-22-08	95006445		Վահագն Հովհաննիսյան	93937176				\N	\N
290	Ուշիի մ/դ	8	1	գ. ՈՒշի	\N	\N	3	\N										\N	\N
291	Ուջանի մ/դ	8	1	գ. Ուջան	\N	\N	3	\N	Հարությունյան Ավետիս	93216393								\N	\N
292	Օհանավանի մ/դ	8	1	գ. Օհանավան	\N	\N	3	\N	Համբարձումյան Աշխարհիկ	93920881	95006451	98610318	Համբարձումյան Թեհմինե	95998007				\N	\N
294	Մուղնիի մ/դ	8	1	գ. Մուղնի	\N	\N	3	\N	Համբարձումյան Գրետա	93383531			Մերի Խոջոյան	093 25-41-40				\N	\N
295	Ագարակի Թերլեմեզյանի անվան մ/դ	8	1	գ. Ագարակ	\N	\N	3	\N	Լորետտա Մարգարյան	95006454	93279303			077 066-883				\N	\N
296	Արագածի թիվ 2 մ/դ	8	1	գ. Արագած	\N	\N	3	\N	Ավդալյան Ֆուրման	93651834	95006371							\N	\N
297	Արայի հմ/դ	8	1	գ. Արա	\N	\N	3	\N	Պետրոսյան Անահիտ	94306044	95006372	25261351						\N	\N
298	Ափնայի մ/դ	8	1	գ. Ափնագյուղ	\N	\N	3	\N	Հակոբյան Սուսաննա	93257233	95006373							\N	\N
300	Թթուջուրի հմ/դ	8	1	գ. Թթուջուր	\N	\N	3	\N	Ղազարյան Գրիշա	25260038	93389364	95006375						\N	\N
301	Լուսագյուղի մ/դ	8	1	գ. Լուսագյուղ	\N	\N	3	\N	Բաղդասարյան Էդվարդ	93899928	95006376	25224129						\N	\N
302	Ձորագլխի մ/դ	8	1	գ. Ձորագլուխ	\N	\N	3	\N	Սողոմոնյան Կարեն	25260040	093 32-43-92		Սահակյան Մերուժան	094 72-54-11				\N	\N
303	Մուլքի (Կայք) մ/դ	8	1	գ. Մուլք (Կայք)	\N	\N	3	\N	Գրիգորյան Գայանե	95006381	55821275		Մարտին	94666539				\N	\N
304	Նիգավանի մ/դ	8	1	գ. Նիգավան	\N	\N	3	\N	Բաղդասարյան Նվեր	95006382	93555095							\N	\N
306	Սարալանջի հմ/դ	8	1	գ. Սարալանջ	\N	\N	3	\N	Սասուն Մանուկյան	25224931	93883489	95006384						\N	\N
307	Վարդենիսի մ/դ	8	1	գ. Վարդենիս	\N	\N	3	\N	Ավետիսյան Ավետիք	93931827	95006385							\N	\N
308	Վարդենուտի մ/դ	8	1	գ. Վարդենուտ	\N	\N	3	\N	Պետրոսյան Արա	91338811	95006386	25296260						\N	\N
310	Աբովյանի մ/դ	8	2	գ. Աբովյան	\N	\N	3	\N	Գրիգորյան Արմենակ	95008659	93676824		Նելլի Խաչատրյան	77076673				\N	\N
311	Լանջազատի մ/դ	8	2	գ. Լանջազատ	\N	\N	3	\N	Մախմուրյան Արուս	95008658	99238889		Մերինե Սարգսյան	94251546				\N	\N
312	Արարատի թիվ 2 մ/դ	8	2	գ. Արարատ, Իսակովի 2	\N	\N	3	\N	Դավթյան Հասմիկ	95005735	94349076		Հայկ Մկրտչյան	93929169				\N	\N
314	Արմաշի մ/դ	8	2	գ. Արմաշ	\N	\N	3	\N	Զեյնալյան Վալոդ	95005732	55360036		Արմինե Ալեքյան	93799730				\N	\N
316	Լանջառի հմ/դ	8	2	գ. Լանջառ	\N	\N	3	\N	Պողոսյան Մարտին	95005731	93621942		Մարտին Հովհաննիսյան	93027972				\N	\N
317	Լուսաշողի մ/դ	8	2	գ. Լուսաշող	\N	\N	3	\N	Մելոյան Մանուշակ	95005141	93902938		Արտակ Հարությունյան	93332475	77191121			\N	\N
319	Շաղափի Զազարյանի անվան մ/դ	8	2	գ. Շաղափ	\N	\N	3	\N	Միքայելյան Լեվոն	95005725	99010129		Գայանե Միքայելյան	77514800				\N	\N
320	Ազատաշենի հմ/դ	8	2	գ. Ազատաշեն	\N	\N	3	\N	Հարությունյան Արմինե	95008657	98577704		Աննա Գրիգորյան	91618788				\N	\N
321	Դարբնիկի մ/դ	8	2	գ. Դարբնիկ	\N	\N	3	\N	Բադալյան Ֆելիքս	95008654	93958507		Աստղիկ Բաղդասարյան	95687429				\N	\N
322	Խաչփարի մ/դ	8	2	գ. Խաչփար	\N	\N	3	\N	Եփրեմյան Սուսաննա	95008656	94836084		Լորաննա Սահակյան	95456120				\N	\N
323	Ջրահովիտի մ/դ	8	2	գ. Ջրահովիտ	\N	\N	3	\N	Բաբայան Արտակ	95008653	93248231		Սեդա Հովսեփյան	91545610				\N	\N
324	Սիփանիկի հմ/դ	8	2	գ. Սիփանիկ	\N	\N	3	\N	Սահակյան Մայիս	95008652	93630280		Առաքելյան Անգին	077 99-25-50				\N	\N
325	Բերքաշատի մ/դ	8	3	գ. Բերքաշատ	40.0411879999999982	43.9052879999999988	3	2	Էդիսոն Թորոսյան	55692762			Լյուդվիգ-նոր օպերատոր	77151588				1	\N
326	Նորակերտ մ/դ	8	3	գ. Նորակերտ	40.1889040000000008	44.3450940000000031	3	2	Վեզիրյան	23161081	44148898			93194565				6	\N
299	Երնջատափի մ/դ	3	1	գ. Երնջատափ	\N	\N	3	\N	Մկրտչյան Արամ	93396314	95006374		Արա	094 82-62-73				\N	\N
315	Զանգակատան մ/դ	8	2	գ. Զանգակատուն	\N	\N	3	\N	Հովհաննիսյան Թամարա	95005727	93892813		Ժիրայր Դանիելյան նոր օպերատոր	098 13-29-77				5	13
313	Արարատի թիվ 3 մ/դ	8	2	գ. Արարատ, Խնկո Ապոր փողոց 43	\N	\N	3	\N	Բալայան Բենիամին	95005734	93401005		Աննա Մարության	93261023				\N	\N
318	Պ. Սևակի մ/դ	8	2	գ. Պ. Սևակ	\N	\N	3	\N	Զաքոյան Արամայիս	95005145	93568310		Տաթևիկ Սահակյան	77130626				\N	\N
309	Բարձրաշենի մ/դ	3	2	գ. Բարձրաշեն	\N	\N	3	\N	Թովմասյան Գոհար	95008661	93766486		Լուսինե Թադևոսյան	93760482				1	3
293	Օշականի 9-ամյա մ/դ	8	1	գ. Օշական	\N	\N	3	2	Սարգիս Հովնանյան	077338338			Մերի Զոհրաբյան	091055253				2	3
331	Շահումյանի մ/դ	8	3	գ. Շահումյան	40.2133090000000024	44.3001580000000033	3	2	Հ. Մանուկյան	93538456			Բաղդասարյան Հակուշիկ	98294066	95802423			1	\N
333	Դաշտի մ/դ	8	3	գ. Դաշտ	40.2264470000000003	44.2990939999999966	3	2	Սուսաննա Նազարյան	77303020			Նազելի Հարությունյան	94225784	93479231			2	\N
334	Մերձավանի մ/դ	8	3	գ. Մերձավան	40.1817939999999965	44.403024000000002	3	2	Մարտիրոսյան Վ.	93518380			Մարտիրոսյան Նոնա	94180108				1	\N
335	Ախպրաձորի մ/դ	8	4	գ. Ախպրաձոր	\N	\N	3	\N	Ղուկասյան Գինեվարդ	95007489	93646340		Ղուկասյան Նժդեհ	91077064				\N	\N
336	Գեղաքարի հմ/դ	8	4	գ. Գեղաքար	\N	\N	3	\N	Աթայան Թագուհի	95007485	93309702							\N	\N
337	Լճավանի մ/դ	8	4	գ. Լճավան	\N	\N	3	\N	Գեվորգյան Նորիկ	95007487	93593239		Մելքոնյան Նարինե	77791506				\N	\N
338	Ծովակի մ/դ	8	4	գ. Ծովակ	\N	\N	3	\N	Հարությունյան Ռուզաննա	95007491	93133363		Սարգսյան Էդիտա	77894891				\N	\N
339	Կարճաղբյուրի մ/դ	8	4	գ. Կարճաղբյուր	\N	\N	3	\N	Գրիգորյան Աֆտանդիլ	95007492	94520502		Հարությունյան Անահիտ	95404949				\N	\N
340	Մաքենիսի մ/դ	8	4	գ. Մաքենիս	\N	\N	3	\N	Մխիթարյան Ադամ	95007493	93866275		Մխիթարյան Մանե	77650568				\N	\N
342	Գավառի թիվ 1 հտ/դ	8	4	ք. Գավառ, Միքայելյան 33	\N	\N	3	\N	Զազյան Լարիսա	95008552	91146677		Խունոյան Աննա	99454616				\N	\N
343	Գեղարքունիքի մ/դ	8	4	գ. Գեղարքունիք	\N	\N	3	\N	Խաչատրյան Ջեմմա	95008553	94667172		Խաչատրյան Աշոտ	93041643				\N	\N
344	Արեգունիի մ/դ	8	4	գ. Արեգունի	\N	\N	3	\N	Վարդանյան Նորիկ	95007486	93232815		Բեգլարյան Մարտուն	94963697				\N	\N
345	Ծափաթաղի մ/դ	8	4	գ. Ծափաթաղ	\N	\N	3	\N	Հակոբյան Պարգև	94634874	077-88-79-00- բարկացած գյուղապետ							\N	\N
346	Մեծ Մասրիկի հմ/դ	8	4	գ. Մեծ Մասրիկ	\N	\N	3	\N	Հովհաննիսյան Նազիկ	95007582	98808780							\N	\N
347	Նորակերտի մ/դ	8	4	գ. Նորակերտ	\N	\N	3	\N	Շահինյան Բենիկ	95007536	93589494		Գալստյան Դավիթ	94728140				\N	\N
348	Շատվանի մ/դ	8	4	գ. Շատվան	\N	\N	3	\N	ԳԵվորգյան Ֆրունզիկ	95007528	93311230							\N	\N
349	Փամբակի մ/դ	8	4	գ. Փամբակ	\N	\N	3	\N	Թովմասյան Գարուն	95007539	098-23-39-38		Թովմասյան Մագդա	93921008				\N	\N
350	Լճափի մ/դ	8	4	գ. Լճափ	\N	\N	3	\N	Հովհաննիսյան Կառլեն	95009765	77100136		Հովհաննիսյան Արևիկ	93457564				\N	\N
352	Արծվանիստի մ/դ	8	4	գ. Արծվանիստ	\N	\N	3	\N	Մանուկյան Անդրանիկ	95006485	94251055		Խալաթյան Աստղիկ	99837333				\N	\N
353	Լեռնակերտի հմ/դ	8	4	գ. Լեռնակերտ	\N	\N	3	\N	Մխիթարյան Սպարտակ	95006484	94868907		Կարապետյան Արտակ	93503197				\N	\N
354	Ծովինարի մ/դ	8	4	գ. Ծովինար	\N	\N	3	\N	Սահակյան Միհրանուշ	95006483	93208990		Սահանույշ	093 57-67-65				\N	\N
356	Վարդենիկի թիվ 1 հմ/դ	8	4	գ. Վարդենիկ	\N	\N	3	\N	Ավետիսյան Ռաֆիկ	95006481	93392908		Բաղոյան Աննա	93845184				\N	\N
357	Վարդենիկի կրթահամալիր	8	4	գ. Վարդենիկ	\N	\N	3	\N	Բադալյան Կամո	95006479	91550444		Պողոսյան Ավետիկ	94069555				\N	\N
358	Գեղհովիտի թիվ 1 մ/դ	8	4	գ. Գեղհովիտ	\N	\N	3	\N	Աղջոյան Բաբկեն	95009294	94219595		Պողոսյան Ռադմիլա	94867528				\N	\N
359	Գեղհովիտի թիվ 2 մ/դ	8	4	գ. Գեղհովիտ	\N	\N	3	\N	Սաֆարյան Մանվել	95009293	93330016		Պետրոսյան Գեղամ	77359003				\N	\N
360	Ծակքարի մ/դ	8	4	գ. Ծակքար	\N	\N	3	\N	Մանուկյան Ռոբերտ	95008548	94217046		Մանուկյան Հրայր	93837340				\N	\N
361	Ծովասարի Մուրադյանի անվան մ/դ	8	4	գ. Ծովասար	\N	\N	3	\N	Վարդանյան Նաիրի	95008574	98610724		Ալեքսանյան Սամվել	94669383				\N	\N
362	Մադինայի մ/դ 	8	4	գ. Մադինա	\N	\N	3	\N	Կարապետյան	93503197			Մխիթարյան Վարազդատ	94397616				\N	\N
410	Մարցի մ/դ	8	6	գ. Մարց	\N	\N	3	\N	Ռուդիկ Ափիցարյան	93625701								1	3
329	Արգինայի մ/դ	8	3	գ. Արգինա	40.2733709999999974	43.7347520000000003	3	2	Արտավազդ Գրիգորյան	93325590			Էլմիրա Մխիթարյան	94593335				2	5
330	Քարակերտի թիվ 1 մ/դ	8	3	գ. Քարակերտ	40.2478399999999965	43.8170209999999969	3	2	Թամարա Բաղդասարյան	93805383			Մասրիամ Նիկողոսյան	077618157				0	15
341	Նորաբակի մ/դ	8	4	գ. Նորաբակ	\N	\N	3	\N	Մկրտչյան Ժիրայր	77454002	95007523		Հակոբքոխքյան Ա.	93701035				3	4
363	Ն. Գետաշենի թիվ 1 մ/դ	8	4	գ. Ն. Գետաշեն	\N	\N	3	\N	Երեմյան Ջուլետա	95008578	91962909		Թևոսյան Հովհաննես	99045859				\N	\N
351	Աստղաձորի մ/դ	8	4	գ. Աստղաձոր	\N	\N	3	\N	Սիրեկանյան Ջիվան	95006486	93668410		Մուշեղյան Սևակ	93300183				\N	\N
364	Վ. Գետաշենի թիվ 1 մ/դ	8	4	գ. Վ. Գետաշեն	\N	\N	3	\N	Գասպարյան Վալոդյա	95008579	94234067		Դավթյան Գյուլփարի	77632735				\N	\N
327	Բագարանի մ/դ	8	3	գ.Բագարան	40.1420320000000004	43.6580680000000001	3	5	Գեղեցիկ Ավետիսյան	98798098			Արաքսյա	77587858				2	4
328	Երվանդաշատի մ/դ	8	3	գ. Երվանդաշատ	40.1213880000000032	43.6708830000000034	3	5	Մարիամ Հովհաննիսյան	93184200			Լիանա Ավագյան	94071317				3	3
366	Հայրավանքի մ/դ	8	4	գ. Հայրավանք	\N	\N	3	\N	Համբարձումյան Սարգիս	95006498	94550348		Սուսաննա Պետրոսյան	94471720				\N	\N
369	Գեղամավանի մ/դ	8	4	գ. Գեղամավան	\N	\N	3	\N	Գրիգորյան Շամամ	95007376	77631203		Ստեփանյան Գայանե	0261/61044				\N	\N
370	Ծովագյուղի մ/դ	8	4	գ. Ծովագյուղ	\N	\N	3	\N	Նավասարդյան Ֆիրդուսի	95007375	94218759		Մինասյան Նինա	93245377				\N	\N
371	Նորաշենի հմ/դ	8	4	գ. Նորաշեն	\N	\N	3	\N	Կիրակոսյան Աբել	95007412	77035356							\N	\N
372	Չկալովկայի մ/դ	8	4	գ. Չկալովկա	\N	\N	3	\N	Միրաքյան Նաիրա	95007398	93061676		Մելքոնյան Արփինե	98295137				\N	\N
373	Սեմյոնովկայի հմ/դ	8	4	գ. Սեմյոնովկա	\N	\N	3	\N	Սարգսյան Վարդանուշ	95007397	93262531							\N	\N
374	Գագարինի մ/դ	8	4	գ. Գագարին	\N	\N	3	\N	Աբրահամյան Սամվել	95007396	93331607		Համբարձումյան Նորայր	98650936				\N	\N
375	Շորժայի մ/դ	8	4	գ. Շորժա	\N	\N	3	\N	Մուրադյան Արամ	94830796			Մելքումյան Ջեմմա զբաղվում է ինետով	93107083	93072766			\N	\N
376	Ջիլի մ/դ	8	4	գ. Ջիլ	\N	\N	3	\N	Ստեփանյան պարզել համարը	95007483			Սիմոնյան Աննա	0265/61602				\N	\N
377	Վահանի մ/դ	8	4	գ.Վահան	\N	\N	3	\N	Մարտիրոսյան	95007484	77740084		մարիամ	95211431				\N	\N
382	Արտանիշի մ/դ	8	4	գ. Արտանիշ	\N	\N	3	\N	Մարգարյան Արայիկ	95007469	55814749		Աղաջանյան Մարինե	94787817				\N	\N
383	Գետիկի մ/դ	8	4	գ. Գետիկ	\N	\N	3	\N	Ղավալյան Հակոբ	95007389	94830887		Ղալեչյան Անահիտ	098 81-21-94				\N	\N
384	Դպրաբակի մ/դ	8	4	գ. Դպրաբակ	\N	\N	3	\N	Խնդկարյան Անթառամ	95007387	94007179		Խոնդկարյան Աշոտ	93098138				\N	\N
385	Դրախտիկի մ/դ	8	4	գ. Դրախտիկ	\N	\N	3	\N	Բաբացյոխյան Նազիկ		94757556		Խաչատրյան Նատալյա օպերատոր	77431142				\N	\N
386	Մարտունիի մ/դ	8	4	գ. Մարտունի	\N	\N	3	\N	Խաչատրյան Արամայիս	94702856			Երիցյան Ալվինա	93609243				\N	\N
387	Լերմոնտովոյի մ/դ	8	6	գ. Լերմոնտովո	\N	\N	3	\N	Հովսեփյան Վ.	91953294			Լիլիթ Վանեսյան	77822745				\N	\N
388	Գուգարքի թիվ 1 մ/դ	8	6	գ. Գուգարք	\N	\N	3	\N	Հարությունյան Թաթուլ	93850780	99850780	322522893	Սիրուշ Մելիքսեթյան	98772363				\N	\N
389	Գուգարքի թիվ 2 մ/դ	8	6	գ. Գուգարք	\N	\N	3	\N	Մացակյան Սամվել	93050240			Ավագյան Հայարփի		95007238	98307050		\N	\N
390	Ազնվաձորի մ/դ	8	6	գ. Ազնվաձոր	\N	\N	3	\N	Շահնազարյան Սեյրան	93246498	95007237		Լիլիթ Խառատյան	093 69-15-65				\N	\N
391	Դեբեդի մ/դ	8	6	գ. Դեբեդ	\N	\N	3	\N	Զավեն Խաչատրյան	93502019			Արփինե Քարհանյան	93627204				\N	\N
393	Լեռնապատի մ/դ	8	6	գ. Լեռնապատ	\N	\N	3	\N	Աիդա Սարուխանյան	93728294			Վարդուհի Պետրոսյան	93698580				\N	\N
394	Մարգահովիտի մ/դ	8	6	գ. Մարգահովիտ	\N	\N	3	\N	Անտինյան Ս.	91070505			Ալվարդ	91551926				\N	\N
395	Վահագնիի մ/դ	8	6	գ. Վահագնի	\N	\N	3	\N	Ներսեսյան Աղունիկ	93303829								\N	\N
398	Ձորագյուղի հմ/դ	8	6	գ. Ձորագյուղ	\N	\N	3	\N	Գրիգորյան Ալվարդ		93130026	95007285						\N	\N
399	Ձորագետի հմ/դ	8	6	գ. Ձորագետ	\N	\N	3	\N	Էլմիրա Եգանյան	93447537								\N	\N
400	Փամբակի հմ/դ	8	6	գ. Փամբակ	\N	\N	3	\N	Դավիթ Բեգլարյան	99852270			Ալբերտ Ուլիխանյան	99111571				\N	\N
401	Օձունի թիվ 1 մ/դ	8	6	գ. Օձուն	\N	\N	3	\N	Աղիկյան Ա	91755867			Դավիթաղյան Գրետա	91761040				\N	\N
402	Օձունի թիվ 2 մ/դ	8	6	գ. Օձուն	\N	\N	3	\N	Թամազյան Աղաբեկ	91682293			Հասմիկ	93172447				\N	\N
406	Լորուտի մ/դ	8	6	գ. Լորուտ	\N	\N	3	\N	Սարգսյան Դավիթ		93848262							\N	\N
407	Աքորիի մ/դ	8	6	գ. Աքորի	\N	\N	3	\N	Կիմիկ Պետրոսյան	91789939			Խլոպուզյան Ալլա	99866146				\N	\N
409	Մեծ Այրումի մ/դ	8	6	գ. Մեծ Այրում	\N	\N	3	\N	Այվազյան Ս.	94346572								\N	\N
404	Շնողի մ/դ	3	6	գ. Շնող	\N	\N	3	\N	Ավետյան Գ.	91791174			Լիլիթ Ներկարարյան	93466565				\N	\N
408	Արևածագի մ/դ	8	6	գ. Արևածագ	\N	\N	3	\N	Ա. Երիցյան	55803410								5	7
397	Անտառամուտի հմ/դ	8	6	գ. Անտառամուտ	\N	\N	3	\N	Գևորգյան Աշոտ	95007262	091772216							3	3
392	Եղեգնուտի մ/դ	8	6	գ. Եղեգնուտ	\N	\N	3	\N	Համբարձումյան Հովիկ	93622260			Քարհանյան Արփիկ	95451743		93451743		3	4
403	Դսեղի մ/դ	8	6	գ. Դսեղ	\N	\N	3	\N	Շեկոյան Էդուարդ	93045514			Նարինե Ափիդարյան	77529283				2	20
378	Ճամբարակի թիվ 4 մ/դ	8	4	ք. Ճամբարակ, Ա. Խաչատրյան 1	\N	\N	3	\N	Գաբրիելյան Հասմիկ	95007471	98023373		Ստեփանյան Վարդան	93981871				\N	\N
379	Ճամբարակի թիվ 1 հմ/դ	8	4	ք. Ճամբարակ, Պ. Սևակի 1	\N	\N	3	\N	Սարգսյան Լյովա	95007468	77223112		Գալստյան Անուշ	77422015				\N	\N
380	Ճամբարակի ա/դ	8	4	ք. Ճամբարակ, Ե. Չարենցի փ.	\N	\N	3	\N	Մկրտչյան Արմինե	95007465	77222365		Ստեփանյան Աիդա	93824635				\N	\N
367	Սևանի թիվ 3 հմ/դ	8	4	ք. Սևան, Կարեն Դեմիրճյան 21	\N	\N	3	\N	Հովհաննիսյան Լուսինե	95007381	91428803		Ղարիբյան Նունե	99134168	0261 2-64-27			\N	\N
368	Սևանի պետական քոլեջ	8	4	ք. Սևան, Նաիրյան 1-ին նրբ. 14	\N	\N	3	\N	Գեվորգյան Ռուբիկ	95007378	94347035							\N	\N
381	Անտառամեջի մ/դ	8	4	գ. Անտառամեջ	\N	\N	3	\N	Ազարյան Արթուր	94018383	96018383							\N	\N
412	Շամուտի հմ/դ	8	6	գ. Շամուտ	\N	\N	3	\N	Արարատ	94728342								\N	\N
413	Հագվու հմ/դ	8	6	գ. Հագվի	\N	\N	3	\N	Մայիլյան Սուրեն	55701129			Վաղանուշ Սահակյան	98452830				\N	\N
418	Թեղուտի մ/դ	8	6	գ. Թեղուտ	\N	\N	3	\N	Վառլեն Բաբայան	94029595			Նատալյա Մելիքսեթյան	98013307				\N	\N
419	Քարկոփի մ/դ	8	6	գ. Քարկոփ	\N	\N	3	\N	Ղումաշյան Ղ.	91761577			Լուսինե Ղազարյան	77603826				\N	\N
420	Հաղպատի մ/դ	8	6	գ. Հաղպատ	\N	\N	3	\N	Ադամյան Հասմիկ	93915598			Մարինե Վարության					\N	\N
421	Կաճաճկուտի հմ/դ	8	6	գ.Կաճաճկուտ	\N	\N	3	\N	Ղարիբ Պողոսյան	91619053								\N	\N
422	Շամլուղի հմ/դ	8	6	գ. Շամլուղ	\N	\N	3	\N	Սոխակյան Հովհաննես	93141155			Տաթևիկ Մարգարյան	93603131				\N	\N
423	Նեղոցի հմ/դ	8	6	գ. Նեղոց	\N	\N	3	\N	Սոսինյան Արևիկ	55305828			Մարգո Մուրադյան	93613853				\N	\N
424	Չկալովի հմ/դ	8	6	գ. Չկալով	\N	\N	3	\N	Աթաբեկյան Գագիկ	55323200			Պարանյան Խաչատուր	98542566				\N	\N
426	Սպիտակի հտ/դ	8	6	ք. Սպիտակ, Խնկոյան փ.	\N	\N	3	\N	Դավթյան Մ.	95344861	95007663		Հայկուհի Հակոբյան, Այդա-հաշվապահ	91345596	55619701			\N	\N
427	Ջրաշենի մ/դ	8	6	գ. Ջրաշեն	\N	\N	3	\N	Մխիթարյան Վ.	94484842								\N	\N
428	Արևաշողի մ/դ	8	6	գ. Արևաշող	\N	\N	3	\N	Թ. Գրիգորյան	93359868			Նաիռա Խաչատրյան	93792318				\N	\N
429	Շիրակամուտի թիվ 1 մ/դ	8	6	գ. Շիրակամուտ	\N	\N	3	\N	Ա. Կյուրեղյան	95007185	093-14-97-79		Հասմիկ Մազմանյան	094 14-97-79				\N	\N
430	Շիրակամուտի հմ/դ	8	6	գ. Շիրակամուտ	\N	\N	3	\N	Ահարոն Նալբանդյան	093 39-75-15								\N	\N
431	Լեռնավանի մ/դ	8	6	գ. Լեռնավան	\N	\N	3	\N	Պայծառ Վարդանյան	93328857			Նաիրա Ավետիսյան	93504055				\N	\N
432	Ծաղկաբերի մ/դ	8	6	գ. Ծաղկաբեր	\N	\N	3	\N	Սարգսյան Ս.	93112050			Գրետա Օհանջանյան	94951432				\N	\N
435	Սարամեջի մ/դ	8	6	գ. Սարամեջ	\N	\N	3	\N	Մալխասյան Լ.	93815947								\N	\N
437	Լուսաղբյուրի մ/դ	8	6	գ. Լուսաղբյուր	\N	\N	3	\N	Քոչարյան Ս.	99161633								\N	\N
439	Ղուրսալու մ/դ	8	6	գ.Ղուրսալի	\N	\N	3	\N	Միքայելյան Խաչատուր	93539733								\N	\N
444	Սարալանջի հմ/դ	8	6	գ. Սարալանջ	\N	\N	3	\N	Թամարա Աֆյան	98128120			Նաիրա Սարոյան	93070391				\N	\N
445	Կաթնաղբյուրի մ/դ	8	6	գ. Կաթնաղբյուր	\N	\N	3	\N	Ավթալյան Ալմաստ	93024978			Սարգսյան Հասմիկ	91077207				\N	\N
447	Սարչապետի մ/դ	8	6	գ. Սարչապետ	\N	\N	3	\N	Դավթյան Համլետ	93201026	0254 6-02-06							\N	\N
449	Արծնիի մ/դ	8	6	գ. Արծնի	\N	\N	3	\N	Ռոստոմյան Մարիետա	93676945	95007127							\N	\N
450	Պետրովկայի մ/դ	8	6	գ. Պետրովկա	\N	\N	3	\N	Փնջոյան Արամայիս		93052644							\N	\N
451	Աթանի հմ/դ	8	6	գ. Աթան	\N	\N	3	\N	Ա. Մարաքյան	93602428			Մարության Գայանե	93419307				\N	\N
454	Ալափարսի մ/դ	8	7	գ. Ալափարս	\N	\N	3	\N	Կակոյան Վրամ	93574083								\N	\N
455	Աղավնաձորի մ/դ	8	7	գ. Աղավնաձոր	\N	\N	3	\N	Աղամալյան Ռուդիկ	93266875								\N	\N
456	Արզականի մ/դ	8	7	գ. Արզական	\N	\N	3	\N	Հակոբյան Սամվել	91234201			Խաչատրյան Արփինե	93939205				\N	\N
457	Արտավազի մ/դ	8	7	գ. Արտավազ	\N	\N	3	\N	Կոնջոռյան Բորիկ	93707749			Հովհաննիսյան Գոհար	77395229				\N	\N
438	Նոր Խաչակապի մ/դ	3	6	գ. Նոր Խաչակապ	\N	\N	3	\N	Սիմոնյան Ս.	93393194								\N	\N
433	Գեղասարի մ/դ	3	6	գ. Գեղասար	\N	\N	3	\N	Ղովասյան Ղ.	94908047								\N	\N
414	Ծաթերի հմ/դ	8	6	գ. Ծաթեր	\N	\N	3	\N	Աննա Դավթյան	91199207			Ավետյան Մանե	094047953				1	6
417	Արդվու հմ/դ	8	6	գ. Արդվի	\N	\N	3	\N	Սեյրան Այդինյան	93337756			Ռուզան Կոստանդյան	99003626				\N	\N
434	Սարահարթի մ/դ	3	6	գ. Սարահարթ	\N	\N	3	\N	Խումարյան Ռուդիկ	93054360			Արմենուհի	0255 60401				6	14
416	Այգեհատի հմ/դ	3	6	գ. Այգեհատ	\N	\N	3	\N	Պ. Շահվերդյան	93437210			Արմինե Թանթուշյան	55047744				\N	\N
443	Խնկոյանի հմ/դ	3	6	գ. Խնկոյան	\N	\N	3	\N	Խանում Կարապետյան	77418415			Վ. Կարապետյան	93164134				\N	\N
441	Քարաձորի մ/դ	8	6	գ. Քարաձոր	\N	\N	3	\N	Ջուլհակյան Հ.	93064249			Գարիկ Հակոբյան	98102560				\N	\N
415	Մղարթի հմ/դ	8	6	գ. Մղարթ	\N	\N	3	\N	Մոսինյան Աղաբեկ	93020883			Ղազարյան Մելիք	093500791				1	3
411	Քարինջի մ/դ	8	6	գ. Քարինջ	\N	\N	3	\N	Արամ եղինյան	0253 60410	77734232		Շահնզարյան լիյա	094843771				3	6
440	Լեռնանցքի մ/դ	8	6	գ. Լեռնանցք	\N	\N	3	\N	Ավագյան Արամ	93388656			Թամարա Թումանյան	096432220				10	13
442	Շենավանի հմ/դ	8	6	գ. Շենավան	\N	\N	3	\N	Ղազարյան Ֆլորա	99115590			Ղալեչյան Քրիստինե	077712808				1	3
425	Ախթալայի թիվ 2 մ/դ	8	6	ք. Ախթալա, Ախթ. թիվ 2 մ/դ	\N	\N	3	\N	Շուշանիկ Հոբոսյան	55101232								\N	\N
446	Միխայլովկայի մ/դ	8	6	գ. Միխայլովկա	\N	\N	3	\N	Ռաֆաելյան Գայանե	93523237			Աբրահամյան Մարինե	077329297				2	4
458	Լեռնանիստի մ/դ	8	7	գ. Լեռնանիստ	\N	\N	3	\N	Հայրապետյան Հայկ	91112936	22328593	95002884						\N	\N
460	Փյունիկի մ/դ	8	7	գ. Փյունիկ	\N	\N	3	\N	Մարաբյան Գագիկ	93137806	22394118							\N	\N
463	Արագյուղի «Տիգրանակերտ» վարժարան	8	7	գ. Արագյուղ	40.4007170000000002	44.5474359999999976	3	2	Ա. Պետրոսյան	98990403			Վ. Ամիրխանյան	94729996				\N	\N
464	Բուժականի մ/դ	8	7	գ. Բուժական	40.4478170000000006	44.5206689999999981	3	2	Մուրադյան Գևորգ	93336159			Հայկ Եգլարյան	093087587 սխալ է				\N	\N
467	Նոր Երզնկայի մ/դ	8	7	գ. Նոր Երզնկա	40.3001580000000033	44.3923419999999993	3	2	Մեսրոպյան Երազիկ	91282944			Արաքսյա Քանանյան	77307408				\N	\N
468	Քանաքեռավանի «Փոքր Մհեր» վարժարան	8	7	գ. Քանաքեռավան	40.2350190000000012	44.5290719999999993	3	2	Մուրադյան Արա	91358928	95003978		Նազիկ					\N	\N
469	Քասախի թիվ 1 մ/դ	8	7	գ. Քասախ	40.2339750000000009	44.4508439999999965	3	1	Գ. Մկրտչյան	94743333			Լիլիթ Եսայան	95003971	91748347			\N	\N
470	Քարաշամբի մ/դ	8	7	գ. Քարաշամբ	\N	\N	3	\N	Հ. Օսիպյան	91061056			Լևոնյան Թամարա	91799982				\N	\N
471	Սարալանջի հմ/դ	8	7	գ. Սարալանջ	40.398887000000002	44.5254019999999997	3	2	Բարսեղյան Թադևոս	91242240			Լաուրա	94969245				\N	\N
475	Գառնիի թիվ 1 հմ/դ	8	7	գ. Գառնի	40.1221940000000004	44.7329620000000006	3	2	Մարգարյան Ա.	93048481			Ս. Օհանյան	55517783				\N	\N
476	Գառնի բանավանի հմ/դ	8	7	գ. Գառնի, Բանավան	40.1080889999999997	44.6817220000000006	3	2	Գասպարյան Ա.	91512893			Հովհաննիսյան Թագուհի	55878427				\N	\N
478	Գեղադիրի մ/դ	8	7	գ. Գեղադիր	40.1525669999999977	44.655307999999998	3	2	Ավետիսյան Զավեն	93846337								\N	\N
479	Գեղարդի մ/դ	8	7	գ. Գեղարդ	40.1570859999999996	44.7981830000000016	3	2	Տարոյան Վիգեն	93753299			Ալեքսանյան Արմենուհի	77763010				\N	\N
480	Գողթի մ/դ	8	7	գ. Գողթ	40.1388490000000004	44.7866110000000006	3	2	Հ. Հովսեփյան	94466357			Նարինե Գաբրիելյան	93912750				\N	\N
481	Զառի մ/դ	8	7	գ. Զառ	\N	\N	3	\N	Խաչատրյան Հ.	94504971			Աբրահամյան Նվարդ	93801882				\N	\N
482	Զովաշենի հմ/դ	8	7	գ. Զովաշեն	\N	\N	3	\N	Եփրեմյան Ռիմա	22220637	94682896		Հ. Խաչատրյան	55212711				\N	\N
483	Կաթնաղբյուրի հմ/դ	8	7	գ. Կաթնաղբյուր	\N	\N	3	\N	Դանիելյան Գ.	93882451			Հասմիկ Հակոբյան	93656480				\N	\N
484	Կամարիսի մ/դ	8	7	գ. Կամարիս	\N	\N	3	\N	Արամայիս Ենոքյան	91458366			Կարիեն Սարգսյան	93763885				\N	\N
485	Կապուտանի մ/դ	8	7	գ. Կապուտան	\N	\N	3	\N	Հովհաննիսյան Սամվել	22260037	93896692		Սաֆարյան Սոնա	98036601				\N	\N
486	Հացավանի մ/դ	8	7	գ. Հացավան	40.1402080000000012	44.6543690000000026	3	2	Ս. Սահակյան	93582623			Մ. Հովհաննիսյան	99096445				\N	\N
487	Նոր Գյուղի մ/դ	8	7	գ. Նոր Գյուղ	\N	\N	3	\N	Հովհաննիսյան Ս.	93356686			Ս. Առուշանյան	93550083				\N	\N
488	Նուռնուսի մ/դ	8	7	գ. Նուռնուս	\N	\N	3	\N	Դ. Կարապետյան	77903600								\N	\N
490	Պտղնիի մ/դ	8	7	գ. Պտղնի	40.2532080000000008	44.5807640000000021	3	1	Արզումանյան Հասմիկ	94228853			Իրինա Արզումանյան	93777244				\N	\N
491	Գետարգելի հմ/դ	8	7	գ. Գետարգել	40.2450749999999999	44.5988150000000019	3	2	Տասալյան Արեգնազ	91738044			Գրիգորյան Սուսաննա	61434				\N	\N
492	Սևաբերդի մ/դ	8	7	գ. Սևաբերդ	\N	\N	3	\N	Զախարյան Վ.	779888901			Արսեն Զաքարյան	77135651				\N	\N
495	Գյումրիի թիվ 1 վարժարան	8	8	ք. Աբովյան, Սարալանջ	\N	\N	3	\N	Ս. Օհանյան	93269331			Լիլիթ Պետրոսյան	77433400				\N	\N
497	Գյումրիի թիվ 3 վարժարան	8	8	ք. Եղվարդ, Երևանյան 7	40.3085060000000013	44.4763420000000025	3	1	Հայկանուշ Հովհաննիսյան	93722969			Գևորգյան Կարմեն	98360909				\N	\N
538	Պեմզաշենի մ/դ	8	8	գ. Քանաքեռավան	40.246259000000002	44.531210999999999	3	2	Կարապետյան Գոհար	91367011								\N	\N
494	Գյումրու թիվ 41 մ/դ	8	8	 ք. Գյումրի, Ե. Չարենցի 4	\N	\N	3	\N	Աթոյան Անահիտ 	 094800991			Արմինե Միքայելյան	094927210		13		13	\N
459	Մարմարիկի մ/դ	8	7	գ. Մարմարիկ	\N	\N	3	\N	Արզումանյան Նոննա	093949565			Կիրակոսյան Սուսաննա	77992477				2	6
462	Արգելի մ/դ	8	7	գ.Արգել	\N	\N	3	\N	Մեսրոպյան Կարինե	093991033			1. Նաիրա Հարությունյան, 2. Անուշիկ Փիլիպոսյան	093149403	094370984			6	10
496	Գյումրու պետական տեխնիկական քոլեջ ՊՈԱԿ	8	8	ք. Գյումրի, Տիգրան Մեծ 29ա	\N	\N	3	\N	Սարգսյան Մխիթար 	93729489			Գայանե Ավետիսյան 	094845148				\N	\N
465	Գետամեջի մ/դ	8	7	գ. Գետամեջ	\N	\N	3	\N	Գեղամյան Լիանա	099103118			Սարգսյան Ալվարդ	077105137				3	8
461	Եղվարդի «Նաիրի» արհեստագործական պետ. ուսումնարան	8	7	ք. Եղվարդ, Երևանյան փող., շ. 10	40.3066079999999971	44.4752280000000013	3	1	Կարիեն Մեհրաբյան	94834504			Սրապիոնյան Նունե	77599476				\N	\N
466	Նոր Գեղիի թիվ 2 մ/դ	8	7	գ. Նոր Գեղի	\N	\N	3	\N	Ա. Հարությունյան	93885586			Ադրինե Տեր- Պողոսյան	93354548				\N	\N
489	Ողջաբերդի մ/դ	8	7	գ. Ողջաբերդ	40.1719220000000021	44.6433669999999978	3	2	Վ. Գրիգորյան	91060846			Լուսինե Հարությունյան	93480861				3	4
493	Վերին Պտղնիի մ/դ	3	7	գ. Վ. Պտղնի	40.249215999999997	44.5847320000000025	3	1	Հակոբյան Արսեն	99111168			Սիլվա Հակոբյան	93468464				\N	\N
473	Ակունքի մ/դ	8	7	գ. Ակունք	\N	\N	3	\N	Սարգսյան Իրինա	93975542			Սարգսյան Ս.	91909994				15	18
499	Լանջիկի մ/դ	8	8	գ. Բալահովիտ	\N	\N	3	\N	Խաչատրյան Թ.	91795657			Ե. Մնացականյան	93197115				\N	\N
500	Ձիթհանքովի մ/դ	8	8	գ. Գեղաշեն	\N	\N	3	\N	Նաիրա Բաբայան	98090608			Տերյան Արթուր	77090623				\N	\N
501	Ձորակապի մ/դ	8	8	գ. Զովք	40.2078920000000011	44.6935689999999965	3	2	Առաքելյան Շողիկ	77827015			Ավչյան Անահիտ	77904598				\N	\N
502	Ջրափիի մ/դ	8	8	գ. Կոտայք	\N	\N	3	\N	Վարդանյան Արա	55457916			Հռիփսիմե Թադևոսյան	55741929				\N	\N
503	Սարակապի մ/դ	8	8	ք. Աբովյան, Բարեկամության	\N	\N	3	\N	Ս. Հանիսյան	99865883			Լուսինե Սարգսյան	93614640	91614640			\N	\N
504	Քարաբերդի մ/դ	8	8	ք. Աբովյան, Տարտուի 1	\N	\N	3	\N	Հովհաննսիյան Սվետլաննա	91338222			Լիաննան Մանուկյան	91090696				\N	\N
505	Լուսաղբյուրի մ/դ	8	8	ք. Աբովյան, Ռոսիա 26	\N	\N	3	\N	Ն. Քեշիշյան	98036246			Կարինե	055 578582				\N	\N
506	Հայկաձորի մ/դ	8	8	ք. Աբովյան, Սարալանջ	\N	\N	3	\N	Վարդանյան Հովհաննես	93045002			Մարիետա Պողոսյան	077 23-90-91				\N	\N
507	Բենիամինի մ/դ	8	8	ք. Աբովյան, 2-րդ միկրոշրջ	\N	\N	3	\N	Գասպարյան Գոհար	77215191			աստղիկ	98004737				\N	\N
508	Լեռնուտի մ/դ	8	8	ք. Աբովյան, ուսանողական թ	\N	\N	3	\N	Դաղբալյան Ա.	99900433			Պողոսյան Մարիամ	55224416				\N	\N
509	Կրաշենի հմ/դ	8	8	գ. Մայակովսկի	\N	\N	3	\N	Տ. Ղազանչյան	93508347			Անի Պետրոսյան	93937573				\N	\N
510	Մեծ Սարիարի մ/դ	8	8	գ. Ջրաբեր	\N	\N	3	\N	Հայրապետյան Արամայիս	94459356			Մարիան Հակոբյան	95569523				\N	\N
511	Ոսկեհասկի մ/դ	8	8	ք. Բյուրեղավան	\N	\N	3	\N	Գալստյան Մարինա	22265180	93750401		Արթուր Ղազարյան					\N	\N
512	Ջաջուռ կայարանի տ/դ	8	8	ք. Բյուրեղավան	\N	\N	3	\N	Սարգսյան Մ.	99992105			Լիլիթ Գրիգորյան	93886694				\N	\N
513	Փոքրաշենի մ/դ	8	8	ք. Բյուրեղավան	\N	\N	3	\N	Խաչիկյան Կ.	94507225								\N	\N
515	Ալվարի մ/դ	8	8	գ. Սոլակ	\N	\N	3	\N	Դավթյան Լիդա	22325726	94200117		Արմինե Ասատրյան	77488477				\N	\N
516	Աղվորիկի հմ/դ	8	8	գ. Քաղսի	\N	\N	3	\N	Մելքոնյան Վաչագան	93651790								\N	\N
517	Արդենիսի մ/դ	8	8	գ. Ֆանտան	\N	\N	3	\N	Աբրահամյան Կարինե	77808810			Գայանե Կոստանդյան	94682505				\N	\N
518	Բերդաշենի մ/դ	8	8	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Շաբոյան Ժանետա	22363077	94247004		Սարդարյան Հասմիկ	94112216				\N	\N
521	Ծաղկուտի մ/դ	8	8	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Բավեյան Անդրանիկ	94910460	22363022		Խաչատրյան Գալինա	98921416				\N	\N
522	Շաղիկի հմ/դ	8	8	ք. Հրազդան, Ջրառատ թաղամա	\N	\N	3	\N	Ստեփանյան Սամվել	91333909	22326498		Աստղիկ Գալստյան	93174700				\N	\N
523	Ամասիայի մ/դ	8	8	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Հարությունյան Հասմիկ	22326404	93584210		Ալեքսանյան Արտյոմ	93157614				\N	\N
525	Բանդիվանի մ/դ	8	8	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Գրիգորյան Գևորգ	93268683	22325907		Ղուշչյան վարսենիկ	22325907				\N	\N
526	Գտաշենի մ/դ	8	8	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Զաքարյան Մելսիկ	22322851	94082299		Սահակյան Նաիրա	94400335				\N	\N
527	Զարիշատի հմ/դ	8	8	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Բարսեղյան Վլադիմիր	22333720	93805202		Դավթյան Արմենուհի	91171967				\N	\N
528	Հողմիկի մ/դ	8	8	ք. Հրազդան, Կաքավաձոր	\N	\N	3	\N	Հասմիկ Ասատրյան	22360645	93237697		Գոհար Միքայելյան	93681234				\N	\N
529	Հովտունի հմ/դ	8	8	գ. Կարենիս	\N	\N	3	\N	Խաչատրյան Նշան	22360012	93868429		Աբրահամյան Հասմիկ	94759878				\N	\N
530	Ջրաձորի մ/դ	8	8	ք. Չարենցավան, VI թաղ.	\N	\N	3	\N	Խաչատրյան Ալլա	22642355	93857985		Հայրապետյան Գայանե	77995429				\N	\N
531	Անուշավանի մ/դ	8	8	ք. Չարենցավան, V թաղ.	\N	\N	3	\N	Գասպարյան Անատոլի	91232319	22641652		Խաչատրյան Ռոզա	77496262				\N	\N
532	Լուսակերտի մ/դ	8	8	ք. Չարենցավան, II միկրոթա	\N	\N	3	\N	Փանոսյան Արմինե	93731336			Կիրակոսյան Անուշ	99604034				\N	\N
533	Հայկասարի հմ/դ	8	8	ք. Չարենցավան, I Ա թաղ.	\N	\N	3	\N	Փանոսյան Գայանե	94527885			Սարիբեկյան Տաթևիկ	94818642				\N	\N
534	Հայրենյացի մ/դ	8	8	ք. Չարենցավան, IV թաղ., շ	\N	\N	3	\N	Խանսամանյան Տիգրան	93599112			Հասմիկ Պարսամյան	93260947				\N	\N
535	Հոռոմի մ/դ	8	8	գ. Զորավան	40.3547190000000029	44.526921999999999	3	2	Հովհաննիսյան Հենրիետա	93973797			Շողիկ Սարգսյան	77502648				\N	\N
536	Հովտաշենի հմ/դ	8	8	ք. Նոր Հաճըն, Է.Տոռոզյանի	\N	\N	3	\N	Սիլվա Վանեսյան	93327762			Կիրակոսյան Մարինե	94968617				\N	\N
537	Մեղրաշենի մ/դ	8	8	գ. Մրգաշեն	\N	\N	3	\N	Գ. Գրիգորյան	93354408			Թևանյան Մանուշակ	93975776				\N	\N
520	Զորակերտի մ/դ	8	8	 գ.Զորակերտ	\N	\N	3	\N	Աղավնի Հովհաննիսյան	094093007			Մկրտիչ	94200065				1	2
498	Աղինի մ/դ	8	8	ք. Եղվարդ, Սաֆարյան 88	40.3211889999999968	44.4816819999999993	3	1	Էլբազյան խաչիկ	093839839			Պետրոսյան Պավել	077713849				1	5
524	Արեգնադեմի մ/դ	3	8	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Միքայելյան Գագիկ	22334556	77574575		Օհանյան Մարիամ	98777116				\N	\N
514	Բասենի մ/դ (Մուսայելյան)	8	8	գ. Բասեն	\N	\N	3	\N	Բեգլարյան Ալեքսան	91693749			Բեգլարյան Գուրգեն	95708092				\N	\N
539	Տուֆաշենի մ/դ	8	8	ք. Նոր Հաճըն, Է. Տոռոզյան	\N	\N	3	\N	Գարիկ Աբրահամյան	91942397			Արմինե Աղայան	99838858				\N	\N
541	Արևշատի մ/դ	8	8	գ. Թեղենիք	\N	\N	3	\N	Գրիգորյան Լաուրիկ	98106306			Տանյա Պողոսյան	98699332				\N	\N
543	Գետափի մ/դ	8	8	գ. Արզնի	\N	\N	3	\N	Սիմոնովնա Սոֆիա	91415344			Իրինա Ալեքսանյան	91238014				\N	\N
544	Հառիճի երեկոյան (Արթիկի երեկոյան դպրոց ) մ/դ	8	8	գ. Ձորաղբյուր, Լուսավորու	40.202058000000001	44.6466920000000016	3	2	Գաբրիելյան Ռայա	91202734			Անտոնյան Նարինե	95191565				\N	\N
547	Նահապետավանի մ/դ	8	8	գ. Բջնի	\N	\N	3	\N	Յաշա Սահակյան	91313131			Դավթյան Հայկ	93353851				\N	\N
548	Սարալանջի մ/դ	8	8	գ. Մեղրաձոր	\N	\N	3	\N	Հրաչ Սարգսյան	93121244			Արևիկ	94341491				\N	\N
549	Սպանդարյանի մ/դ	8	8	ք. Ծաղկաձոր, Մայիսյան 14	\N	\N	3	\N	Եգորյան Սուսաննա	22360255	77320108		Ռուզաննա Ավետիսյան	93386128				\N	\N
552	Արփենիի մ/դ	8	8	ք. Չարենցավան, Լենինի 22	\N	\N	3	\N	Կարապետյան Լուսինե	22644582	94426742		Ա. Հարությունյան	93808836				\N	\N
553	Գոգհովիտի մ/դ	8	8	գ. Զովունի	40.2350330000000014	44.5063109999999966	3	1	Ղազարյան Վարդան	94503544			Հասմիկ Սեղբոսյան	55064686				\N	\N
554	Զույգաղբյուրի մ/դ	8	8	գ. Նոր Արտամետ	\N	\N	3	\N	Մելքոն Կարապետյան	55921959			Սարգսյան Հայկանուշ	55332538				\N	\N
555	Թորոսգյուղի հմ/դ	8	8	գ. Նոր Գեղի, Ց. Խաչատրյան	\N	\N	3	\N	Բաբախանյան Ն.	93500279			Պապյան Հասմիկ	99232909				\N	\N
556	Հարթաշենի հմ/դ	8	8	գ. Պռոշյան	40.2470780000000019	44.4185719999999975	3	1	Մկրտչյան Աննա	93470824			Անահիտ Հակոբյան	93312655				\N	\N
558	Մուսայելյանի (Աշոցք) մ/դ	8	8	ք. Եղվարդ, Չարենցի փ.54	40.3147639999999967	44.4771610000000024	3	1	Սիմոնյան Ռազմիկ	93541207			Սիմոնյան Վարդգես	93800270				\N	\N
559	Ցողամարգի մ/դ	8	8	ք. Նոր Հաճըն, Չարենցի 20	\N	\N	3	\N	Ն. Վարդանյան	55959390			Մանուշակ Պողոսյան	98713893				\N	\N
560	Կաքավասարի հմ/դ	8	8	գ. Հատիս	\N	\N	3	\N		94116150								\N	\N
561	Աշոցքի մ/դ	8	8	գ. Աշոցք	\N	\N	3	\N	ավետիսյան սամվել	95008926	77757767		Կարինե Առուշանյան					\N	\N
562	Բավրայի մ/դ	8	8	գ. Բավրա	\N	\N	3	\N	Վարդանյան Արմեն	95008927	99077567		Անահիտ Մխիթարյան	95877567				\N	\N
563	Թավշուտի մ/դ	8	8	գ. Թավշուտ	\N	\N	3	\N	Սողոյան Ալեքսան	95008928	93945945		Արայիկ Շահբազյան	94322819				\N	\N
565	Կրասարի մ/դ	8	8	գ. Կրասար	\N	\N	3	\N	Առաքելյան Լյուդմիլա	95008952	94963513		Սամվել Ավետիսյան	95008952	77757767			\N	\N
566	Ղազանչիի մ/դ	8	8	գ. Ղազանչի	\N	\N	3	\N	խաչատրյան				Լիա Սարգսյան	77542372				\N	\N
567	Սարագյուղի հմ/դ	8	8	գ. Սարագյուղ	\N	\N	3	\N	Հակոբյան Գինեվարդ	95008953	55107039		Հակոբյան Գինեվարդ	55107039				\N	\N
568	Սիզավետի մ/դ	8	8	գ. Սիզավետ	\N	\N	3	\N	Վարդանյան Վարդանիկ	95008932	93067114		Քնարիկ Համբարյան	77761708				\N	\N
569	Փոքր Սեպասարի հմ/դ	8	8	գ. Փոքր Սեպասար	\N	\N	3	\N	Սարուխանյան Իսկուհի	95008954	99660776							\N	\N
570	Փոքր Սարիարի մ/դ	8	8	գ. Փոքր Սարիար	\N	\N	3	\N	Մխեյան Արմինե	95008956	94626771		Վռամ Հովհաննիսյան	93626771				\N	\N
571	Անի կայարանի մ/դ	8	8	գ. Անիավան (Անի կայարան)	\N	\N	3	\N	Արտյոմ Մինասյան	95009786	93339827		Հովսեփ Մխիթարյան	93443829				\N	\N
572	Բարձրաշենի հմ/դ	8	8	գ. Բարձրաշեն	\N	\N	3	\N										\N	\N
573	Սպանդարյանի մ/դ	8	9	գ. Սպանդարյան	\N	\N	3	\N	Գալստյան Գոհարիկ	77112600	95001643		Հերմինե Բեգլարյան	98685414				\N	\N
574	Բալաքի տարրական դպրոց	8	9	գ. Բալաք	\N	\N	3	\N	Պողոսյան Գայանե	93285764	95001948		Եղյան Սուսաննա	94288929				\N	\N
575	Մուցքի հմ/դ	8	9	գ. Մուցք	\N	\N	3	\N	Խուդավերդյան Գնել	95001945	98086465	55016465	Կիրակոսյան Աղունիկ	94324216				\N	\N
578	Արավուսի տարրական դպրոց	8	9	գ. Արավուս	\N	\N	3	\N	Ջհանգիրյան Նարինե	95001915	77982262							\N	\N
576	Քարաշենի մ/դ	8	9	գ. Քարաշեն	\N	\N	3	\N	Շեգունց Դ․	098595261	95001943		Բաղդասարյան Ռ․	098940333				\N	\N
545	Հառիճի մ/դ	3	8	գ. Ջրվեժ	40.1870750000000001	44.5920819999999978	3	1	Վարդանյան Լլիթ	91539228			Կոբալյան Հերմինե	99811224				\N	\N
542	Գեղանիստի մ/դ	3	8	գ. Առինջ	40.2310450000000017	44.5700720000000032	3	1	Կարինե Ղազարյան	93242346			Մանուշակ Երիցյան	77130579				3	9
551	Փոքր Մանթաշի մ/դ	3	8	ք. Հրազդան, Երևանյան 5	\N	\N	3	\N	Մովսիսյան Գոհար	91491496	22324215		Մկրտչյան Գրետա					\N	\N
546	Մեծ Մանթաշի մ/դ	8	8	ք. Աբովյան, Ս.Մնացականյան	\N	\N	3	\N	Սանդոյան Գոհար	094583484			Չաբյան Անահիտ	094351252				1	-12
540	Լեռնակերտի մ/դ	3	8	ք. Նոր Հաճըն, Շահումյան 1	\N	\N	3	\N	Պողոս Կիրակոսյան	093147676			Ասյա Հարությունյան 	095891011				8	10
550	Վարդաքարի մ/դ	8	8	3 փող, 4 շենք	\N	\N	3	\N	Սահակյան Նարինե	093072413			Մայիլյան Աննա	077616599				1	5
557	Ձորաշենի մ/դ	8	8	գ. Քասախ	40.2362830000000002	44.4575469999999981	3	1	Շաբոյան	091833242	094833242		Գևորգյան Անդրանիկ	94980111				\N	\N
579	Ներքին Խնձորեսկի մ/դ	8	9	գ. Ներքին Խնձորեսկ	\N	\N	3	\N	Գրիգորյան Անուշիկ	95001895	93812845		Դիլանյան Սամվել	93171282				\N	\N
582	Շամբի մ/դ	8	9	գ. Շամբ	\N	\N	3	\N	Զաքարյան Սամվել	95002512	93005958		Հովսեփյան Արուսյակ	98033210				\N	\N
584	Դարբասի մ/դ	8	9	գ. Դարբաս	\N	\N	3	\N	Օհանյան Վալերիկ	95002545	93260298		Կարմեն Գևորգյան	77100233				\N	\N
585	Լորի մ/դ	8	9	գ. Լոր	\N	\N	3	\N	Լիաննա Գրիգորյան	95002567	98780753		Գագիկ Աղաբեկյան	93540406				\N	\N
586	Շենաթաղի հմ/դ	8	9	գ. Շենաթաղ	\N	\N	3	\N	Զաքարյան Ռուբեն	95002273	93019731		Զաքարյան Լիաննա	93789122				\N	\N
587	Սվարանցի մ/դ	8	9	գ. Սվարանց	\N	\N	3	\N	Վարդանյան Նվերիկ	95004615	77587363							\N	\N
590	Շուռնուխի մ/դ	8	9	գ. Շուռնուխ	\N	\N	3	\N	Լալաբեկյան Ալբերտ	94631633	95004637		Ձանունց Դավիթ	98763076				\N	\N
594	Թասիկի հմ/դ	8	9	գ. Թասիկ	\N	\N	3	\N	Հարությունյան Հարություն	95002764	93019166		Հերմինե Դավթյան	94773707				\N	\N
595	Նժդեհ (Սոֆլուի) հմ/դ	8	9	գ. Նժդեհ (Սոֆլու)	\N	\N	3	\N	Ապրեսյան Սերոբ	95002757	93863433		Արթուր Գրիգորյան	93647214				\N	\N
596	Դաստակերտի մ/դ	8	9	գ. Դաստակերտ	\N	\N	3	\N	Ապրեսյան Սերոբ	93863433	95002697		Արթուր Գրիգորյան	93647214				\N	\N
597	Տորունիքի հմ/դ	8	9	գ. Տորունիք	\N	\N	3	\N	Էդգար Հովհաննիսյան	95002696	98585848							\N	\N
598	Ծավի մ/դ	8	9	գ. Ծավ	\N	\N	3	\N	Մարտիրոսյան Յ.	95001283	94148141		Մարգարիտա Գալստյան	94013070				\N	\N
599	Ներքին Հանդի հմ/դ	8	9	գ. Ներքին Հանդ	\N	\N	3	\N	Սողոմոնյան Դոնարա	95001286	77770977		Անուշ Ադամյան	93214591				\N	\N
600	Շիկահողի մ/դ	8	9	գ. Շիկահող	\N	\N	3	\N	Հասմիկ Ղազարյան	95001287	93941662		խաչատրյան Անահիտ	93182111				\N	\N
601	Ճակատենի հմ/դ	8	9	գ. Ճակատեն	\N	\N	3	\N	Բաբայան Եղիշե	95006218	93062138		Օսիպյան Լիանա	95006218	93852930			\N	\N
603	Եղվարդի մ/դ	8	9	գ. Եղվարդ	\N	\N	3	\N	Մանյա Գևորգյան	95006216	93165222		Նարինե Սահակյան	93491038				\N	\N
604	Վարդավանքի մ/դ	8	9	գ. Վարդավանք	\N	\N	3	\N	Համլետ Թորոսյան	95006215	94538225		Թորոսյան Վիլյամ	93959626				\N	\N
605	Կապանի թիվ 8 մ/դ	8	9	ք. Կապան, Շղարշիկ բանավան	\N	\N	3	\N	Գագիկ Հարությունյան	95006214	91370078		Անահիտ	93724093				\N	\N
608	Դավիթ Բեկի մ/դ	8	9	գ. Դավիթ Բեկ	\N	\N	3	\N	Գրիշա Գաբրիելյան	95006197	93177701		Բալայան Վրեժ	94161093				\N	\N
609	Նորաշենիկի մ/դ	8	9	գ. Նորաշենիկ	\N	\N	3	\N	Դավիթ Թումանյան	95006196	98299932		լիլիթ	98875302				\N	\N
610	Օխտարի մ/դ	8	9	գ. Օխտար	\N	\N	3	\N	Պողոսյան Ռաֆիկ	95006195	94208075		Առաքելյան Անահիտ	60860				\N	\N
611	Տավրուսի մ/դ	8	9	գ. Տավրոս	\N	\N	3	\N	Կամո Ավանեսյան	95006173	93135969		Սարգսյան	93573124				\N	\N
614	Տանձավերի մ/դ	8	9	գ. Տանձավեր	\N	\N	3	\N	Թումանյան Անժելա	28560607	95006185	93182728						\N	\N
615	Ձագեձորի մ/դ	8	9	գ. Ձագեձոր	\N	\N	3	\N	Ազարյան Լեռնիկ	95006184	77123167		Ծատրյան Յաննա	77010484				\N	\N
617	Քաջարանի թիվ 5 մ/դ	8	9	ք. Քաջարան, Բարիկավան	\N	\N	3	\N	Մկրտչյան Անուշ	95006182	98309022		Ավետիսյան Լիանա	94640043				\N	\N
618	Քաջարանի թիվ 6 հմ/դ	8	9	ք. Քաջարան, Անդոկավան թաղ	\N	\N	3	\N	Իվանյան Սամվել	93961575	95006173		Հասմիկ Հայրապետյան	94730976				\N	\N
620	Վարդանիձորի մ/դ	8	9	գ. Վարդանիձոր	\N	\N	3	\N	Քնարիկ Տեր-Խաչատրյան	95002462	98711985		Լ.Բեգլարյան	93991591				\N	\N
592	Աշոտավան	4	9	գ. Աշոտավան	\N	\N	3	\N	Օհանյան Հովսեփ	94815210			Կ. Մարգարյան	77993634	28395143			\N	\N
593	Հացավանի մ/դ	8	9	գ. Հացավան	\N	\N	3	\N	Ստեփանյան Արտակ	95002592	98006672	055558338	Լիլիթ Ասատրյան	98985737				4	5
589	Հալիձորի մ/դ	8	9	գ. Հալիձոր	\N	\N	3	\N	Շուշանիկ Գաբրիելյան	95004632	93200720		Արամ Աղաջանյան	93805636				2	11
613	Աղվանի հմ/դ	8	9	գ. Աղվան	\N	\N	3	\N	Մկրտչյան Մարգո	93194008			Սուքիասյան Վանուշ	77382128				1	1
607	Եղեգի մ/դ	8	9	գ. Եղեգ	\N	\N	3	\N	Մերի Գանդալյան	93049480	28560044		Սոսի Մարտիրոսյան					\N	\N
606	Աճանան (Խալաջ) մ/դ	8	9	գ. Աճանան (Խալաջ)	\N	\N	3	\N	Հովհաննիսյան Սոնա	95006213	77160477		Թամարա Միքայելյան	28554102	093500406			1	6
580	Որոտան գյուղ, հմ/դ (Գորիս)	8	9	Որոտան գյուղ	\N	\N	3	\N	Բարսամյան Անուշ	93148938	95001242		Քրիստինե Հարությունյան	55337725				\N	\N
581	Որոտանի մ/դ(Սիսիան)	8	9	գ. Որոտան	\N	\N	3	\N	Անուշ	93148938			Շուշան	77883089				2	3
619	Ագարակի հմ/դ (Կապան)	8	9	գ. Ագարակ	\N	\N	3	\N	Ավանեսյան Ռոզա	95006298		94334021	Սվետլաննա Խաչատրյան		93201795			\N	\N
616	Լեռնաձորի հմ/դ	3	9	գ. Լեռնաձոր	\N	\N	3	\N	Գրիգորյան Ծովինար	77131464	95006183		Շուշան Ներսիսիյան	98316851				\N	\N
583	Լծենի հմ/դ	8	9	գ. Լծեն	\N	\N	3	\N	Կարապետ Ամիրյան	95002537	97718506		Բունիաթյան Լուսինե	98402120				\N	\N
588	Տանձատափի հմ/դ	8	9	գ. Տանձատափ	\N	\N	3	\N	Աբրահամյան Վիլեն	94006411								2	3
602	Գեղանուշի մ/դ	8	9	գ. Գեղանուշ	\N	\N	3	\N	Գայանե Գրիգորյան	077768836		95006217	Կարինե Պողոսյան	93749084	028524487			3	10
621	Լիճքի մ/դ	8	9	գ. Լիճք	\N	\N	3	\N	Էսման Պողոսյան	95002469	94601361		Սեդիկ Հայրապետյան	77900820				\N	\N
622	Լեհվազի մ/դ	8	9	գ. Լեհվազ	\N	\N	3	\N	Վարդանյան Լ.	95002474	93627492		Մ.Խաչատրյան	94876254				\N	\N
623	Կարճևանի հմ/դ	8	9	գ. Կարճևան	\N	\N	3	\N	Պապյան Սվետլաննա	95002476	93512919	91613288	Ռ. Սարգսյան	93700979				\N	\N
625	Աղիտուի հմ/դ	8	9	գ. Աղիտու	\N	\N	3	\N	Բլբուլյան Սուրեն	95002685	93013790		Շահնազարյան Սուրեն	93004495				\N	\N
626	Ալվանքի մ/դ	8	9	գ. Ալվանք	\N	\N	3	\N	Վ.Սևումյան	91314449	95002426		Առաքելյան Ս.	98095895				\N	\N
627	Ագարակաձորի մ/դ	8	10	գ. Ագարակաձոր	\N	\N	3	\N	Հովհաննիսյան Նաիրա	95004658	93642031		Էվելինա Մանուկյան	91280128				\N	\N
628	Աղնջաձորի մ/դ	8	10	գ. Աղնջաձոր	\N	\N	3	\N	Հրաչյան Եդիգարյան	95004663	93832130		Նարինե Ստեփանյան	281201191				\N	\N
629	Արտաբույնքի մ/դ	8	10	գ. Արտաբույնք	\N	\N	3	\N	Բաբայան Մեսրոպ	95004669	96339704							\N	\N
630	Գետափի մ/դ	8	10	գ. Գետափ	\N	\N	3	\N	Քոչարյան Թ.	95004673	93539488		Վոլոդյա Մուրադյան	93200366				\N	\N
631	Գլաձորի մ/դ	8	10	գ. Գլաձոր	\N	\N	3	\N	Հայրապետյան Ա.	95004682	93885120		Մուրադյան Հայկուհի	93825672				\N	\N
632	Մոզրովի հմ/դ	8	10	գ. Մոզրով	\N	\N	3	\N	Ա. Մելքոնյան	95004692	93656092							\N	\N
633	Ելփինի մ/դ	8	10	գ. Ելփին	\N	\N	3	\N	Գևորգյան Ժորա	95004746	93224336		Մարկոսյան Գարիկ	93930824				\N	\N
634	Եղեգիսի մ/դ	8	10	գ. Եղեգիս	\N	\N	3	\N	Լևոն Թադևոսյան	77119399	95004748		Քնարիկ Բաբագուլյան	77635345				\N	\N
635	Թառաթումբի մ/դ	8	10	գ. Թառաթումբ	\N	\N	3	\N	Խաչատրյան Զոհրաբ	95004779	93327403		Էդվարդ Խաչատրյան	77118869				\N	\N
636	Հերմոնի հմ/դ	8	10	գ. Հերմոն	\N	\N	3	\N	Ժորա Խաչատրյան	95004814	94777009		Օվսաննա Վարդանյան	94167583				\N	\N
637	Հորբատեղի հմ/դ	8	10	գ. Հորբատեղ	\N	\N	3	\N	Միքայել Սարգսյան	95004884	99021737		Գևորգ Սարգսյան	96071737				\N	\N
639	Չիվայի մ/դ	8	10	գ. Չիվա	\N	\N	3	\N	Արսեն Ասատրյան	95004994	93565440		Հովիկ Դարբինյան	93851682				\N	\N
640	Ռինդի մ/դ	8	10	գ. Ռինդ	\N	\N	3	\N	Թադևոսյան Աշոտ	95005117	93827319		Սրբուհի Գրիգորյան	98800621				\N	\N
641	Սալլիի հմ/դ	8	10	գ. Սալլի	\N	\N	3	\N	Մհեր Հովակիմյան	95005119	93493626	28121056	Էմմա Մինասյան	28121087				\N	\N
642	Քարագլխի մ/դ	8	10	գ. Քարագլուխ	\N	\N	3	\N	Հովհաննիսյան Արման Սամսոնի	98884031			Մարինե Զաքարյան	77137715				\N	\N
643	Վարդահովիտի հմ/դ	8	10	գ. Վարդահովիտ	\N	\N	3	\N	Մարգարյան Գագիկ	95004657	93091551		Մարգարյան Մարի	91765616				\N	\N
644	Բարձրունիի մ/դ	8	10	գ. Բարձրունի	\N	\N	3	\N	Մարգարյան Ա.	95006147	93823359		Է. Գրիգորյան	77099162				\N	\N
645	Ազատեկի մ/դ	8	10	գ. Ազատեկ	\N	\N	3	\N	Ղազարյան Ա.	95006148	94703299		Լիաննա Հարությունյան	77167555				\N	\N
646	Արինի մ/դ	8	10	գ. Արին	\N	\N	3	\N	Գևորգյան Ս.	95006149	93472102		Լուսինե Գևորգյան	95006149	93472102			\N	\N
647	Արտավանի մ/դ	8	10	գ. Արտավան	\N	\N	3	\N	Մհերյան Հենզել	77350171			Մարինե	94241576	94872229			\N	\N
649	Գոմքի մ/դ	8	10	գ. Գոմք	\N	\N	3	\N	Խաչատրյան Նվարդ	95006156	93587968		Վարդանյան Մխիթար	93530247				\N	\N
650	Զեդեայի հմ/դ	8	10	գ. Զեդեա	\N	\N	3	\N	Սաղաթելյան Զոյա	95006157	98512796		Ղազարյան Արշակ	77412442				\N	\N
651	Կարմրաշենի մ/դ	8	10	գ. Կարմրաշեն	\N	\N	3	\N	Թովմասյան Արմեն	95006158	94040583		Վարդուհի Սահակյան	94133841				\N	\N
652	Մարտիրոսի մ/դ	8	10	գ. Մարտիրոս	\N	\N	3	\N	Հակոբյան Թևոս	94444829	95006159		Հակոբյան Տաթև	98885902				\N	\N
653	Սարավանի հմ/դ	8	10	գ. Սարավան	\N	\N	3	\N	Փանդունց Աշոտ	95006162	94843861		Ռուզաննա Ալեքսանյան	77211225				\N	\N
654	Սերսի հմ/դ	8	10	գ. Սերս	\N	\N	3	\N	Է. Հարությունյան	95006163	93411644							\N	\N
655	Վազաշենի մ/դ	8	11	գ. Վազաշեն	\N	\N	3	\N	Սարգիս Խաչատրյան	95003997	93478570		Արթուր Խաչատրյան	94995195				\N	\N
656	Խաշթառակի մ/դ	8	11	գ. Խաշթառակ	\N	\N	3	\N	Թիրաբյան Գերասիմ	95003982	93639616		Օհանյան Ասյա	94162271				\N	\N
657	Բերքաբերի մ/դ	8	11	գ. Բերքաբեր	\N	\N	3	\N	Հենրիկ Արզումանյան	093 18-94-28								\N	\N
658	Ն. Ծաղկավանի մ/դ	8	11	գ. Ն. Ծաղկավան	\N	\N	3	\N	Դավիթ Յոլչյան	95004117	93303624		Նառա Ռևազյան	77114978				\N	\N
659	Լուսահովիտի հմ/դ	8	11	գ. Լուսահովիտ	\N	\N	3	\N	Արզումանյան Արտակ	95004132	93673784		Պետրոսյան Լուսինե	77441601				\N	\N
661	Կիրանցի հմ/դ	8	11	գ. Կիրանց	\N	\N	3	\N	Բաբինյան Վոլոդյա	95004143	94979494		Մեսրոփ Շահնազարյան	94506004				\N	\N
662	Հովքի մ/դ	8	11	գ. Հովք	\N	\N	3	\N	Ուլիխանյան Արսեն	95004145	93900992		էդիտա	55332494				\N	\N
663	Թեղուտի մ/դ	8	11	գ. Թեղուտ	\N	\N	3	\N	Թամրազյան Արգամ	95004147	93553286		Բագրատ Ստեփանյան	77070679				\N	\N
624	Տաշտունի հմ/դ	8	9	գ. Տաշտուն	\N	\N	3	\N	Գևորգյան Ոսկեհատ	95002485	94043525		Հեղուշ Բաղրամյան	77955332			01-09-2017-ից փակվել է աշակերտ չունեն	\N	\N
638	Շատինի մ/դ	3	10	գ. Շատին	\N	\N	3	1	Բաբիկ Մարգարյան	95004959	99050115		Վարդուհի Տիգրանյան-հին	99881785	093241241-նոր օպերատոր			\N	\N
664	Հաղարծինի մ/դ	8	11	գ. Հաղարծին	\N	\N	3	\N	Թամանյան Գոհար	95004152	94555859		Ատոմ Թամրազյան	93207410				\N	\N
666	Այրումի մ/դ	8	11	գ. Այրում	\N	\N	3	\N	Բաղինյան Արարատ	95004169	91280652							\N	\N
667	Բագրատաշենի թիվ 1 մ/դ	8	11	գ. Բագրատաշեն	\N	\N	3	\N	Եսայան Ռազմիկ	95004172	77960419		Արմենուհի Կարապետյան	94001145				\N	\N
668	Բագրատաշենի թիվ 2 հմ/դ	8	11	գ. Բագրատաշեն	\N	\N	3	\N	Ալավերդյան Լիանա	95004183	77220461		Աիդա Մաթևոսյան	77608515				\N	\N
669	Կոթի մ/դ	8	11	գ. Կոթի	\N	\N	3	\N	Սիրադեղյան Մուշեղ	95004189	93059595		Սաշիկ Աբովյան	94835352				\N	\N
671	Զորականի մ/դ	8	11	գ. Զորական	\N	\N	3	\N	Խոջայան Սիլվա	95004235	94336063		Հայրապետյան Նորա	98734531				\N	\N
672	Ոսկեպարի մ/դ	8	11	գ. Ոսկեպար	\N	\N	3	\N	Ալավերդյան Հարություն	95004274	98697738		Իրինա Աղամյան	93791882				\N	\N
673	Բաղանիսի մ/դ	8	11	գ. Բաղանիս	\N	\N	3	\N	Բայրամյան Ալվարդ	95004275	77433275		Սիլվա Իսրայելյամ	98023365				\N	\N
674	Դովեղի մ/դ	8	11	գ. Դովեղ	\N	\N	3	\N	Վարդանյան Սանասար	95004278	77179900		Անի Գորգինյան	55093747				\N	\N
675	Ջուջևանի մ/դ	8	11	գ. Ջուջևան	\N	\N	3	\N	Վարդանյան Վալերիկ	95004279	94901040		Զինա Բաբաջանյան	77407340				\N	\N
676	Լճկաձորի հմ/դ	8	11	գ. Լճկաձոր	\N	\N	3	\N	Մալինյան Ռուսլան	95004281	93233213							\N	\N
677	Դեղձավանի հմ/դ	8	11	գ. Դեղձավան	\N	\N	3	\N	Բեջանյան Ալիսա	95004286	94803736		Ալինա Բեջանյան	94803736				\N	\N
678	Դեբեդավանի մ/դ	8	11	գ. Դեբեդավան	\N	\N	3	\N	Հարությունյան Մարինե	95004283	77689267		Լիաննա Մովսեսյան	77158112				\N	\N
679	Արծվաբերդի հմ/դ	8	11	գ. Արծվաբերդ	\N	\N	3	\N	Ուզունյան Սիրանուշ	95004284	94943071		Արմինե Անանյան	93404349				\N	\N
680	Այգեձորի մ/դ	8	11	գ. Այգեձոր	\N	\N	3	\N	Եղիազարյան Ելմիրա	95004285	93398598		Վարսիկ Մամիկոնյան	77891557				\N	\N
682	Չինարու մ/դ	8	11	գ. Չինարի	\N	\N	3	\N	Դալլաքյան Գրետա	95004287	94357716		Մհեր Մակարյան	98031091				\N	\N
683	Նավուրի մ/դ	8	11	գ. Նավուր	\N	\N	3	\N	Մարդանյան Կամո	95004294	93338859							\N	\N
685	Վ. Ծաղկավանի մ/դ	8	11	գ. Վ. Ծաղկավան	\N	\N	3	\N	Խաչատրյան Ռուբիկ	95004296	99091440		Գայանե Ղայթմազյան	91988366				\N	\N
686	Վարագավանի մ/դ	8	11	գ. Վարագավան	\N	\N	3	\N	Գրիգորյան Հայկ	95004319	94577501		Գրիգորյան Սարգիս	77788016				\N	\N
687	Պառավաքարի մ/դ	8	11	գ. Պառավաքար	\N	\N	3	\N	Նիգոյան Անգին	95004331	77159009		Դալաքյան Արմինե	93676774				\N	\N
688	Իծաքարի հմ/դ	8	11	գ. Իծաքար	\N	\N	3	\N	Դանիելյան Վարդան	95004336	94990034		Դանիելյան Ա.	77632158				\N	\N
689	Աղավնավանքի մ/դ	8	11	գ. Աղավնավանք	\N	\N	3	\N										\N	\N
690	Աճարկուտի հմ/դ	8	11	գ. Աճարկուտ	\N	\N	3	\N	Վարդումյան Արտակ	95004516	94751555		Գյոզալ Քոչարյան					\N	\N
691	Խաչարձանի հմ/դ	8	11	գ. Խաչարձան	\N	\N	3	\N										\N	\N
694	Երևանի մտավոր թերզարգացում ունեցող երեխաների թիվ 6 հատուկ/օժանդակ դպրոց	8	5	ք. Երևան, Ավան, Աճառյան 4	\N	\N	3	\N	տկն. Արտաշեսյան	95008775	613210	6132220						\N	\N
695	Երևանի պետական ֆինանսատնտեսագիտական քոլեջ	8	5	ք. Երևան, Ավան, Բաբաջանյա	\N	\N	3	\N	Հակոբյան Ավագ	95008776	010-62-57-00, 010-62-72-01	091 40-99-56						\N	\N
696	Երևանի Պ. Չայկովսկու անվ. միջնակարգ երաժշտական դպրոց	8	5	ք. Երևան, Կողբացու 36	\N	\N	3	\N	Կոստանդյան Մարտուն	95008778								\N	\N
745	Սուսերի մ/դ	8	1	գ. Սուսեր	\N	\N	3	\N	Ստեփանյան Ալբերտ				Գրիգորյան Թագուհի	77523077				\N	\N
681	Չորաթանի մ/դ	8	11	գ. Չորաթան	\N	\N	3	\N	Զարգարյան Վազգեն	93351690			Շուշան Քալանթարյան	098806611	93958593			6	26
693	Երևանի թիվ 10 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Հր. Ներսիսյան 3	\N	\N	3	\N	Բարսեղյան Արծրունի	95008773								\N	\N
697	Երևանի թիվ 4 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Գյուլիքեխվյան 2	\N	\N	3	\N	Ադյան Արմեն	95008756	99880909	634070						\N	\N
698	Երևանի թիվ 1 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Արշակունյաց 65	\N	\N	3	\N	Դավթյան Սլավիկ	443701	91427235	95008754	Շողեր Խանզադյան	55524676				\N	\N
699	Երևանի թիվ 5 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Քանաքեռ ՀԷԿ, Բա	\N	\N	3	\N	Ա. Հովհաննիսյան	91500680	95008753		Թամարա Աղաբաբյան	93900386				\N	\N
700	Երևանի թիվ 6 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Լենինականի 3	\N	\N	3	\N	Սոնա Գրիգորյան	99110551	95008752		Նաջարյան Փարանձեմ	91632005				\N	\N
701	Երևանի թիվ 8 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Ավանեսովի 1	\N	\N	3	\N	Մարիամ Հակոբյան	471732	91717381		Անի Կարագյոզյան	471731				\N	\N
665	Դիլիջանի թիվ 6 հմ/դ	8	11	ք. Դիլիջան Կամոյի փ. 131	\N	\N	3	\N	Սարգսյան Սուսաննա	95004165	93614109		Աիդա Ավետիսյան	94191619				\N	\N
684	Տավուշի մ/դ (Թովուզ)	8	11	գ. Տավուշ	\N	\N	3	\N	Կլեկչյան Արաքսյա	94902255			Տաթևիկ Մխիթարյան	94009954	Գևորգ	091451581		10	26
703	Կարբիի մ/դ	8	1	գ. Կարբի	\N	\N	3	\N	Օհանյան Արսեն	95006457			Վարդանուշ Հովհաննիսյան	93832289				\N	\N
704	Կարինի մ/դ	8	1	գ. Կարին	\N	\N	3	\N	Գալստյան Ալվարդ	93652188	23232018		Լիլիա Խաչատրյան	93691146				\N	\N
706	Ոսկեհատի մ/դ	8	1	գ. Ոսկեհատ	\N	\N	3	\N	Նասեյան Նելլի	93640606	23261575		Մուշեղ Գասպարյան					\N	\N
708	Սասունիկի մ/դ	8	1	գ. Սասունիկ	\N	\N	3	\N	Գալստյան Մուշեղ	93368354			Հարությունյան Վարդի	93881845				\N	\N
711	Օրգովի մ/դ	8	1	գ. Օրգոբվ	\N	\N	3	\N	Սեդրակ Զարոյան	93955179	23231653		Հովհաննես Տոնոյան	093 26-06-41				\N	\N
718	Աղձիքի մ/դ	8	1	գ. Աղձիք	\N	\N	3	\N	Սուքիասյան Հարություն	94826242			Պետրոսյան Նելլի	94826044				\N	\N
721	Եղիպատրուշի մ/դ	8	1	գ. Եղիպատրուշ	\N	\N	3	\N	Գրիգորյան Գնել	95006391	93838432		Անի Առաքելյան	095 53-46-36				\N	\N
723	Հարթավանի մ/դ	8	1	գ. Հարթավան	\N	\N	3	\N	Հասմիկ Մամյան	55460824	95006393		Կարապետյան Թագուհի					\N	\N
724	Քուչակի մ/դ	8	1	գ. Քուչակ	\N	\N	3	\N	Մայիլյան Մհեր	95503987	95006394	25291465						\N	\N
727	Շենավանի մ/դ	8	1	գ. Շենավան	\N	\N	3	\N	Ազատյան Ազատ	93271530	95006397	25293313	Աղաբեկյան Արմեն					\N	\N
728	Վերին Բազմաբերդի հմ/դ	8	1	գ. Վերին Բազմաբերդ	\N	\N	3	\N	Հովհաննիսյան Կառլեն	99051211	98051211	0249/60025						\N	\N
730	Ակունքի մ/դ	8	1	գ. Ակունք	\N	\N	3	\N	Բաղդասարյան Սիրուն	93937242			Ասատրյան Աննա	77937242	24990136			\N	\N
735	Եղնիկի հմ/դ	8	1	գ. Եղնիկ	\N	\N	3	\N	Մանասյան Օնիկ	93 31-03-54	95009183							\N	\N
736	Զովասարի մ/դ	8	1	գ. Զովասար	\N	\N	3	\N	Սարգսյան Ալբերտ	95 77-52-94	95009184							\N	\N
739	Կանչի հմ/դ	8	1	գ. Կանչ (Գյալթո)	\N	\N	3	\N	Մխիթարյան Հարություն	94826260								\N	\N
740	Կարմրաշենի մ/դ	8	1	գ. Կարմրաշեն	\N	\N	3	\N	Բարսեղյան Մուշեղ	93280093	95008723	24999288						\N	\N
741	Հակկոի հմ/դ	8	1	գ. Հակկո	\N	\N	3	\N	Լ. Գրիգորյան	77325626			Տարոն Գրիգորյան	94325626				\N	\N
742	Հացաշենի հմ/դ	8	1	գ. Հացաշեն	\N	\N	3	\N	Եղիազարյան Թոռնիկ	93480232	95008997							\N	\N
743	Մաստարաի մ/դ	8	1	գ. Մաստարա	\N	\N	3	\N	Արսենյան Աննա	93341876	95008968		Հովհաննիսյան Հ.					\N	\N
733	Դաշտադեմի Գ. Բաղդասարյանի անվ. մ/դ	8	1	գ. Դաշտադեմ	\N	\N	3	\N	Հակոբյան Ռիմա	093085261			Արամ	077 08-10-80				2	4
734	Դդմասարի հմ/դ	3	1	գ. Դդմասար	\N	\N	3	\N	Արմենուհի Տերտերյան	93000237								\N	\N
707	Ոսկեվազի մ/դ	3	1	գ. Ոսկեվազ	\N	\N	3	\N	Հովհաննիսյան տիկին	98000077			Արտավազդ Սարիբեկյան	093 830-730	099 830-730			\N	\N
702	Բյուրականի Թումանյանի անվ. մ/դ	8	1	գ. Բյուրական	\N	\N	3	\N	Գրիգորյան Խաչատուր	93777688	95006456		Անդրեասյան Արմեն	77775598				\N	\N
729	Ագարակավանի մ/դ	8	1	գ. Ագարակավան (Վ. Ագարակ)	\N	\N	3	\N	 Հունանյան Ջուլյետա /փոխտնօրեն/	041488573								\N	\N
738	Իրինդի Մ. Քոթանյանի անվ. մ/դ	8	1	գ. Իրինդ	\N	\N	3	\N	Խոջաբեկյան Վիկտորիա	77302408	24973179		Գուլոյան Վարդուշ					\N	\N
705	Ղազարավանի մ/դ	8	1	գ. Ղազարավան	\N	\N	3	\N	Թամարա Սարգսյան	077795455			Արուսյակ Մովսիսյան	077474135				1	3
713	Աշտարակի թիվ 1 հտ/դ	8	1	ք. Աշտարակ	\N	\N	3	\N	Աղաբաբյան Սվետլանա	98860867	95006471	-35064						\N	\N
712	Աշտարակի Գր. Ղափանցյանի անվ. թիվ 4 հմ/դ	8	1	ք. Աշտարակ	\N	\N	3	\N	Մկրտչյան Աստղիկ	232 3 34-54,	91-83-16-83	232 357-37						\N	\N
714	Աշտարակի Ն. Աշտարակեցու անվ. թիվ 1 հմ/դ	8	1	ք. Աշտարակ, Պռոշյան 14	\N	\N	3	\N	Բարսեղյան Սուսաննա	93-58-70-22	02323 8-18							\N	\N
715	Աշտարակի Ն. Սիսակայանի անվ. թիվ 5 ա/դ	8	1	ք. Աշտարակ, Տիգրան Մեծի 9	\N	\N	3	\N	Մարինե Սուքիասյան	02323 31-72	95006473	98658880						\N	\N
716	Աշտարակի Պ. Պռոշյանի անվ. թիվ 3 հմ/դ	8	1	ք. Աշտարակ, Չարենցի 1	\N	\N	3	\N	Համլետ Շուխյան	95006474	23233037	95878633		098 03-70-99				\N	\N
717	Աշտարակի Ս. Շահազիզի անվ. թիվ 2 հմ/դ	8	1	ք. Աշտարակ, Ալազանի 10	\N	\N	3	\N	Բալայան Հովհաննես	93925252	0232/35574							\N	\N
719	Ապարանի Վ. Եղիազարյան անվ. թիվ 1 հմ/դ	8	1	ք. Ապարան	\N	\N	3	\N	Եփրեմյան Վահագն	93813171	95006387		Եփրեմյան Վարդան	55447717				\N	\N
725	Ապարանի ա/դ	8	1	ք. Ապարան, Գարեգին Նժդեհի	\N	\N	3	\N	Բարսեղյան Նվարդ	93625858	95006395							\N	\N
726	Ապարանի թիվ 2 հմ/դ	8	1	ք. Ապարան	\N	\N	3	\N	Նաիրա Ղազարյան	93721074	95006396	25225456	Աբրահամյան Մարինե	98810889				8	8
722	Ծաղկաշենի Կ. Համբարձումյանի անվ. մ/դ	8	1	գ. Ծաղկաշեն	\N	\N	3	\N	Զաքարյան Արթուր	94826176	95006392	25261950						\N	\N
731	Աշնակի Գ. Չաուշի անվ. մ/դ	3	1	գ. Աշնակ	\N	\N	3	\N	Մարտիրոսյան Վահրամ	98168444	95008697							\N	\N
744	Շղարշիկի Ա. Մինասյանի անվ. մ/դ	8	1	գ. Շղարշիկ	\N	\N	3	\N	Գդոյան Սամվել	94180318			Կարիեն Սարգսյան	093921784 ամուսին	098 44-50-27			2	8
732	Արևուտի հմ/դ	8	1	գ. Արևուտ (Բարոժ)	\N	\N	3	\N	Խաթուն Հարությունյան	94 82-62-81								\N	\N
710	Օշականի Մ. Մաշտոցի անվ. մ/դ	8	1	գ. Օշական	\N	\N	3	\N	Լիանա Մելիքյան	096420070			Գոհար Գալստյան	091034799				1	47
747	Ցամաքասարի հմ/դ	8	1	գ. Ցամաքասար	\N	\N	3	\N	Մարկոսյան Նազիկ	95008973	93482856							\N	\N
748	Ավթոնայի հմ/դ	8	1	գ. Ավթոնա	\N	\N	3	\N	Լևոն Աբրահամյան	93874401	95008982							\N	\N
749	Արագածավանի թիվ 1 մ/դ	8	1	գ. Արագածավան	\N	\N	3	\N	Խաչատրյան Ասպրամ	77782788	95008983	0249/05122	Արսենյան Գոհար	55974252				\N	\N
750	Արագածավանի թիվ 2 մ/դ	8	1	գ. Արագածավան	\N	\N	3	\N	Ա. Տեր-Մարիտիրոսյան	93129229	95008981		Ղազարյան Գագիկ	77511104				\N	\N
751	Արեգի մ/դ	8	1	գ. Արեգ	\N	\N	3	\N										\N	\N
752	Արտենիի թիվ 1 մ/դ	8	1	գ. Արտենի	\N	\N	3	\N	Շատոյան Մանուշակ	93771791	95008961							\N	\N
753	Դավիթաշենի մ/դ	8	1	գ. Դավիթաշեն	\N	\N	3	\N	Կարապետյան Հրաչուհի		95008979							\N	\N
755	Նոր Արթիկի մ/դ	8	1	գ. Նոր Արթիկ	\N	\N	3	\N	Արշալույս Հակոբյան	93247646			Գոհար Այվազյան	94708630				\N	\N
756	Սորիկի հմ/դ	8	1	գ. Սորիկ	\N	\N	3	\N	Կարապետյան Վարդան	94827818	95008979							\N	\N
757	Թալինի ա/դ	8	1	ք. Թալին	\N	\N	3	\N	Հայկ Դիլանյան	93713362	95008974		Լալա Խուրշուդյան	93879448				\N	\N
758	Թալինի թիվ 2 հմ/դ	8	1	ք. Թալին	\N	\N	3	\N	Հովիկ Գրիգորյան	95006435	77301270	24922813						\N	\N
760	Արարատի թիվ 1 մ/դ	8	2	գ. Արարատ, Վ. Սարգսյանի փ	\N	\N	3	\N	Վարժապետյան Դավիթ	95004568	94388337		Կարինե Խուցեղյան	55570637				\N	\N
762	Ավշարի մ/դ	8	2	գ. Ավշար	\N	\N	3	\N	Աղաբեկյան Գեղեցիկ	55047704	95005847		Իգիտյան Սյուզաննա	94252482				\N	\N
763	Արալեզի մ/դ	8	2	գ. Արալեզ	\N	\N	3	\N	Գուլաբյան Տիգրան	95005787	91753295		Լիլիթ Մանուկյան	94134929				\N	\N
765	Դաշտաքարի մ/դ	8	2	գ. Դաշտաքար	\N	\N	3	\N	Ղիմոյան Վարուժան	95005776	99002886		Մերրի Բալյան	098806810 սխալ համար է				\N	\N
766	Եղեգնավանի մ/դ	8	2	գ. Եղեգնավան	\N	\N	3	\N	Զաքարյան Մանվել	95005779	93646546		Սյուզաննա Գալստյան	93777265				\N	\N
769	Նոյակերտի մ/դ	8	2	գ. Նոյակերտ	\N	\N	3	\N	Իսաջանյան Արթուր	95005762	93579731		Մուշեղ Թորոսյան նոր օպերատոր	099 60-66-19				\N	\N
770	Նոր Կյանքի մ/դ	8	2	գ. Նոր Կյանք	\N	\N	3	\N	Տեր-Նիկողոսյան Գայանե	95005753	91234283		Հասմիկ Ղազարյան					\N	\N
772	Ոսկետափի թիվ 1 հմ/դ	8	2	գ. Ոսկետափ	\N	\N	3	\N	Պետրոսյան Թորգոմ	95005746	91553229		Վարթեր Հովակիմյան	93791276				\N	\N
774	Ուրցաձորի մ/դ	8	2	գ. Ուրցաձոր	\N	\N	3	\N	Մկրտչյան Կարինե	95005739	94316355		Հենզել Գաբրիյելյան	94179714				\N	\N
775	Սիսավանի մ/դ	8	2	գ. Սիսավան	\N	\N	3	\N	Գալստյան Նարինե	95003124	91589551		Տիգրան Թորոսյան	93541631				\N	\N
776	Սուրենավանի մ/դ	8	2	գ. Սուրենավան	\N	\N	3	\N	Ավետիսյան Վալյա	95003135	93200394		Գոհար Ալոյան	55345313	099 34-53-13			\N	\N
777	Վանաշենի մ/դ	8	2	գ. Վանաշեն	\N	\N	3	\N	Մանուկյան Անիկ	95003181	93348818		Հասմիկ Նահապետյան	94755676				\N	\N
778	Տափերականի մ/դ	8	2	գ. Տափերական	\N	\N	3	\N	Սարգսյան Մուշեղ	95005738	93201482		Մարինե Սարգսյան	95901530				\N	\N
779	Փոքր Վեդու մ/դ	8	2	գ. Փոքր Վեդի	\N	\N	3	\N	Հարությունյան Արթուր	95001645	91200856		Մուրադյան Գոհար	094-80-43-95				\N	\N
780	Արարատի 3 հմ/դ	8	2	ք. Արարատ, Խանջյան 61	\N	\N	3	\N	Հովհաննիսյան Գոհարիկ	95003416	93814921		Սարգսյան Գայանե	98388394				\N	\N
782	Արարատի թիվ 4 հմ/դ	8	2	ք. Արարատ, Խանջյան 63	\N	\N	3	\N	Փանոսյան Նուրիցա	95003234	94224367		Մարիանա Անդրեասյան	93570715				\N	\N
783	Արարատի թիվ 5 մ/դ	8	2	ք. Արարատ, ՈԿՖ-ի բանավան	\N	\N	3	\N	Զադոյան Հասմիկ	95003219	55300763		Մելքոնյան Ռուզաննա	093 17-05-17				\N	\N
784	Արարատի թիվ 1 հմ/դ	8	2	ք. Արարատ, Շահումյան 41	\N	\N	3	\N	Նաբիկյան Նունե	95003195	94213500		Մարինե Խաչատրյան	95575696				\N	\N
785	Արարատի Պ. Սևակի անվ. թիվ 2 հմ/դ	8	2	ք. Արարատ, Շահումյան 16	\N	\N	3	\N	Հովհաննիսյան Զինա	95003184	91234310	95551969	Քրիստինե Գևորգյան	94424243				\N	\N
767	Երասխի մ/դ	8	2	գ. Երասխ	\N	\N	3	\N	Լևոնյան Մարիամ	95005773	55109901		Արման Մուրադյան	55104401				5	6
771	Նոր Ուղիի մ/դ	8	2	գ. Նոր Ուղի	\N	\N	3	\N	Մայիլյան Անահիտ	55403099	55403099		Լ. Սարգսյան	94120203				6	11
768	Լուսառատի մ/դ	8	2	գ. Լուսառատ	\N	\N	3	\N	Վերգուշ Առաքելյան	95005767	77500477		Հասմիկ Էմիշյան	093 38-39-43				4	12
759	Թալինի Մ. Գորկու անվ. թիվ 1 հմ/դ	8	1	ք. Թալին	\N	\N	3	\N	Ֆահրադյան Գագիկ	91655911	95006434		Տիգրան Սարգսյան	91765176				\N	\N
825	Վերին Դվինի մ/դ	8	2	գ. Վ. Դվին	\N	\N	3	\N	Լազարեվա Աիդա	95007651	93041667		Արթուր Յուխանաեվ	0235/64404				\N	\N
754	Կաթնաղբյուրի Մ. Գալշոյանի անվ. մ/դ	8	1	գ. Կաթնաղբյաուր	\N	\N	3	\N	Հախոյան Աշոտ	95430349	95008978	24973575						\N	\N
781	Արարատի ա/դ	8	2	ք. Արարատ, Խանջյան 67	\N	\N	3	\N	Շադյան Իլյիչ	95003257	77872707		Լիլիթ Գալստյան	91544054				\N	\N
764	Գոռավանի մ/դ	8	2	գ. Գոռավան, Գևորգ Մարզպետունու 8	\N	\N	3	\N	Աթոյան Գառնիկ	95005782	94673155		Նունե Կարապետյան	077 21-97-18				\N	\N
746	Վերին Սասնաշենի Մ. Մանուկյանի հմ/դ	8	1	գ. Վ.Սասնաշեն	\N	\N	3	\N	Յուրա Մանուկյան	093 84-95-54								\N	\N
786	Վեդու թիվ 2 հմ/դ	8	2	ք. Վեդի, Կասյան 4	\N	\N	3	\N	Նոնա Ադրեասյան	95002997	93493447		Աստղիկ Սահրադյան	0234/6-52-72				\N	\N
790	Արաքսավանի մ/դ	8	2	գ. Արաքսավան	\N	\N	3	\N	Մինասյան Մարտին	95005719	93970027		Աննա Բադալյան	93680391				\N	\N
791	Բյուրավանի մ/դ	8	2	գ. Բյուրավան	\N	\N	3	\N	Մարլենա Վարդանյան-նախկին, Մելիքյան-նոր տնօրեն	95005714	93379854	77361979	Մարիամ Խաչատրյան	93881599				\N	\N
793	Դիմիտրովի մ/դ	8	2	գ. Դիմիտրով	\N	\N	3	\N	Մկրտչյան Հայկ	95005167	93105422		Գոհար Բուդաղյան	94199477				\N	\N
796	Նշավանի մ/դ	8	2	գ. Նշավան	\N	\N	3	\N	Մարինե Բագրատյան	95005152	94160797		Ջուլիետա Մանուկյան	77198319				\N	\N
797	Նորաշենի մ/դ	8	2	գ. Նորաշեն	\N	\N	3	\N	Գոհարիկ Հակոբյան	95005149	91569687		Նաիրա Մանուկյան	077 844-570				\N	\N
799	Ոստանի մ/դ	8	2	գ. Ոստան	\N	\N	3	\N	Գեղամ Արշակյան	95005132	93806055		Հավաքիմյան Լուսինե	55237488				\N	\N
800	Վարդաշենի մ/դ	8	2	գ. Վարդաշեն	\N	\N	3	\N	Սոֆիա Հովսեփյան	95005131	91613464		Արմինե Ղարիբյան	93344450				\N	\N
802	Ազատավան մ/դ	8	2	գ. Ազատավան, Մաշտոցի փ.	\N	\N	3	\N	Նիկողոսյան Էմմա	95005127	91676596		Զեփյուր Խաչատրյան	95277775				\N	\N
804	Արտաշատի թիվ 3 մ/դ	8	2	ք. Արտաշատ, Օգոստոսի 23	\N	\N	3	\N	Միրզոյան Մարգուշ	95008689	93808977		Բադալյան Սոնիկ	93325168				\N	\N
806	Արտաշատի թիվ 5 մ/դ	8	2	ք. Արտաշատ, Աճառյան 1	\N	\N	3	\N	Հայրապետյան Ռուզան	95008685	93755221		Կարինե Աբրահամյան	99266423				\N	\N
807	Արտաշատի թիվ 6 մ/դ	8	2	ք. Արտաշատ, Մարքսի 20	\N	\N	3	\N	Մուրադյան Նարինե	95008684	93740039		Արմենւհի Հայրապետյան	93086737				\N	\N
808	Արտաշատի Թումանյանի անվ. թիվ 2 մ/դ	8	2	ք. Արտաշատ Մռավյան 32	\N	\N	3	\N	Նիկողոսյան Նաիրա	95008683	55220033		Հ.Մովսիսյան	0238/2-23-85				\N	\N
809	Դիտակի մ/դ	8	2	գ. Դիտակ	\N	\N	3	\N	Հովհաննիսյան Սարգիս	95008682	96721313	077 72-13-13						\N	\N
810	Հովտաշենի մ/դ	8	2	գ. Հովտաշեն	\N	\N	3	\N	Հովհաննիսյան Վիրաբ	95008681	55397420		Պողոսյան Ժ.	55626017				\N	\N
811	Մասիսի մ/դ	8	2	գ. Մասիս	\N	\N	3	\N	Խաչատրյան Ռուզաննա	95008679	93540533		Մարինե Միքայելյան	094 54-55-79				\N	\N
812	Մխչյանի մ/դ	8	2	գ. Մխչյան	\N	\N	3	\N	Ավագյան Աննա	95008678	93095050							\N	\N
813	Մրգավանի մ/դ	8	2	գ. Մրգավան	\N	\N	3	\N	Հարությունյան Գայանե		91777002		Վարսենիկ Դանիելյան	93413439				\N	\N
814	Մրգավետի մ/դ	8	2	գ. Մրգավետ	\N	\N	3	\N	Զոհրաբյան Վրեժ	95008675	93682728		Անի Մելքոնյան	94656478				\N	\N
816	Ջրաշենի մ/դ	8	2	գ. Ջրաշեն	\N	\N	3	\N	Գալստյան Երվանդ	95008673	94667584		Լիաննա Գևորգյան	93804032				\N	\N
818	Արևշատի մ/դ	8	2	գ. Արևշատ	\N	\N	3	\N	Սուսաննա Դավթյան	95008672	91796869		Երանուհի Սարգսյան/Գոհար	55630395				\N	\N
819	Բաղրամյանի մ/դ	8	2	գ. Բաղրամյան	\N	\N	3	\N	Թադեվոսյան Ռուզաննա	95008669	91494409		Անահիտբ Պետրոսյան	77019047				\N	\N
823	Հնաբերդի մ/դ	8	2	գ. Հնաբերդ	\N	\N	3	\N	Եղիազարյան Հասմիկ	98705011	95008662		Մխիթարյան Հ.	55646260				\N	\N
798	Շահումյանի մ/դ	8	2	գ. Շահումյան	\N	\N	3	\N	Ստեփանյան Վարսիկ	095820886			Նինել Ծատուրյան	077963997				3	6
792	Դալարի մ/դ	8	2	գ. Դալար	\N	\N	3	\N	Հախվերդյան Շողիկ	95005712	94008385		Լուսինե Հունանյան	077778241	055064403			8	15
820	Բերդիկի մ/դ	8	2	գ. Բերդիկ	\N	\N	3	\N	Մինասյան Սեդա	094818868	91818860	95008667	Համասփյուր Եփրեմյան	094094973				3	5
787	Վեդու Մ. Խաչատրյանի անվ.  ա/դ	8	2	ք. Վեդի	\N	\N	3	\N	Ալեքսանյան Արմեն	95002992	55997744		Վարսիկ Գալստյան	93190018				\N	\N
803	Արտաշատի Ա. Գոլեցյանի անվ. թիվ 1 մ/դ	8	2	ք. Արտաշատ, Մարքսի 13	\N	\N	3	\N	Անահիտ Վարդանյան	-24667	-22567							\N	\N
789	Այգեպատի մ/դ	8	2	գ. Այգեպատ	\N	\N	3	\N	Անահիտ Հովհաննիսյան	93496022			Հռիփսիմե Բունիաթյան	93080165				1	8
794	Կանաչուտի Գ. Եփրեմյանի անվ. մ/դ	8	2	գ. Կանաչուտ	\N	\N	3	\N	Սուսաննա Խաչատրյան	95005157	94726004		Էլմիրա Գալստյան	093 53-07-42				\N	\N
824	Վ. Արտաշատի մ/դ	8	2	գ. Վ. Արտաշատ	\N	\N	3	\N	Եսայան Գրիգոր	95008663	93096691		Սեդա Թամազյան	77338608				\N	\N
805	Արտաշատի թիվ 4 ա/դ	8	2	ք. Արտաշատ, Տերյան 1	\N	\N	3	\N	Նարինե Մուրադյան	093740039			Արմենուհի Հայրապետյան	093086737				8	15
815	Նարեկի մ/դ	8	2	գ. Նարեկ	\N	\N	3	\N	Դավթյան Անուշ	95008674	94748015	0235 6-15-29	Գայանե Ամրոյան, Արևիկ Հակոբյան	77437662	099 88-41-43			1	4
801	Քաղցրաշենի Սամվել Գևորգյանի անվ. մ/դ	8	2	գ. Քաղցրաշեն	\N	\N	3	\N	Թադեւոս Աբրահամյան	98990063			Արմինե Խաչատրյան	93554602				1	15
788	Այգեզարդի Զ. Ղարիբյանի անվ. մ/դ	8	2	գ. Այգեզարդ	\N	\N	3	\N	Նունե Բաբլոյան	93592243			Սյուզաննա Հովհաննիսյան	91009392				2	6
817	Այգեստանի Խ. Միքայելյանի անվ. մ/դ	8	2	գ. Այգեստան	\N	\N	3	\N	Մանուկյան Լեյլի	95008671	98023637		Մարտիրոսյան Լուսինե	94977724				3	11
821	Գետազատի մ/դ	8	2	գ. Գետազատ	\N	\N	3	\N	Մարգարյան Թինա	77003169			Լիլիթ Միխայելյան	77074388				4	5
828	Արբաթի Զաքարյանի անվ. մ/դ	8	2	գ. Արբաթ	\N	\N	3	\N	Կիրակոսյան Արմեն	95008648	93939331		Գոհար Սարգսյան	94212545				\N	\N
830	Գեղանիստի մ/դ	8	2	գ. Գեղանիստ	\N	\N	3	\N	Իսպիրյան Ժորա	95008646	93626290		Նելլի Ալոյան	55994458				\N	\N
832	Դարակերտի մ/դ	8	2	գ. Դարակերտ	\N	\N	3	\N	Վիրաբյան Մուշեղ	95008643	93066108		Փիրուզա Սեյրանյան	77918786				\N	\N
833	Զորակի մ/դ	8	2	գ. Զորակ	\N	\N	3	\N	Բաբախանյան Տիգրան	95008642	93525209		Ավագյան Անժելա	0236/60013	094 40-27-19			\N	\N
835	Հովտաշատի մ/դ	8	2	գ. Հովտաշատ	\N	\N	3	\N	Մկրտչյան Արմենուհի	95008641	93376752		Հայարփի Ստեփանյան	93113402				\N	\N
837	Մարմարաշենի մ/դ	8	2	գ. Մարմարաշեն	\N	\N	3	\N	Համբարձումյան Աննա	95008637	93976480		Հելնար Կոնստանյան	93800516				\N	\N
838	Նիզամիի մ/դ	8	2	գ. Նիզամի	\N	\N	3	\N	Խաչատրյան Թամարա	95008636	93100172		Նունե Ժանոյան	094 89-09-11				\N	\N
839	Նոր Խարբերդ թիվ 2 մ/դ	8	2	գ. Նոր Խարբերդ	\N	\N	3	\N	Մելքումյան Հրաչիկ	95008635	55411411		Արմինե Սարգսյան	93013036				\N	\N
840	Նոր Խարբերդի թիվ 1 մ/դ	8	2	գ. Նոր Խարբերդ	\N	\N	3	\N	Սարգսյան Մարինե	94667667	95008634		Հոթարյան Արևիկ	94743306	55545349			\N	\N
841	Նոր Կյուրինի մ/դ	8	2	գ. Նոր Կյուրին	\N	\N	3	\N	Հակոբյան Վարդուշ	95008632	94839434		Գևորգյան Ե.	94624643				\N	\N
844	Ռանչպարի մ/դ	8	2	գ. Ռանչպար, 6-րդ փ. I փակ	\N	\N	3	\N	Դալլաքյան Սվետա	95008628	93329126		Վյաչեսլավ Իսրաելյան	94227818				\N	\N
845	Սայաթ-Նովայի մ/դ	8	2	գ. Սայաթ-Նովա	\N	\N	3	\N	Ղարսայան Ժենյա	95008627	93088225		Անի Հարությունյան	91945001				\N	\N
846	Սիսի մ/դ	8	2	գ. Սիս	\N	\N	3	\N	Սարգսյան Սարգիս	95008715	55088900		Նաիրա Առաքելյան	93099946				\N	\N
847	Մասիսի թիվ 2 հմ/դ	8	2	ք. Մասիս, Դպրոցականների 1	\N	\N	3	\N	Նազարյան Արևհատ	93570502	0236/4-26-02	95008716	Արմեն Պողոսյան	94181922				\N	\N
849	Մասիսի թիվ 4 հմ/դ	8	2	ք. Մասիս, 5-րդ փողոց	\N	\N	3	\N	Բարսեղյան Նարինե	95008718	93736543		Իրինա Գրիգորյան	98941512				\N	\N
850	Մասիսի թիվ 5 ա/դ	8	2	ք. Մասիս, 4-րդ փողոց	\N	\N	3	\N	Ազնավուրյան Ալինա	95008719	94942425		Անի Հարությունյան	94142544				\N	\N
852	Մասիսի Մաշտոցի անվ. թիվ 1 հմ/դ	8	2	ք. Մասիս, 4-րդ փողոց	\N	\N	3	\N	Արևյան Թամարա	95008724	95962400		Հասմիկ Զաքարյան	99014071				\N	\N
853	Արգավանդի մ/դ	8	2	գ. Արգավանդ	\N	\N	3	\N	Համբարյան Սմբուլ	95008984	55656000							\N	\N
855	Լուկաշինի մ/դ	8	3	գ. Լուկաշին	40.1849220000000003	44.0080979999999968	3	2	Պետրոսյան Արմինե	93208986			Ժաննա Հովհաննիսյան	77473148				2	\N
856	Խանջյանի մ/դ	8	3	գ. Խանջյան	40.1857320000000016	43.9794020000000003	3	2	Աննա Հովսեփյան	98003272			Եղիազարյան Սյուզաննա	77932430				1	\N
857	Հայկավանի մ/դ	8	3	գ. Հայկավան	40.0932919999999982	44.0425570000000022	3	2	Սոֆյա Ալավերդյան	94331004			Հասմիկ	77312424				0	\N
858	Նորապատի մ/դ	8	3	գ. Նորապատ	40.1373439999999988	44.0396250000000009	3	2	Սահակյան Նաիրա	98577300			Արամ Ռուբենյան	93278453				8	\N
862	Արմավիրի թիվ 10 հմ/դ	8	3	ք. Արմավիր, Սայաթ-Նովա 7	40.1473330000000033	44.0516440000000031	3	1	Լիանա Հայրապետյան	93555456			Տաթևիկ Դավթյան	93916478				3	\N
854	Վեդիի թիվ 1 Մարգարյանի անվ. հմ/դ	8	2	ք. Վեդի, Արցախի 5	\N	\N	3	\N	Պապոյան Ալվարդ	95005726	93032100		Վահագն Օհանյան	077-55-00-75				\N	\N
831	Դաշտավանի Տոնոյանի անվ. մ/դ	3	2	գ. Դաշտավան	\N	\N	3	\N	Շահվերդյան Լաուրա	95008645	93100958		Նառա	77300123				\N	\N
843	Նորամարգի մ/դ	3	2	գ. Նորամարգ	\N	\N	3	\N	Գալստյան ծովինար	55478770	0236 64636		Ալլախվերդյան Էլեոնորա	94246325				\N	\N
827	Այնթապի թիվ 1 մ/դ	8	2	գ. Այնթապ	\N	\N	3	\N	Շահբազյան Լիլիա	95008649	93630101		Ադելինա Շահինյան	095109591				2	24
829	Արևաբույրի Թադևոսյանի անվ. մ/դ	8	2	գ. Արևաբուլր	\N	\N	3	\N	Աբգարյան Նվեր	95008647	93093885		Վարսենիկ Շերոյան	98784165				3	9
836	Ղուկասավանի մ/դ	3	2	գ. Ղուկասավան	\N	\N	3	\N	Ահարոնյան Ռուզաննա	093050461	95008638		Գայանե Արուստամյան		94585435	055461273		2	8
848	Մասիսի թիվ 3 հմ/դ	8	2	ք. Մասիս, Դպրոցականների 2	\N	\N	3	\N	Մուրադյան Էմմա	93225282	95008717		Մարգարիտա Թանգյան	93087218				\N	\N
851	Մասիսի թիվ 6 հմ/դ	8	2	ք. Մասիս, Կայարանի թաղամաս	\N	\N	3	\N	Բաբայան Աղունիկ	95008721	93098560		Նունե Հակոբյան	93239272				\N	\N
826	Այնթապի Բյուզանդ Մարգարյանի անվ. 2 մ/դ	8	2	գ. Այնթապ, 4-րդ փողոց	\N	\N	3	\N	Սահակյան Ալվարդ	95008651	93525897		Արմեն Միքայելյան	91948032				\N	\N
842	Նորաբացի Մ. Ապելյանի անվ. մ/դ	8	2	գ. Նորաբաց	\N	\N	3	\N	Մովսիսյան Մարինե	93882725			Լուսինե Գրիգորյան	93882725				\N	\N
861	Արմավիրի թիվ 1 հտ/դ	8	3	ք. Արմավիր, Գորկու 5-րդ նրբ. 14 շենք	40.1607190000000003	44.0478400000000008	3	1	Լ. Ասատրյան	93750787			Սարգսյան Սուսաննա	99827592				3	\N
859	Ալաշկերտի Հ. Քոչարի անվ. մ/դ	8	3	գ. Ալաշկերտ	40.1112340000000032	44.0556160000000006	3	2	Ալինա Նաջարյան				Նաիրա Բաղդասարյան	93335095				1	\N
863	Արմավիրի թիվ 3 հմ/դ	8	3	ք. Արմավիր, Կոմիտաս 27	40.1631309999999999	44.0367839999999973	3	1	Բաղդասարյան Արմեն	93746762			Գայանե Թադևոսյան	93655321				3	\N
867	Արմավիրի թիվ 4 ա/դ	8	3	ք. Արմավիր, Շահումյան 46	40.149363000000001	44.0354249999999965	3	1	Անի Քալաշյան				Եվա Խաչատրյան	94186769				5	\N
868	Արմավիրի թիվ 6 հմ/դ	8	3	ք. Արմավիր, Շահումյան 20	40.146808	44.0419059999999973	3	1	Հասմիկ Գասպարյան	98007919			Մանյան Խաչատրյան	91472016				8	\N
869	Արմավիրի թիվ 8 հմ/դ	8	3	ք. Արմավիր, Աբովյան 182	40.1598279999999974	44.0303159999999991	3	1	Աննա Խաչատրյան				Աննա Գևորգյան	93783468				6	\N
874	Արևիկի մ/դ	8	3	գ. Արևիկ	40.098351000000001	44.0948580000000021	3	2	Լևոն Այվազյան	93577872			Աբրահամյան Վահե	77409569				1	\N
876	Արտաշարի մ/դ	8	3	գ. Արտաշար	40.1114030000000028	44.1806989999999971	3	2	Հասմիկ Սրապիոնյան	93075601			Մանուշ	93471740				1	\N
877	Եղեգնուտի մ/դ	8	3	գ. Եղեգնուտ	40.0911240000000006	44.1544120000000007	3	2	Հովհաննես Մարգարյան	93522237			Եդգար Մարգարյան	77240661				1	\N
879	Զարթոնքի մ/դ	8	3	գ. Զարթոնք	40.1058659999999989	44.1613109999999978	3	2	Մելքոնյան				Սամսոն	93919323				1	\N
880	Մայիսյանի մ/դ	8	3	գ. Մայիսյան	40.1527669999999972	44.0916080000000008	3	2	Պետրոսյան Իշխան	93616984	23763929		Ամատունի Կիրակոսյան	91123440				7	\N
881	Մարգարաի մ/դ	8	3	գ. Մարգարա	40.0338720000000023	44.1831419999999966	3	1	Մարգարյան Արուսյակ	55896674			Լուսինե					1	\N
882	Վարդանաշենի մ/դ	8	3	գ. Վարդանաշեն	40.0518580000000028	44.1930460000000025	3	1	Հակոբ Հովասափյան	55331355	93331334		Նելլի Հայրապետյան	77646093				1	\N
884	Մեծամորի թիվ 2 ա/դ	8	3	ք. Մեծամոր	40.1453089999999975	44.1250209999999967	3	1	Մայիս Նիկողոսյան	91542450			Արմինե	77912898				4	\N
890	Լենուղու Ջիվանու անվ. մ/դ	8	3	գ. Լենուղի	40.1227659999999986	43.9666879999999978	3	2	Աֆյան Փառանձեմ	93186066			Կուտանյան Թամարա	41997909				1	\N
893	Նալբանդյանի մ/դ	8	3	գ. Նալբանդյան	40.0623280000000008	43.9877309999999966	3	2	Տիգրան Գևորգյան	77116622			Կարինե Մկրտչյան	94859104				1	\N
894	Նոր Ամասիայի մ/դ	8	3	գ. Ամասիա Ն. (Ամասիա)	40.0830130000000011	43.9692930000000004	3	2	Գոհար Ներսիսյան	93681847			Համլետ Գինոսյան	93184939				1	\N
895	Նոր Արմավիրի մ/դ	8	3	գ. Նոր Արմավիր	40.089578000000003	43.9940899999999999	3	2	Հերիքնազ Հարությունյան	93200255			Սաֆարյան Հովհաննես	94227006				1	\N
896	Նոր Արտագերսի մ/դ	8	3	գ. Նոր Արտագերս	40.0698250000000016	44.0098190000000002	3	2	Սամվել Խաչատրյան	93335737			Հռիփսիմե Դավթյան	94564636				1	\N
897	Նոր Կեսարիաի մ/դ	8	3	գ. Նոր Կեսարիա	40.0625829999999965	43.9056909999999974	3	2	Վարդան Հակոբյան	77949634	95441177		Պերճանուշ	93010524				1	\N
886	Արաքսի Զ. Ավետիսյանի անվ. մ/դ	8	3	գ. Արաքս	40.0980890000000016	43.9549790000000016	3	2	Բարսեղյան Կարինե	94112410	55112410		Ղազարյան Ալվարդ	77789476				4	\N
875	Արմավիրի մ/դ	8	3	գ. Արմավիր	40.0886780000000016	44.0481320000000025	3	2	Ռուզաննա Ասմարյան	77021677			Narine	98525975				1	10
883	Մեծամորի թիվ 1 հմ/դ	8	3	ք. Մեծամոր	40.1456019999999967	44.1160939999999968	3	1	Գևորգյան Նունե	93522166			Աննա	93120424	Լուսինե ինֆ ուսուց	093004068		12	13
888	Բամբակաշատի մ/դ	8	3	գ. Բամբակաշատ	40.1133700000000033	44.0142219999999966	3	2	Պարոնյան Գայանե	093820897	95008534		Մարտիրոսյան Շուշանիկ	55344588	93399589			4	12
889	Գետաշենի մ/դ	8	3	գ. Գետաշեն	40.0458950000000016	43.9470090000000013	3	2	Գևորգ Մուքոյան	93437505			Նելլի	77250082				10	40
865	Հացիկի Ա. Բաղդասրյանի անվ. մ/դ	8	3	գ. Հացիկ	40.1675779999999989	43.9533539999999974	3	2	Տաթևիկ Մկրտչյան	93802783			Սիրան Բաղդասարյան	93648566				1	\N
864	Արմավիրի Վ. Բախշյանի անվ. թիվ 2 հմ/դ	8	3	ք. Արմավիր, Հանրապետության 26	40.1540600000000012	44.0382979999999975	3	1	Գևորգ Առաքելյան	93936879			Աննա Հայրապետյան	93542329				1	\N
866	Արմավիրի Ա. Օզանյանի անվ. թիվ 5 հմ/դ	8	3	ք. Արմավիր, Հանրապետության 20	40.1519779999999997	44.0349629999999976	3	1	Իվանյան Մաշա	93999508			Ռուզան	77039765				20	\N
870	Արմավիրի թիվ 9 հմ/դ	8	3	ք. Արմավիր, Գորկու 5-րդ նրբ.	40.161403	44.0467239999999975	3	1	Այվազյան Գոռ	98503667	95007276		Նազենի Միանսյան	94901513				5	\N
871	Արմավիրի Ռ. Եղոյանի անվ. թիվ 1 ա/դ	8	3	ք. Արմավիր, Ավետիսյան 4	40.1511399999999981	44.0286329999999992	3	1	Նունե Դոլինյան	93757477			Արմինե Իվանյան	93801380				17	\N
885	Այգևանի Մ. Խորենացու անվ. մ/դ	8	3	գ. Այգևան	40.1399600000000021	43.9796770000000024	3	2	Կարեն Մովսիսյան	94690606			Մարինե Մովսիսյան	95413161				2	\N
891	Մրգաշատի Մ. Մաղաքյանի անվ. թիվ 2 մ/դ	8	3	գ. Մրգաշատ	40.1228890000000007	44.0567139999999995	3	2	ՌոբերտՀամբարձումյան	93713883			Ռուզաննա Հարությունյան	77685898				2	\N
892	Մրգաշատի Վ. Ափոյանի անվ. թիվ 1 մ/դ	8	3	գ. Մրգաշատ	40.1232820000000032	44.067419000000001	3	2	Լենա Նալբանդյան	77838343			Գայանե Մելիքյան	94233281				1	6
887	Արգավանդի մ/դ	8	3	գ. Արգավանդ	40.0632990000000007	44.091230000000003	3	1	Մխիթար Դանիելյան	98130026	96130026		Ջեմա	98899310				1	12
873	Արազափի Թ. Հուրյանի անվ. մ/դ	8	3	գ. Արազափ	40.0430830000000029	44.141849999999998	3	2	Չինար Կարապետյան	093171063			Քրիստինե					1	6
967	Ֆերիկի հմ/դ	8	3	գ. Ֆերիկ	40.1836119999999966	44.2125929999999983	3	2	Պողոսյան Լևոն	93725759	93225259							1	\N
900	Ջրաշենի մ/դ	8	3	գ. Ջրաշեն	40.0874639999999971	44.0167399999999986	3	2	Սամվել Պողոսյան	77646414			Ներսիկ	93223326				1	\N
906	Մյասնիկյանի Արայի անվ. մ/դ	8	3	գ. Մյասնիկյան	40.178600000000003	43.9165429999999972	3	2	Զուբեիդա Հովհաննիսյան	93191220			Գասպարյան Վարսենիկ	93194614				7	\N
907	Շենիկի մ/դ	8	3	գ. Շենիկ	40.2108739999999969	43.770265000000002	3	2	Լավրենտ Հայրապետյան	93386044			Տաթևիկ	77254420				1	\N
908	Լեռնագոգի մ/դ	8	3	գ. Լեռնագոգ	40.2573760000000007	43.8655439999999999	3	2	Կորյուն Մակարյան	94635885	95007312		Ալիսա Առաքելյան	93184275				4	\N
909	Քարակերտի թիվ 2 մ/դ	8	3	գ. Քարակերտ	40.2444810000000004	43.8196470000000033	3	2	Վաարդիթեր Պապոյան	94172041			Մեսրոպյան Սուսաննա	77987500				1	\N
911	Արտիմետի հմ/դ	8	3	գ. Արտիմետ	40.1511139999999997	44.2668430000000015	3	2	Գյոզալյան Արտակ	93186288			Խաչատրյան Քրիստինե	77139066				1	\N
912	Հուշակերտի մ/դ	8	3	գ. Հուշակերտ	40.0855590000000035	43.9250070000000008	3	2	Խարաջանյան Մկրտիչ	93379107			Թորոսյան Նելլի	94604555				3	\N
917	Ակնաշենի մ/դ	8	3	գ. Ակնաշեն	40.0946709999999982	44.2864840000000015	3	2	Նորիկ  Բաղդասարյան	93138812			Հռիփսիմե Ենոքյան	77019157				2	\N
918	Այգեկի մ/դ	8	3	գ. Այգեկ	40.1899859999999975	44.3837979999999988	3	2	Արիստակեսյան Ռ.	93961696			Էդիկ Բաղդասարյան	98572730				1	\N
919	Այգեշատ(Էջ.)ի մ/դ	8	3	գ. Այգեշատ(Էջ.)	40.2326049999999995	44.287585	3	2	Հովսեփյան Նաիրա	055161677սխալէ	98880000		Խաչատրյան Սուսաննա	94200232				1	\N
920	Առատաշենի մ/դ	8	3	գ. Առատաշեն	40.1295410000000032	44.2296240000000012	3	2	Ղազարյան Սևակ	93744644			Մարիամ Ամիրյան	77424882	55703637			1	\N
923	Արևաշատի մ/դ	8	3	գ. Արևաշատ	40.1432509999999994	44.3749309999999966	3	2	Առաքելյան Հ.	77430610			Ա. Մկրտչյան	93108034				4	\N
924	Բաղրամյանի (Էջ.) մ/դ	8	3	գ. Բաղրամյան /Էջմիածնի տա	40.1901560000000018	44.367561000000002	3	2	Շուշանիկ Ոսկանյան	93814414			Ոսկանյան Ռոզա	94337676				2	\N
925	Գայի մ/դ	8	3	գ. Գայ	40.0837590000000006	40.0837590000000006	3	2	Հարությունյան 	93555632			Խաչատրյան	94567941				1	\N
926	Գեղակերտի մ/դ	8	3	գ. Գեղակերտ	40.1854379999999978	44.2484340000000032	3	2	Արմեն Ահարոնյան	93185645			Ալավերդյան Լուսինե	93513075				1	\N
928	Դողսի մ/դ	8	3	գ. Դողս	40.2270099999999999	44.2731989999999982	3	2	Ավետիսյան Գոհար	77030388				55543566				3	\N
929	Թաիրովի մ/դ	8	3	գ. Թաիրով	40.1634499999999974	44.421247000000001	3	1	Մ. Բաղամյան	93284191			Մարիամ Մնացականյան	94670055				10	\N
930	Լեռնամերձի հմ/դ	8	3	գ. Լեռնամերձ	40.2564429999999973	44.2655159999999981	3	2	Զավեն Գրիգորյան	93875138			Լուսինե Գրիգորյան	55273751				2	\N
931	Խորոնքի մ/դ	8	3	գ. Խորոնք	40.1334810000000033	44.2443990000000014	3	2	Ասատրյան Նշան	77148000			Ծաղիկ Փաթաթանյան	55255760	Ալվարդ055255760			3	\N
932	Ծաղկալանջի մ/դ	8	3	գ. Ծաղկալանջ	40.1990150000000028	44.2291480000000021	3	2										5	\N
933	Ծիածանի մ/դ	8	3	գ. Ծիածան	40.1816850000000017	44.2644159999999971	3	2	Գազազյան Գ.	93597220			Անուշ Սերգոյան	94656795	77377547			8	\N
903	Փշատավանի մ/դ	8	3	գ. Փշատավան	40.0405640000000034	44.0648449999999983	3	2	Նելի Ղորղանյան	93623293			Դիանա	93619334				1	11
921	Արագածի Մ. Մեխակյանի անվ. մ/դ	8	3	գ. Արագած	40.2169969999999992	44.2335229999999981	3	2	Սայադյան Վրեժ	94494920			Մերի Վարդանյան	94858502				6	\N
910	Արևադաշտի մ/դ	8	3	գ. Արևադաշտ	40.1331720000000018	43.9406949999999981	3	2	Նազիկ Բաբայան	99582344	41042344		Շողիկ	93505456				1	1
915	Դալարիկի Հ. Հովհաննիսյանի անվ. մ/դ	8	3	գ. Դալարիկ	40.2259320000000002	43.8781540000000021	3	2	Հեբոյան Բավական	93928362	95007654		Ռեհանյան Մարինե	93669948				1	\N
916	Աղավնատան Ղ. Աբգարյանի անվ. մ/դ	3	3	գ. Աղավնատուն	40.228588000000002	44.2524330000000035	3	2	Ա. Ավետիսյան	93195868	95008626		Արմինե Ավետիսյան	77692719				11	\N
922	Արաքս (Էջ.)-ի մ/դ	8	3	գ. Արաքս(Էջ.)	40.0532439999999994	44.3017660000000006	3	2	Մարտիրոսյան Շ.	94145000			Հովակիմյան Արմենուհի	93549559				0	\N
927	Գրիբոյեդովի Վ. Ռոստոմյանի անվ. մ/դ	3	3	գ. Գրիբոյեդով	40.1127010000000013	44.2730069999999998	3	2	Սերգեյ Թադևոսյան	93185955			Աշոտ Արզումանյան	93492994	95492994			8	13
902	Տանձուտի մ/դ	8	3	գ. Տանձուտ	40.0698730000000012	44.079225000000001	3	2	Հովսեփ Այվազյան	93439968			Անտոնյան Անժելա	98353040				3	11
914	Տալվորիկի հմ/դ	8	3	գ. Տալվորիկ	40.1016499999999994	43.8823640000000026	3	2	Մարինե Սաֆարյան	94159132			Հռիփսիմե Սաղաթելյան	94585001				2	2
913	Վանանդի մ/դ	8	3	գ. Վանանդ	40.105203000000003	43.8178789999999978	3	2	Խաչիկյան Հայկ	93394060			Անահիտ Մարգարյան	93480578				1	6
905	Արտամետի մ/դ	8	3	գ. Արտամետ	40.1232210000000009	43.8607829999999979	3	2	Ղազարյան Մելքոն	93243740			Աննա	77638990				11	14
899	Ջանֆիդայի Էդ. Դաշտոյանի անվ. մ/դ	8	3	գ. Ջանֆիդա	40.0416990000000013	44.0266850000000005	3	2	Հակոբ Սրեյան	55441414	93363768		Մարիամ Հարությունյան	77428062				1	7
898	Շենավանի մ/դ	8	3	գ. Շենավան	40.0569229999999976	43.9305980000000034	3	2	Հակոբյան Դերենիկ	93751696			Նաիրա Գալստյան	94587207				2	\N
901	Սարդարապատի մ/դ	8	3	գ. Սարդարապատ	40.1310519999999968	44.0095919999999978	3	2	Մանուկյան Անահիտ	93186505			Կարինե Սմբատյան	94605555	Օֆելյա Սարգսյան 	094833435		13	13
1006	Զովաբերի մ/դ	8	4	գ. Զովաբեր	\N	\N	3	\N	Պողոսյան Վաչե	95006496	77404494		Ստեփանյան Արմինե	93592408				\N	\N
935	Հովտամեջի մ/դ	8	3	գ. Հովտամեջ	40.182265000000001	44.2564709999999977	3	2	Եղյան Ն.	55189113	ուսմասվար095505768	41512900	Հայկանուշ Մեսրոպյան	77512900				3	\N
936	Մեծամորի մ/դ	8	3	գ. Մեծամոր	40.0726349999999982	44.2919869999999989	3	2	Եղիազարյան Գասպար	95008549	93057822		Էմին Մարտիրոսյան	93759119				5	\N
940	Ոսկեհատի մ/դ	8	3	գ. Ոսկեհատ	40.1456510000000009	44.3327370000000016	3	2	Սյուզաննա Շմավոնյան	93544425	23148020		Պետրոսյան Սոֆիկ	93418062	Թերմինե094851139	տնտեսվարՄարտին093456334		4	\N
941	Պտղունքի Տիգրան Մեծի անվ. մ/դ	8	3	գ. Պտղունք	40.1616349999999969	44.3624340000000004	3	1	Սիլվա Մկրտումյան	94141310	ուսմասվար093197181		Վերոնիկա Լոքյան	94683395	Կարինե043216258			3	\N
943	Փարաքարի հմ/դ	8	3	գ. Փարաքար, Խ.Գասպարյան 2	40.1646429999999981	44.4028360000000006	3	1	Ա. Նարինբեկյան	963636912	77263377		Նաիրա Գրիգորյան	93510759				1	\N
944	Փարաքարի մ/դ	8	3	գ. Փարաքար	40.1624070000000017	44.3991910000000018	3	1	Հակոբյան Վարազդատ	93917555			Լուսինե Սարգսյան	55900248				1	\N
950	Վաղարշապատի Մ. Ա. Ս. Էջմիածնի Է. Օռնեկյանի անվան դպրոց	8	3	ք. Վաղարշապատ, Արարատյան	40.1607940000000028	44.2959770000000006	3	1					Նելլի Խաչատրյան	93206507				8	\N
957	Վաղարշապատի թիվ 9 հմ/դ	8	3	ք. Վաղարշապատ, Կույբիշև 1	40.1574120000000008	44.3016560000000013	3	1	Սամվելյան Մ.	93198534			Վարդանյան Վարդիթեր	55804920	Մարի091008204			7	\N
958	Վաղարշապատի թիվ 11 հմ/դ	8	3	ք. Վաղարշապատ, Չարենց 0	40.1575380000000024	44.2813000000000017	3	1	Սարգսյան 	77082500			Սուսան	91065510				1	\N
963	Լուսագյուղի մ/դ	8	3	գ. Լուսագյուղ	40.0896660000000011	44.269525999999999	3	2	Բաղդասարյան Հ.	93193292			Կոստանդյան Ալինա	94193644				2	\N
964	Հայթաղի Կարապետյանի անվ. մ/դ	8	3	գ. Հայթաղ	40.1802780000000013	44.2284069999999971	3	2	Գաբրիելյան Ռ.	93444090			Վարդանյան Լիլիթ	93114105				6	\N
961	Ապագաի մ/դ	8	3	գ. Ապագա	40.0978530000000006	44.2531230000000022	3	2	Մխիթար Մխիթարյան	93453597			Արմեն Ղուկասյան	55305820				5	\N
954	Վաղարշապատի Մ. Գորկու անվ. թիվ 5 ա/դ	8	3	ք. Վաղարշապատ, Շահումյան 100	40.1578289999999996	44.3045839999999984	3	1	Գ. Սաֆարյան	93185811			Ստեփանյան Լիլիթ	93484805		93050075		13	13
948	Վաղարշապատի Զ. Անդրանիկի անվ. թիվ 12 հմ/դ	8	3	ք. Վաղարշապատ, Արագածի զանգված	40.1676969999999969	44.3243429999999989	3	1	Հովհաննսիյան Վեմիր	93410708			Արշակյան Գոհարիկ	98808619	95131011			7	\N
949	Վաղարշապատի թիվ 2 հտ/դ	8	3	ք. Վաղարշապատ, Զվարթնոց թաղամաս	40.1720129999999997	44.3301069999999982	3	1	Լիանա Սայադյան	93328051				77230006				3	\N
951	Վաղարշապատի թիվ 4 հմ/դ	8	3	ք. Վաղարշապատ, Սպանդարյան	40.1711850000000013	44.2965579999999974	3	1	Արուսյակ Մուրադյան	93575184			Կարինե Մանուկյան	55011017		99778585		1	\N
953	Վաղարշապատի Մ. Խորենացու անվ. թիվ 10 ա/դ	8	3	ք. Վաղարշապատ, Զվարթնոց թաղ.	40.1700930000000014	44.3308109999999971	3	1	Հայկ Բաղդասարյան	93193646			Արմինե Աղաջանյան	93905893	ՄովսիսյանԿարինե	93914869		11	\N
946	Վաղարշապատի Գ. Նժդեհի անվ. թիվ 8 հմ/դ	8	3	ք. Վաղարշապատ, Մանուշյան 1	40.1646149999999977	44.339500000000001	3	1	Գալստյան Եսթեր	93235300			Թովմասյան Թովմաս նախկին օպերատոր	55650657	94243267	95243267		1	4
955	Վաղարշապատի թիվ 1 հմ/դ	8	3	ք. Վաղարշապատ, Բաղրամյան 12	40.1654709999999966	44.2914919999999981	3	1	Հովակիմյան Կարինե	9980023			Կարինե	93723804	Թագուհի	94511707		1	\N
956	Վաղարշապատի Ներսիսյան թիվ 6 հմ/դ	8	3	ք. Վաղարշապատ, Աթարբեկյան 101	40.1650800000000032	44.2848609999999994	3	1	Սեդա Ենգիբարյան	98053707			Նարինե	23147307	95500321			1	\N
934	Հայկաշենի Գ. Կիրակոսյանի անվ. մ/դ	8	3	գ. Հայկաշեն	40.0735079999999968	44.3032690000000002	3	2	Հենրիկ Խրոյան	94861199			Կարինե Անդրեասյան	77776399				0	\N
937	Մուսալեռի Ֆր. Վերֆելի անվ. մ/դ	8	3	գ. Մուսալեռ	40.1543909999999968	44.3756410000000017	3	2	Ա. Վեզիրյան	93529269			Անի	55041670	ՊալոյանՍամվել093562536			4	\N
938	Մրգաստանի Կ. Հարությունյանի անվ. մ/դ	8	3	գ. Մրգաստան	40.1993670000000023	44.2784059999999968	3	2	Ասատրյան Նունուֆար	93555621			Գևորգյան Անահիտ	93194077				1	\N
942	Ջրառատի Թ. Խաչատրյանի անվ. մ/դ	8	3	գ. Ջրառատ	40.0712109999999981	44.2665390000000016	3	2	Հարությունյան Դավիթ	98413839	ուսմասվարՎարդանյան077550027							0	\N
959	Ակնալճի Ա. Հարությունյանի անվ. մ/դ	8	3	գ. Ակնալիճ	40.1434520000000035	44.1595900000000015	3	2	Վարդիթեր Վարդերեսյան	93536859			Լուսինե Բաղդասարյան	77923028				3	\N
960	Ամբերդի Հ. Նավասարդյանի անվ. մ/դ	8	3	գ. Ամբերդ	40.238151000000002	44.2738700000000023	3	2	Զոհրաբ Մաղաքյան	94442256			Մելինե Ստեփանյան	93231777				1	\N
962	Արշալույսի Ս. Գրիգորյանի անվ. մ/դ	8	3	գ. Արշալույս	40.172272999999997	44.2104270000000028	3	2	Է. Եղիազարյան	91330064			Իրինա Գալստյան	77727010				17	\N
939	Նորավանի մ/դ	8	3	գ. Նորավան	40.1699199999999976	44.0296519999999987	3	2	Հովհաննես Ստեփանյան	93280944			Էլյանորա	93439296				3	15
947	Վաղարշապատի Ե. Օտյանի անվ. թիվ 7 հմ/դ	8	3	ք. Վաղարշապատ, Գարեգին Նժդեհ	40.1757989999999978	44.304668999999997	3	1	Վ. Հայրապետյան	93322105			Գայանե Հակոբյան	99336571				1	\N
965	Ջրարբիի մ/դ	8	3	գ. Ջրառատի թ/ֆ	40.0809349999999966	44.2477489999999989	3	2	Է. Պետրոսյան	93809807			Խաչատրյան Արաքսյա	77060039	Անժելա041262720			1	\N
966	Տարոնիկի մ/դ	8	3	գ. Տարոնիկ	40.1352159999999998	44.197575999999998	3	2	Հակոբյան Ա.	93563077			Ղավալյան Արմինե	95224884				6	\N
968	Գանձակի թիվ 1 մ/դ	8	4	գ. Գանձակ	\N	\N	3	\N	Եղիազարյան Հասմիկ	95006497	77668812	96668812	Հակոբյան Քրիստինե	94752013				\N	\N
969	Գանձակի թիվ 2 մ/դ	8	4	գ. Գանձակ	\N	\N	3	\N	Ասատրյան Հրաչիկ	95007592	91764343		Հակոբյան Միկիչ	99382460				\N	\N
970	Ծաղկաշենի մ/դ	8	4	գ. Ծաղկաշեն	\N	\N	3	\N	Սարգսյան Սանասար	95007613	55662685		Գասպարյան Անուշիկ	99236744				\N	\N
971	Կարմիրգյուղի թիվ 1 մ/դ	8	4	գ. Կարմիրգյուղ	\N	\N	3	\N	Շահբազյան Կարինե	95007616	77070759			93601934				\N	\N
972	Կարմիրգյուղի թիվ 2 մ/դ	8	4	գ. Կարմիրգյուղ	\N	\N	3	\N	Ենգոյան Գոհար	95007621	94206651		Իսկանդարյան Ֆրիստիկ					\N	\N
973	Նորատուսի թիվ 1 մ/դ	8	4	գ. Նորատուս	\N	\N	3	\N	Ավետիսյան Վարդ	95007623	93249400		Նիկողոսյան Ստելլա	93591952				\N	\N
974	Նորատուսի թիվ 2 մ/դ	8	4	գ. Նորատուս	\N	\N	3	\N	Ներսիսյան Նաիրա	95007624	93670443		Արմազյան Անուշ	99999374				\N	\N
975	Նորատուսի թիվ 3 մ/դ	8	4	գ. Նորատուս	\N	\N	3	\N	Բաղդասարյան Արեվ	95007626	93217020		Հարությունյան Էդուարդ	93379634				\N	\N
977	Սարուխանի թիվ 2 մ/դ	8	4	գ. Սարուխան	\N	\N	3	\N	Դանիելյան Սվետլանա	95007628	93381137		Մակարյան Արմինե	77908990				\N	\N
978	Սարուխանի թիվ 3 մ/դ	8	4	գ. Սարուխան	\N	\N	3	\N	Բալասանյան Անահիտ	95007629	99999814		Խաչատրյան Հասմիկ	94146625				\N	\N
979	Գավառի ա/դ	8	4	ք. Գավառ, Թումանյան 3	\N	\N	3	\N	Չիչակյան Տաթևիկ	95007631	93335966		Ղուլոյան Արմինե	91710021				\N	\N
980	Գավառի թիվ 1 հմ/դ	8	4	ք. Գավառ, Դեմիրճյան 32	\N	\N	3	\N	Խունոյան Մանուշ	95007632	93388466		Գասպարյան Գոհար	95415749				\N	\N
981	Գավառի թիվ 2 մ/դ	8	4	ք. Գավառ, Հացառատ թաղ.	\N	\N	3	\N	Հակոբյան Անահիտ	95007634	77375752		Ալեքսանյան Հերմինե	96011230				\N	\N
984	Գավառի թիվ 5 մ/դ	8	4	ք. Գավառ, Ազատության փ.	\N	\N	3	\N	Արզաքանյան Սաթիկ	95007637	93345898	99345898	Ավագյան Լալա	99594845				\N	\N
985	Գավառի թիվ 7 մ/դ	8	4	ք. Գավառ, Արծվաքար թ.	\N	\N	3	\N	Մերթարչյան Լաուրա	95007591	99801511		Մելիքյան Լիանա	77617622				\N	\N
986	Գավառի թիվ 8 մ/դ	8	4	ք. Գավառ, Հացառատ թաղամաս	\N	\N	3	\N	Սարգսյան Վլադիմիր	95007392	93378296		Դավթյան Անահիտ	98761873				\N	\N
987	Ճամբարակի Մ. Քոչարյանի անվ. թիվ 2 հմ/դ	8	4	ք. Ճամբարակ	\N	\N	3	\N	Գրիգորյան Կարինե	95007383	91603887	95440600	Սարգսյան Աննա	91039101				\N	\N
988	Աղբերքի մ/դ	8	4	գ. Աղբերք	\N	\N	3	\N	Ղալեչյան Անահիտ	95007382	93393871		Ստեփանյան Վազգուհի	94524159				\N	\N
989	Երանոսի թիվ 1 մ/դ	8	4	գ. Երանոս	\N	\N	3	\N	Հակոբյան Տիգրան	95008592	91217054		Փինողյան Էլիս	93771552				\N	\N
990	Երանոսի թիվ 2 մ/դ	8	4	գ. Երանոս	\N	\N	3	\N	Բավեյան Սաշա	95008554	94090273		Բավեյան Աննա	77664641				\N	\N
993	Լիճքի թիվ 1 մ/դ	8	4	գ. Լիճք	\N	\N	3	\N	Հոխիկյան Աշոտ	95008559	93351083		Հոխիկյան Արմեն	55610546				\N	\N
994	Լիճքի թիվ 2 հմ/դ	8	4	գ. Լիճք	\N	\N	3	\N	Մկրտչյան Գագիկ	95008561	94072454		Լեւոն Մկրտչյան նոր օպերատոր	055 66-85-66				\N	\N
995	Ն.Գետաշենի Ա. Եղիազարյանի թիվ 2 մ/դ	8	4	գ. Ն. Գետաշեն	\N	\N	3	\N	Եղիազարյան Գագիկ	95009312	94935636		Ղուկասյան Սրբուհի	98606800				\N	\N
997	Վաղաշենի մ/դ	8	4	գ. Վաղաշեն	\N	\N	3	\N	Վարդանյան Արթուր	95009295	94011217		Սուվարյան Սյուզաննա	0262/44688				\N	\N
998	Վարդաձորի մ/դ	8	4	գ. Վարդաձոր	\N	\N	3	\N	Հակոբյան Մայիս	95008593	77655412		Ավետիսյան Մաքսիմ	99070504				\N	\N
1003	Դդմաշենի մ/դ	8	4	գ. Դդմաշեն	\N	\N	3	\N	Գալստյան Սեդրակ	95007395	93360696		Մաթևոսյան Անուշ	93021946				\N	\N
982	Գավառի թիվ 3 հմ/դ	8	4	ք. Գավառ, Արծրունի եղբ. 98	\N	\N	3	\N	Հովակիմյան Մելանյա	95007635	93554821		Մուսոյան Աննա	94506833				\N	\N
983	Գավառի թիվ 4 հմ/դ	8	4	ք. Գավառ, Գ. Լուսավորիչի 6	\N	\N	3	\N	Մկրտչյան Գայանե	95007636	91551215	0264 22086	Հակոբյան Անահիտ	77074131				\N	\N
1000	Մարտունու թիվ 1 հմ/դ	8	4	ք. Մարտունի, Կոմիտաս -11	\N	\N	3	\N	Ղազարյան Խանում	95008596	94605004		Զաքարյան Ավետիք	98984598				\N	\N
976	Սարուխանի թիվ 1 մ/դ	8	4	գ. Սարուխան, Գ. Դարբինյան փ. 14	\N	\N	3	\N	Մուդոյան Հայկ	95007627	93203500		Գալոյան Մ.	93363533				\N	\N
1001	Մարտունու ա/դ	8	4	ք. Մարտունի, Նարեկացի 7	\N	\N	3	\N	Ավետիսյան Վրույր	95008598	94516791		Ավետիսյան Գայանե	91404056				\N	\N
1002	Մարտունու թիվ 2 հմ/դ	8	4	ք. Մարտունի, Գարեգին Նժդեհի 4	\N	\N	3	\N	Գալստյան Լեվոն	95008612	77773061		Ավետիսյան Զառա	94942716				\N	\N
999	Վարդենիկի Ա. Օհանյանի անվ. թիվ 2 հմ/դ	8	4	գ. Վարդենիկ, բանավան, շենք 8	\N	\N	3	\N	Գափոյան Սեվադա	95008594	94218775		Հարեյան Սամվել	93387711				\N	\N
996	Վ. Գետաշենի թիվ 2 մ/դ	8	4	գ. Վ. Գետաշեն	\N	\N	3	\N	Բարեյան Պյոտր	95008613	93879182		Ավետիսյան Մ.					\N	\N
1004	Ծաղկունքի Թումանյանի անվ. մ/դ	8	4	գ. Ծաղկունք	\N	\N	3	\N	Անդրեյ Սարգսյան տեր նշան քահանա Սարգսյան	77751160			Ռուզաննա Առաքելյանի	77172979	262 6-00-82			\N	\N
1005	Վարսերի մ/դ	8	4	գ. Վարսեր	\N	\N	3	\N	Ադամյան Ծաղիկ	93764340	95007393		Առաքելյան Ռ.	0261/27469				\N	\N
1007	Լճաշենի մ/դ	8	4	գ. Լճաշեն	\N	\N	3	\N	Մուրադյան Աիդա	95006495			Մանուկյան Վարդուհի	0261/27733	077 69-77-33			\N	\N
1010	Սևանի Յակով Զորբյանի անվ. թիվ 2 հմ/դ	8	4	ք. Սևան, Խաղաղության 3	\N	\N	3	\N	ԳԵվորգյան Կարինե	95006492	94480052		Անտոնյան Լիլիթ	99067171				\N	\N
1011	Սևանի թիվ 4 հմ/դ	8	4	ք. Սևան, Չարենցի 2	\N	\N	3	\N	Մխեյան Մարիետա	95006491	99650678		Գաբրիելյան Նաիրա	91858536				\N	\N
1012	Սևանի Խ. Աբովյանի անվ. ա/դ	8	4	ք. Սևան, Աբովյան 6	\N	\N	3	\N	Մկրտչյան Լիաննա	95006489	91285999		Բադալյան Լիանա	96885686				\N	\N
1013	Սևանի Մ.Մաշտոցի անվ. թիվ 1 հմ/դ	8	4	Ք. Սևան, Նաիրյան 173	\N	\N	3	\N	Նիկողոսյան Աննա	95006487	99119411		Ավետիսյան Արևիկ	93971287	0261/22402			\N	\N
1014	Տրետուքի մ/դ	8	4	գ. Տրետուք	\N	\N	3	\N	Մանուկյան Տարիել	95007497	93812466		Արևշատյան Վիլեն	77878756				\N	\N
1016	Ազատի հմ/դ	8	4	գ. Ազատ	\N	\N	3	\N	Ներսեսյան Վարդան	95007496	94301737		Բայանդուրյան Արմինե					\N	\N
1017	Ակունքի մ/դ	8	4	գ. Ակունք	\N	\N	3	\N	Արշակյան Սարգիս	95007495	94916946		Ղազարյան Արթուր	98932332				\N	\N
1018	Այրքի մ/դ	8	4	գ. Այրք	\N	\N	3	\N	Դավթյան Հրանտ	95007512	93266060		Դավթյան Հեղինե	94266062				\N	\N
1019	Ավազանի հմ/դ	8	4	գ. Ավազան	\N	\N	3	\N	Լալայան Սարգիս	95007498	94516816		Դաբաղյան Էդուարդ	93742209				\N	\N
1020	Գեղամաբակի հմ/դ	8	4	գ. Գեղամաբակ	\N	\N	3	\N	Բարսեղյան Աշխեն	95007478								\N	\N
1021	Գեղամասարի մ/դ	8	4	գ. Գեղամասար	\N	\N	3	\N	Բարսեղյան Աշոտ	95007476	93250099		Շարոյան Անուշ					\N	\N
1022	Խաչաղբյուրի մ/դ	8	4	գ. Խաչաղբյուր	\N	\N	3	\N	Ղազարյան Սամվել	95007475	98088718		Թամարա	093 465505				\N	\N
1023	Կախակնի մ/դ	8	4	գ. Կախակն	\N	\N	3	\N	Խլոյան Արտաշ	95007473	94028882							\N	\N
1024	Կութի մ/դ	8	4	գ. Կութ	\N	\N	3	\N	Կոստանյան Աղվան	95007472	93262244							\N	\N
1025	Կուտականի մ/դ	8	4	գ. Կուտական	\N	\N	3	\N	Ավետիսյան Ռաֆայել	95007587	93317579		Արևշատյան Վիլեն	77878756				\N	\N
1026	Մեծ Մասրիկի մ/դ	8	4	գ. Մեծ Մասրիկ	\N	\N	3	\N	Հակոբյան Ատոմ	95007583	94774700		Մկրտչյան Թերեզա	93234655				\N	\N
1027	Շատջրեքի մ/դ	8	4	գ. Շատջրեք	\N	\N	3	\N	Աբրահամյան Աշոտ	95007554	93273082		Աբրահամյան Տիգրանուհի	77853050				\N	\N
1028	Ջաղացաձորի մ/դ	8	4	գ. Ջաղացաձոր	\N	\N	3	\N	Թադեվոսյան Կարինե	95007549	93400626		Թովմասյան Նարինե	0269/22753				\N	\N
1029	Սոթքի մ/դ	8	4	գ. Սոթք	\N	\N	3	\N	Մելքոնյան Արտակ	95007548	93203045		Խաչատրյան Պարույր	98112662	98712662			\N	\N
1030	Վանեվանի մ/դ	8	4	գ. Վանեվան	\N	\N	3	\N	Քոչարյան Վազգեն	95007546	93843948		Միրզոյան Չինաշխարհիկ	93541513				\N	\N
1039	Մ. Սեբաստացի կրթահամալիրի հիմնական դպրոց	8	5	Ծովակալ Իսակովի 52/6	\N	\N	3	\N	Գոհար Բալջյան	93133807			Սեն	93328186	077033799 տիգրան			\N	\N
1042	Երևանի Աթարբեկյանի անվ. թիվ 61 մ/դ	8	5	Հովսեփյան 91	\N	\N	3	\N	Գրիգորյան Լուսինե	95008789	99659911		Մկրտչյան Հայկանուշ	96500420				\N	\N
1043	Երևանի Ալ. Մյասնիկյանի անվ. թիվ 66 հմ/դ	8	5	Բագրատունյաց 9	\N	\N	3	\N	Այվազյան Զարուհի	420833	95008916		Անահիտ Շահինյան	94420923				\N	\N
1015	Լուսակունքի մ/դ	8	4	գ. Լուսակունք	\N	\N	3	\N	Հարությունյան Անահիտ	95007494	93373092	0269/22743						\N	\N
1036	Երևանի Ա. Երզնկյանի անվ. թիվ 118 ա/դ	8	5	Արզումանյան 8	\N	\N	3	\N	Կ. Հովակիմյան	10391070	98004444		Օգանեզովա Մելանյա	91304322				\N	\N
1037	Երևանի Ա. Հովհաննիսյանի անվ. թիվ 194 հմ/դ	8	5	Նոր-Արեշ 7 փ. 1	\N	\N	3	\N	Մանուկյան Նունե	453920	091/458521		Կեմարջյան Զեփյուռ	93147046				\N	\N
1038	Երևանի Ա. Մանուկյանի անվ. թիվ 93 մ/դ	8	5	Դավիթաշեն 5-րդ փող.	\N	\N	3	\N	Արմեն Թորոսյան	93573203								\N	\N
1040	Երևանի Ա. Շավարշյանի անվ. թիվ 40 հմ/դ	8	5	Վարդանանց 30	\N	\N	3	\N	Դավթյան Հռիփսիմե	91583611	550643		Անահիտ Իշխանյան	93881510				\N	\N
1041	Երևանի Ա. Պուշկինի անվ. թիվ 8 հմ/դ	8	5	Մոսկովյան 17	\N	\N	3	\N	ստեփանյան նատալյա		95008914	564931						\N	\N
1008	Սևանի թիվ 5 մ/դ	8	4	ք. Սևան, Կ. Դեմիրճյան 21	\N	\N	3	\N	Սահակյան Նարինե	95006494	99900618		Դավթյան Սերինե	98922020				\N	\N
1009	ք. Սևանի թիվ 6 մ/դ	8	4	ք. Սևան, Խորհուրդների 8	\N	\N	3	\N	Գեվորգյան Էդիկ	95006493	91207512	98207512	Ավագյան Սերգեյ	93340016				\N	\N
1033	Վարդենիսի Էդ. Պողոսյանի անվ. թիվ 2 հմ/դ	8	4	ք. Վարդենիս, Երևանյան փ. 37	\N	\N	3	\N	Խլոյան Սոֆյա	95007557	98845533		Կարապետյան Ագնեսա	93077232				\N	\N
1034	Վարդենիսի թիվ 1 ա/դ	8	4	ք. Վարդենիս, Երևանյան 103	\N	\N	3	\N										\N	\N
1035	Վարդենիսի թիվ 3 հմ/դ	8	4	ք. Վարդենիս, Լեռնագործների փ.	\N	\N	3	\N	Պետրոսյան Արմեն	95007481	93012235		Արմինե					\N	\N
1048	Երևանի Բ-1 թաղ-ի հանրակրթական դպրոց	8	5	Ա. Բաբաջանյան 47/1	\N	\N	3	\N	Լուսինե Փաշայան	93595244			Արմինե Տեր-Արսենյան	77733885				\N	\N
1049	Երևանի Բ-4 թաղ-ի հանրակրթական դպրոց	8	5	Ա. Բաբաջանյան 38/1	\N	\N	3	\N	Տաթև Բլեյան	77092848	95006361		Անուշ Հովհաննիսյան	93076993				\N	\N
1058	Երևանի Գեղարվեստի վարժարան	8	5	Րաֆֆու 69/1	\N	\N	3	\N	Լուսինե Մանուկյան	99994947			Ծովինար Սարգսյան	93091504				\N	\N
1059	Երևանի Գրիբոյեդովի անվ. թիվ 41 հմ/դ	8	5	Մյասնիկյան 2	\N	\N	3	\N	Մարգարյան Սուսաննա	95008939	93505095							\N	\N
1062	Երևանի Թելմանի անվ. թիվ 13 հմ/դ	8	5	Արշակունյաց 20	\N	\N	3	\N			95006353	525663						\N	\N
1063	Երևանի թիվ 101 մ/դ	8	5	Մուշական	\N	\N	3	\N	Արտեմիս Քեշքերյան	450601	95006352	091/690993	Հայարփի Խարազյան	98026082				\N	\N
1064	Երևանի թիվ 105 ա/դ	8	5	Օտյան 45	\N	\N	3	\N	Սուքիասյան Բելլա	99611414			Ռուզաննա Ստեփանյան	91955454				\N	\N
1065	Երևանի թիվ 107 մ/դ	8	5	Ջրաշենի 1 փ., 41շ.	\N	\N	3	\N	Ս. Ամիրյան	452483	91549558		Մարինե Խաչատրյան	77572277				\N	\N
1066	Երևանի թիվ 108 մ/դ	8	5	Սիլիկյան թաղամաս 10	\N	\N	3	\N	Ավետիսյան Անդրանիկ	95006347	93425521		Գևորգյան Տաթևիկ	93493280				\N	\N
1067	Երևանի թիվ 109 ա/դ	8	5	Մարգարյան 2 նրբ. 14	\N	\N	3	\N	Թադևոսյան Վլադիմիր	91210174	95006348		Վահագն Ավագյան	93425011				\N	\N
1068	Երևանի թիվ 110 հմ/դ	8	5	Ս. Տարոնցի 11	\N	\N	3	\N	Հովակիմյան Տաթևիկ	95006349	91224555		Գալստյան Իրինա	99224555				\N	\N
1069	Երևանի թիվ 111 մ/դ	8	5	Լուկաշինի 1\\5	\N	\N	3	\N	Քեհեյան Անդրանիկ	95006351	353183	91556188	Նադիրյան Գայանե	91529225				\N	\N
1070	Երևանի թիվ 12 հտ/դ	8	5	Սիմոն Վրացյան 75	\N	\N	3	\N	Արշակյան Արծվինե	95008937	552241		Արփինե	552241	95812545			\N	\N
1071	Երևանի թիվ 120 հմ/դ	8	5	Մ. Խորենացի 207	\N	\N	3	\N	Հայրապետյան Գ.	94997916	573460		Նելլի Սարգսյան	94210609				\N	\N
1072	Երևանի թիվ 13 երաժշտական մ/դ	8	5	Ծովակալ Իսակովի 13	\N	\N	3	\N										\N	\N
1073	Երևանի թիվ 134 հմ/դ	8	5	Նանսենի 14փ	\N	\N	3	\N	Հակոբյան Անահիտ	94602424	634800		Արմեն Վանյան	55668153				\N	\N
1074	Երևանի թիվ 136 հմ/դ	8	5	Լեփսիուսի 6 փ.	\N	\N	3	\N	Գրետա Թունյան	200846	240846							\N	\N
1075	Երևանի թիվ 140 հմ/դ	8	5	Նորագավիթ 1-ին փող. 99	\N	\N	3	\N	Սարգսյան Մարինե	91553284	95006341		Աննա Վարդանյան	93544418				\N	\N
1078	Երևանի թիվ 152 հմ/դ	8	5	Արարատյան 1 զանգված	\N	\N	3	\N	Ասատրյան Միխայիլ	93772196	95006338		Արմինե Հարությունյան	91566995				\N	\N
1079	Երևանի թիվ 153 հմ/դ	8	5	Առաքելյան 47	\N	\N	3	\N	Սարգսյան Անուշ	91214232	95006337							\N	\N
1047	Երևանի Արհեստագործական ավագ դպրոց	8	5	Անդրանիկի 92/1	\N	\N	3	\N	Էլեն Թադևոսյան	93484746			Նարիեն Պողոսյան	94132026				\N	\N
1076	Երևանի թիվ 144 հմ/դ	8	5	Վերին Շենգավիթ 2-րդ փող. 9	\N	\N	3	\N	Հովհաննիսյան Գագիկ	91756160			Մելիքյան Հրանուշ	91842012				\N	\N
1077	Երևանի թիվ 147 հմ/դ	8	5	Կ. ՈՒլնեցու 1	\N	\N	3	\N	Ադամյան Լարիսա	245020	95006343		Պայծառ Բոյաջյան	99577333				\N	\N
1044	Երևանի Ալ. Բլոկի անվ. թիվ 122 հմ/դ	8	5	Արզումանյան 5	\N	\N	3	\N	Մալախյան Մարինե	91416772			Սեդրակյան Վիոլետա	99320932				\N	\N
1045	Երևանի Ալ. Շիրվանզադեի անվ. թիվ 21 մ/դ	8	5	Վ. Վաղարշյան 24	\N	\N	3	\N	Երիցյան Նելլի	223110			Շողիկ Շահբազյան	55100953				\N	\N
1046	Երևանի Ավ. Իսահակյանի անվ. թիվ 16 ա/դ	8	5	Բուռնազյան 37	\N	\N	3	\N										\N	\N
1050	Երևանի Գ. Գյուլբեկյանի անվ. թիվ 190 ա/դ	8	5	Հ/Ա Բ - 2 թաղ.	\N	\N	3	\N	Զատիկյան Կարինե	99803939	95006358		Տիգրան Սարգսյան	55539408				\N	\N
1051	Երևանի Գ. Նժդեհի անվ. թիվ 161 հմ/դ	8	5	Բագրատունյաց 32/1	\N	\N	3	\N	Մ. Սինանյան	95006356	94450279	487670	Մարիանա Բադաղյան	91237148				\N	\N
1053	Երևանի Գ. Էմինի անվ. թիվ 182 ա/դ	8	5	Կրիվոյի 55	\N	\N	3	\N	Ռ. Ալավերդյան	540010	93786688		Գայանե Ավետիսյան	55380718				\N	\N
1054	Երևանի Գ. Մահարու անվ. թիվ 176 հմ/դ	8	5	Հովնաթանի 33	\N	\N	3	\N	Մ. Հ. Խաչատրյան	91123429	95008913		Խաչատրյան Աննա	077508014/91735410				\N	\N
1055	Երևանի Գ. Մարգարյանի անվ. թիվ 94 ա/դ	8	5	Բաշինջաղյան 100	\N	\N	3	\N	Վարդանյան Սուսաննա	94100162	95008912		Զինա Խաչատրյան	91373294				\N	\N
1056	Երևանի Գ. Նարեկացու անվ. թիվ 137 հմ/դ	8	5	Ս. Տարոնցի 17	\N	\N	3	\N	Զոհրաբյան Աննա	93262027	95008957		Անահիտ Արտեմյան	94265819				\N	\N
1057	Երևանի Գ. Ստեփանյանի անվ. թիվ 135 հմ/դ	8	5	Ն/Ն2-րդ զ.Սեփանյան 5	\N	\N	3	\N	Ներսեսյան Գարեգին	95008941	632580							\N	\N
1060	Երևանի Դ. Հովսեփյանի անվ. թիվ 191 հմ/դ	8	5	Անդրանիկի 73	\N	\N	3	\N	Թ. Ավդալյան	95006354	94737508		Անյուտա Ալեքսանյան	93350554				\N	\N
1061	Երևանի Է. Բոյաջյանի անվ. թիվ 121 հմ/դ	8	5	Պ. Տիչինայի նրբ.	\N	\N	3	\N	Աղաբեկյան Օֆելյա	95008938	93349560		Հարությունյան Զարուհի	55792500				\N	\N
1080	Երևանի թիվ 157 մ/դ	8	5	Նորք-Մարաշ 11 փողոց 62	\N	\N	3	\N	Միրզոյան Նարինե	94404081			Տիրուհի Նիկողոսյան	94654614				\N	\N
1082	Երևանի թիվ 160 հմ/դ	8	5	Ավանեսովի 10	\N	\N	3	\N	Անահիտ Գալստյան	471700	95006332	094/392098	Էլլադա Հովհաննիսյան	93473775				\N	\N
1641	Վահագնաձորի հմ/դ	8	6	գ. Վահագնաձոր	\N	\N	3	\N	Անահիտ Ջումարդյան	94671484								\N	\N
1084	Երևանի թիվ 167 հմ/դ	8	5	Սարի-թաղ 28 փ. 1	\N	\N	3	\N	Սարգսյան Կիմա	550842			Անուշիկ Հարությունյան	94227384				\N	\N
1085	Երևանի թիվ 168 հմ/դ	8	5	Բաշինջաղյան 1 նրբ	\N	\N	3	\N	Գալստյան Սոնա	94415620	94415020	95006293	Արմինե Ավանիսովա	93365264				\N	\N
1086	Երևանի թիվ 170 ա/դ	8	5	Ավան Թումանյան 3	\N	\N	3	\N	Հարյան Անուշ	95006294	91515518		Նորեկյան Վաչագան	96644722				\N	\N
1087	Երևանի թիվ 171 հմ/դ	8	5	Իսահակյան թաղ.	\N	\N	3	\N	Արամ Սաֆարյան	95006295	10627311							\N	\N
1088	Երևանի թիվ 174 հմ/դ	8	5	Սվաճյան - 42	\N	\N	3	\N	Գ. Վասիլյան	93710310	95006264		Արմինե Խաչատրյան	93203863				\N	\N
1089	Երևանի թիվ 175 մ/դ	8	5	Նուբարաշեն 11 փող.	\N	\N	3	\N	Անահիտ Բաբաջանյան	98368597	476540		Սիմոնյան Պերճուհի	94300840				\N	\N
1090	Երևանի թիվ 178 հմ/դ	8	5	Խաղաղ-Դոնի 25	\N	\N	3	\N	Նինա Բալոյան	91236066			Աղայանց Լիլիթ	470200	93263778			\N	\N
1091	Երևանի թիվ 179 հմ/դ	8	5	Օհանովի փող.	\N	\N	3	\N	Ա. Օհանյան	729110	93262476	95006219	Սուսաննա	77507090				\N	\N
1092	Երևանի թիվ 180 հմ/դ	8	5	Ավան-Առինջ	\N	\N	3	\N	Սարգսյան Լևոն	91471275	95006221		Գոհար Մուրադյան	55321191				\N	\N
1093	Երևանի թիվ 181 հմ/դ	8	5	Բաբաջանյան փողոց 4	\N	\N	3	\N	Վ. Կիրակոսյան	95006225	94901196		Հունանյան Ռուզաննա	94022882				\N	\N
1094	Երևանի թիվ 185 հմ/դ	8	5	Բեկնազարյան 5	\N	\N	3	\N	Քարամյան Համլետ	95006227			Ալոյան Նաիրա					\N	\N
1095	Երևանի թիվ 186 հմ/դ	8	5	Ն/Ն 8-րդ զ.	\N	\N	3	\N	Քոչարյան Մարինե	93064774	95006228							\N	\N
1096	Երևանի թիվ 188 հմ/դ	8	5	Համո Բեկնազարյան 5	\N	\N	3	\N	Խաչատրյան Վարդիթեր	95483596	95006229		Մարգարյան Մարիամ	91097197				\N	\N
1097	Երևանի թիվ 195 ա/դ	8	5	Մազմանյան 5ա	\N	\N	3	\N	Պողոսյան Անահիտ	359555	95006231		Լուսինե Մակարյան	99627230				\N	\N
1098	Երևանի Ա. Նավասարդյանի անվ. թիվ 196 հմ/դ	8	5	Դավթաշեն 4-րդ թաղամաս	\N	\N	3	\N	Նավասարդյան Անուշ	371908	95006232							\N	\N
1099	Երևանի թիվ 197 հմ/դ	8	5	Ն/Ն 9-րդ մ/շ Վիլնյուսի փ.	\N	\N	3	\N	Թադևոսյան Վարսենիկ	656450	664311							\N	\N
1102	Երևանի թիվ 2 հտ/կթհ	8	5	Րաֆֆու 113	\N	\N	3	\N	Շաբոյան Լ.	95006237	95944050							\N	\N
1103	Երևանի թիվ 2 ա/դ	8	5	Տիգրան Մեծի 34	\N	\N	3	\N	Ք. Սարյան	94411135	95006238		Շահինար Բալախչյան	99730130				\N	\N
1104	Երևանի թիվ 200 հմ/դ	8	5	Տ. Պետրոսյան	\N	\N	3	\N	Խալափյան Սիլվա	91345236	99361094	369093	Մխիթարյան Սաթիկ	55365181				\N	\N
1105	Երևանի թիվ 22 հմ/դ	8	5	Գ-3 թաղամաս	\N	\N	3	\N	Թորոսյան Շողիկ	391113			Հասմիկ Գյուրջինյան					\N	\N
1106	Երևանի Ա. Մարգարյանի անվ. թիվ 29 ա/դ	8	5	Սարյան 23	\N	\N	3	\N	Սարուխանյան Ռուզան	91456764	95006242	583270						\N	\N
1107	Երևանի թիվ 31 հմ/դ	8	5	Հ. Հովսեփյան 2	\N	\N	3	\N	Նարիա Հակոբյան	95006243	55995966		Մարիա Մարգարյան	55679669				\N	\N
1108	Երևանի Մ. Նալբանդյանի անվ. թիվ 33 հմ/դ	8	5	Նար-Դոսի փող. 38	\N	\N	3	\N	Իշխանյան Աննա	55573459	95006245	551522	Հակոբյան Մելինե	95556564				\N	\N
1109	Երևանի թիվ 37 հմ/դ	8	5	Քանաքեռ ՀԷԿ 14	\N	\N	3	\N	Պարոնյան Նելլի	95006246			Մարիամ Սերոբյան	94496642				\N	\N
1110	Երևանի թիվ 39 հմ/դ	8	5	Ծխախոտագործների - 1	\N	\N	3	\N	Բաբայան Ա.	95006247	95876103		Գևորգ Գրիգորյան	55642606				\N	\N
1111	Երևանի թիվ 44 հմ/դ	8	5	Մ. Ավետիսյանի 89	\N	\N	3	\N	Մարինա Տոնոյան	091 211-799			Նալանյան Լիլիթ	99124777				\N	\N
1112	Երևանի թիվ 46 ա/դ	8	5	Մանանդյան 2	\N	\N	3	\N	Ա. Հայրապետյան	95595657			Գայանե Գրիգորյան	94354220				\N	\N
1114	Երևանի թիվ 50 հմ/դ	8	5	Շևչենկո 34	\N	\N	3	\N	Վարդանյան Սոս	95838687	95006252		Շողակաթ Բաբայան	55442911				\N	\N
1115	Երևանի Մ. Քաջունու անվ. թիվ 54 ա/դ	8	5	Ն. Տիգրան - 12	\N	\N	3	\N	Պետրոսյան Էթերի	91971555	231891		Իրինա Սանամյան	94889956				\N	\N
1116	Երևանի թիվ 64 հմ/դ	8	5	Վարդաշեն 3-րդ փ. 2 շենք	\N	\N	3	\N	Շահնազարյան Անահիտ	10453331	93388066		Պողոսյան Երանուհի	95260489				\N	\N
1118	Երևանի Մովսես Պողոս Ճամբազյանի անվ. թիվ 79 հմ/դ	8	5	Հ. Հովհաննիսյան 30	\N	\N	3	\N	Ք. Հայրապետյան	95006257	98602012		Մելինե Հարությունյան	463420				\N	\N
1119	Երևանի թիվ 81 մ/դ	8	5	Թաիրովի 14	\N	\N	3	\N	Ամիրյան Գայանե	562855	91950081	95006258	Շաքարյան Լուսինե	94633071				\N	\N
1083	Երևանի թիվ 162 հմ/դ	8	5	Անդրանիկի-4	\N	\N	3	\N	Ստեփանյան Աննա	91236094	95006331		Հասմիկ Բալայան	91086575				\N	\N
1100	Երևանի Հ. Խաչատրյանի անվ. թիվ 199 հմ/դ	8	5	Դավթաշեն 4-րդ թաղ.	\N	\N	3	\N	Ա. Գալստյան	95006235	91838499		Հասմիկ Ենգիբարյան	94360919				\N	\N
1101	Երևանի մտավոր թերզարգացում ունեցող երեխաների թիվ 2 հտ/դ	8	5	Նորքի այգիներ 247	\N	\N	3	\N	Ղազարյան Համլետ	95006236	91421353							\N	\N
1117	Երևանի թիվ 75 հմ/դ	8	5	Ներքին Շենգավիթ 12-րդ փող. 13	\N	\N	3	\N	Մ. Սարգսյան	488890	95006256							\N	\N
1121	Երևանի թիվ 91 հմ/դ	8	5	Ծերենցի 72ա	\N	\N	3	\N	Ղալումյան Է.	93228605			Գոհարբ Այվազյան	95800114				\N	\N
1123	Երևանի թիվ 98 հմ/դ	8	5	Նորագավիթ 1-ին փող. 97	\N	\N	3	\N	Ավագյան Մարիաննա	91322272	485967	95006282	Անահիտ	96002555				\N	\N
1124	Երևանի Թումանյանի անվ. թիվ 32 հմ/դ	8	5	Սևանի 132	\N	\N	3	\N	Քալաշյան Մարինե	95006281	77446339		Քալաշյան Սուսաննա	55518516				\N	\N
1125	Երևանի Լ. Միրիջանյանի անվ. թիվ 155 հմ/դ	8	5	Բաշինջաղյան 2 նրբ.	\N	\N	3	\N	Դանիելյան Լուսինե	10340966	95006279		Ղայթանչյան Գայանե	93112281				\N	\N
1126	Երևանի Լ.Արիսյանի անվ. թիվ 127 ա/դ	8	5	Պ. Սևակի 11	\N	\N	3	\N	Էլոյան Նելսիկ	91456727	95006278		Հայրապետյան Մարիամ	281332	93287870			\N	\N
1127	Երևանի Լ.Բելինսկու անվ. թիվ 38 հմ/դ	8	5	Գ. Նժդեհի 22	\N	\N	3	\N	Վանեսքեհյան Ավետիք	98380038	440066		Սարգսյան Ռոզա	91317694				\N	\N
1134	Երևանի Խաչատուր Աբովյանի անվ. թիվ 2 հմ/դ	8	5	ք. Երևան, Ա. Իսահակյանի 3	\N	\N	3	\N	Հակոբյան Իռեն	583862	95006268	091/483090	Մխիթարյան Գոհար	55548543				\N	\N
1136	Երևանի Կոստան Զարյանի անվ. թիվ 117 հմ/դ	8	5	Ֆանարջյան 15	\N	\N	3	\N	Մարիեն Արիստակեսյան	287697	93302404		Բաբայան Ժաննա	287697				\N	\N
1139	Երևանի Հ.Աճառյանի անվ. թիվ 72 հմ/դ	8	5	Մխիթար Հերացու 2ա	\N	\N	3	\N	Մարտիրոսյան Գայանե	91109943	553581	551843	Քաոյան Անի	93886882				\N	\N
1149	Երևանի Ղևոնդ Ալիշանի անվ. թիվ 95 մ/դ	8	5	Նուբարաշեն 13 փող. 1 տուն	\N	\N	3	\N	Ակոջյան Սոետլաննա	93668160	95006826	476041	Հովսեփյան Շուշանիկ	95517357				\N	\N
1122	Երևանի թիվ 97 ա/դ	8	5	Ներքին Շենգավիթ 12-րդ փող. 1	\N	\N	3	\N	Դավթյան Ս.	99428969			Ալլա Մադաթյան	93336756				\N	\N
1128	Երևանի Լ. Շանթի անվ. թիվ 4 հմ/դ	8	5	Ալեք Մանուկյան 3	\N	\N	3	\N	Վարդանյան Անահիտ	552771	93718175		Սահակյան Անահիտ	99559555				\N	\N
1150	Երևանի Մ. Աբեղյանի անվ. ԵՃՇՊՀ ա/դ	8	5	Խանջյան 9	\N	\N	3	\N	Մ. Էյրամչյան	95006812	526471							\N	\N
1142	Երևանի Հ. Հովհաննիսյանի անվ. թիվ 52 հմ/դ	8	5	Շիրակի 3	\N	\N	3	\N	Նարինե Շառյան	420642	95006816		Մարգարյան Մարիամ	55434643				\N	\N
1140	Երևանի Հ. Ավետիսյանի անվ. թիվ 74 հմ/դ	8	5	Բագրատունյաց 23	\N	\N	3	\N	Պետրոսյան Արսեն	94070767			Ղաջոյան Շուշան	77539602				\N	\N
1138	Երևանի Հ. Մորգենթաուի անվ. թիվ 126 հմ/դ	8	5	Էստոնական 8	\N	\N	3	\N	Արզանյան	91322309			Գոհար Մովսիսյան	55396910				\N	\N
1137	Երևանի կույրերի երեկոյան հտ/դ	8	5	Ն. Տիգրանյան 6	\N	\N	3	\N	Հովսեփյան Ալվարդ	91238778			Տեր-Գևորգյան Անի	77165943				\N	\N
1135	Երևանի Կարեն Դեմիրճյանի անվ. թիվ 139 ա/դ	8	5	Ն/Ն Ն Ստեփանյան 3	\N	\N	3	\N	Սարգսյան Երվանդ	91487007			Գոհար Ղազարյան	95606842				\N	\N
1133	Երևանի Խ. Սամուելյանի անվ. թիվ 47 հմ/դ	8	5	Սարի թաղ 5	\N	\N	3	\N	Խաչատրյան Կարինե	578507	96459040		570310					\N	\N
1132	Երևանի Խ. Աբովյանի ՀՊՄՀ-ի հենակետային վարժ. ա/դ	8	5	Ագաթանգեղոսի 7ա	\N	\N	3	\N	Նաիրա Սաֆարյան	91428863	95006271		Արամ Հարությունյան	91569188				\N	\N
1131	Երևանի Խ. Աբովյանի անվ. թիվ 84 հմ/դ	8	5	Քանաքեռ 14 փող. թիվ 1	\N	\N	3	\N	Էլոյան Արկադի	91428003	95006272	283591						\N	\N
1130	Երևանի Լիսիցիանի անվ. թիվ 34 հմ/դ	8	5	Տիգրան Մեծի 38	\N	\N	3	\N	Նաիրա Մանուկյան	550170	77040305		Փանաջյան Զարուհի	93454795				\N	\N
1129	Երևանի Լ. Տոլստոյի անվ. թիվ 128 հմ/դ	8	5	Ազատության 5	\N	\N	3	\N	Վ. Սուքիասյան	200012	95006274		Սիմոնյան Գայանե	77502889				\N	\N
1148	Երևանի Ղ. Աղայանի անվ. թիվ 63 հմ/դ	8	5	Կիևյան 9	\N	\N	3	\N	Փիրումյան Լուսինե	220369			Հասմիկ Հայրապետյան	96009575				\N	\N
1147	Երևանի Հրանտ Մաթևոսյանի անվ. 96 հմ/դ	8	5	Նոր-Նորք Դ. Մալյան -24	\N	\N	3	\N	Լ. Մկրտչյան	91212107	95006825		Թորոսյան Լիլիթ	77122895				\N	\N
1146	Երևանի ՀՊՃՀ ա/դ	8	5	Տերյան 105, 7-րդ մասնաշենք	\N	\N	3	\N	Համլետ Մարտիրոսյան	91413232	520630		Ռուբինա Ղազարյան	93930404				\N	\N
1145	Երևանի Հակոբ Կոջոյանի անվ. թիվ 15 կթհ.	8	5	Մաշտոցի 2ա և 11	\N	\N	3	\N	Սանյան Գոհար	95006821			Հովհաննիսյան Վարդուհի	93863863				\N	\N
1143	Երևանի Հ. Պարոնյանի անվ. թիվ 59 հմ/դ	8	5	Վարշավյան 45	\N	\N	3	\N	Ադամյան Սամվել	95006818	257279	93221227	Արեգա Մկրտչյան	55207742				\N	\N
1155	Երևանի Մ. Մեծարենցի անվ. թիվ 146 հմ/դ	8	5	Լուկաշինի 6	\N	\N	3	\N	Ա. Դիլբանյան	91762352	95006718		Մարիետա Դավթյան	93300026				\N	\N
1154	Երևանի Մ. Մանուշյանի անվ. թիվ 48 հմ/դ	8	5	Դրոյի 11	\N	\N	3	\N	Արիստակեսյան Ժ>	91889964			Արև Մովսիսյան	94884750				\N	\N
1153	Երևանի Մ. Խորենացու անվ. 143 հմ/դ	8	5	Նորքի 3-րդ զ. Բաղյան 5	\N	\N	3	\N	գարեգին Կոստանյան	91411334			Նարինե Մամյան	665524				\N	\N
1152	Երևանի Մ. Գորգիսյանի անվ. թիվ 158 հմ/դ	8	5	Շիրակի 2-րդ նրբ. 5	\N	\N	3	\N	Գյուլումյան Արև	95006751	91727728		Հովսեփյան Օլյա	93241962				\N	\N
1151	Երևանի Մ. Գալշոյանի անվան թիվ 148 ա/դ	8	5	Սունդուկյանի 78	\N	\N	3	\N	Լ. Հարությունյան	227366	91002162		Գոհար Աբրահամյան	91768603				\N	\N
1303	Ֆանտանի մ/դ	8	7	գ. Ֆանտան	\N	\N	3	\N	Աբրահամյան Կարինե	77808810			Գայանե Կոստանդյան	94682505				\N	\N
1160	Երևանի մտավոր թերզարգացում ունեցող երեխաների թիվ 11 հտ/դ	8	5	Նուբարաշեն 6 փող 1 շենք	\N	\N	3	\N	Խաչիկ Մուրադյան	94241200	476120		Շուշանիկ Հովհաննիսյան	95096530				\N	\N
1169	Երևանի Նար-Դոսի անվ. թիվ 14 մ/դ	8	5	Երվանդ Քոչարի 12/1	\N	\N	3	\N	Բարսեղյան Արուսյակ	550744	95006748	93433615	Արմինե Մանուկյան	93164674				\N	\N
1173	Երևանի պարարվեստի պետական քոլեջ	8	5	Բայրոնի 5	\N	\N	3	\N	Գրիգորյան Արմեն	99119941	56-44-26		Վելիջանյան Գայանե	93190277	95260427			\N	\N
1159	Երևանի Մուրացանի անվ. թիվ 18 հմ/դ	8	5	Բագրատունյաց 32	\N	\N	3	\N	Կ. Կարապետյան	483971	95006596							\N	\N
1158	Երևանի Մոնթե Մելքոնյանի անվ. թիվ 11 հմ/դ	8	5	Հ/Ա Բ2 թաղամաս	\N	\N	3	\N	Ազիզյան Ռ.	91425393	95006716	720221	Համբարձումյան Գայանե	94923641				\N	\N
1157	Երևանի Մ. Սարյանի անվ. թիվ 86. Հ մ/դ	8	5	Բագրատունյաց 45	\N	\N	3	\N	Շառոյան Անահիտ	95006749	91905670		Իսրաելյան Կարիեն	96532225				\N	\N
1156	Երևանի Մ. Մխոյանի անվ. թիվ 68 հմ/դ	8	5	Նոր - Արեշ 8 փ. 56 տուն	\N	\N	3	\N	Ազիզյան Սուսաննա	91555566	452980		Խաչատրյան Ռաֆայել	91651583				\N	\N
1174	Երևանի Ռ. Սևակի անվ. թիվ 151 հմ/դ	8	5	Բաբայան 40	\N	\N	3	\N	Ղազարյան Ջուլիետա	98436355	95006743	255788	Աղամյան Մարինա	93567477				\N	\N
1172	Երևանի Պ. Սևակի անվ. թիվ 123 հմ/դ	8	5	Նոր-Արեշ 35 փողոց, հ. 2	\N	\N	3	\N	Բագդյան Լարիսա	459710			Սիմոնյան Անժելա	454806				\N	\N
1171	Երևանի Շ. Սիմոնյանի անվ. թիվ 112 ա/դ	8	5	Սեբաստիա 84ա	\N	\N	3	\N	Քարամյան Սարգիս	91409487	95006746		Քոչարյան Սարգիս	93389708				\N	\N
1170	Երևանի Շ. Ռուսթավելու անվ. թիվ 23 հմ/դ	8	5	Ռուսթավելու 17	\N	\N	3	\N	Արուսյակ Ադյան	95006747	91329691							\N	\N
1168	Երևանի Ն. Ստեփանյանի անվ. թիվ 71 հմ/դ	8	5	Հանրապետության 72	\N	\N	3	\N	Գայանե Դեմիրյան	91430036	523882		Ռուզաննա Սարուխանյան	55560311				\N	\N
1167	Երևանի Ն. Սաֆարյանի անվ. թիվ 164 հմ/դ	8	5	Ն/Ն-2-րդ զ. Թոթովենցի 7	\N	\N	3	\N			95006529		Մարտիկյան Սեդրակ	91421408				\N	\N
1166	Երևանի Ն. Մեծի անվ. թիվ 124 հմ/դ	8	5	Աճարյան 15	\N	\N	3	\N	Ն. Մարտիրոսյան	91357180								\N	\N
1165	Երևանի Ն. Խաչատրյանի անվ. թիվ 113 մ/դ	8	5	Հաղթանակ 6 փ. 51 շենք	\N	\N	3	\N	Վարդանյան Վարդգես	94610971	95006521		Անահիտ Հակոբյան	94023850				\N	\N
1164	Երևանի Ն. Զարյանի անվ. թիվ 130 հմ/դ	8	5	Հ. Հակոբյանի նրբ. 3	\N	\N	3	\N	Հովհաննիսյան Նարինե	93223491	222300		Աննա Թադևոսյան	91320828				\N	\N
1163	Երևանի Ն. Գոգոլի անվ. թիվ 35 հմ/դ	8	5	Էրեբունի 16	\N	\N	3	\N	Խաչատրյան Կարինե	91406767			Հայհակնուշ Գրիգորյան	55166050	94166050			\N	\N
1162	Երևանի Ն. Աղբալյանի անվ. թիվ 19 հմ/դ	8	5	Տերյան 54	\N	\N	3	\N	Արշրաֆյան Լիանա	587350	91690000		Լուսինե Խաչատրյան	94820879				\N	\N
1179	Երևանի Ս. Շահմուրադյանի անվ. թիվ 85 հմ/դ	8	5	Ծարավ-Աղբյուրի 21	\N	\N	3	\N	Ղուկասյան Դիանա	95006737	91454624	287727	Նարինե Թարջումանյան	91907751				\N	\N
1178	Երևանի Ս. Հովսեփյանի անվ. թիվ 115 ա/դ	8	5	Շիրակի 72/1	\N	\N	3	\N	Անտոնյան Գոհար	95006738	77994811		Արմեն Մկրտչյան	91212931				\N	\N
1177	Երևանի Ս. Խանզադյանի անվ. թիվ 184 ա/դ	8	5	Շերամի փողոց 91ա	\N	\N	3	\N	Հարությունյան Աշոտ	95006739	91313465		Կարեն	91721834				\N	\N
1176	Երևանի Ս. Գևորգյանի անվ. թիվ 189 ա/դ	8	5	Տիգրան Պետրոսյան 1 թաղ.	\N	\N	3	\N	Պետրոսյան Սերգեյ	91430889	95006741							\N	\N
1184	Երևանի Վ. Թեքեյանի անվ. թիվ 92 հմ/դ	8	5	Սեբաստիա 54	\N	\N	3	\N	Մարդանյան Ծովինար	95006731	344005	98344005	արփինե Զաքինյան	91775202				\N	\N
1183	Երևանի Վ. Զատիկյանի անվ. թիվ 90 հմ/դ	8	5	Բատիկյան 89	\N	\N	3	\N	Խոցանյան Սոխակ	772536	93270000		Խոցանյան Սիրամարգ	93500243				\N	\N
1182	Երևանի Ստարովայտովայի անվ. թիվ 177 հմ/դ	8	5	Դուրյան թաղ. 3-24	\N	\N	3	\N	Մադոյան Ռաֆաել	91346454								\N	\N
1181	Երևանի Ստ. Շահումյանի անվ. թիվ 1 հմ/դ	8	5	Մաշտոցի պող. 33	\N	\N	3	\N	Սաքանյան Կարինե	93700074	533223		Օհանյան Զարուհւի	533223				\N	\N
1180	Երևանի Ստ. Զորյանի անվ. թիվ 56 հմ/դ	8	5	Հ. Քոչարի 13	\N	\N	3	\N	Ս. Գալստյան	95006736	272070	228830	Քալողյան Շողիկ	91107768				\N	\N
1186	Երևանի Վ. Համբաձումյանի անվ. թիվ 12 հմ/դ	8	5	Գ. Նժդեհի 11	\N	\N	3	\N	Ստեփանյան Վլադիմիր	95006728	91406901							\N	\N
1187	Երևանի Վ. Համբարձումյանի անվ. թիվ 17 հմ/դ	8	5	Սասունցի-Դավթի 78	\N	\N	3	\N	Նաիրուհի Սարգսյան	450952			Երանոսյան Նունե	91471435				\N	\N
1188	Երևանի Վ. Մայակովսկու անվ. թիվ 7 հմ/դ	8	5	Գրիգոր Լուսավորչի 7	\N	\N	3	\N	Ռուխկյան Վիկտորիա	95006726	524621	77704441						\N	\N
1189	Երևանի Վ. Վաղարշյանի անվ. թիվ 80 հմ/դ	8	5	Ծովակալ Իսակովի 2/1	\N	\N	3	\N	Արսենյան Ռիտա	91210037			Գայանե Եսայան	99294939				\N	\N
1185	Խ. Աբովյանի անվան ՀՊՄՀ-ի հիմնական դպրոց	8	5	Դեղատան 17	\N	\N	3	\N	Ս. Խաչատրյան	527826	95006729	93558844	Նոնա Հայրապետյան	55887001				\N	\N
1193	Երևանի օլիմպիական հերթափոխի պետական մարզական մգ մ/դ	8	5	Մանուկյան 31	\N	\N	3	\N	Գաբրիելյան Արմեն	773430			Աղավնի Տիգրանյան	94722182				\N	\N
1199	Ալավերդու թիվ 4 մ/դ	8	6	ք. Ալավերդի, Սանահին թաղ.	\N	\N	3	\N	Մոսինայն Նունե	91933440			Այդինյան Այդա	32506				\N	\N
1204	Բազումի մ/դ	8	6	գ. Բազում	\N	\N	3	\N	Ալավերդյան Մ.	91959525			Լիլիթ Հովհաննիսյան	98111949				\N	\N
1207	Շահումյանի մ/դ	8	6	գ. Շահումյան	\N	\N	3	\N	ուսմասվարԱպերյան	055 855405								\N	\N
1213	Սպիտակի Վարդանանց անվ. թիվ 4 մ/դ	8	6	ք. Սպիտակ, Այգեստան 53	\N	\N	3	\N	Օ. Պետրոսյան	55953787			Սաթիկ Հովհաննիսյան	94247719				\N	\N
1217	Լոռի Բերդի հմ/դ	8	6	գ. Լոռի Բերդ	\N	\N	3	\N	Ավագյան Էդիկ	91777053			Մելիքյան Լիլիթ	94036400				\N	\N
1218	Կողեսի հմ/դ	8	6	գ. Կողես	\N	\N	3	\N	Տրանդաֆիլով Իլյա	93330019			Հասմիկ Մամաջանյան	55592555				\N	\N
1220	Յաղդանի հմ/դ	8	6	գ. Յաղդան	\N	\N	3	\N	Սիմոնյան Անահիտ	93216947			Աննա Զաքարյան	55104565				\N	\N
1221	Պուշկինոյի հմ/դ	8	6	գ. Պուշկինո	\N	\N	3	\N	Տոնոյան Գագիկ	55817550			Նազարյան Նարեկ	55565859				\N	\N
1223	Արմանիսի հմ/դ	8	6	գ. Արմանիս	\N	\N	3	\N	Արամ Մխոյան	94715273	99715273		Լիզա Վարդանյան	93072077				\N	\N
1224	Բովաձորի մ/դ	8	6	գ. Բովաձոր	\N	\N	3	\N	Խարազյան Սամվել	95007425	25660075							\N	\N
1225	Լեջանի մ/դ	8	6	գ. Լեջան	\N	\N	3	\N	Սահակյան Էդուարդ	94736084			Քրիստինե	94458527				\N	\N
1226	Ուռուտի մ/դ	8	6	գ. Ուռուտ	\N	\N	3	\N	Անուշ Օհանյան	94759892			Այվազյան Հեղինե	91046076				\N	\N
1205	Արջուտի մ/դ	3	6	գ. Արջուտ	\N	\N	3	\N	Սողոմոնյան Անդրանիկ	93861277								\N	\N
1196	Ալավերդու Ակների թիվ 11 մ/դ	8	6	ք. Ալավերդի, Ակներ	\N	\N	3	\N	Ծատինյան Անահիտ	99062871			Հայարփի Սիմոնյան	91696270				3	4
1200	Ալավերդու Թումանյանի անվ. թիվ 2 մ/դ	8	6	ք. Ալավերդի, Ջրավազանի 6ա	\N	\N	3	\N	Լուսինե Միքաելյան	25323057	91022583		Մելանիա Անդրեասյան	094 93-94-84				\N	\N
1190	Երևանի Վ. Վարդևանյանի անվ. թիվ 173 հմ/դ	8	5	Հ. Հովսեփյան 4	\N	\N	3	\N	Մարինյան Նարինե	91180862	95006724		Նունե Բաբայան	77385777				\N	\N
1191	Երևանի Վ. Տերյանի անվ. թիվ 60 հմ/դ	8	5	Տիգրան Մեծի 42	\N	\N	3	\N	Իսկանդարյան Անիչկա	550070	77099522		Տաթևիկ Դավթյան	77565181				\N	\N
1192	Երևանի Րաֆֆու անվան թիվ 36 հմ/դ	8	5	Արաբկիր Կոմիտաս 37	\N	\N	3	\N	Ա. Անդրեասյան	234856	91311189		Կարապետյան Շամիրամ	95274045	274045			\N	\N
1194	Ալավերդու Ս. Նովայի անվ. թիվ 8 մ/դ	8	6	ք. Ալավերդի, Սան. Սարահարթ 3-10 ա	\N	\N	3	\N	Բաբայան Ա.	94099081				91641425				\N	\N
1195	Ալավերդու Ստ. Շահումյանի անվ. թիվ 5 մ/դ	8	6	ք. Ալավերդի, Խուդյակովի 2ա	\N	\N	3	\N	Մելիքսեթյան Լաուրա	91009044	95007361		Վարդանյան Էլմիրա	22231				\N	\N
1197	Ալավերդու Ե. Չարենցի անվ. թիվ 9 մ/դ	8	6	ք. Ալավերդի, Դեբետի 60 ա	\N	\N	3	\N	Ա. Գորգինյան	91591698			Անահիտ Գորգինյան	99591698				\N	\N
1198	Ալավերդու թիվ 12 մ/դ	8	6	ք. Ալավերդի, Սարահարթ 2/26 ա	\N	\N	3	\N	Գոհարիկ Ավետյան	55777175			Գոհար Բարսեղյան	55446080				13	15
1201	Ալավերդու Մ. Թանդիլյանի անվ. թիվ 10 հմ/դ	8	6	ք. Ալավերդի, Շահումյան-2ա	\N	\N	3	\N	Նալբանդյան Սեդա	94581518			Սեդա Բաղդասարյան	99712571				\N	\N
1202	Ալավերդու Մյասնիկյանի անվ. թիվ 7 մ/դ	8	6	ք. Ալավերդի, Սանահին կայ. դպրոցական.114	\N	\N	3	\N	Ռ. Ն. Մելիքսեթյան	93731415	95007656		Հակոբյան Սելինե	91224644				\N	\N
1208	Սպիտակի Ա. Շիրակացու անվ. թիվ 8 մ/դ	8	6	ք. Սպիտակ, Երևանյան խճ. 1	\N	\N	3	\N	Մաթոսյան Ս.	7722145			Պողոսյան Մհեր	93328122				\N	\N
1209	Սպիտակի թիվ 2 մ/դ	8	6	ք. Սպիտակ, Ս. Ավետիսյան 1	\N	\N	3	\N	Մաթոսյան Լ.	91572275			Սուսաննա Հովսեփյան	0255 2 -23 -80				\N	\N
1210	Սպիտակի թիվ 5 հիմնական դպրոց	8	6	ք. Սպիտակ, Իտալական թաղամաս	\N	\N	3	\N	Դավթյան Հ.	77729708								\N	\N
1211	Սպիտակի թիվ 3 հմ/դ	8	6	ք. Սպիտակ, Պանրագործների	\N	\N	3	\N	Հարությունյան Շահեն	99962526			Թագուհի Ոսկանյան	93442410				\N	\N
1212	Սպիտակի Ս. Ավետիսյանի անվ.  մ/դ	8	6	ք. Սպիտակ, Շահումյան 15	\N	\N	3	\N	Սարդարյան Ե.	55333877			Լ. Գրիգորյան	93946183				\N	\N
1216	Գյուլագարակի մ/դ	8	6	գ. Գյուլագարակ	\N	\N	3	\N	Մատինյան Գառնիկ	93098609			Շավերդյան Լուսինե	77126027				5	10
1214	Ամրակիցի մ/դ	8	6	գ. Ամրակից	\N	\N	3	\N	Սարգսյան Գոհար	95016859			Մատինյան Զարուհի	094644102				5	7
1227	Ուրասարի հմ/դ	8	6	գ. Ուրասար	\N	\N	3	\N	Շոլինյան Մարիամ	94788796	93565804		Կոստանդյան Ստեփան	94788796				4	5
1215	Գարգառի Վ. Բալայանի անվ. մ/դ	8	6	գ. Գարգառ	\N	\N	3	\N	Չիլինգարյան Գագիկ	93598839			Սիրվարդ Հարությունյան	99862129				2	10
1219	Հոբարձու մ/դ	8	6	գ. Հոբարձի	\N	\N	3	\N	Կարինե Գալստյան	93881855			Սահակյան Անի	98691684				3	9
1222	Վարդաբլուրի մ/դ	8	6	գ. Վարդաբլուր	\N	\N	3	\N	Հարությունյան Հայկարամ	93226180			Ասրյան Գայանե	99922818				5	8
1228	Սվերդլովի մ/դ	8	6	գ. Սվերդլով	\N	\N	3	\N	Ա. Ղուկասյան	55236335	95007423	95007423	Սաքանյան Մարինե	91088648				\N	\N
1233	Ստեփանավանի Ստ.Շահումյանի անվ. թիվ 1 մ/դ	8	6	ք. Ստեփանավան, Մ.Բաղրամյա	\N	\N	3	\N	Սարգսյան Գ.	93335132			Գայանե Գևորգյան	96004498				\N	\N
1237	ՎՊՄԻ հենակետային վարժարան ա/դ	8	6	ք. Վանաձոր, Տիգրան Մեծի 3	\N	\N	3	\N										\N	\N
1242	Վանաձորի Գայի անվ. թիվ 21 հմ/դ	8	6	ք. Վանաձոր, Նիզամու	\N	\N	3	\N	Սուլյան Սարգիս	93229849			Արմենուհի Ստեփանյան	99048896				\N	\N
1247	Վանաձորի Դ. Վարուժանի անվ. թիվ 16 հմ/դ	8	6	ք. Վանաձոր, Տարոն 4	\N	\N	3	\N	Հարությունյան Ն	93402523			Առաքելյան Արփինե	55610255				\N	\N
1251	Վանաձորի Մաթեմատիկայի և բնագիտ. առարկաների խորացված ուսուցմամբ վարժ.	8	6	ք. Վանաձոր, Վարդանանց 100	\N	\N	3	\N	Ծատուրյան Արմեն	91208126			Պողոսյան Իրինա	93330125				\N	\N
1258	Վանաձորի Ա. Պուշկինի անվ. թիվ 4 հմ/դ	8	6	ք. Վանաձոր, Տիգրան Մեծի 23	\N	\N	3	\N	Խումարյան Համլետ	94817600			Լիանա Կարապետյան	91816571				\N	\N
1229	Ստեփանավանի Ա. Պուշկինի անվ. թիվ 2 մ/դ	8	6	ք. Ստեփանավան, Սուրբ-Նշանի 39	\N	\N	3	\N	Հարությունյան Լիլիա	95007449	25622532		Գագինյան Նարինե	91232311				\N	\N
1230	Ստեփանավանի Երևանի բժշկահոգեբանամանկավարժական գնահատման կենտրոնի մասնաճյուղ հտ/հմդ	8	6	ք. Ստեփանավան, Երիտասարդական 51	\N	\N	3	\N	Սավանյան Նաիրա-նախկին	096272327-նախկին	055597000-նախկին	11743	Դալաքյան Շուշանիկ	55117057				\N	\N
1231	Ստեփանավանի Հ. Թումանյանի անվ. ա/դ	8	6	ք. Ստեփանավան, Մեղապարտի 15-ա	\N	\N	3	\N	Սեդա Թունյան	91760696			Մովսեսյան Գայանե	91193706				\N	\N
1235	Ստեփանավանի վարժ.	8	6	ք. Ստեփանավան, Բաղրամյան 67	\N	\N	3	\N	Բաբաջանյան Ալմիրա	91746963			Պետրոսյան Անժելա	55428746				\N	\N
1234	Ստեփանավանի Վ. Թեքեյանի անվ. թիվ 6 մ/դ	8	6	ք. Ստեփանավան, Ս. Վարդանի 1	\N	\N	3	\N	Վոլոդյա Մարտիրոսյան	94101206			Մարգարիտ Զարգարյան	77001137				\N	\N
1236	ՀՊՃՀ Վանաձորի կրթահամալիրին կից ճարտարագիտական թեքումով հենակետային ավագ-դպրոց վարժարան	8	6	ք. Վանաձոր, Մաշտոցի 117	\N	\N	3	\N	Սիրադեղյան Ա.	93698847								\N	\N
1238	Վանաձորի «Վիդրոջենյա» թիվ 28 հմ/դ	8	6	ք. Վանաձոր, Տարոն 2, ՔՇՀ-3	\N	\N	3	\N	Բրուտյան Ա.	93643343			Մխիթարյան Ռիտա	60423	95007341			\N	\N
1239	Վանաձորի Ա. Բակունցի անվ. թիվ 7 հմ/դ	8	6	ք. Վանաձոր, Թևոսյան 1ա	\N	\N	3	\N	Լուսիկ Սարգսյան	94062686			Անի Պողոսյան	94160375	07716-32-56			\N	\N
1240	Վանաձորի Ա. Խլղաթյանի անվ. թիվ 18 մ/դ	8	6	ք. Վանաձոր, Երևանյան խճ. 155	\N	\N	3	\N	Մուրադյան Արսեն	91586153								\N	\N
1241	Վանաձորի Գ. Չաուշի անվ. թիվ 24 մ/դ	8	6	ք. Վանաձոր, Ներսիսյան 6	\N	\N	3	\N										\N	\N
1243	Վանաձորի Եղ. Չարենցի անվ. թիվ 12 հմ/դ	8	6	ք. Վանաձոր, Անանիա Շիրակացու 12 ա	\N	\N	3	\N	Հովակիմյան Մարինե	55203346			Մելքոնյան Էդիտա	55811898				\N	\N
1244	Վանաձորի թիվ 1 հատուկ (օժանդակ) դպրոց	8	6	ք. Վանաձոր, Բաղրամյան պ/նրբ.22	\N	\N	3	\N	Հարությունյան Սասուն	99996628			Պողոսյան Զինա					\N	\N
1246	Վանաձորի Ծովակալ Իսակովի անվ. թիվ 23 մ/դ	8	6	ք. Վանաձոր, 3 ուսանողական	\N	\N	3	\N	Տաթևիկ Հովսեփյան	99026292			Թագուհի Մամյան	91933353				\N	\N
1245	Վանաձորի Խ. Աբովյանի անվ. թիվ 9 մ/դ	8	6	ք. Վանաձոր, Զորավար Անդրանիկի 71	\N	\N	3	\N	Վարդանյան Անահիտ	55217759			Կարմեն Հովհաննիսյան	0322 29169				\N	\N
1248	Վանաձորի Ղ. Ալիշանի անվ. թիվ 27 հմ/դ	8	6	ք. Վանաձոր, Տարոն 4	\N	\N	3	\N	Գարեգին Քարհանյան	99002280			Հախվերդյան Ռուզան	55017477				\N	\N
1249	Վանաձորի Մ. Խորենացու անվ. թիվ 17 ա/դ	8	6	ք. Վանաձոր, Բաղրամյան 88	\N	\N	3	\N	Սաղաթելյան Թամարա	93266001			Ամիրխանյան Մարիամ	77582814				\N	\N
1250	Վանաձորի Մ. Մաշտոցի անվ. թիվ 15 հմ/դ	8	6	ք. Վանաձոր, Աղայան 69	\N	\N	3	\N	Հախինյան Ժորա	93343679								\N	\N
1252	Վանաձորի Մարշալ Բաղրամյանի անվ. թիվ 26 հմ/դ	8	6	ք. Վանաձոր, Սիվաշավան	\N	\N	3	\N	Խարազյան Մարգարիտա	91752146			Ինեսա Գրիգորյան	55888679				\N	\N
1253	Վանաձորի Պ. Սևակի անվ. թիվ 30 հմ/դ	8	6	ք. Վանաձոր, Տարոն 2, Ուկրաինական	\N	\N	3	\N	Դարբինյան Ս.	95007241	99360069		Չատինյան Լիլիթ	05556-43-47				\N	\N
1255	Վանաձորի Ստ. Զորյանի անվ. թիվ 22 հմ/դ	8	6	ք. Վանաձոր, Բանակի 29	\N	\N	3	\N	Դ. Մելքոնյան	22977	91540050		Սիրանուշ Խաչատրյան	77973300				\N	\N
1256	Վանաձորի Ստ. Շահումյանի անվ. թիվ 6 հմ/դ	8	6	ք. Վանաձոր, Գր. Լուսավորչի 47	\N	\N	3	\N	Նուրիկյան Լյուդմիլա	55328091			Ռուզաննա Պեպանյան	77343389				\N	\N
1257	Վանաձորի Ա. Մաթրոսյանի անվ. թիվ 8 հմ/դ	8	6	ք. Վանաձոր, Մաշտոցի 7	\N	\N	3	\N	Սարուխանյան Անուշ	095758507			Մխիթարյան Սյուզի	77641652				\N	\N
1259	Վանաձորի Ա.Հ.Կ. Վազգեն 1-ի  անվ. թիվ 1 հմ/դ	8	6	ք. Վանաձոր, Մյասնիկյան 10	\N	\N	3	\N	Գայանե Հովիվյան	91475993			Միկիչյան Արեգնազան	93506444				\N	\N
1268	Բլագոդորնոյեի հմ/դ	8	6	գ. Բլագոդարնոյե	\N	\N	3	\N	Սուքիասյան Սուսաննա	93028750								\N	\N
1272	Ձյունաշողի մ/դ	8	6	գ. Ձյունաշող	\N	\N	3	\N	Հայրապետյան Փիրուզա	77723805			Էռնա Ծատուրյան	93165322				\N	\N
1273	Մեդովկայի մ/դ	8	6	գ. Մեդովկա	\N	\N	3	\N	Սուսաննա Ավդալյան	94103623								\N	\N
1279	Սարատովկայի մ/դ	8	6	գ. Սարատովկա	\N	\N	3	\N	Մարդոյան Ռիմա	98907165			Գ. Հակոբյան	94777402				\N	\N
1281	Աբովյանի թիվ 8 հմ/դ	8	7	ք. Աբովյան, Սարալանջ	\N	\N	3	\N	Ս. Օհանյան	93269331			Լիլիթ Պետրոսյան	77433400				\N	\N
1283	Եղվարդի թիվ 3 հմ/դ	8	7	ք. Եղվարդ, Երևանյան 7	40.3085060000000013	44.4763420000000025	3	1	Հայկանուշ Հովհաննիսյան	93722969			Գևորգյան Կարմեն	98360909				\N	\N
1290	Աբովյանի թիվ 2 հմ/դ	8	7	ք. Աբովյան, Տարտուի 1	\N	\N	3	\N	Հովհաննսիյան Սվետլաննա	91338222			Լիաննան Մանուկյան	91090696				\N	\N
1291	Աբովյանի թիվ 4 ա/դ	8	7	ք. Աբովյան, Ռոսիա 26	\N	\N	3	\N	Ն. Քեշիշյան	98036246			Կարինե	055 578582				\N	\N
1292	Աբովյանի թիվ 6 ա/դ	8	7	ք. Աբովյան, Սարալանջ	\N	\N	3	\N	Վարդանյան Հովհաննես	93045002			Մարիետա Պողոսյան	077 23-90-91				\N	\N
1294	Աբովյանի կթհ	8	7	ք. Աբովյան, ուսանողական թ	\N	\N	3	\N	Դաղբալյան Ա.	99900433			Պողոսյան Մարիամ	55224416				\N	\N
1296	Ջրաբերի մ/դ	8	7	գ. Ջրաբեր	\N	\N	3	\N	Հայրապետյան Արամայիս	94459356			Մարիան Հակոբյան	95569523				\N	\N
1275	Մեծավանի թիվ 2 մ/դ	8	6	գ. Մեծավան	\N	\N	3	\N	Արարատ Սոլոյան	098426242	94859636		Փիրյուզա	094723805				\N	\N
1280	Աբովյանի թիվ 1 հտ/դ	8	7	ք. Աբովյան	\N	\N	3	\N	Տաթև Շիրինյան	93549367			Ռոզա-գործավար	77564055	Հովհաննիսյան Լիպարիտ	077497746		2	2
1274	Մեծավանի թիվ 1 մ/դ	8	6	գ. Մեծավան	\N	\N	3	\N	Մխոյան Ալվարդ	93053730			Սոլոյան Անի					2	14
1260	Վանաձորի Ավ. Իսահակյանի անվ. թիվ 2 հմ/դ	8	6	ք. Վանաձոր, Մխ.Հերացու 20	\N	\N	3	\N	Մադոյան	23526								\N	\N
1262	Վանաձորի Պ. Տիչինայի անվ. թիվ 20 հմ/դ	8	6	ք. Վանաձոր, Տիգրան Մեծի 75ա	\N	\N	3	\N	Աթոյան Կարինե	40074	093 111-889		Լիզա Մարգարյան	94991465				\N	\N
1263	Վանաձորի Հ. Թումանյանի անվ. թիվ 3 հմ/դ	8	6	ք. Վանաձոր, Տիգրան Մեծի 31	\N	\N	3	\N	Թազագուլովա Սվետլաննա	95007229	44696		Նաիրա Մխիթարյան	93078009				\N	\N
1264	Վանաձորի Ս. Նովայի անվ. թիվ 10 ա/դ	8	6	ք. Վանաձոր, Աղայան	\N	\N	3	\N	Պարանյան Խաչատուր Գուրգենի	098 54-25-66	055 54-25-66	0322 4 93 31	Համբարձումյան Անի	93967939				\N	\N
1265	Վանաձորի Վ. Համբարձումյանի անվ. թիվ 25 մ/դ	8	6	ք. Վանաձոր, Համբարձումյանի 2 շ.	\N	\N	3	\N	Ճաղարյան Սիլվարդ	93528903			Արթուր Գրիգորյան	77943430				\N	\N
1266	Վանաձորի Տերյանի անվ. թիվ 5 ա/դ	8	6	ք. Վանաձոր, Տիգրան Մեծի փակուղի 1-1	\N	\N	3	\N	Բարոյան Լյովա	93091196			Սաֆարյան Եղիշե	94858516				\N	\N
1267	Վանաձորի Րաֆֆու անվ. թիվ 19 մ/դ	8	6	ք. Վանաձոր, Չուխաջյան 12ա	\N	\N	3	\N	Անուշ Եդոյան	55068668			Նելլի Գրիգորյան	94043326				\N	\N
1276	Տաշիրի ա/դ	8	6	ք. Տաշիր, Սայաթ-Նովա 5	\N	\N	3	\N	Պետրոսյան Արշակ	91421723			Լոռա Հազոյան	77420381				\N	\N
1282	Աբովյանի Ն. Վանյանի անվ. թիվ 5 մ/դ	8	7	ք. Աբովյան, 2-րդ միկրոշրջան	\N	\N	3	\N	Էմին Եղիազարյան	93593232								\N	\N
1278	Տաշիրի թիվ 1 հմ/դ	8	6	ք. Տաշիր	\N	\N	3	\N	Դրմեյան Բագրատ	94011504								\N	\N
1277	Տաշիրի թիվ 2 հմ/դ	8	6	ք. Տաշիր, Կ. Դեմիրճյան	\N	\N	3	\N	Սալվի ՄելոյաՆ	91201580			Բաղդասարյան Սյուզաննա	94212055				\N	\N
1289	Աբովյանի Խ. Աբովյանի անվ. թիվ 1 ա/դ	8	7	ք. Աբովյան, Բարեկամության 9	\N	\N	3	\N	Ս. Հանիսյան	99865883			Լուսինե Սարգսյան	93614640	91614640			\N	\N
1293	Աբովյանի թիվ 7 հմ/դ	8	7	ք. Աբովյան, 2-րդ միկրոշրջան	\N	\N	3	\N	Գասպարյան Գոհար	77215191			աստղիկ	98004737				\N	\N
1284	Եղվարդի Հ. Թադևոսյանի անվ. թիվ 2 հմ/դ	8	7	ք. Եղվարդ, Սաֆարյան 88	40.3211889999999968	44.4816819999999993	3	1	Աբգարյան Վարվառա	94254597			Վալենտինա Բաբայան	77807577				\N	\N
1285	Բալահովիտի Ի. Վիրաբյանի անվ. մ/դ	8	7	գ. Բալահովիտ	\N	\N	3	\N	Խաչատրյան Թ.	91795657			Ե. Մնացականյան	93197115				\N	\N
1287	Զովքի Գ. Շահինյանի անվ. մ/դ	8	7	գ. Զովք	40.2078920000000011	44.6935689999999965	3	2	Առաքելյան Շողիկ	77827015			Ավչյան Անահիտ	77904598				\N	\N
1288	Կոտայքի Ս. Վարդանյանի անվ. մ/դ	8	7	գ. Կոտայք	\N	\N	3	\N	Վարդանյան Արա	55457916			Հռիփսիմե Թադևոսյան	55741929				\N	\N
1295	Մայակովսկու Հր. Հովհաննիսյանի անվ. մ/դ	8	7	գ. Մայակովսկի	\N	\N	3	\N	Տ. Ղազանչյան	93508347			Անի Պետրոսյան	93937573				\N	\N
1297	Բյուրեղավանի գիշերօթիկ հաստատություն	8	7	ք. Բյուրեղավան	\N	\N	3	\N	Գալստյան Մարինա	22265180	93750401		Արթուր Ղազարյան					\N	\N
1286	Գեղաշենի մ/դ	8	7	գ. Գեղաշեն	\N	\N	3	\N	Նաիրա Բաբայան	98090608			Մակարյան Հասմիկ	94537923				15	27
1270	Լեռնահովիտի մ/դ	8	6	գ. Լեռնահովիտ	\N	\N	3	\N	Բուլղադարյան Արաքսյա	94017089			Հեղինե Պողոսյան	77389096				5	20
1271	Կաթնառատի մ/դ	8	6	գ. Կաթնառատ	\N	\N	3	\N	Ռեվազյան Հայկանուշ	93881824			Մովսիսյան Անիկ	94728009				1	9
1298	Բյուրեղավանի թիվ 2 հմ/դ	8	7	ք. Բյուրեղավան	\N	\N	3	\N	Սարգսյան Մ.	99992105			Լիլիթ Գրիգորյան	93886694				\N	\N
1299	Բյուրեղավանի Ս. Վարդանյանի անվ. թիվ 1 ա/դ	8	7	ք. Բյուրեղավան	\N	\N	3	\N	Խաչիկյան Կ.	94507225								\N	\N
1300	Ջրառատի մ/դ	8	7	գ. Ջրառատ	\N	\N	3	\N	Բեգլարյան Ալեքսան	91693749			Բեգլարյան Գուրգեն	95708092				\N	\N
1301	Սոլակի մ/դ	8	7	գ. Սոլակ	\N	\N	3	\N	Դավթյան Լիդա	22325726	94200117		Արմինե Ասատրյան	77488477				\N	\N
1302	Քաղսի մ/դ	8	7	գ. Քաղսի	\N	\N	3	\N	Մելքոնյան Վաչագան	93651790								\N	\N
1340	Կապսի մ/դ	8	8	գ. Կապս	\N	\N	3	\N	Խոջումյան Նելլի			77438305	Աննա Մկոյան	94632153				\N	\N
1307	Հրազդանի թիվ 14 հմ/դ	8	7	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Բավեյան Անդրանիկ	94910460	22363022		Խաչատրյան Գալինա	98921416				\N	\N
1313	Հրազդանի Վ. Մայակովսկու անվ. թիվ 10 ա/դ	8	7	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Բարսեղյան Վլադիմիր	22333720	93805202		Դավթյան Արմենուհի	91171967				\N	\N
1314	Հրազդանի Րաֆֆու անվ. թիվ 7 մ/դ	8	7	ք. Հրազդան, Կաքավաձոր	\N	\N	3	\N	Հասմիկ Ասատրյան	22360645	93237697		Գոհար Միքայելյան	93681234				\N	\N
1315	Կարենիսի մ/դ	8	7	գ. Կարենիս	\N	\N	3	\N	Խաչատրյան Նշան	22360012	93868429		Աբրահամյան Հասմիկ	94759878				\N	\N
1317	Չարենցավանի թիվ 2 հմ/դ	8	7	ք. Չարենցավան, V թաղ.	\N	\N	3	\N	Գասպարյան Անատոլի	91232319	22641652		Խաչատրյան Ռոզա	77496262				\N	\N
1321	Զորավանի մ/դ	8	7	գ. Զորավան	40.3547190000000029	44.526921999999999	3	2	Հովհաննիսյան Հենրիետա	93973797			Շողիկ Սարգսյան	77502648				\N	\N
1323	Մրգաշենի մ/դ	8	7	գ. Մրգաշեն	\N	\N	3	\N	Գ. Գրիգորյան	93354408			Թևանյան Մանուշակ	93975776				\N	\N
1324	Քանաքեռավանի մ/դ	8	7	գ. Քանաքեռավան	40.246259000000002	44.531210999999999	3	2	Կարապետյան Գոհար	91367011								\N	\N
1328	Ազատանի մ/դ	8	8	գ. Ազատան	\N	\N	3	\N	Ոսկանյան Համլետ	95008568	94121412		Մարգարյան Նատալյա	94726246				\N	\N
1330	Ախուրյանի թիվ 1 հմ/դ	8	8	գ. Ախուրյան	\N	\N	3	\N	Ենգոյան Աննա	95008569	91451306		Սերոբյան Աննա	99192424				\N	\N
1331	Ախուրյանի թիվ 2 հմ/դ	8	8	գ. Ախուրյան	\N	\N	3	\N	Մուշեղյան Նարինե	95009272	91777687		Հասմիկ Սաֆարյան	93903543				\N	\N
1333	Այգաբացի մ/դ	8	8	գ. Այգաբաց	\N	\N	3	\N	Հուրոյան Հռիփսիկ	93844176			Հուրոյան Սիսակ	93078537				\N	\N
1304	Հրազդանի Ա. Իսահակյանի անվ. թիվ 9 հմ/դ	8	7	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Շաբոյան Ժանետա	22363077	94247004		Սարդարյան Հասմիկ	94112216				\N	\N
1305	Հրազդանի Ա. Մռավյանի անվ. թիվ 4 հմ/դ	8	7	ք. Հրազդան, Շահումյան 170	\N	\N	3	\N	Նահապետյան Արևիկ	22362314	98123012		Սուսաննա Հովասյան	94001063				\N	\N
1306	Հրազդանի Ե. Չարենցի անվ. թիվ 2 հմ/դ	8	7	ք. Հրազդան, Կոստանյան 1	\N	\N	3	\N	Սուսաննա Ալեքսանյան	22324743	93246454		Էվելինա Առաքելյան	94312851				\N	\N
1308	Հրազդանի Հ. Թումանյանի անվ. թիվ 5 հմ/դ	8	7	ք. Հրազդան, Ջրառատ թաղամաս	\N	\N	3	\N	Ստեփանյան Սամվել	91333909	22326498		Աստղիկ Գալստյան	93174700				\N	\N
1309	Հրազդանի Հ. Օրբելու անվ. թիվ 13 ա/դ	8	7	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Հարությունյան Հասմիկ	22326404	93584210		Ալեքսանյան Արտյոմ	93157614				\N	\N
1310	Հրազդանի Հ. Պարոնյանի անվ. թիվ 12 հմ/դ	8	7	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Միքայելյան Գագիկ	22334556	77574575		Օհանյան Մարիամ	98777116				\N	\N
1311	Հրազդանի Պ. Սևակի անվ. թիվ 8 հմ/դ	8	7	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Գրիգորյան Գևորգ	93268683	22325907		Ղուշչյան վարսենիկ	22325907				\N	\N
1312	Հրազդանի Վ. Սարոյանի անվ. թիվ 11 մ/դ	8	7	ք. Հրազդան, Միկրոշրջան	\N	\N	3	\N	Զաքարյան Մելսիկ	22322851	94082299		Սահակյան Նաիրա	94400335				\N	\N
1316	Չարենցավանի Ե. Չարենցի անվ. թիվ 5 հմ/դ	8	7	ք. Չարենցավան, VI թաղ.	\N	\N	3	\N	Խաչատրյան Ալլա	22642355	93857985		Հայրապետյան Գայանե	77995429				\N	\N
1318	Չարենցավանի թիվ 6 հմ/դ	8	7	ք. Չարենցավան, II միկրոթաղ	\N	\N	3	\N	Փանոսյան Արմինե	93731336			Կիրակոսյան Անուշ	99604034				\N	\N
1319	Չարենցավանի Մ. Մաշտոցի անվ. թիվ 1 ա/դ	8	7	ք. Չարենցավան, I Ա թաղ.	\N	\N	3	\N	Փանոսյան Գայանե	94527885			Սարիբեկյան Տաթևիկ	94818642				\N	\N
1320	Չարենցավանի Ս. Ավանյանի անվ. թիվ 4 հմ/դ	8	7	ք. Չարենցավան, IV թաղ.,  շինարարների 4	\N	\N	3	\N	Խանսամանյան Տիգրան	93599112			Հասմիկ Պարսամյան	93260947				\N	\N
1322	Նոր Հաճնի թիվ 2 ա/դ	8	7	ք. Նոր Հաճն, Է. Տոռոզյանի 13	\N	\N	3	\N	Սիլվա Վանեսյան	93327762			Կիրակոսյան Մարինե	94968617				\N	\N
1325	Նոր Հաճնի թիվ 3 հմ/դ	8	7	ք. Նոր Հաճն, Է. Տոռոզյան	\N	\N	3	\N	Գարիկ Աբրահամյան	91942397			Արմինե Աղայան	99838858				\N	\N
1327	Թեղենիքի Վ. Ջինիշյանի անվ. մ/դ	8	7	գ. Թեղենիք	\N	\N	3	\N	Գրիգորյան Լաուրիկ	98106306			Տանյա Պողոսյան	98699332				\N	\N
1332	Ախուրյանի Ն. Աղբալյանի անվ. ա/դ	8	8	գ. Ախուրյան	\N	\N	3	\N	Պապիկյան Խանում	95009271	93380917		Քրիստինե Հարությունյան	98011228				\N	\N
1329	Ախուրիկի մ/դ	8	8	գ. Ախուրիկ	\N	\N	3	\N	Գասպարյան Վահիդա	95008615	91471261		Արփինե Դարբինյան	098040217 				3	3
1334	Առափիի մ/դ	8	8	գ. Առափի	\N	\N	3	\N	Նազարյան Ստեփան	95009267	98203933		Մանիկ Նազարյան	98640565				\N	\N
1337	Գետքի մ/դ	8	8	գ. Գետք	\N	\N	3	\N	Հերմինե Թադևոսյան	91558605	95009256							\N	\N
1339	Կամոյի Շիրազի անվ. մ/դ	8	8	գ. Կամո	\N	\N	3	\N	Էդվարդ Դրմեյան	95009251	94917562		Մերի Հակոբյան	94010311				\N	\N
1642	Ահնիձորի հմ/դ	8	6	գ. Ահնիձոր	\N	\N	3	\N										\N	\N
1343	Հացիկի մ/դ	8	8	գ. Հացիկ	\N	\N	3	\N	Պետրոսյան Համլետ	95009227	91211868		Արմինե Աբգարյան	99768684				\N	\N
1344	Հովիտի մ/դ	8	8	գ. Հովիտ	\N	\N	3	\N	Սանդրոսյան Սաթենիկ	95009218	93403985		Կարինե Հակոբյան	93229108				\N	\N
1345	Հովունու մ/դ	8	8	գ. Հովունի	\N	\N	3	\N	Հակոբյան Հասմիկ	95009216	98181390		Ռիմա Ղանդիլյան	777624454				\N	\N
1346	Ղարիբջանյանի մ/դ	8	8	գ. Ղարիբջանյան	\N	\N	3	\N	Յայլոյան Վաղարշակ	95009214	94052211		Անահիտ Հազիբյան	77052211				\N	\N
1347	Մայիսյանի մ/դ	8	8	գ. Մայիսյան	\N	\N	3	\N	Կարախանյան Վարդան	95009212	93628926		Գարնիկ Ղամբարյան	55539987				\N	\N
1348	Մարմաշենի մ/դ	8	8	գ. Մարմաշեն	\N	\N	3	\N	Մխիթարյան Հրաչիկ	95009198	91572056		Մխիթար Մխիթարյան փոխվել է	91324152				\N	\N
1349	Նոր Ախուրյանի հմ/դ	8	8	գ. Ախուրյան	\N	\N	3	\N	Սահակյան Մերուժան	95009197			Աննա Սահակյան	93321681				\N	\N
1353	Վահրամաբերդի մ/դ	8	8	գ. Վահրամաբերդ	\N	\N	3	\N	Թորոսյան Սպարտակ	95009186	93444211		Ռոբերտ Հովսեփյան	93313342				\N	\N
1355	Բյուրակնի մ/դ	8	8	գ. Բյուրակն	\N	\N	3	\N	Լուսինե Մելիքյան	094 82-12-76			Մելիքյան Առաքել					\N	\N
1356	Մեղրաշատի մ/դ	8	8	գ. Մեղրաշատ	\N	\N	3	\N	Բարսեղյան Լենա	95008947	94889112							\N	\N
1357	Ողջիի մ/դ	8	8	գ. Ողջի	\N	\N	3	\N			077 50-82-82.							\N	\N
1360	Իսահակյանի մ/դ	8	8	գ. Իսահակյան	\N	\N	3	\N	Հարությունյան Գնել	95009782	93410129		Ամալյա Արսենյան	98424882				\N	\N
1361	Շիրակավանի մ/դ	8	8	գ. Շիրակավան	\N	\N	3	\N	Մկրտչյան Ջուլիետա	95009781	93325291		Մինաս Բալոյան	77333237				\N	\N
1362	Մարալիկի թիվ 1 մ/դ	8	8	ք. Մարալիկ	\N	\N	3	\N	Հովհաննիսյան Կարինե	95009778			Ավդալյան Լիլիթ	0242/2-25-10	055 09-19-77			\N	\N
1363	Նոր Կյանքի մ/դ	8	8	գ. Նոր Կյանք, 7 փողոց 2	\N	\N	3	\N	Պետրոսյան Զավեն	95008735	93826437		Զարուհի Պետրոսյան	93668826				\N	\N
1364	Փանիկի մ/դ	8	8	գ. Փանիկ	\N	\N	3	\N	Գևորգյան Սամվել	95008734	94001949		Արմեն Գևորգյան	77902077				\N	\N
1365	Արթիկի թիվ 1 հմ/դ	8	8	ք. Արթիկ, Թումանյան 28	\N	\N	3	\N	Մայորյան Սիրական	95008732	94914888		Գայանե Մահորյան	55015919				\N	\N
1367	Արթիկի թիվ 4 հմ/դ	8	8	ք.Արթիկ, Հակոբյան 8	\N	\N	3	\N	Արուսյակ Ստեփանյան	95008731	93404535		Նուշիկ Ղազարյան	93225999				\N	\N
1354	Քեթիի մ/դ	3	8	գ. Քեթի	\N	\N	3	\N	Նիկողոսյան Ալիսա	95009185	93632309		Նարինե Խաչատրյան	93241062				\N	\N
1351	Ջաջուռի մ/դ	3	8	գ. Ջաջուռ	\N	\N	3	\N	Թամարա Սուվարյան	95009189	91165774		Աիդա Տոնոյան	77415241				\N	\N
1335	Արևիկի մ/դ	8	8	գ. Արևիկ	\N	\N	3	\N	Թորոյան Հակոբ	93182848			Արմինե Դիլբաղյան	094470167				3	10
1341	Կառնուտի մ/դ	8	8	գ. Կառնուտ	\N	\N	3	\N	Հովհաննիսյան Հայկուհի	093858435			Ծառուկյան Սյուզի	77407565				1	10
1373	Գյումրու «Սուրբ թարգմանչածե թիվ 30 հմ/դ	8	8	ք. Գյումրի, Շչեդրինի 7	\N	\N	3	\N	Կարեն Ստեփանյան	77434743	95008487		Անահիտ Հակոբյան	93883470				2	6
1342	Հայկավանի մ/դ	8	8	գ. Հայկավան	\N	\N	3	\N	Կարեն Գալստյան	094091282			Մուրադյան Գայանե	077004169				9	9
1358	Անիպեմզաի մ/դ	8	8	գ. Անիպեմզա	\N	\N	3	\N	Նազարյան Հասմիկ	95009784	93805209		Սուսաննա Ավջյան	077 759-444				1	1
1352	Ջրառատի մ/դ	8	8	գ. Ջրառատ	\N	\N	3	\N	Սուքիասյան Արա	95009187	93398544				խաչատրյան Հայկանուշ	094503822		2	6
1366	Արթիկի թիվ 1 հտ/դ	8	8	ք. Արթիկ, Սասունցի Դավթի 1	\N	\N	3	\N	Ճգնավորյան Անդրանիկ	95008757	93824827	0244/52831	Հաջարյան Լիլիթ	77056701				\N	\N
1368	Արթիկի թիվ 5 հմ/դ	8	8	ք. Արթիկ, Շինարարների փ. 1	\N	\N	3	\N	Պետրոսյան Արսեն	95008763	94821629		Մարինե Չոբանյան	93852557				\N	\N
1369	Արթիկի թիվ 7 ա/դ	8	8	ք. Արթիկ, Տուֆագործների 15	\N	\N	3	\N	Բաբոյան Սերյոժա	95008728	93339747		Չարչյան Նարինե	94621100				\N	\N
1371	«Գյումրու Օլիմպիական հերթ. պետ. մարզական քոլեջ»	8	8	ք. Գյումրի, Բուլվարային 10ա	\N	\N	3	\N	Հակոբ Փանոսյան	95008483	93101050		Սոֆի Ջեյրանյան	93277757				\N	\N
1372	Գյումրու «Պրոգրեսե համ.-ի հենակ. վարժ.	8	8	ք. Գյումրի, Խրիմյան Հայրիկ խճ. 40ա	\N	\N	3	\N	Գոհարիկ Բաղդասարյան	95008486	94222240		Արմինե Խաչատրյան	95694929				\N	\N
1359	Գուսանագյուղի մ/դ	8	8	գ. Գուսանագյուղ	\N	\N	3	\N	Մարգարյան Հենրիկ	94821522		95009783	Գասպարյան Համեստ	94821522				1	5
1336	Բայանդուրի մ/դ	8	8	գ. Բայանդուր	\N	\N	3	\N	Մարտիրոսյան Կարեն	094098020	91098021	95009261	Գրիգորյան Սոֆյա	98567224				2	3
1350	Շիրակի մ/դ	8	8	գ. Շիրակ	\N	\N	3	\N	Հասմիկ Վարդանյան	95009192	93316459		Ռոզա Համբարձումյան	093016564				2	6
1376	Գյումրու Գ.Նժդեհի անվ. թիվ 17 հմ/դ	8	8	ք. Գյումրի, Ռետինի 2	\N	\N	3	\N	Կարապետ Ներսիսյան	95008492	93324460		Ալլա Կարապետյան	93424276				\N	\N
1377	Գյումրու թիվ 1 կթհ	8	8	ք. Գյումրի, Վ.Աճեմյան 40	\N	\N	3	\N	Թադեվոսյան Նաիրա	95008493	93149296		Արփինե	077 208658				\N	\N
1379	Գյումրու թիվ 28 հմ/դ	8	8	ք. Գյումրի, Երևանյան խճ.	\N	\N	3	\N	Մարիամ Առաքելյան	95008495	94409046		Նաիրա Գրիգորյան	77237514				\N	\N
1381	Գյումրու թիվ 42 ա/դ	8	8	ք. Գյումրի, "Մուշ-2" թաղ.	\N	\N	3	\N	Լիաննա Մարդոյան	95008497	93056915		Սյուզաննա Բաբայան	91038906				\N	\N
1383	Գյումրու թիվ 44 հմ/դ	8	8	ք. Գյումրի, Շիրակի օդանավ	\N	\N	3	\N	Արտաշես Հակոբյան	95008512	94441400		Նունե Շահբազյան	93153571				\N	\N
1405	Գյումրու թիվ 38 հմ/դ	8	8	ք. Գյումրի, Բուլվարային 3	\N	\N	3	\N	Շահբազյան Գոհարիկ	95009841	93276341		Նարինե Մխիթարյան	94504981				\N	\N
1389	Գյումրու Վազգեն Ա-ի անվ. թիվ 27 մ/դ	8	8	ք. Գյումրի, Գարեգին Ա 2	\N	\N	3	\N	Կարինե Լալազարյան	94151419	94151419	0312 42337	Աննա Մաքեյան	093831704				1	12
1406	Գյումրու թիվ 45 ա/դ	8	8	ք. Գյումրի, Սպենդիարով 10ա	\N	\N	3	\N	Վարդանյան Աստղիկ	95009832	93773736		Եղոյան Արմինե	093 91-74-01				\N	\N
1393	Գյումրու «Բալատոն» ա/դ	8	8	ք. Գյումրի, Վ. Սարգսյան փ. 15	\N	\N	3	\N	Հովհաննիսյան Արուսյակ	95009857	99147337	55147373	Հայկանուշ Գրիգորյան	91210791				\N	\N
1374	Գյումրու «Տեմպ» վարժարան	8	8	ք. Գյումրի, Մհեր Մկրտչյան 2	\N	\N	3	\N	Աշոտ Պապոյան	95008489	0312/4-35-28		Նունե Բեգլարյան	0312/4-65-83				\N	\N
1382	Գյումրու թիվ 43 հմ/դ	8	8	ք. Գյումրի, "Շերամ-2" թաղամաս	\N	\N	3	\N	Անահիտ Նահապետյան	95008498	55482844		Աննա Էլլարյան	55821609				\N	\N
1375	Գյումրու «Ֆոտոն» վարժ.	8	8	ք. Գյումրի, Անի թաղամաս Եղիշե Չարենցի փողոց 12	\N	\N	3	\N	Մանվել Մովսիսյան	95008491	94331500		Սեդա	 093855877				\N	\N
1392	Գյումրու Ֆ. Վերֆելի անվ. թիվ 40 մ/դ	8	8	ք. Գյումրի, Ավստրիական,Վերֆելի հր. 4	\N	\N	3	\N	Ալեքսանյան Արսեն	098922922	0312/63697	95009867	Հերմինե Հարությունյան	09529-21-27		 094719015		5	6
1378	Գյումրու թիվ 10 հմ/դ	8	8	ք. Գյումրի, Մ. Գորկու 77	\N	\N	3	\N	Լիանա Վարդանյան	95008494	94024464		Աշոտ Ադամյան	93116624				\N	\N
1380	Գյումրու տնտեսագիտական վարժարան 	8	8	ք. Գյումրի, Կիրովականյան 21 և Վ. Սարգսյան 32	\N	\N	3	\N	Ավագյան/Չախոյան/ Նառա	93822075	95008496	95009818	Սուսաննա Համբարձումյան	55787832	Թեհմինե Կարապետյան	98011802		\N	\N
1385	Գյումրու Ղ. Ալիշանի անվ. թիվ 8 մ/դ	8	8	ք. Գյումրի, Լիսինյան 6	\N	\N	3	\N	Արարատ Սահակյան	95008481	91735343		Ալվարդ Ազիզյան	93308434				\N	\N
1386	Գյումրու Ղ. Աղայանի անվ. թիվ 19 հմ/դ	8	8	ք. Գյումրի, Վ. Սարգսյան 26	\N	\N	3	\N	Նարինե Մեսրոպյան	95008479	94342311		Հեղինե Ղևոնդյան	94945540				\N	\N
1387	Գյումրու Մ. Խորենացու անվ.  թիվ 37 ա/դ	8	8	ք. Գյումրի, Չարենցի 12	\N	\N	3	\N	Աստղիկ Ավետիսյան	95008478	93144114	0312/3-48-07	Պետրոսյան Երվանդ	98114452				\N	\N
1388	Գյումրու մտավոր թերզարգացում ունեցող երեխաների թ. 3 հտ/դ	8	8	ք. Գյումրի, Խրիմյան Հայրիկ 1	\N	\N	3	\N	Տիգրան Գուլյան	95008476	94050513		Սեդա Գուլյան	94050513				\N	\N
1390	Գյումրու Րաֆֆու անվ. թիվ 32 հմ/դ	8	8	ք. Գյումրի, Հնոցավան փ. 	\N	\N	3	\N	Արմինե Սուքիասյան	95009895	96999110		Նաիրա Հովսեփյան	94821320				\N	\N
1391	Գյումրու Օյունջյան հմ/դ	8	8	ք. Գյումրի, Մհեր Մկրտչյանի 47	\N	\N	3	\N	Հասմիկ Անդրիասյան	94920021		95009869	Նարինե Գևորգյան	93420830				4	30
1395	Գյումրու Բայրոնի անվ. թիվ 20 մ/դ	8	8	ք. Գյումրի, Մ. Թետչերի 1	\N	\N	3	\N	Հարությունյան Գրիգոր	95009849	94500232	31233682						\N	\N
1396	Գյումրու Գ. Նարեկացու անվ. թիվ 9 հմ/դ	8	8	ք. Գյումրի, Հաղթանակի պողոտա 40	\N	\N	3	\N	Մովսիսյան Անահիտ	95009846	93449755		Նարինե Հովհաննիսյան	91342922				\N	\N
1397	Գյումրու Գ. Սարյանի անվ. թիվ 24 հմ/դ	8	8	ք. Գյումրի, Ա. Շիրակացի 173	\N	\N	3	\N	Հակոբ Հակոբյան	95009843	93197565		Անժելա Հակոբյան	94814166				\N	\N
1399	Գյումրու Գր. Լուսավորիչի անվ. թիվ 31 հմ/դ	8	8	ք. Գյումրի, Խ.Հայրիկի 1-ին թաղ.	\N	\N	3	\N	Արթուր Ղազարյան	95009839	98465354		Սվետլանա Կուչկոյան	93576947				\N	\N
1400	Գյումրու Ե. Չարենցի անվ. թիվ 25 հմ/դ	8	8	ք. Գյումրի, Պուշկինի 101	\N	\N	3	\N	Ստեփանյան Գագիկ	95009838	93114407		Մարինե Գրիգորյան	91610567				\N	\N
1402	Գյումրու թիվ 23 մ/դ	8	8	ք. Գյումրի, Շիրակացի փ., 8-րդ զինվորական թաղամաս	\N	\N	3	\N	Արփենիկ Արաքչյան	95009836	77414578		Հռիփսիմե Կիրակոսյան					\N	\N
1403	Գյումրու թիվ 26 ա/դ	8	8	ք. Գյումրի, Տիգրան Մեծի 27	\N	\N	3	\N	Սեփոսյան Գագիկ	041677710 		95009834	Սիրանուշ Բեգջանյան	093 44-99-05				22	36
1416	Հարթաշենի մ/դ	8	9	գ. Հարթաշեն	\N	\N	3	\N	Մկրտչյան Սիրազարդ	93018415	95004636		Բալոյան Սոետլաննա	95004636	93018415			\N	\N
1417	Քարահունջի մ/դ	8	9	գ. Քարահունջ	\N	\N	3	\N	Սվետլաննա Շամիրյան	95006187	91532418		Արմեն Մկրտչյան	93702825				\N	\N
1419	Գորիսի թիվ 2 հմ/դ	8	9	ք. Գորիս, Կապանի 34	\N	\N	3	\N	Ակունց Սիրուշ	95006171	94204904		Ն. Դրդիրյան	93232023				\N	\N
1425	Խոտի մ/դ	8	9	գ. Խոտ	\N	\N	3	\N	Սևակ Գրիգորյան	94003643	95004542		Լ. Մինասյան	99099964				\N	\N
1426	Հարժիսի մ/դ	8	9	գ. Հարժիս	\N	\N	3	\N	Հովսեփյան Վոլոդյա	95004547	93902856							\N	\N
1427	Շինուհայրի մ/դ	8	9	գ. Շինուհայր	\N	\N	3	\N	Գրիգորյան Շիրազ	95004548	93351858		Հարությունյան Հարություն	55390039				\N	\N
1428	Քաջարանի թիվ 1 մ/դ	8	9	ք. Քաջարան, Խանջյան 7	\N	\N	3	\N	Գևորգյան Ե.	93649042	95006194		Վիկտորիա Հայրապետյան	77820938				\N	\N
1429	Քաջարանի թիվ 2 մ/դ	8	9	ք. Քաջարան, Աբովյան 12	\N	\N	3	\N	Գրիգորյան Ռաֆաել	93000607	95006193		Հովհաննիսյան Շաքե		93990219			\N	\N
1430	Երևանի բժշկահոգեբանամանկա­վար­ժական գնահատման կենտրոնի Կապանի մասնաճյուղ հտ. հմ/դ	8	9	ք. Կապան, Լեն. հանքեր	\N	\N	3	\N	Առաքելյան Լեռնիկ	28525421	95006178	93157777	Զարուհի Առաքելյան	93925651				\N	\N
1438	Կապանի թիվ 3 հտ/կթհ	8	9	ք. Կապան, Սպանդարյան 4	\N	\N	3	\N	Ռիտա Դավթյան	95001312	96435413	0285 23429	Նունե Ոսկանյան	93648181				\N	\N
1439	Կապանի թիվ 3 մ/դ	8	9	ք. Կապան, Ա. Մանուկյան 7	\N	\N	3	\N	Բեգլարյան Եդվարդ	95001294	94809083		Նազիկ Օհանջանյան	93195906				\N	\N
1407	Գյումրու թիվ 7 մ/դ	8	8	ք. Գյումրի, Ա. Մանուկյան 4	\N	\N	3	\N	Կարապետյան Գագիկ	95009831	93471245		Լուսինե Ղուկասյան	98475138				\N	\N
1418	Գորիսի Բակունցի անվ. թիվ 1 ա/դ	8	9	ք. Գորիս, Անկախության 58	\N	\N	3	\N	Մովսիսյան Կարինե	28423871	95006169	077414372	Իվանյան Մառա	96666934				17	45
1411	Գյումրու Ռ. Թուֆենքյանի անվ. թիվ 5 հմ/դ	8	8	ք. Գյումրի, Մատնիշյան 301	\N	\N	3	\N	Թահմազյան Մարինե	95009772	77051177		Արմինե Էլոյան	99717719				\N	\N
1422	Գորիսի Յու. Բախշյանի անվ. թիվ 3 հմ/դ	8	9	ք. Գորիս, Սյունիքի 183	\N	\N	3	\N	Կարապետյան Կարմեն	95001552	91241903		Նունե Շեգունց	94006501				\N	\N
1414	Գյումրու Վ. Տերյանի անվ. թիվ 15 հմ/դ	8	8	ք. Գյումրի, Զ. Եսայան 34ա	\N	\N	3	\N	Համբարձումյան Սեդա	95009824	77707575		Արմենուհի Հարությունյան	94750387				\N	\N
1424	Բարձրավան	4	9	գ. Բարձրավան	\N	\N	3	2										\N	\N
1408	Գյումրու Մ. Մաշտոցի անվ. թիվ 29 հմ/դ	8	8	ք. Գյումրի, Մ. Մանուշյան 7	\N	\N	3	\N	Գայանե Բիչախչյան	95009829	0312/36703							\N	\N
1410	Գյումրու Պ. Սևակի անվ. թիվ 18 մ/դ	8	8	ք. Գյումրի, Ս. Լազոյի 2	\N	\N	3	\N	Ալեքսանյան Շողիկ	093855301			Հերիքնազ Ալեքսանյան	093 63-06-39				2	15
1412	Գյումրու Վ. Թեքեյանի անվ. թիվ 2 ա/դ	8	8	ք. Գյումրի, Գ. Նժդեհի 11	\N	\N	3	\N	Պետրոսյան Հովհաննես	95009826	93190013		Սուսաննա	55631347				\N	\N
1413	Գյումրու Վ. Համբարձումյանի անվ. թիվ 4 հմ/դ	8	8	ք. Գյումրի, Կամոյի 173	\N	\N	3	\N	Համբարձումյան Զարիկ	94845440		95009825	Գայանե Հովհաննիսյան	098712757		10		6	\N
1420	Գորիսի թիվ 4 ա/դ	8	9	ք. Գորիս, Գրիգոր Տաթևացի 18	\N	\N	3	\N	Արմինե Շեգունց	95004639	93961747		Լուսինե Շեգունց	93407813				\N	\N
1421	Գորիսի թիվ 5 հմ/դ	8	9	ք. Գորիս, Բեգլարյանների 2/13	\N	\N	3	\N	Արևիկ Մաքունց	094997544			Նինել Նահապետյան	77720970				8	8
1423	Գորիսի Ս. Խանզադյանի անվ. թիվ 6 հմ/դ	8	9	ք. Գորիս, Գետափնյա 1	\N	\N	3	\N	Փարոյան Արամայիս	95004539	93061192		Տիգրան Ավետյան	91080052				\N	\N
1431	Կապանի թիվ 5 հմ/դ	8	9	ք. Կապան, Բաղաբերդ թաղ. 27	\N	\N	3	\N	Սիրանուշ Հարությունյան	95006179	93438540		Ղազարյան Ռիտա	94553762				\N	\N
1432	Կապանի թիվ 1 հմ/դ	8	9	ք. Կապան, Լեռնագործների 16	\N	\N	3	\N	Մարգարյան Լևոն	93337733	95006175		Լուսինե Հարությունյան	91768949				\N	\N
1433	Կապանի թիվ 10 մ/դ	8	9	ք. Կապան, Շինարարներ 19	\N	\N	3	\N	Արթուր Հակոբյան	95006174	93986880		Մերի Միրզոյան	93972492				\N	\N
1434	Կապանի թիվ 11 մ/դ	8	9	ք. Կապան, Կավարտ բանավան	\N	\N	3	\N	Նելլի Կոստանդյան	95006198	94006065		Օվսաննա Հովակիմյան	91779699				\N	\N
1435	Կապանի թիվ 12 հմ/դ	8	9	ք. Կապան, Բարաբաթում բանավան	\N	\N	3	\N	Ավանեսյան Ա.	28524790	93612290	95001554	Մարտիրոսյան Անդրանիկ	77051077				\N	\N
1436	Կապանի թիվ 13 հմ/դ	8	9	ք. Կապան, Ձորքի թաղամաս	\N	\N	3	\N	Զավեն Ստեփանյան	94111150	95002113		Սուսաննա Օհանջանյան					\N	\N
1440	Կապանի թիվ 6 հմ/դ	8	9	ք. Կապան, Մ. Հարությունյան 5-Ա	\N	\N	3	\N	Մարինե Դավթյան	943782955	95004647		Մարգարիտա Դավթյան	94355759				\N	\N
1437	Կապանի թիվ 2 ա/դ	8	9	ք. Կապան, Մելիք Ստեփանյան 5	\N	\N	3	\N	Հարությունյան Լ.-նախկին տնօրեն	95001524	94007799	(0285) 24879	Մարինե Գրիգորյան	55027283				\N	\N
1415	Ակների մ/դ	8	9	գ. Ակներ	\N	\N	3	\N	Ամարյան Էմմա	93789954	95004569		Առաքելյան Անաիդա	093027456				3	5
1443	Արծվանիկի մ/դ	8	9	գ. Արծվանիկ	\N	\N	3	\N	Կարո Անդրեասյան	94908044	95006192		Նելլի Հովհաննիսյան	94901075				\N	\N
1444	Սյունիքի մ/դ	8	9	գ. Սյունիք	\N	\N	3	\N	Արթուր Մնացականյան	28560444	95006191	93933233	Հասմիկ Մնացականյան	98983293				\N	\N
1445	Կապանի թիվ 4 մ/դ	8	9	ք. Կապան, Վաչագան բանավան	\N	\N	3	\N	Էլմիրա Զաքարյան	95006189	94815798		Ավանեսյան Սուսաննա	77004958				\N	\N
1447	Մեղրու թիվ 1 մ/դ	8	9	ք. Մեղրի, Ադելյան 1	\N	\N	3	\N	Սիմոն Սարգսյան	95002441	93062205		Լուսյա Մանուկյան	77042729				\N	\N
1448	Մեղրու թիվ 2 մ/դ	8	9	ք. Մեղրի, Զ. Անդրանիկի 10	\N	\N	3	\N	Մերի Հակոբյան	95002458	77193969		Ալվարդ Ստեփանյան	77093039				\N	\N
1450	Ծղուկի մ/դ	8	9	գ. Ծղուկ	\N	\N	3	\N	Նավասարդյան Լարիսա	98272725			Հայրապետյան Սեյրան	98679892				\N	\N
1451	Ախլաթյանի մ/դ	8	9	գ. Ախլաթյան	\N	\N	3	\N	Հակոբյան Ջուլետա	93028598	95002679							\N	\N
1452	Անգեղակոթի մ/դ	8	9	գ. Անգեղակոթ	\N	\N	3	\N	Պետրոսյան Անահիտ	95002674	98394913		Մովսեսյան Գոհար	98358283				\N	\N
1453	Բնունիսի հմ/դ	8	9	գ. Բնունիս	\N	\N	3	\N	Նազարյան Գոհար	95002796	77707585		Արմինե Հովհաննիսյան	93214835				\N	\N
1454	Բռնակոթի մ/դ	8	9	գ. Բռնակոթ	\N	\N	3	\N	Բալասանյան Գագիկ	95002776	93374977		Հայրապետյան Լուսինե	93772239				\N	\N
1455	Իշխանասարի հմ/դ	8	9	գ. Իշխանասար	\N	\N	3	\N	Մովսիսյան Լ	95002935	93043301		Վարդանյան Արփինե	77657037				\N	\N
1456	Շաքիի մ/դ	8	9	գ. Շաքի	\N	\N	3	\N	Հարությունյան Վաղինակ	95002928	93197519		Արմինե Առաքելյան	93644113				\N	\N
1457	Ույծի մ/դ	8	9	գ. Ույծ	\N	\N	3	\N	Նիկողոսյան Արմիկ	95002918	93016398		Խաղումյան Հմայակ	95591122				\N	\N
1458	Սառնակունքի մ/դ	8	9	գ. Սառնակունք	\N	\N	3	\N	Վարդանյան Անուշավան	95002393	93024068		Լիլիթ Հոհանյան	77025969				\N	\N
1461	Սիսիանի թիվ 2 hմ/դ	8	9	ք. Սիսիան, Շիրվանզադե 7	\N	\N	3	\N	Ազարումյան Հրանտ	95002669	93613100		Արշա;ույս Օհանյան	77559570				\N	\N
1462	Սիսիանի թիվ 3 ա/դ	8	9	ք. Սիսյան, Մյասնիկյան 8	\N	\N	3	\N	Ներսիսյան Նաիրա	95002775	77382865		Սնեցունց Սիրուև	93467744				\N	\N
1463	Սիսիանի թիվ 4 hմ/դ	8	9	ք. Սիսիան, Շահամիրյան 61	\N	\N	3	\N	Ստեփանյան Նարիրա	95002829	93487802		Ռուզան Առաքելյան	98814963	94284228			\N	\N
1464	Սիսիանի թիվ 5 hմ/դ	8	9	ք. Սիսիան, Նար-Դոսի 1	\N	\N	3	\N	Ալեքսանյան Հովիկ	93013477	95002853		Աննա Սուքիասյան	94488840				\N	\N
1467	Ջերմուկի թիվ 2 ա/դ	8	10	ք. Ջերմուկ, Ձախ ափ	\N	\N	3	\N	Արսենյան Արմինե	95006167	93036331	55575222	Մուշեղյան Արմինե	77289500				\N	\N
1468	Վայքի վարժ.	8	10	ք. Վայք, Միասնիկյան 1ա	\N	\N	3	\N	Սահակ Գասպարյան	95006146	93728208		Հասմիկ Գասպարյան	96221868				\N	\N
1469	Բերդի թիվ 1 հմ/դ	8	11	ք. Բերդ, Լևոն Բեկի 3	\N	\N	3	\N	Վիրաբյան Արտուշ	95004513	94832532							\N	\N
1471	Բերդի թիվ 4 հմ/դ	8	11	ք. Բերդ, Ստեփանյան 13	\N	\N	3	\N	Աբգարյան Անահիտ	95004352	93612316		Լիլիտ Շարյան	94339923				\N	\N
1473	Ակնաղբյուրի հմ/դ	8	11	գ. Ակնաղբյուր	\N	\N	3	\N	Թիրաբյան Էդիկ	95004519	94060540		Դավիթ Թիրաբյան	77404320				\N	\N
1474	Աչաջրի մ/դ	8	11	գ. Աչաջուր	\N	\N	3	\N	Ղալթախչյան Սուրեն	95004518	93555745		Կարինե Աղինյան	93555745				\N	\N
1475	Գանձաքարի մ/դ	8	11	գ. Գանձաքար	\N	\N	3	\N	Մատինյան Սամվել	95004374	91911577		Վանուհի Մելիքսեթյան	93084564				\N	\N
1476	Գետահովիտի մ/դ	8	11	գ. Գետահովիտ	\N	\N	3	\N	Հարություն Ղազարյան	95004373	77034851		Շողեր Ղազարյան	77208077				\N	\N
1477	Ենոքավանի մ/դ	8	11	գ. Ենոքավան	\N	\N	3	\N	Աշոտ Ղազարյան	91751593			Նարինե	55932600				\N	\N
1479	Սևքարի մ/դ	8	11	գ. Սևքար	\N	\N	3	\N	Նաիրա Թամանյան	95004529	94732245		Անժելա Հայրապետյան	94162466				\N	\N
1472	Դիլիջանի թիվ 5 մ/դ	8	11	ք. Դիլիջան Շամախյան 1	\N	\N	3	\N	Անանյան Հովհաննես	95004523	94904097							\N	\N
1460	Տոլորսի մ/դ	3	9	գ. Տոլորս	\N	\N	3	\N	Բադալյան Երանուհի	95002625	77055806		Դանիելյան Հասմիկ	94042968				\N	\N
1449	Գորայքի մ/դ	8	9	գ. Գորայք	\N	\N	3	\N	Մարտուն Թադևոսյան	95002795	93018873		Մոնիկա Հարությունյան, (օպերատոր-Դավիթ Ջանունց)	077388770				6	11
1446	Ագարակի մ/դ (Մեղրի)	3	9	ք. Ագարակ	\N	\N	3	\N	Էռնա Բարխուդարյան	95002394	98126492		Աննա Գասպարյան	94941230				\N	\N
1442	Կապանի թիվ 9 ա/դ	8	9	ք. Կապան, թիվ Ավետիսյան 14	\N	\N	3	\N	Գագիկ Հովհաննիսյան	95004654	94095333		Հերմինե Պողոսյան	93431685				\N	\N
1441	Կապանի թիվ 7 հմ/դ	8	9	ք. Կապան, Շահումյան 16-Ա	\N	\N	3	\N	Հովհաննիսյան Կ.	95004648	94212276		Պողոսյան Հերմինե	93607515				\N	\N
1466	Եղեգնաձորի վարժ.	8	10	ք. Եղեգնաձոր, Վահան տեր-Առաքելյան 10	\N	\N	3	\N	Աբրահամյան Վահան	94450920	95006165		Հասմիկ Դավթյան	93991339				\N	\N
1465	Եղեգնաձորի թիվ 2 հմ/դ	8	10	ք. Եղեգնաձոր, Նարեկացու փող., 12 շենք	\N	\N	3	\N	Սարգսյան Ա.	95006164	99622362		Լիլիթ Կարապետյան	93105936				\N	\N
1470	Բերդի թիվ 2 ա/դ	3	11	ք. Բերդ, Հ. Նահապետի 22ա	\N	\N	3	\N	Մելիքյան Արթուր	95004534	93777347		Լեռնուհի Մելիքյան	77171302				\N	\N
1459	Վաղատինի մ/դ	8	9	գ. Վաղատին	\N	\N	3	\N	Բաբայան Վազգեն	95002593	93313031		Հրանուշ Աթայան	93408952	094433353			4	5
1480	Դիլիջանի թիվ 2 հմ/դ	8	11	ք. Դիլիջան Կալինինի137	\N	\N	3	\N	Խաչատրյան Կամո	95004531	94371300		Նաիրա Պողոսյան	94526376				\N	\N
1482	Իջևանի թիվ 2 ա/դ	8	11	ք. Իջևան, Թատերական 3	\N	\N	3	\N	Խոջայան Արմեն	95005854	77791911							\N	\N
1483	Իջևանի թիվ 4 հմ/դ	8	11	ք. Իջևան, Նալբանդյան 1	\N	\N	3	\N	Խառատյան Ռոզա	95004536	94005450		Կարապետյան Լիլիթ	94070400				\N	\N
1484	Իջևանի թիվ 5 հմ/դ	8	11	ք. Իջևան, Երիտասարդական 3	\N	\N	3	\N	Ստեփան Կարապետյան	95004538	93670007							\N	\N
1486	Իջևանի վարժ.	8	11	ք. Իջևան, Անկախության	\N	\N	3	\N	Ամիրյան Հասմիկ	95001561	94520011		Նարինե Մարտիրոսյան	93057605				\N	\N
1487	Այգեհովիտի մ/դ	8	11	գ. Այգեհովիտ	\N	\N	3	\N	Մելքումյան Արմեն	93614422			Ալվարդ	77694419				\N	\N
1489	Սարիգյուղի մ/դ	8	11	գ. Սարիգյուղ	\N	\N	3	\N	Փաշինյան Գառնիկ	95008934	94700825		Լուիզա Ռեվազյան	93672089				\N	\N
1491	Չինչինի մ/դ	8	11	գ. Չինչին	\N	\N	3	\N	Ջուլակյան Արփիկ	95001373	93795532		Արևհատ Գինովյան	91583233				\N	\N
1493	Բերդի ա/ու	8	11	ք. Բերդ	\N	\N	3	\N	Ավալյան Աննա	95001357	94952552	26721332	Լուսինե Այվազյան	0267/21332				\N	\N
1494	Բերդի թիվ 3 հմ/դ	8	11	ք. Բերդ, Մաշտոցի 14	\N	\N	3	\N	Թումանյան Ռուզան	95001326	93673893							\N	\N
1495	Բերդի վարժ.	8	11	ք. Բերդ, Սայաթ Նովա 2	\N	\N	3	\N	Մանուչարյան Վեներա	95001325	95505659							\N	\N
1497	Ծաղկահովիտի մ/դ	8	1	գ. Ծաղկահովիտ	\N	\N	3	\N	Միքաելյան Արեստակ	93703974	95006367	0257/02142	Հովհաննիսյան Նարինե					\N	\N
1498	Նորաշենի մ/դ	8	1	գ. Նորաշեն	\N	\N	3	\N	Մուքոյան Գառնիկ	93899511	95006368							\N	\N
1499	Ռյա Թազայի մ/դ	8	1	գ. Ռյա Թազա	\N	\N	3	\N	Աթաշյան Դավիթ	94826022	95006369							\N	\N
1500	Ներքին Սասնաշենի մ/դ	8	1	գ. Ներքին Սասնաշեն	\N	\N	3	\N	Մելքոնյան Հովիկ	055 593-640	93593640		Մարտիրոսյան Մարինե	93593640				\N	\N
1501	Այգուտի մ/դ	8	4	գ. Այգուտ	\N	\N	3	\N										\N	\N
1503	Երևանի «Մխիթար Սեբաստացի» կթհ	8	5	Ա. Բաբաջանյան 25	\N	\N	3	\N	Գևորգ Հակոբյան	77615140	95006794		Լիլիթ Գասպարյան	93991472				\N	\N
1504	Երևանի «Վարդանանց ասպետներ» թիվ 106 հմ/դ	8	5	Ն/ն Նանսենի 11	\N	\N	3	\N	Վարդանյան Մարինե	93611993	632590		Եղիկյան Սվետլաննա	91645519				\N	\N
1513	Երևանի բժշկահոգեբանամանկավարժական գնահատման կենտրոնի հտ. հմ/դ	8	5	Քաջազնունի 12	\N	\N	3	\N	Կատինյան Վարդուշ	95006792			Ավագ Կատինյան	91171008				\N	\N
1515	Երևանի Ադդարյանի անվ. թիվ 133 հմ/դ	8	5	Ն/Ն 2-րդ զծ. Մոլդովական փ	\N	\N	3	\N	Վ. Սամվելյան	91362757			Լիաննա Մինասյան	77797610				\N	\N
1502	Երևանի «Արգենտինյան Հանրապետության» թիվ 76 հմ/դ	8	5	Բաղրամյան 52	\N	\N	3	\N	Ն. Ադամյան	265777	77770007	95006795	Սուսաննա Մուրադյան	91795266				\N	\N
1505	Երևանի «Օլիմպոս» կթհ	8	5	Գ. Հովսեփյան 6	\N	\N	3	\N	Գրիգորյան Վահրամ	91414142			Գայանե Ղազարյան	77437753				\N	\N
1506	Երևանի Ա. Շիրակացու անվ. Ճեմարան տ/դ	8	5	Նոր-Նորք , Ա. Միկոյան 35	\N	\N	3	\N	Ալիխանյան Աշոտ	95006783	91401546		Դավիթ Մինասյան	93257642				\N	\N
1507	Երևանի Ա. Արմենակյանի անվ. թիվ 26 մ/դ	8	5	Նորք 5-րդ փողոց 51 շ.	\N	\N	3	\N	Արմենակյան Արմենակ	650106	95006784		Արմենակյան <Մարիամ	093645368 հաշվապահ	77654824			\N	\N
1508	Երևանի Ա. Խանջյանի անվ. թիվ 53 հմ/դ	8	5	Տիգրան Մեծի 26	\N	\N	3	\N	Ս. Սարգսյան	94444870	582414		Պողոսյան Անահիտ	94054064				\N	\N
1509	Երևանի Ա. Ղարիբյանի անվ. թիվ 142 ա/դ	8	5	Գյուլիքեվխյան 33	\N	\N	3	\N	Միրզոյան Արմանուշ	91635950	95006786	635950	Դոխոյան Սիրանուշ	96672189	672189			\N	\N
1510	Երևանի Ա. Միկոյանի անվ. թիվ 166 հմ/դ	8	5	Ն/Ն5-րդ զանգված Մառի 8	\N	\N	3	\N	Քուշկյան Մարգարիտ	91924750			Արմենուհի Վարդանյան	91700204				\N	\N
1511	Երևանի Ա. Չեխովի անվ. թիվ 55 հմ/դ	8	5	Բաղրամյան 16	\N	\N	3	\N	Սարուխանյան Գայանե	95006789	91202006							\N	\N
1512	Երևանի Բ. Ժամկոչյանի անվ. թիվ 119 ա/դ	8	5	Տիգրան Մեծ 64	\N	\N	3	\N	Կարապետյան Հովհաննես	99909290	573740		Մելքոնյան Անուշ	99432226				\N	\N
1514	Երևանի Գ. Զոհրապի անվ. թիվ 43 ա/դ	8	5	Նոր-Արեշ 9-րդ փ. 54 շ.	\N	\N	3	\N	Բեգջանյան Ռուզան	556772	95006793		Լիաննա Սահակյան	10450730				\N	\N
1516	Երևանի Դ. Դեմիրճյանի անվ. թիվ 27 հմ/դ	8	5	Արտաշիսյան 52	\N	\N	3	\N	Սարգսյան Սուսաննա	95750175			Սոնա Խաչատրյան	93834625				\N	\N
1517	Երևանի Դ. Վարուժանի անվ. թիվ 89 հմ/դ	8	5	Սեբաստիա 19	\N	\N	3	\N	Օ. Պետրոսյան	95006765	98252256		Արմինե Աջարյան	93977297				\N	\N
1518	Երևանի Ե. Չարենցի անվ. թիվ 67 հմ/դ	8	5	Ամիրյան 9	\N	\N	3	\N	Անահիտ Խեչոյան	55484448	538786		Մարիամ Սարգսյան	95749060				\N	\N
1496	Աշտարակի Վ. Պետրոսյան անվ. հմ/դ	8	1	ք. Աշտարակ, Գեներալ Սաֆար	\N	\N	3	\N	Գևորգյան Գրիշա	93-20-02-85	02323 6706							\N	\N
1481	Իջևանի Գ. Էդիլյան անվ. թիվ 3 հմ/դ	8	11	ք. Իջևան, Թուխիկյան 25	\N	\N	3	\N	Հրայր Պողոսյան	0263 3072	098 522256		Մարիամ Այդինյան	99964960				\N	\N
1485	Իջևանի Ս. Սարգսյանի անվ. թիվ 1 հմ/դ	8	11	ք. Իջևան, Իջևանյան 8	\N	\N	3	\N										\N	\N
1490	Ն. Կարմիր Աղբյուրի մ/դ	8	11	գ. Ն. Կարմիր Աղբյուր	\N	\N	3	\N	Ադամյան Իվան	95001995	77771158							\N	\N
1521	Երևանի թիվ 100 հմ/դ	8	5	Մարգարյան 9	\N	\N	3	\N	Ա. Օհանովա	95551525			Սարսյան Ալվարդ	55340681				\N	\N
1522	Երևանի թիվ 102 հմ/դ	8	5	Ֆուչիկի 2 նրբ.11	\N	\N	3	\N	հայրապետյան Ռուզաննա	95006771	344333		Նարիեն Ղազարյան	94033068	99033068	91033068		\N	\N
1524	Երևանի թիվ 116 հմ/դ	8	5	Արարատյան 2 զանգված	\N	\N	3	\N	Հովհաննիսյան Թ.	95006768	77773432		Վահե Մելքոնյան	55722277				\N	\N
1525	Երևանի Հ. Բժշկյանցի անվ. թիվ 129 հմ/դ	8	5	Հրաչյա Քոչար 29	\N	\N	3	\N	Լիանա Պետրոսյան	223482	95006759							\N	\N
1526	Երևանի թիվ 14 հտ. մ/դ	8	5	Մամիկոնյանց 31	\N	\N	3	\N	Ահարոնյան Ալեքսան	91481791	95006761							\N	\N
1527	Երևանի թիվ 15 հտ. մ/դ	8	5	Նորքի այգիներ 193	\N	\N	3	\N	Ավետիսյան Աշոտ	651060	95006762	094/401045	Գուրգեն Խանումյան	94421997				\N	\N
1528	Երևանի թիվ 154 հմ/դ	8	5	Ֆրունզե 4	\N	\N	3	\N	Արշակյան Սուսաննա	447302	91788629		Հարությունյան Մարինա	55982478				\N	\N
1529	Երևանի թիվ 156 հմ/դ	8	5	Շիրազի 11	\N	\N	3	\N	Խաչատրյան Անժելա	95006756	345049		Վարդանյան Սուսաննա	345049				\N	\N
1530	Երևանի թիվ 16 հտ. մ/դ	8	5	Աճառյան 40	\N	\N	3	\N	Պետրոսյան Մարիետա	91401145	612840	95006764	Գեղամ Խաչատրյան	55150535				\N	\N
1531	Երևանի թիվ 163 հմ/դ	8	5	Նոր-Նորքի 6-րդ զ. Գյուրջյ	\N	\N	3	\N	Շահնազարյան Կարեն	93467623	95006554		Բադալյան Արուսյակ	91631241				\N	\N
1532	Երևանի թիվ 17 հտ. մ/դ	8	5	Մոլդովական 41	\N	\N	3	\N	Հարությունյան Ամալյա	91540178	620674		Նելի Թովմասյան	94545359				\N	\N
1533	Երևանի թիվ 187 մ/դ	8	5	Ջրվեժ, «Մայակե թաղամաս, թ	\N	\N	3	\N	Ղևոնդյան Վյաչեսլավ	91308686	95006561		Գայանե Ալեքսանյան	94640466				\N	\N
1534	Երևանի թիվ 192 հմ/դ	8	5	2 թաղամաս	\N	\N	3	\N	Թադևոսյան Ալվարդ	369880	95006572	77733759	Մանուշակ Մկոյան	77916891	360584			\N	\N
1535	Երևանի թիվ 198 հեղինակային ա/դ	8	5	Նոր Նորքի 9-րդ զանգված 13	\N	\N	3	\N	Ա. Թորոսյան	91202119	667250	95006574						\N	\N
1537	Երևանի թիվ 45 հմ/դ	8	5	Նոր - Արեշ 26 փ. 45 շ.	\N	\N	3	\N	Միհրան Փաշյան	454021	091/458510		Սվետլաննա Պողոսյան	439530				\N	\N
1539	Երևանի թիվ 8 հտ. մ/դ	8	5	Ծարավ աղբյուրի 14	\N	\N	3	\N	Խեբոյան Վարդուհի	91285351	95006581		Հերմինե	91562301				\N	\N
1540	Երևանի թիվ 99 հմ/դ	8	5	Ներքին Չարբախ 3-րդ փող. 1	\N	\N	3	\N	Մարգարյան Լիլիթ	98428481			Անահիտ Քոսակյան	94611061				\N	\N
1547	Երևանի Լեոյի անվ. թիվ 65 ա/դ	8	5	Ֆրունզե 56	\N	\N	3	\N	Խրիմյան Նորայր	91361148								\N	\N
1549	Երևանի Խրիմյան Հայրիկի անվ. թիվ 10 հմ/դ	8	5	Չարենցի 75	\N	\N	3	\N	Ապետնակյան Սիրվարդ-նախկին տնօրեն	559771	091/387381	552325	Սուսաննա Հարությունյան	99537530				\N	\N
1550	Երևանի Հանրապետական թիվ 1 հտ/կթ.	8	5	Վարդաշեն 6-րդ փողոց	\N	\N	3	\N	Լարիսա Սարգսյան	10451421	91488736		Մարկոսյան Գալինա	55172271				\N	\N
1551	Երևանի ՀՀ Գյուղ. ակադեմիայի վարժ. ա/դ	8	5	Կորյունի 19, ՀՊԱՀ-ի 5-րդ	\N	\N	3	\N	Սեխպոսյան	141581434			Հակոբյան Անահիտ	98590777				\N	\N
1554	Երևանի Ջոն Կիրակոսյանի անվ. թիվ 20 հմ/դ	8	5	Այգեստան 94	\N	\N	3	\N	Անահիտ Խոսրովյան	552881								\N	\N
1538	Երևանի թիվ 62 ա/դ	8	5	1 զանգված	\N	\N	3	\N	Սողոմոնյան Մարիեն	091008463	634520		Տիգրան Ձախոյան	55637459		091637459		50	70
1520	Երևանի Շիրազի անվ. թիվ 169 հմ/դ	8	5	Աերացիա	\N	\N	3	\N	Մալոյան Սուսաննա	99402554	95006774		Քամալյան Իզաբելլա	99467669				\N	\N
1541	Երևանի Գալստյանի անվ. թիվ 83 ա/դ	8	5	Օրբելի 63	\N	\N	3	\N	Մ. Պապոյան	95006586	99888050		Միրզոյան Մարիամ	94115510				\N	\N
1542	Երևանի թիվ Իսակովի անվ. թիվ 132 հմ/դ	8	5	Ա. Խաչատրյան 28	\N	\N	3	\N	Հայրապետյան	251144	55512817		Անուշ Մասնուկյան	55530591				\N	\N
1543	Երևանի Կարապենցի անվ. թիվ 6 հմ/դ	8	5	Սասունցի-Դավթի 2	\N	\N	3	\N	Վարդանյան Սիրանուշ	55033066	453800		Սվետլաննա Սիմոնյան	95280329				\N	\N
1544	Երևանի Հ. Հայրապետյանի անվ թիվ 78 հմ/դ	8	5	Բաղրամյան 59ա	\N	\N	3	\N	Ա. Միրզոյան	91422413	95006714		Անահիտ Գալֆայան	77250266	55250266			\N	\N
1545	Երևանի Պողոսյանի անվան թիվ 82 հմ/դ	8	5	Մամիկոնյանց 33	\N	\N	3	\N	Բախշինյան Ռիմա	95950927			Հովհաննիսյան Լուսինե	94827771				\N	\N
1548	Երևանի Խ. Դաշտենցի անվ. թիվ 114 ա/դ	8	5	Հանրապետության 73	\N	\N	3	\N	Կոստանյան Ռուզաննա	91402755			Մարանգոզյան Լուսիկ	91380388				\N	\N
1552	Երևանի Մ. Իշխանի անվ. թիվ 5 հմ/դ	8	5	Փ. Բյուզանդի 107	\N	\N	3	\N	Անահիտ Սարգսյան	91497498	533661		Ռաֆաել Խաչատրյան	91651583				\N	\N
1553	Երևանի Պ. Յավորովի անվ. թիվ 131 հմ/դ	8	5	Արզումանյան 22	\N	\N	3	\N	Սաֆարյան Ռ. Գ.	95007825	91415575							\N	\N
1555	Երևանի Ռ. Միրոյանի անվ. թիվ 77 հմ/դ	8	5	Ադոնցի 11	\N	\N	3	\N	Ն. Պետրոսյան	93421755			Մարիեն Հովհաննիսյան	93285734				\N	\N
1536	ԵՊԲՀ-ի Հերացի ավագ դպրոց	8	5	Հ. Ներսիսյանի 3	\N	\N	3	\N	Սարգսյան	285360			Գալստյան Սրբուհի	94285422				\N	\N
1546	Երևանի Օշականի անվ. թիվ 172 հմ/դ	8	5	Մ. Բաղրամյան պող. 59ա	\N	\N	3	\N	Մկրտչյան Գայանե	010225834			Նարինե Առաքելյան	98270678				16	16
1559	Երևանի Վ. Սարոյանի անվ. թիվ 138 հմ/դ	8	5	Մարգարյան 2 նրբ. 30ա	\N	\N	3	\N	Հովհաննիսյան Լուիզա	344800	91373232		Անաիդա Նեսիսյան	93695777				\N	\N
1600	Վերիշենի մ/դ	8	9	գ. Վերիշեն	\N	\N	3	\N	Ղազարյան Մատվեյ	95002878	94948868		Մարիամ Տոռոզյան	77057674				\N	\N
1564	Ախթալայի թիվ 1 մ/դ	8	6	ք. Ախթալա, Շահումյան 10	\N	\N	3	\N	Ճիճիլյան Լ.		93405605		Դավոյան Հերմինե	95007458	94405605			\N	\N
1566	Կաթնաջուրի մ/դ	8	6	գ. Կաթնաջուր	\N	\N	3	\N	Էդվարդ Ասատրյան	91067033	98067033		Արփինե Մարուքյան	94660673				\N	\N
1567	Հարթագյուղի մ/դ	8	6	գ. Հարթագյուղ	\N	\N	3	\N	Հունանյան Սամվել	94809054			Անժելա Մկրտչյան	77204880				\N	\N
1569	Սպիտակի Ա. Մյասնիկյանի անվ թիվ 1 մ/դ	8	6	ք. Սպիտակ, Մյասնիկյան	\N	\N	3	\N	Մ. Ավետիսյան	95007448			Խաչատրյան Մ.	55248812				\N	\N
1570	Ագարակի մ/դ	8	6	գ. Ագարակ	\N	\N	3	\N	Վարդունյան Հայկ	91044288			Խուբլարյան Նվարդ	91620880	55580550			\N	\N
1574	Արզնիի մ/դ	8	7	գ. Արզնի	\N	\N	3	\N	Սիմոնովնա Սոֆիա	91415344			Իրինա Ալեքսանյան	91238014				\N	\N
1576	Ջրվեժի հմ/դ	8	7	գ. Ջրվեժ	40.1870750000000001	44.5920819999999978	3	1	Վարդանյան Լլիթ	91539228			Կոբալյան Հերմինե	99811224				\N	\N
1578	Բջնիի Թումանյանի անվ. մ/դ	8	7	գ. Բջնի	\N	\N	3	\N	Յաշա Սահակյան	91313131			Դավթյան Հայկ	93353851				\N	\N
1579	Մեղրաձորի Հակոբյանի անվ. մ/դ	8	7	գ. Մեղրաձոր	\N	\N	3	\N	Հրաչ Սարգսյան	93121244			Արևիկ	94341491				\N	\N
1585	Նոր Արտամետի մ/դ	8	7	գ. Նոր Արտամետ	\N	\N	3	\N	Մելքոն Կարապետյան	55921959			Սարգսյան Հայկանուշ	55332538				\N	\N
1586	Նոր Գեղիի թիվ 1 մ/դ	8	7	գ. Նոր Գեղի, Ց. Խաչատրյան	\N	\N	3	\N	Բաբախանյան Ն.	93500279			Պապյան Հասմիկ	99232909				\N	\N
1580	Ծաղկաձորի մ/դ	8	7	ք. Ծաղկաձոր, Մայիսյան 14	\N	\N	3	\N	Եգորյան Սուսաննա	22360255	77320108		Ռուզաննա Ավետիսյան	93386128				2	5
1556	Երևանի Ս. Կապւտիկյանի անվ. թիվ 145 հմ/դ	8	5	Հովսեփ-Էմինի 8	\N	\N	3	\N	Դավթյան Ռիմա	91416093			Ամիրխանյան Անի	91909154				\N	\N
1557	Երևանի Ս. Սպանդարյանի անվ. թիվ 24 հմ/դ	8	5	Պարոնյան 3	\N	\N	3	\N	Ա. Ավետիսյան	584721								\N	\N
1560	Երևանի Վ. Դավթյանի անվ. թիվ149 ա/դ	8	5	Հովսեփ Էմինի նրբ. 4	\N	\N	3	\N	Գ. Գալստյան	95007819	99458472	237220	Լուսինե Հարությունյան	98207219				\N	\N
1561	Երևանի Վ. Պետրոսյանի անվ. թիվ 51 հմ/դ	8	5	Զարյան 23	\N	\N	3	\N	Անյա Սահակյան	91795890			Առուշանյան Սվետլանա	94009816				\N	\N
1562	Երևանի Տ. Շևչենկոյի անվ. թիվ 42 ա/դ	8	5	Մաշտոցի 5/2	\N	\N	3	\N	Թումանյան Էլեանորա	535641								\N	\N
1563	Երևանի ֆ. Նանսենի անվ. թիվ 150 հմ/դ	8	5	Ն/Ն 4-րդ 1-ին հատված զ. Բ	\N	\N	3	\N	Հայրապետյան Մանյակ	91487735			Էլիգումյան Գոհար	93903998				\N	\N
1558	Երևանի Սախարովի անվ. թիվ 69 հմ/դ	8	5	Արարատյան 26	\N	\N	3	\N	Մարիաննա Մելյան	077555473	95007817		Աննա Թումասյան	093366853		11		8	\N
1572	Վանաձորի Ա. Գրիբոյեդովի անվ. թիվ 11 ա/դ	8	6	ք. Վանաձոր, Ազատամարտիկների պուրակ	\N	\N	3	\N	Նարինե Սահակյան	91222770			Մխիթարյան Աննա	93629551				\N	\N
1565	Թումանյանի Խ. Աբովյանի անվ. մ/դ	8	6	ք. Թումանյան, 2 մաս.	\N	\N	3	\N	Անահիտ Ռամազյան	94554060			Մխեյան Լիանա	94973941				\N	\N
1568	Մեծ Պառնիի Մ. Մելքոնյանի անվ. մ/դ	8	6	գ. Մեծ Պառնի	\N	\N	3	\N	Հրաչ Փիրուզյան	93462236			Սարգիս Փիլոյան	77064191				\N	\N
1577	Աբովյանի Վ. Համբարձումյանի անվ. թիվ 10 հմ/դ	8	7	ք. Աբովյան, Ս. Մնացականյանի 5	\N	\N	3	\N	Լ. Սառաջյան	98909393			Ասատրյան Արեգնազ	95687006				\N	\N
1589	Եղվարդի Գր. Հակոբյանի անվ. թիվ 1 ա/դ	8	7	ք. Եղվարդ, Չարենցի փ. 54	40.3147639999999967	44.4771610000000024	3	1	Սիմոնյան Ռազմիկ	93541207			Սիմոնյան Վարդգես	93800270				\N	\N
1582	Հրազդանի Խ. Աբովյանի անվ. թիվ 1 ա/դ	8	7	ք. Հրազդան, Երևանյան 5	\N	\N	3	\N	Մովսիսյան Գոհար	91491496	22324215		Մկրտչյան Գրետա					\N	\N
1583	Չարենցավանի թիվ 3 հմ/դ	8	7	ք. Չարենցավան, Լենինի 22	\N	\N	3	\N	Կարապետյան Լուսինե	22644582	94426742		Ա. Հարությունյան	93808836				\N	\N
1590	Նոր Հաճնի թիվ 1 հմ/դ	8	7	ք. Նոր Հաճն, Չարենցի 20	\N	\N	3	\N	Ն. Վարդանյան	55959390			Մանուշակ Պողոսյան	98713893				\N	\N
1584	Զովունիի Ռ. Բաղդասարյանի անվ. մ/դ	8	7	գ. Զովունի	40.2350330000000014	44.5063109999999966	3	1	Ղազարյան Վարդան	94503544			Հասմիկ Սեղբոսյան	55064686				\N	\N
1588	Քասախի Ա. Հովհաննիսյանի անվ. թիվ 2 մ/դ	8	7	գ. Քասախ	40.2362830000000002	44.4575469999999981	3	1	Ղազարյան Պայծառ	55131960	94196013		Գևորգյան Անդրանիկ	194980111				\N	\N
1573	Առինջի Կ. Ծառուկյանի անվ. մ/դ	8	7	գ. Առինջ	40.2310450000000017	44.5700720000000032	3	1	Գրիգորյան Սահակ	91350630			Անահիտ Սարգսյան	77216100				\N	\N
1575	Ձորաղբյուրի մ/դ	8	7	գ. Ձորաղբյուր,  Լուսավորության 25	40.202058000000001	44.6466920000000016	3	2	Գաբրիելյան Ռայա	91202734			Անտոնյան Նարինե	95191565				\N	\N
1571	Կուրթանի մ/դ	8	6	գ. Կուրթանի	\N	\N	3	\N	Վանիչկա Նալբանդյան	55110756	94449596		Անուշ Ստեփանյան	95172495				4	10
1593	Մեծ Սեպասարի մ/դ	8	8	գ. Մեծ Սեպասար	\N	\N	3	\N	Հրանտիկ Մելիքյան	95008746	77950486		Հրանտիկ Մելիքյան	95008746	77950486			\N	\N
1594	Սարատակի մ/դ	8	8	գ. Սարատակ	\N	\N	3	\N	Մինասյան Սերյոժա	95008782	77455346		Գրիգորյան Իրինա	93593803				\N	\N
1595	Արթիկի թիվ 2 հմ/դ	8	8	ք. Արթիկ, Անկախության 15	\N	\N	3	\N	Բավական Աբրահամյան	95008958	94912240		Ալվարդ Պետիկյան	93968850				\N	\N
1596	Արթիկի թիվ 3 ա/դ	8	8	ք. Արթիկ, Աբովյան 10	\N	\N	3	\N	Աշոտ Վարագյան	95008781	77204863		Զարուհի Պետրոսյան	93668826				\N	\N
1597	Արթիկի թիվ 6 հմ/դ	8	8	ք. Արթիկ, Շիրազի 8	\N	\N	3	\N	Դավթյան Աղունիկ	95008779	94958724		Նազիկ Երանոսյան	93653019				\N	\N
1601	Տաթևի Սուրեն Առաքելյանի անվ. մ/դ	8	9	գ. Տաթև	\N	\N	3	\N	Մովսիսյան Նորվարդ	28497471	94515337	95002957	Գայանե Պողոսյան	93605954				\N	\N
1607	Սիսիանի թիվ 1 hմ/դ	8	9	ք. Սիսիան, Կամոյի 3	\N	\N	3	\N	Դավթյան -Սարգսյան Գոհար	93656358	95002881		Լուսիկ Դովլաթյան	94797641				\N	\N
1608	Սիսիանի թիվ 1 հտ. հմ/դ	8	9	ք. Սիսիան, Կամոյի 5	\N	\N	3	\N	Մակարյան Սեյրան	95002883	93026015		Նելլի Մանուչարյան	55944046				\N	\N
1609	Աղավնաձորի մ/դ	8	10	գ. Աղավնաձոր	\N	\N	3	\N	Մանուկյան Նահապետ	95006145	94726908		Սուսաննա Գրիգորյան	94870894				\N	\N
1610	Արենիի մ/դ	8	10	գ. Արենի	\N	\N	3	\N	Հայրապետյան Ա.	95006143	93933780		Միանասյան Համեստ	93732705				\N	\N
1611	Արփիի մ/դ	8	10	գ. Արփի	\N	\N	3	\N	Ա. Հովսեփյան	93763173			Գագիկ Ավետյան	93612530				\N	\N
1612	Խաչիկի մ/դ	8	10	գ. Խաչիկ	\N	\N	3	\N	Թադևոսյան Ս.	93780399								\N	\N
1613	Մալիշկայի թիվ 1 մ/դ	8	10	գ. Մալիշկա	\N	\N	3	\N	Մարգարյան Արմեն	95006138	93840230		Գալուստ Դովլաթյան	77916133				\N	\N
1614	Մալիշկայի թիվ 2 մ/դ	8	10	գ. Մալիշկա	\N	\N	3	\N	Հասմիկ Դավթյան	95006139	93454563		Աննա Արսենյան	94584666				\N	\N
1615	Վերնաշենի մ/դ	8	10	գ. Վերնաշեն	\N	\N	3	\N	Հարությունյան Համլետ	95006137	93385556		Գասպարյան Արմինե	77713276				\N	\N
1619	Հերհերի մ/դ	8	10	գ. Հերհեր	\N	\N	3	\N	Ոսկանյան Երվանդ	95006113	93836503		Լուսինե Առաքելյան	28293135				\N	\N
1620	Ջերմուկի թիվ 1 հմ/դ	8	10	ք. Ջերմուկ, Շահումյան 7	\N	\N	3	\N	Սարգսյան Լուսիկ	95005898	94381836		Մովսիսյան Արտակ	94007141				\N	\N
1621	Ջերմուկի թիվ 3 հմ/դ	8	10	գ. Կեչուտ	\N	\N	3	\N	Ս. Ստեփանյան	95005864	94999201		Գոհար Ասատրյան	94010423				\N	\N
1622	Վայքի թիվ 1 ա/դ	8	10	ք. Վայք, Շահումյամ 93	\N	\N	3	\N	Հակոբյան Թարո	93318070	95005859		Ներսիսյան Ռուբիկ	94449655				\N	\N
1623	Վայքի թիվ 2 հմ/դ	8	10	ք. Վայք, Ալավերդյան 17	\N	\N	3	\N	Մնացականյան Հովիկ	94221292			Քնարիկ Ստեփանյան	28221020	94458822			\N	\N
1624	Ազատամուտի մ/դ	8	11	գ. Ազատամուտ	\N	\N	3	\N	Հակոբյան Լարիսա	95004161	93119144		Մարգարիտ Բադալյան	77734347				\N	\N
1627	Դիլիջանի թիվ 4 հմ/դ	8	11	ք. Դիլիջան Շահումյան 6	\N	\N	3	\N	Մկրտչյան Ծովիկ	95001543	94907500							\N	\N
1628	Արճիսի մ/դ	8	11	գ. Արճիս	\N	\N	3	\N	Մուսայելյան Հենրիկ	95001775	94446099		Մակարյան Սեդա	91809684				\N	\N
1629	Բերդավանի մ/դ	8	11	գ. Բերդավան	\N	\N	3	\N	Ասատրյան Արևիկ	95001954	93449599		Անահիտ Բարխուդարյան	55263788				\N	\N
1630	Կողբի թիվ 2 մ/դ	8	11	գ. Կողբ	\N	\N	3	\N	Նազարյան Կարեն	95001751	98764242		Մանիկ Ազատյան	55030317				\N	\N
1606	Շաղաթի մ/դ	8	9	գ. Շաղատ	\N	\N	3	\N	Հարությունյան Արամ	094386062			Նաիրա Եփրեմյան	77136381				5	12
1603	Գորիսի թիվ 1 հտ. հմ/դ	8	9	ք. Գորիս, Արզումանյան 7	\N	\N	3	\N	Շալունց Վլադիկ	95002937	91779040		Անուշ Դալլաքյան	98023754				\N	\N
1625	Գոշի թիվ 1 մ/դ	8	11	գ. Գոշ	\N	\N	3	\N	Ամիրխանյան Հայկազ	95004173	93093211		Շուշանիկ Ամիրխանյան	94261300				10	10
1604	Վաղատուրի մ/դ	8	9	գ. Վաղատուր	\N	\N	3	\N	Վարազդատ Խաչատրյան	094820172			Սերգեյ Սամվելյան	077659718				3	3
1616	Եղեգնաձորի  ա/դ	8	10	ք. Եղեգնաձոր, Շահումյան 12	\N	\N	3	\N	Հարությունյան Կ.	95006131	98387555							\N	\N
1617	Եղեգնաձորի թիվ 1 հմ/դ	8	10	ք. Եղեգնաձոր, Վայքի փ., 4 շենք	\N	\N	3	\N	Գրիգորյան Ա.	95006129	77724982		Սարգսյան Նարինե	77250711				\N	\N
1618	Զառիթափի Ա. Մելիքյանի անվ. մ/դ	8	10	գ. Զառիթափ	\N	\N	3	\N	Աբրահամյան Ս.	77175444			Հովհաննիսյան Կիմա	77398002				\N	\N
1626	Դիլիջանի թիվ 1 ա/դ	8	11	ք. Դիլիջան փ. Մյասնիկյան 61	\N	\N	3	\N	Արամյան Արա	95001495	91744257							\N	\N
1631	Կողբի Ջ. Կարախանյանի անվ. թիվ 1 մ/դ	8	11	գ. Կողբ	\N	\N	3	\N	Ղարագյոզյան Մարինե	95001952	93730873		Արմինե Ազատյան	98108204				\N	\N
1632	Ոսկեվանի մ/դ	8	11	գ. Ոսկեվան	\N	\N	3	\N	Մամյան Գարիկ		93703870		Վլադիմիր Զալինյան	91778416				\N	\N
1605	Նորավանի մ/դ	8	9	գ. Նորավան	\N	\N	3	\N	Արամ Անդրեասյան	95002857	93018795		Սուրեն Շահնազարյան	99006551				4	4
1598	Խնձորեսկի մ/դ	8	9	գ. Խնձորեսկ	\N	\N	3	\N	Վալենտինա Բալայան	95004643	94223380		Սրապունց Սոնա	093931905				5	19
1602	Տեղի թիվ 1 մ/դ	8	9	գ. Տեղ	\N	\N	3	\N	Գրիգորյան Սլավիկ	95002946	93003890		Խաչունց Մ․	077993227				3	11
1633	Պտղավանի մ/դ	8	11	գ. Պտղավան	\N	\N	3	\N	Կոպիյան Էլմիրա	95002117	94918276		Աշխեն Ավետյան	77409102				\N	\N
1636	Այգեպարի մ/դ	8	11	գ. Այգեպար	\N	\N	3	\N	Արզումանյան Արև	93913253	95001854		Արաքսյան Ադամյան	93301195				\N	\N
1638	Մովսեսի մ/դ	8	11	գ. Մովսես	\N	\N	3	\N	Ադամյան Ռուզաննա	95001583	98610461		Լիանա Ապերյան	94353523				\N	\N
1639	Նորաշենի մ/դ	8	11	գ. Նորաշեն	\N	\N	3	\N	Մխիթարյան Գագիկ	95001663	77121777		Չինար Միրզախանյան	94009978				\N	\N
1640	Տիգրանաշենի մ/դ	8	2	գ. Տիգրանաշեն	\N	\N	3	\N	Անդրեասյան Գեղամ	95006327	93545806							\N	\N
1643	Ծաղկաշատի հմ/դ	8	6	գ. Ծաղկաշատ	\N	\N	3	\N	Անահիտ Մուսայելյան	93928580			Պարանյան Վիկտորիա	77936963				\N	\N
1644	Կարմիր Աղեգու հմ/դ	8	6	գ. Կարմիր Աղեկ	\N	\N	3	\N	Միկոյան Սիրանուշ	55132688			Արփինե Մարգարյան , Մոսինյան Աննա (փոխարինող)	099 02 47 04	91528974			\N	\N
1645	Ջիլիզայի մ/դ	8	6	գ. Ջիլիզա	\N	\N	3	\N	Թունյան Սաթենիկ	93645089								\N	\N
1646	Ձորամուտի մ/դ	8	6	գ. Ձորամուտ	\N	\N	3	\N	Սուսաննա Պողոյան	95516412			Օվսաննա Գինոյան	94561675				\N	\N
1647	Պրիվոլնոյեյի մ/դ	8	6	գ. Պրիվոլնոյե	\N	\N	3	\N	Ֆյոդորովա Աննա	93077462			Գրիգորյան Էմիլ	91909225				\N	\N
1649	Սառնաղբյուրի մ/դ	8	8	գ. Սառնաղբյուր	\N	\N	3	\N	Հակոբյան Հմայակ	95006316	93850051		Բաղրյան Հայկուշ	98917552				\N	\N
1650	Արևիսի հմ/դ	8	9	գ. Արևիս	\N	\N	3	\N	Գրիգորյան Ռիտա	95006315	94374753		Առաքելյան Գայանե	98814299				\N	\N
1651	Խոզնավարի մ/դ	8	9	գ. Խոզնավար	\N	\N	3	\N	Գևորգյան Աշոտ	95006314	93604445		Գալստյան Մարգուշ	93334394				\N	\N
1652	Խնածախի մ/դ	8	9	գ. Խնածախ	\N	\N	3	\N	Ալբերտ Աղաջանյան	28490172	95006313	93 764505						\N	\N
1653	Գեղիի մ/դ	8	9	գ. Գեղի	\N	\N	3	\N	Խ. Տեր-Ստեփանյան	95006312	93996361		Ալեն Ղուկասյան	98330023				\N	\N
1654	Շվանիձորի մ/դ	8	9	գ. Շվանիձոր	\N	\N	3	\N	Անահիտ Զաքարյան	95006297	77995433		Ռ.Ստեփանյան	98051169				\N	\N
1655	Նռնաձորի մ/դ	8	9	գ. Նռնաձոր	\N	\N	3	\N	Գրիգորյան Սուսաննա	95006296	94105818		Թ.Մելյան	93161593				\N	\N
1656	Գողթանիկի հմ/դ	8	10	գ. Գողթանիկ	\N	\N	3	\N	Ասատրյան Անահիտ	94305857	95006285							\N	\N
1657	Հորսի հմ/դ	8	10	գ. Հորս	\N	\N	3	\N	Վարդանյան Մխիթար	95006286	99178090							\N	\N
1658	Գոշի թիվ 2 հմ/դ	8	11	գ. Գոշ	\N	\N	3	\N	Հովհաննիսյան Անահիտ	95006287	77551565		Արմեն Սարգսյան	94551569				\N	\N
1659	Բարեկամավանի մ/դ	8	11	գ. Բարեկամավան	\N	\N	3	\N	Ազատյան Աստղիկ	95006289	94902049		Հրանտ Աբովյան	77870779				\N	\N
1660	Կալավանի մ/դ	8	4	գ. Կալավան	\N	\N	3	\N	Քեշիշյան Զվարթ	95006291	93149993		Ղուկասյան Հովիկ	0265/60113				\N	\N
1664	ՀՖ Պահեստ	6	5	Պարոնյան 8/8	\N	\N	3	\N										\N	\N
1665	ՀՖ Գրասենյակ	7	5	Պարոնյան 8/9	\N	\N	3	\N										\N	\N
474	Արամուսի մ/դ 	3	7	գ. Արամուս	\N	\N	3	\N	Ֆրունզ Պողոսյան	94700826			Մարինե Սահակյան	094224475	Վարդուհի Վարդանյան	094841136		12	25
878	Երասխահունի մ/դ	3	3	գ. Երասխահուն	40.0727779999999996	44.2196229999999986	3	1	Սարիբեկյան Ս.	93877400			Ռուզաննա Շմավոնյան	93820237				\N	\N
904	Բաղրամյան մ/դ	3	3	գ. Բաղրամյան (Բաղրամյանի շրջ)	40.1965799999999973	43.8599329999999981	3	2	Տոմիկյան Աղասի	94244420			Պետրոսյան Իզաբելլա	77276767				\N	\N
720	Արագածի թիվ 1 մ/դ	3	1	գ. Արագած	\N	\N	3	\N	Սարգսյան Համլետ	0252/92281	93262607	95006389						\N	\N
1666	Փարաքար	4	3	գ.Փարաքար	40.1637259999999969	44.4150380000000027	3	1	Սիրեկան Սահակյան	55221172	94221172							\N	\N
1587	Պռոշյանի Պ. Ղևոնդյանի անվ. մ/դ	3	7	գ. Պռոշյան	40.2470780000000019	44.4185719999999975	3	1	Մկրտչյան Աննա	93470824			Անահիտ Հակոբյան	93312655				\N	\N
281	Արագածոտնի մ/դ	3	1	գ. Արագածոտն	\N	\N	3	\N	Միրզոյան Թամարա	55421401			Միքաելյան Անժելա					\N	\N
305	Չքնաղի հմ/դ	3	1	գ. Չքնաղ	\N	\N	3	\N	Դավթյան Մհեր	93872974	950063823							\N	\N
1663	Խնձորուտի մ/դ	8	10	գ. Խնձորուտ	\N	\N	3	\N	Համլետ Օհանյան	094-82-86-01	28294115	09465-75-96				24		12	\N
269	Սիփանի մ/դ	3	1	գ. Սիփան	\N	\N	3	2	Սադոյան Մրազ	93382214	95006417							\N	\N
1661	Սյունիքի տարածաշրջանային պետական քոլեջ	8	9	ք. Կապան, Արզումանյան 11	\N	\N	3	\N	Սարդարյան Մարատ	95008985	98406516		Ղոնյան Մերի	94731286				\N	\N
1662	Վայոց ձորի տարածաշրջանային պետական քոլեջ	8	10	ք. Եղեգնաձոր, Սպանդարյան 3	\N	\N	3	\N	Սարգսյան Խաչանուշ	93876199	95001573		Ավետիսյան Գոհար	28125375				\N	\N
1635	Նոյեմբերյանի թիվ 2 հմ/դ	8	11	ք. Նոյեմբերյան, Դպրոցականների 15	\N	\N	3	\N	Ալեքսանյան Փարսադամ	95003823	94013173		Լուսինե Հովհաննիսյան	94301044				\N	\N
1634	Նոյեմբերյանի թիվ 1 ա/դ	8	11	ք. Նոյեմբերյան, Դպրոցականների 13	\N	\N	3	\N	Գիշյան Ռուբիկ	95001837	94925892		Արևիկ Աղբալյան	94022289				\N	\N
1637	Արծվաբերդի Բ. Աղաբաբյանի անվ.մ/դ	8	11	գ. Արծվաբերդ	\N	\N	3	\N	Մխիթարյան Արտաշես	95001856	94107066		Զորաբյան Լիանա	93018575				\N	\N
1648	Հատիսի մ/դ	8	7	գ. Հատիս	\N	\N	3	\N		94116150								1	3
39	Պարտիզակ	4	1		\N	\N	3	\N										\N	\N
1671	Ոսկեթաս	4	1		40.4439940000000036	43.9450110000000009	3	\N										\N	\N
822	Դեղձուտի մ/դ	3	2	գ. Դեղձուտ	\N	\N	3	\N	Մելքոնյան Սրբուհի	95008664	94060558		Էդիկ Մելքոնյան	77776905	99116171			\N	\N
1672	Տիգրանաշեն	4	2		39.7856140000000025	44.9451079999999976	3	\N										\N	\N
1673	Զովաշեն	1	2		39.829895999999998	44.9936849999999993	3	\N										\N	\N
1674	Լանջաղբյուր	5	4		40.2668329999999983	45.1372670000000014	3	\N										\N	\N
1675	Սեմյոնովկա	1	4		40.6574200000000019	44.9314499999999981	3	\N										\N	\N
992	Զոլաքարի թիվ 1 մ/դ	3	4	գ. Զոլաքար	\N	\N	3	\N	Սողոյան Թամարա	95008557	93386197		Հայրապետյան Ս.	94638053				\N	\N
355	Ծովինարի տ/դ	3	4	գ. Ծովինար	\N	\N	3	\N	Գևորգյան Լուսինար	77225054			Գեվորգյան Վարդիթեր		94217058			\N	\N
1478	Լուսաձորի հմ/դ	3	11	գ. Լուսաձոր	\N	\N	3	\N	Սարդարյան Արմեն	95005853	94522707		Հասմիկ Այվազյան	93696070				\N	\N
1488	Դիտավանի հմ/դ	3	11	գ. Դիտավան	\N	\N	3	\N	Արմեն Հախվերդյան	95003882	77808660		Արշակ Ավետիսյան	94075353				\N	\N
1677	Չինչին	2	11		\N	\N	3	\N										\N	\N
1678	Չինարի	5	11		40.8491530000000012	45.5541109999999989	3	\N										\N	\N
1679	Քարկոպ	2	11		41.1806079999999994	44.8603809999999967	3	\N										\N	\N
1676	Բերքաբեր	4	11		41.0551060000000021	45.1468289999999968	3	\N										\N	\N
519	Գառնառիճի մ/դ	3	8	ք. Հրազդան, Շահումյան 170	\N	\N	3	\N	Նահապետյան Արևիկ	22362314	98123012		Սուսաննա Հովասյան	94001063				\N	\N
564	Կարմրավանի հմ/դ	3	8	գ. Կարմրավան	\N	\N	3	\N	Ավետիսյան Լուսինե	95008929	77232924		Էլիզա Սարգսյան	94539610				\N	\N
1338	Երազգավորսի մ/դ	3	8	գ. Երազգավորս	\N	\N	3	\N	Մխիթարյան Արամ	95009254	93018207		Սահակյան Անի	98931317				\N	\N
1680	Գյումրի Գալա	4	8		40.8071100000000015	43.846390999999997	3	\N										\N	\N
1269	Դաշտադեմի մ/դ	3	6	գ. Դաշտադեմ	\N	\N	3	\N	Աղաջանյան Սերգեյ	055 857585			Խրոյան Գայանե					\N	\N
1492	Վ. Կ. Աղբյուրի մ/դ	8	11	գ. Վ. Կ. Աղբյուր	\N	\N	3	\N	Մխիթարյան Հրանտ	95001363	93530785		Լիա Բադալյան	093152722				12	22
1681	Քարինջ	4	6		40.9733779999999967	44.691673999999999	3	\N										\N	\N
436	Գոգարանի մ/դ	8	6	գ. Գոգարան	\N	\N	3	\N	Նիկողոսյան Հ.	93696290								\N	\N
448	Նորաշենի մ/դ	8	6	գ. Նորաշեն	\N	\N	3	\N	Ռաֆիկ Մարտիրոսյան	77737128			Գալստյան Տաթևիկ	94718998				\N	\N
396	Ֆիոլետովոյի մ/դ	8	6	գ. Ֆիոլետովո	\N	\N	3	\N	Միրազաբեկյան Վալերի	91714950			Դավիթ Մարտիրոսյան	99195222				\N	\N
405	Ճոճկանի մ/դ	3	6	գ. Ճոճկան	\N	\N	3	\N	Խաչատրյան Է.	77090750								\N	\N
648	Գնդեվազի մ/դ	3	10	գ. Գնդեվազ	\N	\N	3	\N	Գերասիմ Անդրեասյան	95006154	93765876		Նաիրա Նիկողոսյան	93652258				\N	\N
612	Վերին Խոտանանի մ/դ	3	9	գ. Վերին Խոտանան	\N	\N	3	\N	Բադալյան Խաչատուր	95006172	93417395		Ոսկանյան Նարինե	94209080				\N	\N
1683	Զառ	4	7		40.2564319999999967	44.7372030000000009	3	\N										\N	\N
1684	Բջնի	4	7		40.464184000000003	44.6527280000000033	3	\N										\N	\N
1686	Ձորաղբյուր	4	7		40.2039970000000011	44.6367440000000002	3	\N										\N	\N
1687	Քուչակ	5	1		40.5231720000000024	44.390697000000003	3	\N										\N	\N
1081	Երևանի թիվ 159 ա/դ	8	5	Նորք-Նորք 5-րդ Մ/Շ	\N	\N	3	1	Զարինե Ղազարյան	010641133	95006334			099370875				\N	\N
1688	Բժնի-Արմենակ	4	7		\N	\N	\N	2	Արմենակ Այվազյան	094990676	055505450							\N	\N
1685	Գառնիի ամբուլատորիա	11	7		40.1172559999999976	44.7265769999999989	3	\N										\N	\N
591	Սալվարդի հմ/դ	8	9	գ. Սալվարդ	\N	\N	3	\N	Քրիստափորյան Հովհաննես	95002585	93627778		Աբելյան Կարինե-նախկին	93549852	Գևորգյան Գոհար	077381006		2	4
952	Վաղարշապատի թիվ 3 հմ/դ	8	3	ք. Վաղարշապատ, Աթարբեկյան	40.1636260000000007	44.289512000000002	3	1	Մարտիրոսյան Հունան	055020357		23152060	Սիմոնյան Ռուզան	98152211		55943539		6	10
1120	Երևանի թիվ 87 մ/դ	8	5	Խուդյակովի 44	\N	\N	3	\N	 Զեյնալյան Նարգիզ	94623141		611240	Ա. Բադալյան	91301305	Թևոսյան Անահիտ			10	32
1690	Գառնի	1	7		40.1213570000000033	44.7107489999999999	3	2										\N	\N
1141	Երևանի Հ.Գյուլիքեխվյանի անվ. թիվ 103 ա/դ	8	5	Զ. Սարկավագի 14	\N	\N	3	\N	Սպարտակ Վարդանյան	091714541	95006815	284685	Գոհար  Ասատրյան	095070196				24	10
1682	Դսեղ ամբուլատորիա	11	6		\N	\N	3	\N										\N	\N
1175	Երևանի Ս. Բյուրատի անվ. թիվ 125 հմ/դ	8	5	Պարույր Սևակի 89	\N	\N	3	\N	Լիլիթ Անտոնյան	096466364	95006742		Ալավերդյան Եպրաքսյա	99433004				14	54
773	Ոսկետափի ա/դ	3	2	գ. Ոսկետափ	\N	\N	3	\N	Մկրտչյան Հովիկ	95005743	93566070		Մկրտչյան Տաթև	099 58-34-57				\N	\N
365	Ձորագյուղի  ա/դ	8	4	գ. Ձորագյուղ	\N	\N	3	\N	Խաչատրյան Հերիքնազ	95008591	94804632		Հակոբյան Մերրի	93235351				\N	\N
1394	Գյումրու թիվ 6 հմ/դ	3	8	ք. Գյումրի, Թումանյան 20	\N	\N	3	\N	Արտաշես Սարգսյան	95009864	94901096		Կարո Սարգսյան	94961096				\N	\N
670	գ. Հաղթանակի մ/դ	8	11	գ. Հաղթանակ	\N	\N	3	\N	Բիջոյան Գևորգ	95004221	93442934		Աիդա Եգանյան	93148902				\N	\N
1232	Ստեփանավանի Մ. Խորենացու անվ. թիվ 3 մ/դ	8	6	ք. Ստեփանավան, Աշոտաբերդ թ.	\N	\N	3	\N	Մկրտչյան Նառա	25623186	95007286		Նոնա Բեժանյան	25624964	95007826	077057124		\N	\N
1599	Կոռնիձորի մ/դ	8	9	գ. Կոռնիձոր	\N	\N	3	\N	Սուսաննա Հովհաննիսյան	95004656	093468626		Նառա Գրիգորյան	94442286				3	8
1052	Երևանի Գ. Բաղյանի անվ. թիվ 141 հմ/դ	8	5	Ն/Ն Գյուլիքևիսյան-27	\N	\N	3	\N	Հովհաննիսյան Անահիտ	93816715	633401	95008768	Սանթրյան Արմինե	77915800				12	13
1523	Երևանի թիվ 104 հմ/դ	8	5	Աճառյան 5	\N	\N	3	\N	Նիկոյան Հայկանուշ	093131470	618450		Աթայան Անահիտ	094546101				18	18
289	Շամիրամի հմ/դ	8	1	գ. Շամիրամ	\N	\N	3	\N	Հովհաննիսյան Աշոտ	093834229 			Վասիլյան Արմենուհի	077688784				4	8
860	Արմավիրի «Տիգրան Մեծի» անվան ռազմամարզական հատուկ վարժարան	8	3	ք. Արմավիր, Աբովյան 149	40.1615419999999972	44.0226479999999967	3	1	Կորյուն Ղումաշյան	77212665			Բարեյան Ա	093212665		20		1	\N
1691	Նեղոց Building AP	4	6		\N	\N	\N	\N										\N	\N
660	Կայանի մ/դ	8	11	գ. Կայանավան	\N	\N	3	\N	Վարդանյան Լենա	93422924	95004139		Վանուհի Գուլինյան	98733037				6	10
1693	Մուցք	4	9	գ․Մուցք	\N	\N	3	2										\N	\N
1694	Բարձրավանի մ/դ	8	9	գ. Բարձրավան	\N	\N	3	2	Էդիկ Հովհաննիսյան	95004541	28439218	94423689	Մարգարյան Մարիա	91222205				\N	\N
1695	Եղվարդ	4	9	գ. Եղվարդ	\N	\N	3	2										\N	\N
1696	Սյունիք Building AP	4	9	գ․ Սյունիք	\N	\N	3	2										\N	\N
1697	Ձագեձոր	1	9	գ․ Ձագեձոր	\N	\N	3	2										\N	\N
1031	Փոքր Մասրիկի մ/դ	8	4	գ. Փոքր Մասրիկ	\N	\N	3	\N	Հովհաննիսյան Արմեն	95007558	93898259		Գրիգորյան Գայանե	77431822				2	4
692	Երևանի թիվ 9 արհեստագործական պետական ուսումնարան	8	5	ք. Երևան, Վարդաշեն փ. 6,	\N	\N	3	\N	Տոպոլյան Ռուզան	77010290	95008772		Միքայել Միքայելյան	99241224				\N	\N
1698	FastNet	13	5	Նալբանդյան 7/15	\N	\N	\N	\N										\N	\N
1692	Աշոտավանի մ/դ	8	9	գ. Աշոտավան	\N	\N	3	2	Օհանյան Հովսեփ	94815210			Կ. Մարգարյան	77993634	28395143			\N	\N
1699	Սևանի Վազգենյան հոգևոր դպրանոց	8	4	Սևանի թերակղզի	\N	\N	3	2										\N	\N
834	Հայանիստի մ/դ	3	2	գ. Հայանիստ	\N	\N	3	\N	Ավետիսյան Արմինե	094527000		95008639	Ելենա Գրիգորյան	93464425	099464425			1	10
1591	Բագրավանի մ/դ	8	8	գ. Հատիս	\N	\N	3	\N	Հարությունյան Հ:	094158383			Ժենյա Հովսեփյան	093143562				2	10
453	Կոտայքի տարածաշրջանային պետական քոլեջ	8	7	ք. Հրազդան, Կենտրոն	\N	\N	3	\N	Գևորգյան Գագիկ	93920922			Աննա Եղիազարյան	93141504				\N	\N
1113	Երևանի թիվ 49 հմ/դ	8	5	Նոր-Արեշ 5-րդ փող. 2	\N	\N	3	\N	Աբհրահամյան Ալեքսան	91411132	450200		Նելի Հախվերդյան	450630				\N	\N
1144	Երևանի Հ. Սահյանի անվ. թիվ 70 հմ/դ	8	5	Սարի-թաղ 3-րդ փող., 44 շ.	\N	\N	3	\N	Շափաղարյան Հերմինե	93393762	95006819	557578	Ավետիսյան Սաթիկ	55345447				\N	\N
1161	Երևանի Յ. Լեփսիուսի անվ. թիվ 88 հմ/դ	8	5	Կարախանյան 11	\N	\N	3	\N	Հարությունյան Գայանե	95006712	667300		Հարությունյան Նահրուհի	95638862				\N	\N
1519	Երևանի ԵՊՀ-ին առընթեր Ա. Շահինյանի անվան ֆիզ.մաթ. վարժ.	8	5	Ազատության պող. 2-րդ նրբանցք թիվ 9	\N	\N	3	\N	Նավասարդյան Հայկազ	95011055	95006775							\N	\N
872	Այգեշատի Յու. Հովհաննիսյանի անվ. մ/դ	8	3	գ. Այգեշատ	40.0762829999999965	44.059387000000001	3	2	Արմենակ Սարդարյան	094340539			Կարինե Տեր-Հարությունյան	93993035				1	9
761	Այգավանի մ/դ	8	2	գ. Այգավան, Սերոբ Հովհաննիսյան 43	\N	\N	3	\N	Ավետիսյան Կարինե	93211242	95007832		Անի Հարությունյան	93350460				15	35
945	Վաղարշապատի Գ. Նարեկացու անվան թիվ 2 ա/դ	8	3	ք. Վաղարշապատ, Մաշտոցի 75/2	40.1667660000000026	44.3016289999999984	3	1	Ալվարդ Հայրապետյան	93539448			Ալիսա Բաղդասարյան	94030520	94030520	93433828		3	\N
332	Էջմիածնի արհեստագործական պետ. Ուսումնարան	8	3	ք. Վաղարշապատ, Աթարբեկյան 101	40.1337249999999983	44.2936229999999966	3	2	Հովսեփ Վարդանյան	93719779			Լուսինե Թովմասյան	98848139			Պետք է միացնեն օպտիկա․․ Առաժմ ռադիո է․․	1	\N
1032	ք. Վարդենիսի թիվ 4 հմ/դ	8	4	ք. Վարդենիս, Շահումյան փ. թ. 5	\N	\N	3	\N	Սահակյան Անահիտ	95007542	94870449		Հովհաննիսյան Սեդա	93772804				\N	\N
1326	Նոր Հաճնի Մեծ Մուրադի թիվ 4 հմ/դ	8	7	ք. Նոր Հաճն, Շահումյան 1	\N	\N	3	\N	Հայկանուշ Պետրոսյան	98204447			Հարությունյան Կարինե	93975428				15	15
477	Գառնիի Ատոմի անվան թիվ 2 ա/դ	3	7	գ. Գառնի, փ. Ջ. Ալեքյան	40.117125999999999	44.7316239999999965	3	2	Հովհաննես Հարությունյան	096686761			Լուսինե Գեղամյան	99311119				10	40
1409	Գյումրու  թիվ 11 հմ/դ ՊՈԱԿ	8	8	ք. Գյումրի, Անի թաղ., Արամ Խաչատրյան  27	\N	\N	3	\N	Գրիգորյան Արմենուհի	055099960	 		Լարիսա Ալեքսանյան	98661080	095210958			6	6
709	Փարպիի Ղ. Փարպեցու անվ. մ/դ	8	1	գ. Փարպի	\N	\N	3	\N	Արշակյան Նորիկ	93900737	0232/96351		Արմինե Հարությունյան	077002920	Օվսաննա Գալստյան	098587088		3	10
1206	Դարպասի մ/դ	8	6	գ. Դարպաս	40.8321290000000019	44.4275710000000004	3	\N	Գուրջանյան Ս.	95007245	93916180		Արդենյան Հասմիկ	03226-29-44	032261672	093831895		\N	\N
991	Զոլաքարի Ա. Վարդանյանի անվ. թիվ 2 մ/դ	8	4	գ. Զոլաքար	\N	\N	3	\N	Մելիքյան Սամվել	95008556	93380026		Մարտիրոսյան Ներսիկ	93889138				\N	\N
1203	Ալավերդու Ս. Սպանդարյանի անվ. թիվ 1 մ/դ	8	6	ք. Ալավերդի, Էնգելսի 2 ա	\N	\N	3	\N	Սեդա Վահրամյան	95007461	91435941		Սերինե Հակոբյան	0253 23-72	96363836			\N	\N
1254	Վանաձորի Սոսի անվ. թիվ 13 մ/դ	8	6	ք. Վանաձոր, Թաղամաս 3 ուսանողական 11	\N	\N	3	\N	Էմինյան Գագիկ	0322-2-65-07	93705960		քարտոիղար Արփինե	98716812				\N	\N
1261	Վանաձորի թիվ 1 ա/ու	8	6	ք. Վանաձոր, Կ. Դեմիրճյանի 23	\N	\N	3	\N	Ղարաքեշիշյան Կառլեն	93022221			Դանիելյան Նազելի	91971611				\N	\N
472	Աբովյանի թիվ 1 արհեստագործական պետ. ուսումնարան	8	7	ք. Աբովյան, երիտասարդական 22	\N	\N	3	\N	Շահբազյան Մ	93269126	22220228		Զախարյան Օվսաննա	93356864				\N	\N
1581	Հրազդանի Ա. Շիրակացու անվ. թիվ 6 հմ/դ	8	7	ք. Հրազդան, Վանատուր թաղ, Զորավար Անդրանիկի 396	\N	\N	3	\N	Ղազարյան Գրիշա	22324753	93254793		Մանուշ Վարդանյան	91459121				\N	\N
1370	Արթիկի թիվ 8 հմ/դ	8	8	ք. Արթիկ, Բաղրամյան 19	\N	\N	3	\N	Մինասյան Հենրիկ	95008727	94171505		Կուրղինյան Դավիթ	55102088				\N	\N
1398	Գյումրու ԳՄԻ հենակետային Ակադեմիական վարժարան	8	8	ք. Գյումրի, Վ. Սարգսյան 13	\N	\N	3	\N	Լևոն Սեխպոսյան	41581434	 91581434		Սաթենիկ Վարդանյան	94848413	Կարապետյան Ալլա	093424276		6	8
1592	Մարալիկի թիվ 2 մ/դ	8	8	ք. Մարալիկ,Կոլտնտեսականների 2	\N	\N	3	\N	Գևորգյան Ռոզա	95009773	94845513		Նաիրա Գասպարյան	93055850				\N	\N
1701	Արմաշ Client-Ռադիկ	4	2		\N	\N	\N	\N										\N	\N
1702	Լանջառ Client-Պետիկ	4	2		\N	\N	\N	\N										\N	\N
\.


--
-- Name: Site_Site_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Site_Site_ID_seq"', 1702, true);


--
-- Data for Name: Site_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Site_Type" ("Site_Type_ID", "Site_Type_Name") FROM stdin;
1	TV Tower
2	New Tower
3	School AP
4	Building AP
5	Ucom AP
6	HF Stock
7	HF Office
8	School
11	Ambulatory
13	Partner Stock
\.


--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Site_Type_Site_Type_ID_seq"', 13, true);


--
-- Data for Name: Transfer_Status; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Transfer_Status" ("Transfer_Status_ID", "Transfer_Status_Name") FROM stdin;
1	Open
2	Close
\.


--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Transfer_Status_Transfer_Status_ID_seq"', 6, true);


--
-- Data for Name: Worker; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Worker" ("Worker_ID", "Worker_Name", "Worker_Position_ID", "Phone_Work", "Phone_Pers", "Email_Work", "Email_Pers") FROM stdin;
1	Մուրադ Մուրադյան	2	95412884	94990661	mourad@hf.am	test@test.ts
2	Մարիա Ասմանգուլյան	4	95556810	94990672	maria@hf.am	test@test.ts
3	Սիրեկան Սահակյան	3	55221172	94221172	sirekan@hf.am	test@test.ts
4	Վահրամ Մարտինյան	1	95556820	93120440	vahram@hf.am	test@test.ts
14	Արմենակ Այվազյան	5	055505450	094990676		
7	Վահե Մելքոնյան	5	95958316	77508009	vahmelk@gmail.com	vahmelk@mail.ru
9	Արթուր Մավյան	5	95958339	99633733	amavyan1980@gmail.com	mavyan1980@gmail.com
16	Արման Արոյան	5	095958331	098751074	armanaroyan77@gmail.com	
12	Թաթուլ Մկրտչյան	5	095958340	093605559	mkrtchyantatul3@gmail.com	tatulmcrtchyan@mail.ru
17	Վիկտոր Պողոսյան	5		077888883	taronvik4@gmail.com	taronvik1@gmail.com
13	Հայկ Օհանյան	5	095999335	099999335	haiko31@gmail.com	
18	Արթուր Պետրոսյան	5	095958332	077428309	arturpetrosyan090981@gmail.com	artur_petrosyan0@mail.ru
8	Գևորգ Արշակյան	5	95958854	99791197	arshakyangevorg121284@gmail.com	arshakyangevorg@mail.ru
15	Վիլեն Մամյան	5	095958320	055771141	mamyanvilen@gmail.com	vilen_mamyan@yahoo.com
21	Արմեն Գալստյան	5	095958335	096676679	agalstyan676@gmail.com	armenarmo@mail.ru
22	Արարատ Թիրաբյան	5	095958319	094480104	1ahqe1@gmail.com	ahqe@mail.ru
19	Սուրեն Կարապետյան	5	095958849	098237723	Surensurenyanc@gmail.com	suren_karapetyan@mail.ru
23	Վարդան Ավետիսյան	5	095958843	094003925	vardanavetisyan70620@gmail.com	vardan_av70@mail.ru
24	Ռոբերտ Պողոսյան	5	095958841	077205663	robertpoghosyan63@gmail.com	
20	Թաթուլ Մելքոնյան	5	095958842	094378825	tatul.melqonyan@gmail.com	tatul_melkonian@yahoo.com
5	Արմեն Հայրապետյան	5	95958347	93117339	a.hayrapetyan@hf.am	anonymbox555@gmail.com
25	Վարդան Հարությունյան 	5	055789514	093789514		harvar2017@gmail.com
6	Արմեն Սարգսյան	5	95556818	94990671	sarmen@hf.am	sarmen32@gmail.com
\.


--
-- Data for Name: Worker_Position; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "Worker_Position" ("Worker_Position_ID", "Worker_Position_Name") FROM stdin;
1	Admin
2	Ղեկավար
3	Տեխնիկական ղեկավար
4	Ֆինանսական ղեկավար
5	Տեխնիկ
\.


--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Worker_Position_Worker_Position_ID_seq"', 7, true);


--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('"Worker_Worker_ID_seq"', 25, true);


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY "__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20170728103548_IdentityAdded	1.1.2
\.


--
-- Name: Connection_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Connection_Type"
    ADD CONSTRAINT "Connection_Type_pkey" PRIMARY KEY ("Connection_Type_ID");


--
-- Name: Frequency_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Frequency"
    ADD CONSTRAINT "Frequency_pkey" PRIMARY KEY ("Frequency_ID");


--
-- Name: Item_Mode_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Item_Mode"
    ADD CONSTRAINT "Item_Mode_pkey" PRIMARY KEY ("Item_Mode_ID");


--
-- Name: Item_Status_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Item_Status"
    ADD CONSTRAINT "Item_Status_pkey" PRIMARY KEY ("Item_Status_ID");


--
-- Name: Item_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Item_Type"
    ADD CONSTRAINT "Item_Type_pkey" PRIMARY KEY ("Item_Type_ID");


--
-- Name: Item_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Item"
    ADD CONSTRAINT "Item_pkey" PRIMARY KEY ("Item_ID");


--
-- Name: Location_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY ("Location_ID");


--
-- Name: Manufacturer_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Manufacturer"
    ADD CONSTRAINT "Manufacturer_pkey" PRIMARY KEY ("Manufacturer_ID");


--
-- Name: Model_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Model"
    ADD CONSTRAINT "Model_pkey" PRIMARY KEY ("Model_ID");


--
-- Name: Owner_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Owner"
    ADD CONSTRAINT "Owner_pkey" PRIMARY KEY ("Owner_ID");


--
-- Name: PK_AspNetRoleClaims; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetRoleClaims"
    ADD CONSTRAINT "PK_AspNetRoleClaims" PRIMARY KEY ("Id");


--
-- Name: PK_AspNetRoles; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetRoles"
    ADD CONSTRAINT "PK_AspNetRoles" PRIMARY KEY ("Id");


--
-- Name: PK_AspNetUserClaims; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetUserClaims"
    ADD CONSTRAINT "PK_AspNetUserClaims" PRIMARY KEY ("Id");


--
-- Name: PK_AspNetUserLogins; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetUserLogins"
    ADD CONSTRAINT "PK_AspNetUserLogins" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: PK_AspNetUserRoles; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetUserRoles"
    ADD CONSTRAINT "PK_AspNetUserRoles" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: PK_AspNetUserTokens; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetUserTokens"
    ADD CONSTRAINT "PK_AspNetUserTokens" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: PK_AspNetUsers; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "AspNetUsers"
    ADD CONSTRAINT "PK_AspNetUsers" PRIMARY KEY ("Id");


--
-- Name: PK___EFMigrationsHistory; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");


--
-- Name: Region_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Region"
    ADD CONSTRAINT "Region_pkey" PRIMARY KEY ("Region_ID");


--
-- Name: Site_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Site_Type"
    ADD CONSTRAINT "Site_Type_pkey" PRIMARY KEY ("Site_Type_ID");


--
-- Name: Site_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Site"
    ADD CONSTRAINT "Site_pkey" PRIMARY KEY ("Site_ID");


--
-- Name: Transfer_Status_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Transfer_Status"
    ADD CONSTRAINT "Transfer_Status_pkey" PRIMARY KEY ("Transfer_Status_ID");


--
-- Name: Worker_Position_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Worker_Position"
    ADD CONSTRAINT "Worker_Position_pkey" PRIMARY KEY ("Worker_Position_ID");


--
-- Name: Worker_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory; Tablespace: 
--

ALTER TABLE ONLY "Worker"
    ADD CONSTRAINT "Worker_pkey" PRIMARY KEY ("Worker_ID");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE INDEX "EmailIndex" ON "AspNetUsers" USING btree ("NormalizedEmail");


--
-- Name: IX_AspNetRoleClaims_RoleId; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE INDEX "IX_AspNetRoleClaims_RoleId" ON "AspNetRoleClaims" USING btree ("RoleId");


--
-- Name: IX_AspNetUserClaims_UserId; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE INDEX "IX_AspNetUserClaims_UserId" ON "AspNetUserClaims" USING btree ("UserId");


--
-- Name: IX_AspNetUserLogins_UserId; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE INDEX "IX_AspNetUserLogins_UserId" ON "AspNetUserLogins" USING btree ("UserId");


--
-- Name: IX_AspNetUserRoles_RoleId; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE INDEX "IX_AspNetUserRoles_RoleId" ON "AspNetUserRoles" USING btree ("RoleId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE UNIQUE INDEX "RoleNameIndex" ON "AspNetRoles" USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: inventory; Tablespace: 
--

CREATE UNIQUE INDEX "UserNameIndex" ON "AspNetUsers" USING btree ("NormalizedUserName");


--
-- Name: Assigner_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Assigner_ID" FOREIGN KEY ("Assigner_ID") REFERENCES "Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Connection_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site"
    ADD CONSTRAINT "Connection_Type_ID" FOREIGN KEY ("Connection_Type_ID") REFERENCES "Connection_Type"("Connection_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: FK_AspNetRoleClaims_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetRoleClaims"
    ADD CONSTRAINT "FK_AspNetRoleClaims_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES "AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: FK_AspNetUserClaims_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetUserClaims"
    ADD CONSTRAINT "FK_AspNetUserClaims_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: FK_AspNetUserLogins_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetUserLogins"
    ADD CONSTRAINT "FK_AspNetUserLogins_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: FK_AspNetUserRoles_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES "AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: FK_AspNetUserRoles_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES "AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: Frequency_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Model"
    ADD CONSTRAINT "Frequency_ID" FOREIGN KEY ("Frequency_ID") REFERENCES "Frequency"("Frequency_ID") MATCH FULL ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: From_Site_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "From_Site_ID" FOREIGN KEY ("From_Site_ID") REFERENCES "Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Item_ID" FOREIGN KEY ("Item_ID") REFERENCES "Item"("Item_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Item_Mode_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Item_Mode_ID" FOREIGN KEY ("Item_Mode_ID") REFERENCES "Item_Mode"("Item_Mode_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item_Status_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Item_Status_ID" FOREIGN KEY ("Item_Status_ID") REFERENCES "Item_Status"("Item_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Model"
    ADD CONSTRAINT "Item_Type_ID" FOREIGN KEY ("Item_Type_ID") REFERENCES "Item_Type"("Item_Type_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Manufacturer_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Model"
    ADD CONSTRAINT "Manufacturer_ID" FOREIGN KEY ("Manufacturer_ID") REFERENCES "Manufacturer"("Manufacturer_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item"
    ADD CONSTRAINT "Model_ID" FOREIGN KEY ("Model_ID") REFERENCES "Model"("Model_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Owner_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Item"
    ADD CONSTRAINT "Owner_ID" FOREIGN KEY ("Owner_ID") REFERENCES "Owner"("Owner_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: PhysicalConnected_Item_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "PhysicalConnected_Item_ID" FOREIGN KEY ("PhysicalConnected_Item_ID") REFERENCES "Item"("Item_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Region_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site"
    ADD CONSTRAINT "Region_ID" FOREIGN KEY ("Region_ID") REFERENCES "Region"("Region_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Responsive_Person_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site"
    ADD CONSTRAINT "Responsive_Person_ID" FOREIGN KEY ("Responsive_Person_ID") REFERENCES "Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Site"
    ADD CONSTRAINT "Site_Type_ID" FOREIGN KEY ("Site_Type_ID") REFERENCES "Site_Type"("Site_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Technician_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Technician_ID" FOREIGN KEY ("Technician_ID") REFERENCES "Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: To_Site_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "To_Site_ID" FOREIGN KEY ("To_Site_ID") REFERENCES "Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Transfer_Status_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Location"
    ADD CONSTRAINT "Transfer_Status_ID" FOREIGN KEY ("Transfer_Status_ID") REFERENCES "Transfer_Status"("Transfer_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Worker_Position_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY "Worker"
    ADD CONSTRAINT "Worker_Position_ID" FOREIGN KEY ("Worker_Position_ID") REFERENCES "Worker_Position"("Worker_Position_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

