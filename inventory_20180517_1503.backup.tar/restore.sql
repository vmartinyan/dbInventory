--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.3 (Ubuntu 10.3-1)
-- Dumped by pg_dump version 10.3 (Ubuntu 10.3-1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."Worker" DROP CONSTRAINT "Worker_Worker_Position_ID_fkey";
ALTER TABLE ONLY public."Worker" DROP CONSTRAINT "Worker_Region_ID_fkey";
ALTER TABLE ONLY public."Worker" DROP CONSTRAINT "Worker_Region_ID";
ALTER TABLE ONLY public."Worker" DROP CONSTRAINT "Worker_Position_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Transfer_Status_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "To_Site_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Technician_ID";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_To_Site_ID_fkey";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_Technician_ID_fkey";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_Speedy_ID_fkey";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_From_Site_ID_fkey";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_Assigner_ID_fkey";
ALTER TABLE ONLY public."Speedy_Stock" DROP CONSTRAINT "Speedy_Stock_Speedy_ID_fkey";
ALTER TABLE ONLY public."Speedy_Stock" DROP CONSTRAINT "Speedy_Stock_Site_ID_fkey";
ALTER TABLE ONLY public."Speedy" DROP CONSTRAINT "Speedy_Measure_ID_fkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_Type_ID";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_Site_Type_ID_fkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_Responsive_Person_ID_fkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_Region_ID_fkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_Connection_Type_ID_fkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Responsive_Person_ID";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Region_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "PhysicalConnected_Item_ID";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Owner_ID";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Model_Manufacturer_ID_fkey";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Model_Item_Type_ID_fkey";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Model_ID";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Model_Frequency_ID_fkey";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Manufacturer_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Transfer_Status_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_To_Site_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Technician_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_PhysicalConnected_Item_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Item_Status_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Item_Mode_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Item_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_From_Site_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_Assigner_ID_fkey";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Item_Type_ID";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Item_Status_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Item_Status_ID";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Item_Owner_ID_fkey";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Item_Model_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Item_Mode_ID";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Item_Item_Status_ID_fkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Item_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "From_Site_ID";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Frequency_ID";
ALTER TABLE ONLY public."AspNetUserRoles" DROP CONSTRAINT "FK_AspNetUserRoles_AspNetUsers_UserId";
ALTER TABLE ONLY public."AspNetUserRoles" DROP CONSTRAINT "FK_AspNetUserRoles_AspNetRoles_RoleId";
ALTER TABLE ONLY public."AspNetUserLogins" DROP CONSTRAINT "FK_AspNetUserLogins_AspNetUsers_UserId";
ALTER TABLE ONLY public."AspNetUserClaims" DROP CONSTRAINT "FK_AspNetUserClaims_AspNetUsers_UserId";
ALTER TABLE ONLY public."AspNetRoleClaims" DROP CONSTRAINT "FK_AspNetRoleClaims_AspNetRoles_RoleId";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Connection_Type_ID";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Assigner_ID";
ALTER TABLE ONLY public."AspNetUserRoles" DROP CONSTRAINT "AspNetUserRoles_UserId_fkey";
ALTER TABLE ONLY public."AspNetUserRoles" DROP CONSTRAINT "AspNetUserRoles_RoleId_fkey";
ALTER TABLE ONLY public."AspNetUserLogins" DROP CONSTRAINT "AspNetUserLogins_UserId_fkey";
ALTER TABLE ONLY public."AspNetUserClaims" DROP CONSTRAINT "AspNetUserClaims_UserId_fkey";
ALTER TABLE ONLY public."AspNetRoleClaims" DROP CONSTRAINT "AspNetRoleClaims_RoleId_fkey";
DROP INDEX public."UserNameIndex";
DROP INDEX public."RoleNameIndex";
DROP INDEX public."IX_AspNetUserRoles_RoleId";
DROP INDEX public."IX_AspNetUserLogins_UserId";
DROP INDEX public."IX_AspNetUserClaims_UserId";
DROP INDEX public."IX_AspNetRoleClaims_RoleId";
DROP INDEX public."EmailIndex";
ALTER TABLE ONLY public."__EFMigrationsHistory" DROP CONSTRAINT "__EFMigrationsHistory_pkey";
ALTER TABLE ONLY public."Worker" DROP CONSTRAINT "Worker_pkey";
ALTER TABLE ONLY public."Worker_Position" DROP CONSTRAINT "Worker_Position_pkey";
ALTER TABLE ONLY public."Transfer_Status" DROP CONSTRAINT "Transfer_Status_pkey";
ALTER TABLE ONLY public."Speedy" DROP CONSTRAINT "Speedy_pkey";
ALTER TABLE ONLY public."Speedy_Transfer" DROP CONSTRAINT "Speedy_Transfer_pkey";
ALTER TABLE ONLY public."Speedy_Stock" DROP CONSTRAINT "Speedy_Stock_pkey";
ALTER TABLE ONLY public."Site" DROP CONSTRAINT "Site_pkey";
ALTER TABLE ONLY public."Site_Type" DROP CONSTRAINT "Site_Type_pkey";
ALTER TABLE ONLY public."Region" DROP CONSTRAINT "Region_pkey";
ALTER TABLE ONLY public."Owner" DROP CONSTRAINT "Owner_pkey";
ALTER TABLE ONLY public."Model" DROP CONSTRAINT "Model_pkey";
ALTER TABLE ONLY public."Measure" DROP CONSTRAINT "Measure_pkey";
ALTER TABLE ONLY public."Manufacturer" DROP CONSTRAINT "Manufacturer_pkey";
ALTER TABLE ONLY public."Location" DROP CONSTRAINT "Location_pkey";
ALTER TABLE ONLY public."Item" DROP CONSTRAINT "Item_pkey";
ALTER TABLE ONLY public."Item_Type" DROP CONSTRAINT "Item_Type_pkey";
ALTER TABLE ONLY public."Item_Status" DROP CONSTRAINT "Item_Status_pkey";
ALTER TABLE ONLY public."Item_Mode" DROP CONSTRAINT "Item_Mode_pkey";
ALTER TABLE ONLY public."Frequency" DROP CONSTRAINT "Frequency_pkey";
ALTER TABLE ONLY public."Connection_Type" DROP CONSTRAINT "Connection_Type_pkey";
ALTER TABLE ONLY public."AspNetUsers" DROP CONSTRAINT "AspNetUsers_pkey";
ALTER TABLE ONLY public."AspNetUserTokens" DROP CONSTRAINT "AspNetUserTokens_pkey";
ALTER TABLE ONLY public."AspNetUserRoles" DROP CONSTRAINT "AspNetUserRoles_pkey";
ALTER TABLE ONLY public."AspNetUserLogins" DROP CONSTRAINT "AspNetUserLogins_pkey";
ALTER TABLE ONLY public."AspNetUserClaims" DROP CONSTRAINT "AspNetUserClaims_pkey";
ALTER TABLE ONLY public."AspNetRoles" DROP CONSTRAINT "AspNetRoles_pkey";
ALTER TABLE ONLY public."AspNetRoleClaims" DROP CONSTRAINT "AspNetRoleClaims_pkey";
ALTER TABLE public."Worker_Position" ALTER COLUMN "Worker_Position_ID" DROP DEFAULT;
ALTER TABLE public."Worker" ALTER COLUMN "Worker_ID" DROP DEFAULT;
ALTER TABLE public."Transfer_Status" ALTER COLUMN "Transfer_Status_ID" DROP DEFAULT;
ALTER TABLE public."Speedy_Transfer" ALTER COLUMN "Speedy_Transfer_ID" DROP DEFAULT;
ALTER TABLE public."Speedy_Stock" ALTER COLUMN "Speedy_Stock_ID" DROP DEFAULT;
ALTER TABLE public."Speedy" ALTER COLUMN "Speedy_ID" DROP DEFAULT;
ALTER TABLE public."Site_Type" ALTER COLUMN "Site_Type_ID" DROP DEFAULT;
ALTER TABLE public."Site" ALTER COLUMN "Site_ID" DROP DEFAULT;
ALTER TABLE public."Region" ALTER COLUMN "Region_ID" DROP DEFAULT;
ALTER TABLE public."Owner" ALTER COLUMN "Owner_ID" DROP DEFAULT;
ALTER TABLE public."Model" ALTER COLUMN "Model_ID" DROP DEFAULT;
ALTER TABLE public."Measure" ALTER COLUMN "Measure_ID" DROP DEFAULT;
ALTER TABLE public."Manufacturer" ALTER COLUMN "Manufacturer_ID" DROP DEFAULT;
ALTER TABLE public."Location" ALTER COLUMN "Location_ID" DROP DEFAULT;
ALTER TABLE public."Item_Type" ALTER COLUMN "Item_Type_ID" DROP DEFAULT;
ALTER TABLE public."Item_Status" ALTER COLUMN "Item_Status_ID" DROP DEFAULT;
ALTER TABLE public."Item_Mode" ALTER COLUMN "Item_Mode_ID" DROP DEFAULT;
ALTER TABLE public."Item" ALTER COLUMN "Item_ID" DROP DEFAULT;
ALTER TABLE public."Frequency" ALTER COLUMN "Frequency_ID" DROP DEFAULT;
ALTER TABLE public."Connection_Type" ALTER COLUMN "Connection_Type_ID" DROP DEFAULT;
ALTER TABLE public."AspNetUserClaims" ALTER COLUMN "Id" DROP DEFAULT;
ALTER TABLE public."AspNetRoleClaims" ALTER COLUMN "Id" DROP DEFAULT;
DROP VIEW public."vwWorker";
DROP VIEW public."vwTransfer";
DROP VIEW public."vwSpeedy_Transfer";
DROP VIEW public."vwSpeedy_Stock";
DROP VIEW public."vwSpeedy";
DROP VIEW public."vwSite";
DROP VIEW public."vwModel";
DROP VIEW public."vwLocation";
DROP VIEW public."vwToSite";
DROP VIEW public."vwTechnisian";
DROP VIEW public."vwPCItem";
DROP VIEW public."vwItem";
DROP VIEW public."vwFromSite";
DROP VIEW public."vwAsigner";
DROP TABLE public."__EFMigrationsHistory";
DROP SEQUENCE public."Worker_Worker_ID_seq";
DROP SEQUENCE public."Worker_Position_Worker_Position_ID_seq";
DROP TABLE public."Worker_Position";
DROP TABLE public."Worker";
DROP SEQUENCE public."Transfer_Status_Transfer_Status_ID_seq";
DROP TABLE public."Transfer_Status";
DROP SEQUENCE public."Speedy_Transfer_ID";
DROP TABLE public."Speedy_Transfer";
DROP SEQUENCE public."Speedy_Stock_ID";
DROP TABLE public."Speedy_Stock";
DROP SEQUENCE public."Speedy_ID";
DROP TABLE public."Speedy";
DROP SEQUENCE public."Site_Type_Site_Type_ID_seq";
DROP TABLE public."Site_Type";
DROP SEQUENCE public."Site_Site_ID_seq";
DROP TABLE public."Site";
DROP SEQUENCE public."Region_Region_ID_seq";
DROP TABLE public."Region";
DROP SEQUENCE public."Owner_Owner_ID_seq";
DROP TABLE public."Owner";
DROP SEQUENCE public."Model_Model_ID_seq";
DROP TABLE public."Model";
DROP SEQUENCE public."Measure_ID";
DROP TABLE public."Measure";
DROP SEQUENCE public."Manufacturer_Manufacturer_ID_seq";
DROP TABLE public."Manufacturer";
DROP SEQUENCE public."Location_Location_ID_seq";
DROP TABLE public."Location";
DROP SEQUENCE public."Item_Type_Item_Type_ID_seq";
DROP TABLE public."Item_Type";
DROP SEQUENCE public."Item_Status_Item_Status_ID_seq";
DROP TABLE public."Item_Status";
DROP SEQUENCE public."Item_Mode_Item_Mode_ID_seq";
DROP TABLE public."Item_Mode";
DROP SEQUENCE public."Item_Item_ID_seq";
DROP TABLE public."Item";
DROP SEQUENCE public."Frequency_Frequency_ID_seq";
DROP TABLE public."Frequency";
DROP SEQUENCE public."Connection_Type_Connection_Type_ID_seq";
DROP TABLE public."Connection_Type";
DROP TABLE public."AspNetUsers";
DROP TABLE public."AspNetUserTokens";
DROP TABLE public."AspNetUserRoles";
DROP TABLE public."AspNetUserLogins";
DROP SEQUENCE public."AspNetUserClaims_Id_seq";
DROP TABLE public."AspNetUserClaims";
DROP TABLE public."AspNetRoles";
DROP SEQUENCE public."AspNetRoleClaims_Id_seq";
DROP TABLE public."AspNetRoleClaims";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: AspNetRoleClaims; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetRoleClaims" (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "RoleId" text NOT NULL
);


ALTER TABLE public."AspNetRoleClaims" OWNER TO inventory;

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."AspNetRoleClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AspNetRoleClaims_Id_seq" OWNER TO inventory;

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."AspNetRoleClaims_Id_seq" OWNED BY public."AspNetRoleClaims"."Id";


--
-- Name: AspNetRoles; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetRoles" (
    "Id" text NOT NULL,
    "ConcurrencyStamp" text,
    "Name" character varying(256),
    "NormalizedName" character varying(256)
);


ALTER TABLE public."AspNetRoles" OWNER TO inventory;

--
-- Name: AspNetUserClaims; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetUserClaims" (
    "Id" integer NOT NULL,
    "ClaimType" text,
    "ClaimValue" text,
    "UserId" text NOT NULL
);


ALTER TABLE public."AspNetUserClaims" OWNER TO inventory;

--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."AspNetUserClaims_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."AspNetUserClaims_Id_seq" OWNER TO inventory;

--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."AspNetUserClaims_Id_seq" OWNED BY public."AspNetUserClaims"."Id";


--
-- Name: AspNetUserLogins; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetUserLogins" (
    "LoginProvider" text NOT NULL,
    "ProviderKey" text NOT NULL,
    "ProviderDisplayName" text,
    "UserId" text NOT NULL
);


ALTER TABLE public."AspNetUserLogins" OWNER TO inventory;

--
-- Name: AspNetUserRoles; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetUserRoles" (
    "UserId" text NOT NULL,
    "RoleId" text NOT NULL
);


ALTER TABLE public."AspNetUserRoles" OWNER TO inventory;

--
-- Name: AspNetUserTokens; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetUserTokens" (
    "UserId" text NOT NULL,
    "LoginProvider" text NOT NULL,
    "Name" text NOT NULL,
    "Value" text
);


ALTER TABLE public."AspNetUserTokens" OWNER TO inventory;

--
-- Name: AspNetUsers; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."AspNetUsers" (
    "Id" text NOT NULL,
    "AccessFailedCount" integer NOT NULL,
    "ConcurrencyStamp" text,
    "Email" character varying(256),
    "EmailConfirmed" boolean NOT NULL,
    "LockoutEnabled" boolean NOT NULL,
    "LockoutEnd" timestamp(6) with time zone,
    "NormalizedEmail" character varying(256),
    "NormalizedUserName" character varying(256),
    "PasswordHash" text,
    "PhoneNumber" text,
    "PhoneNumberConfirmed" boolean NOT NULL,
    "SecurityStamp" text,
    "TwoFactorEnabled" boolean NOT NULL,
    "UserName" character varying(256)
);


ALTER TABLE public."AspNetUsers" OWNER TO inventory;

--
-- Name: Connection_Type; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Connection_Type" (
    "Connection_Type_ID" integer NOT NULL,
    "Connection_Type_Name" text
);


ALTER TABLE public."Connection_Type" OWNER TO inventory;

--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Connection_Type_Connection_Type_ID_seq"
    START WITH 7
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Connection_Type_Connection_Type_ID_seq" OWNER TO inventory;

--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Connection_Type_Connection_Type_ID_seq" OWNED BY public."Connection_Type"."Connection_Type_ID";


--
-- Name: Frequency; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Frequency" (
    "Frequency_ID" integer NOT NULL,
    "Frequency_Name" text
);


ALTER TABLE public."Frequency" OWNER TO inventory;

--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Frequency_Frequency_ID_seq"
    START WITH 1002
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Frequency_Frequency_ID_seq" OWNER TO inventory;

--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Frequency_Frequency_ID_seq" OWNED BY public."Frequency"."Frequency_ID";


--
-- Name: Item; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Item" (
    "Item_ID" integer NOT NULL,
    "Model_ID" integer,
    "Serial_Number" text,
    "Inventory_Number" text,
    "Owner_ID" integer,
    "MAC_Address" text,
    "Item_Status_ID" integer,
    "Creator" character varying(255),
    "LastModifier" character varying(255)
);


ALTER TABLE public."Item" OWNER TO inventory;

--
-- Name: Item_Item_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Item_Item_ID_seq"
    START WITH 4121
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Item_ID_seq" OWNER TO inventory;

--
-- Name: Item_Item_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Item_Item_ID_seq" OWNED BY public."Item"."Item_ID";


--
-- Name: Item_Mode; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Item_Mode" (
    "Item_Mode_ID" integer NOT NULL,
    "Item_Mode_Name" text
);


ALTER TABLE public."Item_Mode" OWNER TO inventory;

--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Item_Mode_Item_Mode_ID_seq"
    START WITH 5
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Mode_Item_Mode_ID_seq" OWNER TO inventory;

--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Item_Mode_Item_Mode_ID_seq" OWNED BY public."Item_Mode"."Item_Mode_ID";


--
-- Name: Item_Status; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Item_Status" (
    "Item_Status_ID" integer NOT NULL,
    "Item_Status_Name" text
);


ALTER TABLE public."Item_Status" OWNER TO inventory;

--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Item_Status_Item_Status_ID_seq"
    START WITH 7
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Status_Item_Status_ID_seq" OWNER TO inventory;

--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Item_Status_Item_Status_ID_seq" OWNED BY public."Item_Status"."Item_Status_ID";


--
-- Name: Item_Type; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Item_Type" (
    "Item_Type_ID" integer NOT NULL,
    "Item_Type_Name" text
);


ALTER TABLE public."Item_Type" OWNER TO inventory;

--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Item_Type_Item_Type_ID_seq"
    START WITH 12
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Item_Type_Item_Type_ID_seq" OWNER TO inventory;

--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Item_Type_Item_Type_ID_seq" OWNED BY public."Item_Type"."Item_Type_ID";


--
-- Name: Location; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Location" (
    "Location_ID" integer NOT NULL,
    "Device_Name" text,
    "PhysicalConnected_Item_ID" integer,
    "From_Site_ID" integer,
    "To_Site_ID" integer,
    "Item_Status_ID" integer,
    "Start_Date" date,
    "End_Date" date,
    "Item_IP_Address" text,
    "Item_Mode_ID" integer,
    "Item_SSID" text,
    "Technician_ID" integer,
    "Assigner_ID" integer,
    "Transfer_Status_ID" integer,
    "Description" text,
    "Item_ID" integer,
    "Creator" character varying(255),
    "LastModifier" character varying(255)
);


ALTER TABLE public."Location" OWNER TO inventory;

--
-- Name: Location_Location_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Location_Location_ID_seq"
    START WITH 5387
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Location_Location_ID_seq" OWNER TO inventory;

--
-- Name: Location_Location_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Location_Location_ID_seq" OWNED BY public."Location"."Location_ID";


--
-- Name: Manufacturer; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Manufacturer" (
    "Manufacturer_ID" integer NOT NULL,
    "Manufacturer_Name" text NOT NULL
);


ALTER TABLE public."Manufacturer" OWNER TO inventory;

--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Manufacturer_Manufacturer_ID_seq"
    START WITH 49
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Manufacturer_Manufacturer_ID_seq" OWNER TO inventory;

--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Manufacturer_Manufacturer_ID_seq" OWNED BY public."Manufacturer"."Manufacturer_ID";


--
-- Name: Measure; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Measure" (
    "Measure_ID" integer NOT NULL,
    "Measure_Name" text NOT NULL
);


ALTER TABLE public."Measure" OWNER TO inventory;

--
-- Name: Measure_ID; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Measure_ID"
    START WITH 8
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Measure_ID" OWNER TO inventory;

--
-- Name: Measure_ID; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Measure_ID" OWNED BY public."Measure"."Measure_ID";


--
-- Name: Model; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Model" (
    "Model_ID" integer NOT NULL,
    "Model_Name" text NOT NULL,
    "Manufacturer_ID" integer,
    "Power" text,
    "Frequency_ID" integer,
    "Item_Type_ID" integer
);


ALTER TABLE public."Model" OWNER TO inventory;

--
-- Name: Model_Model_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Model_Model_ID_seq"
    START WITH 140
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Model_Model_ID_seq" OWNER TO inventory;

--
-- Name: Model_Model_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Model_Model_ID_seq" OWNED BY public."Model"."Model_ID";


--
-- Name: Owner; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Owner" (
    "Owner_ID" integer NOT NULL,
    "Owner_Name" text
);


ALTER TABLE public."Owner" OWNER TO inventory;

--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Owner_Owner_ID_seq"
    START WITH 9
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Owner_Owner_ID_seq" OWNER TO inventory;

--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Owner_Owner_ID_seq" OWNED BY public."Owner"."Owner_ID";


--
-- Name: Region; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Region" (
    "Region_ID" integer NOT NULL,
    "Region_Name" text
);


ALTER TABLE public."Region" OWNER TO inventory;

--
-- Name: Region_Region_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Region_Region_ID_seq"
    START WITH 13
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Region_Region_ID_seq" OWNER TO inventory;

--
-- Name: Region_Region_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Region_Region_ID_seq" OWNED BY public."Region"."Region_ID";


--
-- Name: Site; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Site" (
    "Site_ID" integer NOT NULL,
    "Site_Name" text,
    "Site_Type_ID" integer,
    "Region_ID" integer,
    "Address" text,
    "Latitude" double precision,
    "Longitude" double precision,
    "Responsive_Person_ID" integer,
    "Connection_Type_ID" integer,
    "Head_Name" text,
    "Head_Phone_1" text,
    "Head_Phone_2" text,
    "Head_Phone_3" text,
    "Operator_Name" text,
    "Operator_Phone_1" text,
    "Operator_Phone_2" text,
    "Operator_Phone_3" text,
    "Description" text,
    "Connected_Comp_Count" integer,
    "School_Comp_Count" integer,
    "Creator" character varying(255),
    "LastModifier" character varying(255)
);


ALTER TABLE public."Site" OWNER TO inventory;

--
-- Name: Site_Site_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Site_Site_ID_seq"
    START WITH 1726
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Site_Site_ID_seq" OWNER TO inventory;

--
-- Name: Site_Site_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Site_Site_ID_seq" OWNED BY public."Site"."Site_ID";


--
-- Name: Site_Type; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Site_Type" (
    "Site_Type_ID" integer NOT NULL,
    "Site_Type_Name" text
);


ALTER TABLE public."Site_Type" OWNER TO inventory;

--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Site_Type_Site_Type_ID_seq"
    START WITH 14
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Site_Type_Site_Type_ID_seq" OWNER TO inventory;

--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Site_Type_Site_Type_ID_seq" OWNED BY public."Site_Type"."Site_Type_ID";


--
-- Name: Speedy; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Speedy" (
    "Speedy_ID" integer NOT NULL,
    "Speedy_Name" text,
    "Measure_ID" integer
);


ALTER TABLE public."Speedy" OWNER TO inventory;

--
-- Name: Speedy_ID; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Speedy_ID"
    START WITH 32
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Speedy_ID" OWNER TO inventory;

--
-- Name: Speedy_ID; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Speedy_ID" OWNED BY public."Speedy"."Speedy_ID";


--
-- Name: Speedy_Stock; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Speedy_Stock" (
    "Speedy_Stock_ID" integer NOT NULL,
    "Site_ID" integer NOT NULL,
    "Speedy_ID" integer DEFAULT nextval('public."Speedy_ID"'::regclass) NOT NULL,
    "Count" double precision NOT NULL
);


ALTER TABLE public."Speedy_Stock" OWNER TO inventory;

--
-- Name: Speedy_Stock_ID; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Speedy_Stock_ID"
    START WITH 104
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Speedy_Stock_ID" OWNER TO inventory;

--
-- Name: Speedy_Stock_ID; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Speedy_Stock_ID" OWNED BY public."Speedy_Stock"."Speedy_Stock_ID";


--
-- Name: Speedy_Transfer; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Speedy_Transfer" (
    "Speedy_Transfer_ID" integer NOT NULL,
    "Speedy_ID" integer,
    "Count" double precision,
    "From_Site_ID" integer,
    "To_Site_ID" integer,
    "Date" date,
    "Description" text,
    "Technician_ID" integer,
    "Assigner_ID" integer,
    "Creator" character varying(255),
    "LastModifier" character varying(255)
);


ALTER TABLE public."Speedy_Transfer" OWNER TO inventory;

--
-- Name: Speedy_Transfer_ID; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Speedy_Transfer_ID"
    START WITH 132
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Speedy_Transfer_ID" OWNER TO inventory;

--
-- Name: Speedy_Transfer_ID; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Speedy_Transfer_ID" OWNED BY public."Speedy_Transfer"."Speedy_Transfer_ID";


--
-- Name: Transfer_Status; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Transfer_Status" (
    "Transfer_Status_ID" integer NOT NULL,
    "Transfer_Status_Name" text
);


ALTER TABLE public."Transfer_Status" OWNER TO inventory;

--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Transfer_Status_Transfer_Status_ID_seq"
    START WITH 6
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Transfer_Status_Transfer_Status_ID_seq" OWNER TO inventory;

--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Transfer_Status_Transfer_Status_ID_seq" OWNED BY public."Transfer_Status"."Transfer_Status_ID";


--
-- Name: Worker; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Worker" (
    "Worker_ID" integer NOT NULL,
    "Worker_Name" text,
    "Worker_Position_ID" integer,
    "Phone_Work" text,
    "Phone_Pers" text,
    "Email_Work" text,
    "Email_Pers" text,
    "Region_ID" integer
);


ALTER TABLE public."Worker" OWNER TO inventory;

--
-- Name: Worker_Position; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."Worker_Position" (
    "Worker_Position_ID" integer NOT NULL,
    "Worker_Position_Name" text
);


ALTER TABLE public."Worker_Position" OWNER TO inventory;

--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Worker_Position_Worker_Position_ID_seq"
    START WITH 10
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Worker_Position_Worker_Position_ID_seq" OWNER TO inventory;

--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Worker_Position_Worker_Position_ID_seq" OWNED BY public."Worker_Position"."Worker_Position_ID";


--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE; Schema: public; Owner: inventory
--

CREATE SEQUENCE public."Worker_Worker_ID_seq"
    START WITH 27
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Worker_Worker_ID_seq" OWNER TO inventory;

--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: inventory
--

ALTER SEQUENCE public."Worker_Worker_ID_seq" OWNED BY public."Worker"."Worker_ID";


--
-- Name: __EFMigrationsHistory; Type: TABLE; Schema: public; Owner: inventory
--

CREATE TABLE public."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE public."__EFMigrationsHistory" OWNER TO inventory;

--
-- Name: vwAsigner; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwAsigner" AS
 SELECT "Worker"."Worker_ID",
    "Worker"."Worker_Name",
    "Worker"."Worker_Position_ID",
    "Worker"."Phone_Work",
    "Worker"."Phone_Pers",
    "Worker"."Email_Work",
    "Worker"."Email_Pers",
    "Worker_Position"."Worker_Position_Name"
   FROM (public."Worker"
     LEFT JOIN public."Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")));


ALTER TABLE public."vwAsigner" OWNER TO inventory;

--
-- Name: vwFromSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwFromSite" AS
 SELECT "Site"."Site_ID",
    "Site"."Site_Name",
    "Site"."Site_Type_ID",
    "Site"."Region_ID",
    "Site_Type"."Site_Type_Name",
    "Region"."Region_Name",
    concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info",
    concat_ws(' '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name") AS "Site_Full_Name"
   FROM ((public."Site"
     LEFT JOIN public."Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID")))
     LEFT JOIN public."Region" ON (("Site"."Region_ID" = "Region"."Region_ID")));


ALTER TABLE public."vwFromSite" OWNER TO inventory;

--
-- Name: vwItem; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwItem" AS
 SELECT "Item"."Item_ID",
    "Item"."Model_ID",
    "Item"."Serial_Number",
    "Item"."Inventory_Number",
    "Item"."Owner_ID",
    "Item"."MAC_Address",
    "Model"."Model_Name",
    "Model"."Manufacturer_ID",
    "Model"."Power",
    "Model"."Frequency_ID",
    "Model"."Item_Type_ID",
    "Owner"."Owner_Name",
    "Manufacturer"."Manufacturer_Name",
    "Item_Type"."Item_Type_Name",
    "Frequency"."Frequency_Name",
    concat_ws(' - '::text, "Item"."Serial_Number", "Model"."Model_Name", "Owner"."Owner_Name") AS "Item_Info",
    "Item"."Item_Status_ID",
    "Item_Status"."Item_Status_Name",
    "Item"."Creator",
    "Item"."LastModifier"
   FROM ((((((public."Item"
     LEFT JOIN public."Model" ON (("Item"."Model_ID" = "Model"."Model_ID")))
     LEFT JOIN public."Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID")))
     LEFT JOIN public."Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID")))
     LEFT JOIN public."Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")))
     LEFT JOIN public."Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")))
     LEFT JOIN public."Item_Status" ON (("Item"."Item_Status_ID" = "Item_Status"."Item_Status_ID")));


ALTER TABLE public."vwItem" OWNER TO inventory;

--
-- Name: vwPCItem; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwPCItem" AS
 SELECT "Item"."Item_ID",
    "Item"."Model_ID",
    "Item"."Serial_Number",
    "Item"."Inventory_Number",
    "Item"."Owner_ID",
    "Item"."MAC_Address",
    "Model"."Model_Name",
    "Model"."Manufacturer_ID",
    "Model"."Power",
    "Model"."Frequency_ID",
    "Model"."Item_Type_ID",
    "Owner"."Owner_Name",
    "Manufacturer"."Manufacturer_Name",
    "Item_Type"."Item_Type_Name",
    "Frequency"."Frequency_Name",
    concat_ws(' - '::text, "Item"."Serial_Number", "Model"."Model_Name", "Owner"."Owner_Name") AS "Item_Info"
   FROM (((((public."Item"
     LEFT JOIN public."Model" ON (("Item"."Model_ID" = "Model"."Model_ID")))
     LEFT JOIN public."Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID")))
     LEFT JOIN public."Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID")))
     LEFT JOIN public."Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")))
     LEFT JOIN public."Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwPCItem" OWNER TO inventory;

--
-- Name: vwTechnisian; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwTechnisian" AS
 SELECT "Worker"."Worker_ID",
    "Worker"."Worker_Name",
    "Worker"."Worker_Position_ID",
    "Worker"."Phone_Work",
    "Worker"."Phone_Pers",
    "Worker"."Email_Work",
    "Worker"."Email_Pers",
    "Worker_Position"."Worker_Position_Name"
   FROM (public."Worker"
     LEFT JOIN public."Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")));


ALTER TABLE public."vwTechnisian" OWNER TO inventory;

--
-- Name: vwToSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwToSite" AS
 SELECT "Site"."Site_ID",
    "Site"."Site_Name",
    "Site"."Site_Type_ID",
    "Site"."Region_ID",
    "Site_Type"."Site_Type_Name",
    "Region"."Region_Name",
    concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info",
    concat_ws(' '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name") AS "Site_full_Name"
   FROM ((public."Site"
     LEFT JOIN public."Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID")))
     LEFT JOIN public."Region" ON (("Site"."Region_ID" = "Region"."Region_ID")));


ALTER TABLE public."vwToSite" OWNER TO inventory;

--
-- Name: vwLocation; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwLocation" AS
 SELECT "Location"."Location_ID",
    "Location"."Device_Name",
    "Location"."PhysicalConnected_Item_ID",
    "vwPCItem"."Serial_Number" AS "PC_Serial_Number",
    "vwPCItem"."Model_Name" AS "PC_Model_Name",
    "vwPCItem"."Owner_Name" AS "PC_Owner_Name",
    "vwPCItem"."Item_Info" AS "PC_Item_Info",
    "Location"."From_Site_ID",
    "vwFromSite"."Site_Name" AS "From_Site",
    "vwFromSite"."Region_Name" AS "From_Site_Region",
    "vwFromSite"."Site_Info" AS "From_Site_Info",
    "Location"."To_Site_ID",
    "vwToSite"."Site_Name" AS "To_Site",
    "vwToSite"."Region_Name" AS "To_Site_Region",
    "vwToSite"."Site_Info" AS "To_Site_Info",
    "Location"."Item_Status_ID",
    "Item_Status"."Item_Status_Name",
    "Location"."Start_Date",
    "Location"."End_Date",
    "Location"."Item_IP_Address",
    "Item_Mode"."Item_Mode_Name",
    "Location"."Item_Mode_ID",
    "Location"."Item_SSID",
    "vwTechnisian"."Worker_Name" AS "Technician_Name",
    "Location"."Technician_ID",
    "Location"."Assigner_ID",
    "vwAsigner"."Worker_Name" AS "Assigner_Name",
    "Transfer_Status"."Transfer_Status_Name",
    "Location"."Transfer_Status_ID",
    "Location"."Description",
    "Location"."Item_ID",
    "Item"."Serial_Number" AS "Item_Serial_Number",
    "Item"."Inventory_Number" AS "Item_Inventory_Number",
    "Item"."MAC_Address" AS "Item_MAC_Address",
    "Model"."Model_Name" AS "Item_Model_Name",
    "Owner"."Owner_Name" AS "Item_Owner_Name",
    "Model"."Power" AS "Item_Power",
    "Manufacturer"."Manufacturer_Name" AS "Item_Manufacturer_Name",
    "Item_Type"."Item_Type_Name" AS "Item_Item_Type_Name",
    "Frequency"."Frequency_Name" AS "Item_Frequency_Name",
    "vwFromSite"."Site_Type_Name" AS "From_Site_Type_Name",
    "vwToSite"."Site_Type_Name" AS "To_Site_Type_Name",
    "vwFromSite"."Site_Full_Name" AS "From_Site_Full_Name",
    "vwToSite"."Site_full_Name" AS "To_Site_Full_Name",
    "Item"."Owner_ID" AS "Item_Owner_ID",
    "Item"."Model_ID" AS "Item_Model_ID",
    "Location"."Creator",
    "Location"."LastModifier"
   FROM ((((((((((((((public."Location"
     LEFT JOIN public."vwPCItem" ON (("Location"."PhysicalConnected_Item_ID" = "vwPCItem"."Item_ID")))
     LEFT JOIN public."vwFromSite" ON (("Location"."From_Site_ID" = "vwFromSite"."Site_ID")))
     LEFT JOIN public."vwToSite" ON (("Location"."To_Site_ID" = "vwToSite"."Site_ID")))
     LEFT JOIN public."Item_Status" ON (("Location"."Item_Status_ID" = "Item_Status"."Item_Status_ID")))
     LEFT JOIN public."Item_Mode" ON (("Location"."Item_Mode_ID" = "Item_Mode"."Item_Mode_ID")))
     LEFT JOIN public."vwTechnisian" ON (("Location"."Technician_ID" = "vwTechnisian"."Worker_ID")))
     LEFT JOIN public."vwAsigner" ON (("Location"."Assigner_ID" = "vwAsigner"."Worker_ID")))
     LEFT JOIN public."Transfer_Status" ON (("Location"."Transfer_Status_ID" = "Transfer_Status"."Transfer_Status_ID")))
     LEFT JOIN public."Item" ON (("Location"."Item_ID" = "Item"."Item_ID")))
     LEFT JOIN public."Model" ON (("Item"."Model_ID" = "Model"."Model_ID")))
     LEFT JOIN public."Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID")))
     LEFT JOIN public."Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID")))
     LEFT JOIN public."Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")))
     LEFT JOIN public."Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwLocation" OWNER TO inventory;

--
-- Name: vwModel; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwModel" AS
 SELECT "Model"."Model_ID",
    "Model"."Model_Name",
    "Model"."Manufacturer_ID",
    "Model"."Power",
    "Model"."Frequency_ID",
    "Model"."Item_Type_ID",
    "Manufacturer"."Manufacturer_Name",
    "Frequency"."Frequency_Name",
    "Item_Type"."Item_Type_Name",
    concat_ws(' - '::text, "Manufacturer"."Manufacturer_Name", "Model"."Model_Name", "Item_Type"."Item_Type_Name") AS "Model_Info"
   FROM (((public."Model"
     LEFT JOIN public."Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID")))
     LEFT JOIN public."Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")))
     LEFT JOIN public."Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")));


ALTER TABLE public."vwModel" OWNER TO inventory;

--
-- Name: vwSite; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwSite" AS
 SELECT "Site"."Site_ID",
    "Site"."Site_Name",
    "Site"."Site_Type_ID",
    "Site"."Region_ID",
    "Site"."Address",
    "Site"."Latitude",
    "Site"."Longitude",
    "Site"."Responsive_Person_ID",
    "Site"."Connection_Type_ID",
    "Site"."Head_Name",
    "Site"."Head_Phone_1",
    "Site"."Head_Phone_2",
    "Site"."Head_Phone_3",
    "Site"."Operator_Name",
    "Site"."Operator_Phone_1",
    "Site"."Operator_Phone_2",
    "Site"."Operator_Phone_3",
    "Site"."Description",
    "Site"."Connected_Comp_Count",
    "Site"."School_Comp_Count",
    "Site_Type"."Site_Type_Name",
    "Region"."Region_Name",
    "Worker"."Worker_Name",
    "Connection_Type"."Connection_Type_Name",
    concat_ws(' - '::text, "Site"."Site_Name", "Site_Type"."Site_Type_Name", "Region"."Region_Name") AS "Site_Info",
    concat_ws(', '::text, "Site"."Head_Name", "Site"."Head_Phone_1", "Site"."Head_Phone_2", "Site"."Head_Phone_3") AS "Head_Info",
    concat_ws(', '::text, "Site"."Operator_Name", "Site"."Operator_Phone_1", "Site"."Operator_Phone_2", "Site"."Operator_Phone_3") AS "Operator_Info",
    "Site"."Creator",
    "Site"."LastModifier"
   FROM ((((public."Site"
     LEFT JOIN public."Site_Type" ON (("Site"."Site_Type_ID" = "Site_Type"."Site_Type_ID")))
     LEFT JOIN public."Region" ON (("Site"."Region_ID" = "Region"."Region_ID")))
     LEFT JOIN public."Worker" ON (("Site"."Responsive_Person_ID" = "Worker"."Worker_ID")))
     LEFT JOIN public."Connection_Type" ON (("Site"."Connection_Type_ID" = "Connection_Type"."Connection_Type_ID")));


ALTER TABLE public."vwSite" OWNER TO inventory;

--
-- Name: vwSpeedy; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwSpeedy" AS
 SELECT "Speedy"."Speedy_ID",
    "Speedy"."Speedy_Name",
    "Speedy"."Measure_ID",
    "Measure"."Measure_Name"
   FROM (public."Speedy"
     LEFT JOIN public."Measure" ON (("Speedy"."Measure_ID" = "Measure"."Measure_ID")));


ALTER TABLE public."vwSpeedy" OWNER TO inventory;

--
-- Name: vwSpeedy_Stock; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwSpeedy_Stock" AS
 SELECT "Speedy_Stock"."Speedy_Stock_ID",
    "Speedy_Stock"."Site_ID",
    "Speedy_Stock"."Speedy_ID",
    "Speedy_Stock"."Count",
    "vwFromSite"."Site_Full_Name",
    "vwSpeedy"."Speedy_Name",
    "vwSpeedy"."Measure_Name"
   FROM ((public."Speedy_Stock"
     LEFT JOIN public."vwFromSite" ON (("Speedy_Stock"."Site_ID" = "vwFromSite"."Site_ID")))
     LEFT JOIN public."vwSpeedy" ON (("Speedy_Stock"."Speedy_ID" = "vwSpeedy"."Speedy_ID")));


ALTER TABLE public."vwSpeedy_Stock" OWNER TO inventory;

--
-- Name: vwSpeedy_Transfer; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwSpeedy_Transfer" AS
 SELECT "Speedy_Transfer"."Speedy_Transfer_ID",
    "Speedy_Transfer"."Speedy_ID",
    "Speedy_Transfer"."Count",
    "Speedy_Transfer"."From_Site_ID",
    "Speedy_Transfer"."To_Site_ID",
    "Speedy_Transfer"."Date",
    "Speedy_Transfer"."Description",
    "vwSpeedy"."Speedy_Name",
    "vwSpeedy"."Measure_Name",
    "vwFromSite"."Site_Full_Name" AS "FromSite_Full_Name",
    "vwToSite"."Site_full_Name" AS "ToSite_Full_Name",
    "Speedy_Transfer"."Technician_ID",
    "Speedy_Transfer"."Assigner_ID",
    "vwAsigner"."Worker_Name" AS "Assigner_Name",
    "vwTechnisian"."Worker_Name" AS "Technician_Name",
    "Speedy_Transfer"."Creator",
    "Speedy_Transfer"."LastModifier"
   FROM (((((public."Speedy_Transfer"
     LEFT JOIN public."vwSpeedy" ON (("Speedy_Transfer"."Speedy_ID" = "vwSpeedy"."Speedy_ID")))
     LEFT JOIN public."vwFromSite" ON (("Speedy_Transfer"."From_Site_ID" = "vwFromSite"."Site_ID")))
     LEFT JOIN public."vwToSite" ON (("Speedy_Transfer"."To_Site_ID" = "vwToSite"."Site_ID")))
     LEFT JOIN public."vwTechnisian" ON (("Speedy_Transfer"."Technician_ID" = "vwTechnisian"."Worker_ID")))
     LEFT JOIN public."vwAsigner" ON (("Speedy_Transfer"."Assigner_ID" = "vwAsigner"."Worker_ID")));


ALTER TABLE public."vwSpeedy_Transfer" OWNER TO inventory;

--
-- Name: vwTransfer; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwTransfer" AS
 SELECT "Location"."Location_ID",
    "Location"."Device_Name",
    "Location"."PhysicalConnected_Item_ID",
    "vwPCItem"."Serial_Number" AS "PC_Serial_Number",
    "vwPCItem"."Model_Name" AS "PC_Model_Name",
    "vwPCItem"."Owner_Name" AS "PC_Owner_Name",
    "vwPCItem"."Item_Info" AS "PC_Item_Info",
    "Location"."From_Site_ID",
    "vwFromSite"."Site_Name" AS "From_Site",
    "vwFromSite"."Region_Name" AS "From_Site_Region",
    "vwFromSite"."Site_Info" AS "From_Site_Info",
    "Location"."To_Site_ID",
    "vwToSite"."Site_Name" AS "To_Site",
    "vwToSite"."Region_Name" AS "To_Site_Region",
    "vwToSite"."Site_Info" AS "To_Site_Info",
    "Location"."Item_Status_ID",
    "Item_Status"."Item_Status_Name",
    "Location"."Start_Date",
    "Location"."End_Date",
    "Location"."Item_IP_Address",
    "Item_Mode"."Item_Mode_Name",
    "Location"."Item_Mode_ID",
    "Location"."Item_SSID",
    "vwTechnisian"."Worker_Name" AS "Technician_Name",
    "Location"."Technician_ID",
    "Location"."Assigner_ID",
    "vwAsigner"."Worker_Name" AS "Assigner_Name",
    "Transfer_Status"."Transfer_Status_Name",
    "Location"."Transfer_Status_ID",
    "Location"."Description",
    "Location"."Item_ID",
    "Item"."Serial_Number" AS "Item_Serial_Number",
    "Item"."Inventory_Number" AS "Item_Inventory_Number",
    "Item"."MAC_Address" AS "Item_MAC_Address",
    "Model"."Model_Name" AS "Item_Model_Name",
    "Owner"."Owner_Name" AS "Item_Owner_Name",
    "Model"."Power" AS "Item_Power",
    "Manufacturer"."Manufacturer_Name" AS "Item_Manufacturer_Name",
    "Item_Type"."Item_Type_Name" AS "Item_Item_Type_Name",
    "Frequency"."Frequency_Name" AS "Item_Frequency_Name"
   FROM ((((((((((((((public."Location"
     LEFT JOIN public."vwPCItem" ON (("Location"."PhysicalConnected_Item_ID" = "vwPCItem"."Item_ID")))
     LEFT JOIN public."vwFromSite" ON (("Location"."From_Site_ID" = "vwFromSite"."Site_ID")))
     LEFT JOIN public."vwToSite" ON (("Location"."To_Site_ID" = "vwToSite"."Site_ID")))
     LEFT JOIN public."Item_Status" ON (("Location"."Item_Status_ID" = "Item_Status"."Item_Status_ID")))
     LEFT JOIN public."Item_Mode" ON (("Location"."Item_Mode_ID" = "Item_Mode"."Item_Mode_ID")))
     LEFT JOIN public."vwTechnisian" ON (("Location"."Technician_ID" = "vwTechnisian"."Worker_ID")))
     LEFT JOIN public."vwAsigner" ON (("Location"."Assigner_ID" = "vwAsigner"."Worker_ID")))
     LEFT JOIN public."Transfer_Status" ON (("Location"."Transfer_Status_ID" = "Transfer_Status"."Transfer_Status_ID")))
     LEFT JOIN public."Item" ON (("Location"."Item_ID" = "Item"."Item_ID")))
     LEFT JOIN public."Model" ON (("Item"."Model_ID" = "Model"."Model_ID")))
     LEFT JOIN public."Owner" ON (("Item"."Owner_ID" = "Owner"."Owner_ID")))
     LEFT JOIN public."Manufacturer" ON (("Model"."Manufacturer_ID" = "Manufacturer"."Manufacturer_ID")))
     LEFT JOIN public."Item_Type" ON (("Model"."Item_Type_ID" = "Item_Type"."Item_Type_ID")))
     LEFT JOIN public."Frequency" ON (("Model"."Frequency_ID" = "Frequency"."Frequency_ID")));


ALTER TABLE public."vwTransfer" OWNER TO inventory;

--
-- Name: vwWorker; Type: VIEW; Schema: public; Owner: inventory
--

CREATE VIEW public."vwWorker" AS
 SELECT "Worker"."Worker_ID",
    "Worker"."Worker_Name",
    "Worker"."Worker_Position_ID",
    "Worker"."Phone_Work",
    "Worker"."Phone_Pers",
    "Worker"."Email_Work",
    "Worker"."Email_Pers",
    "Worker_Position"."Worker_Position_Name",
    "Worker"."Region_ID",
    "Region"."Region_Name"
   FROM ((public."Worker"
     LEFT JOIN public."Worker_Position" ON (("Worker"."Worker_Position_ID" = "Worker_Position"."Worker_Position_ID")))
     LEFT JOIN public."Region" ON (("Worker"."Region_ID" = "Region"."Region_ID")));


ALTER TABLE public."vwWorker" OWNER TO inventory;

--
-- Name: AspNetRoleClaims Id; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetRoleClaims" ALTER COLUMN "Id" SET DEFAULT nextval('public."AspNetRoleClaims_Id_seq"'::regclass);


--
-- Name: AspNetUserClaims Id; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserClaims" ALTER COLUMN "Id" SET DEFAULT nextval('public."AspNetUserClaims_Id_seq"'::regclass);


--
-- Name: Connection_Type Connection_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Connection_Type" ALTER COLUMN "Connection_Type_ID" SET DEFAULT nextval('public."Connection_Type_Connection_Type_ID_seq"'::regclass);


--
-- Name: Frequency Frequency_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Frequency" ALTER COLUMN "Frequency_ID" SET DEFAULT nextval('public."Frequency_Frequency_ID_seq"'::regclass);


--
-- Name: Item Item_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item" ALTER COLUMN "Item_ID" SET DEFAULT nextval('public."Item_Item_ID_seq"'::regclass);


--
-- Name: Item_Mode Item_Mode_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Mode" ALTER COLUMN "Item_Mode_ID" SET DEFAULT nextval('public."Item_Mode_Item_Mode_ID_seq"'::regclass);


--
-- Name: Item_Status Item_Status_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Status" ALTER COLUMN "Item_Status_ID" SET DEFAULT nextval('public."Item_Status_Item_Status_ID_seq"'::regclass);


--
-- Name: Item_Type Item_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Type" ALTER COLUMN "Item_Type_ID" SET DEFAULT nextval('public."Item_Type_Item_Type_ID_seq"'::regclass);


--
-- Name: Location Location_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location" ALTER COLUMN "Location_ID" SET DEFAULT nextval('public."Location_Location_ID_seq"'::regclass);


--
-- Name: Manufacturer Manufacturer_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Manufacturer" ALTER COLUMN "Manufacturer_ID" SET DEFAULT nextval('public."Manufacturer_Manufacturer_ID_seq"'::regclass);


--
-- Name: Measure Measure_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Measure" ALTER COLUMN "Measure_ID" SET DEFAULT nextval('public."Measure_ID"'::regclass);


--
-- Name: Model Model_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model" ALTER COLUMN "Model_ID" SET DEFAULT nextval('public."Model_Model_ID_seq"'::regclass);


--
-- Name: Owner Owner_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Owner" ALTER COLUMN "Owner_ID" SET DEFAULT nextval('public."Owner_Owner_ID_seq"'::regclass);


--
-- Name: Region Region_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Region" ALTER COLUMN "Region_ID" SET DEFAULT nextval('public."Region_Region_ID_seq"'::regclass);


--
-- Name: Site Site_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site" ALTER COLUMN "Site_ID" SET DEFAULT nextval('public."Site_Site_ID_seq"'::regclass);


--
-- Name: Site_Type Site_Type_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site_Type" ALTER COLUMN "Site_Type_ID" SET DEFAULT nextval('public."Site_Type_Site_Type_ID_seq"'::regclass);


--
-- Name: Speedy Speedy_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy" ALTER COLUMN "Speedy_ID" SET DEFAULT nextval('public."Speedy_ID"'::regclass);


--
-- Name: Speedy_Stock Speedy_Stock_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Stock" ALTER COLUMN "Speedy_Stock_ID" SET DEFAULT nextval('public."Speedy_Stock_ID"'::regclass);


--
-- Name: Speedy_Transfer Speedy_Transfer_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer" ALTER COLUMN "Speedy_Transfer_ID" SET DEFAULT nextval('public."Speedy_Transfer_ID"'::regclass);


--
-- Name: Transfer_Status Transfer_Status_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Transfer_Status" ALTER COLUMN "Transfer_Status_ID" SET DEFAULT nextval('public."Transfer_Status_Transfer_Status_ID_seq"'::regclass);


--
-- Name: Worker Worker_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker" ALTER COLUMN "Worker_ID" SET DEFAULT nextval('public."Worker_Worker_ID_seq"'::regclass);


--
-- Name: Worker_Position Worker_Position_ID; Type: DEFAULT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker_Position" ALTER COLUMN "Worker_Position_ID" SET DEFAULT nextval('public."Worker_Position_Worker_Position_ID_seq"'::regclass);


--
-- Data for Name: AspNetRoleClaims; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetRoleClaims" ("Id", "ClaimType", "ClaimValue", "RoleId") FROM stdin;
\.
COPY public."AspNetRoleClaims" ("Id", "ClaimType", "ClaimValue", "RoleId") FROM '$$PATH$$/3320.dat';

--
-- Data for Name: AspNetRoles; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetRoles" ("Id", "ConcurrencyStamp", "Name", "NormalizedName") FROM stdin;
\.
COPY public."AspNetRoles" ("Id", "ConcurrencyStamp", "Name", "NormalizedName") FROM '$$PATH$$/3321.dat';

--
-- Data for Name: AspNetUserClaims; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetUserClaims" ("Id", "ClaimType", "ClaimValue", "UserId") FROM stdin;
\.
COPY public."AspNetUserClaims" ("Id", "ClaimType", "ClaimValue", "UserId") FROM '$$PATH$$/3322.dat';

--
-- Data for Name: AspNetUserLogins; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetUserLogins" ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM stdin;
\.
COPY public."AspNetUserLogins" ("LoginProvider", "ProviderKey", "ProviderDisplayName", "UserId") FROM '$$PATH$$/3323.dat';

--
-- Data for Name: AspNetUserRoles; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetUserRoles" ("UserId", "RoleId") FROM stdin;
\.
COPY public."AspNetUserRoles" ("UserId", "RoleId") FROM '$$PATH$$/3324.dat';

--
-- Data for Name: AspNetUserTokens; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetUserTokens" ("UserId", "LoginProvider", "Name", "Value") FROM stdin;
\.
COPY public."AspNetUserTokens" ("UserId", "LoginProvider", "Name", "Value") FROM '$$PATH$$/3326.dat';

--
-- Data for Name: AspNetUsers; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."AspNetUsers" ("Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName") FROM stdin;
\.
COPY public."AspNetUsers" ("Id", "AccessFailedCount", "ConcurrencyStamp", "Email", "EmailConfirmed", "LockoutEnabled", "LockoutEnd", "NormalizedEmail", "NormalizedUserName", "PasswordHash", "PhoneNumber", "PhoneNumberConfirmed", "SecurityStamp", "TwoFactorEnabled", "UserName") FROM '$$PATH$$/3325.dat';

--
-- Data for Name: Connection_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Connection_Type" ("Connection_Type_ID", "Connection_Type_Name") FROM stdin;
\.
COPY public."Connection_Type" ("Connection_Type_ID", "Connection_Type_Name") FROM '$$PATH$$/3327.dat';

--
-- Data for Name: Frequency; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Frequency" ("Frequency_ID", "Frequency_Name") FROM stdin;
\.
COPY public."Frequency" ("Frequency_ID", "Frequency_Name") FROM '$$PATH$$/3328.dat';

--
-- Data for Name: Item; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Item" ("Item_ID", "Model_ID", "Serial_Number", "Inventory_Number", "Owner_ID", "MAC_Address", "Item_Status_ID", "Creator", "LastModifier") FROM stdin;
\.
COPY public."Item" ("Item_ID", "Model_ID", "Serial_Number", "Inventory_Number", "Owner_ID", "MAC_Address", "Item_Status_ID", "Creator", "LastModifier") FROM '$$PATH$$/3329.dat';

--
-- Data for Name: Item_Mode; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Item_Mode" ("Item_Mode_ID", "Item_Mode_Name") FROM stdin;
\.
COPY public."Item_Mode" ("Item_Mode_ID", "Item_Mode_Name") FROM '$$PATH$$/3330.dat';

--
-- Data for Name: Item_Status; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Item_Status" ("Item_Status_ID", "Item_Status_Name") FROM stdin;
\.
COPY public."Item_Status" ("Item_Status_ID", "Item_Status_Name") FROM '$$PATH$$/3331.dat';

--
-- Data for Name: Item_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Item_Type" ("Item_Type_ID", "Item_Type_Name") FROM stdin;
\.
COPY public."Item_Type" ("Item_Type_ID", "Item_Type_Name") FROM '$$PATH$$/3332.dat';

--
-- Data for Name: Location; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Location" ("Location_ID", "Device_Name", "PhysicalConnected_Item_ID", "From_Site_ID", "To_Site_ID", "Item_Status_ID", "Start_Date", "End_Date", "Item_IP_Address", "Item_Mode_ID", "Item_SSID", "Technician_ID", "Assigner_ID", "Transfer_Status_ID", "Description", "Item_ID", "Creator", "LastModifier") FROM stdin;
\.
COPY public."Location" ("Location_ID", "Device_Name", "PhysicalConnected_Item_ID", "From_Site_ID", "To_Site_ID", "Item_Status_ID", "Start_Date", "End_Date", "Item_IP_Address", "Item_Mode_ID", "Item_SSID", "Technician_ID", "Assigner_ID", "Transfer_Status_ID", "Description", "Item_ID", "Creator", "LastModifier") FROM '$$PATH$$/3333.dat';

--
-- Data for Name: Manufacturer; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Manufacturer" ("Manufacturer_ID", "Manufacturer_Name") FROM stdin;
\.
COPY public."Manufacturer" ("Manufacturer_ID", "Manufacturer_Name") FROM '$$PATH$$/3334.dat';

--
-- Data for Name: Measure; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Measure" ("Measure_ID", "Measure_Name") FROM stdin;
\.
COPY public."Measure" ("Measure_ID", "Measure_Name") FROM '$$PATH$$/3335.dat';

--
-- Data for Name: Model; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Model" ("Model_ID", "Model_Name", "Manufacturer_ID", "Power", "Frequency_ID", "Item_Type_ID") FROM stdin;
\.
COPY public."Model" ("Model_ID", "Model_Name", "Manufacturer_ID", "Power", "Frequency_ID", "Item_Type_ID") FROM '$$PATH$$/3336.dat';

--
-- Data for Name: Owner; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Owner" ("Owner_ID", "Owner_Name") FROM stdin;
\.
COPY public."Owner" ("Owner_ID", "Owner_Name") FROM '$$PATH$$/3337.dat';

--
-- Data for Name: Region; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Region" ("Region_ID", "Region_Name") FROM stdin;
\.
COPY public."Region" ("Region_ID", "Region_Name") FROM '$$PATH$$/3338.dat';

--
-- Data for Name: Site; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Site" ("Site_ID", "Site_Name", "Site_Type_ID", "Region_ID", "Address", "Latitude", "Longitude", "Responsive_Person_ID", "Connection_Type_ID", "Head_Name", "Head_Phone_1", "Head_Phone_2", "Head_Phone_3", "Operator_Name", "Operator_Phone_1", "Operator_Phone_2", "Operator_Phone_3", "Description", "Connected_Comp_Count", "School_Comp_Count", "Creator", "LastModifier") FROM stdin;
\.
COPY public."Site" ("Site_ID", "Site_Name", "Site_Type_ID", "Region_ID", "Address", "Latitude", "Longitude", "Responsive_Person_ID", "Connection_Type_ID", "Head_Name", "Head_Phone_1", "Head_Phone_2", "Head_Phone_3", "Operator_Name", "Operator_Phone_1", "Operator_Phone_2", "Operator_Phone_3", "Description", "Connected_Comp_Count", "School_Comp_Count", "Creator", "LastModifier") FROM '$$PATH$$/3339.dat';

--
-- Data for Name: Site_Type; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Site_Type" ("Site_Type_ID", "Site_Type_Name") FROM stdin;
\.
COPY public."Site_Type" ("Site_Type_ID", "Site_Type_Name") FROM '$$PATH$$/3340.dat';

--
-- Data for Name: Speedy; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Speedy" ("Speedy_ID", "Speedy_Name", "Measure_ID") FROM stdin;
\.
COPY public."Speedy" ("Speedy_ID", "Speedy_Name", "Measure_ID") FROM '$$PATH$$/3341.dat';

--
-- Data for Name: Speedy_Stock; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Speedy_Stock" ("Speedy_Stock_ID", "Site_ID", "Speedy_ID", "Count") FROM stdin;
\.
COPY public."Speedy_Stock" ("Speedy_Stock_ID", "Site_ID", "Speedy_ID", "Count") FROM '$$PATH$$/3342.dat';

--
-- Data for Name: Speedy_Transfer; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Speedy_Transfer" ("Speedy_Transfer_ID", "Speedy_ID", "Count", "From_Site_ID", "To_Site_ID", "Date", "Description", "Technician_ID", "Assigner_ID", "Creator", "LastModifier") FROM stdin;
\.
COPY public."Speedy_Transfer" ("Speedy_Transfer_ID", "Speedy_ID", "Count", "From_Site_ID", "To_Site_ID", "Date", "Description", "Technician_ID", "Assigner_ID", "Creator", "LastModifier") FROM '$$PATH$$/3343.dat';

--
-- Data for Name: Transfer_Status; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Transfer_Status" ("Transfer_Status_ID", "Transfer_Status_Name") FROM stdin;
\.
COPY public."Transfer_Status" ("Transfer_Status_ID", "Transfer_Status_Name") FROM '$$PATH$$/3344.dat';

--
-- Data for Name: Worker; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Worker" ("Worker_ID", "Worker_Name", "Worker_Position_ID", "Phone_Work", "Phone_Pers", "Email_Work", "Email_Pers", "Region_ID") FROM stdin;
\.
COPY public."Worker" ("Worker_ID", "Worker_Name", "Worker_Position_ID", "Phone_Work", "Phone_Pers", "Email_Work", "Email_Pers", "Region_ID") FROM '$$PATH$$/3345.dat';

--
-- Data for Name: Worker_Position; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."Worker_Position" ("Worker_Position_ID", "Worker_Position_Name") FROM stdin;
\.
COPY public."Worker_Position" ("Worker_Position_ID", "Worker_Position_Name") FROM '$$PATH$$/3346.dat';

--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: inventory
--

COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
\.
COPY public."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM '$$PATH$$/3319.dat';

--
-- Name: AspNetRoleClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."AspNetRoleClaims_Id_seq"', 1, false);


--
-- Name: AspNetUserClaims_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."AspNetUserClaims_Id_seq"', 1, false);


--
-- Name: Connection_Type_Connection_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Connection_Type_Connection_Type_ID_seq"', 8, true);


--
-- Name: Frequency_Frequency_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Frequency_Frequency_ID_seq"', 1003, true);


--
-- Name: Item_Item_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Item_Item_ID_seq"', 4137, true);


--
-- Name: Item_Mode_Item_Mode_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Item_Mode_Item_Mode_ID_seq"', 5, true);


--
-- Name: Item_Status_Item_Status_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Item_Status_Item_Status_ID_seq"', 8, true);


--
-- Name: Item_Type_Item_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Item_Type_Item_Type_ID_seq"', 13, true);


--
-- Name: Location_Location_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Location_Location_ID_seq"', 5438, true);


--
-- Name: Manufacturer_Manufacturer_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Manufacturer_Manufacturer_ID_seq"', 50, true);


--
-- Name: Measure_ID; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Measure_ID"', 9, true);


--
-- Name: Model_Model_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Model_Model_ID_seq"', 144, true);


--
-- Name: Owner_Owner_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Owner_Owner_ID_seq"', 10, true);


--
-- Name: Region_Region_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Region_Region_ID_seq"', 14, true);


--
-- Name: Site_Site_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Site_Site_ID_seq"', 1727, true);


--
-- Name: Site_Type_Site_Type_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Site_Type_Site_Type_ID_seq"', 15, true);


--
-- Name: Speedy_ID; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Speedy_ID"', 33, true);


--
-- Name: Speedy_Stock_ID; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Speedy_Stock_ID"', 104, true);


--
-- Name: Speedy_Transfer_ID; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Speedy_Transfer_ID"', 132, true);


--
-- Name: Transfer_Status_Transfer_Status_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Transfer_Status_Transfer_Status_ID_seq"', 7, true);


--
-- Name: Worker_Position_Worker_Position_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Worker_Position_Worker_Position_ID_seq"', 11, true);


--
-- Name: Worker_Worker_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: inventory
--

SELECT pg_catalog.setval('public."Worker_Worker_ID_seq"', 28, true);


--
-- Name: AspNetRoleClaims AspNetRoleClaims_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "AspNetRoleClaims_pkey" PRIMARY KEY ("Id");


--
-- Name: AspNetRoles AspNetRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetRoles"
    ADD CONSTRAINT "AspNetRoles_pkey" PRIMARY KEY ("Id");


--
-- Name: AspNetUserClaims AspNetUserClaims_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "AspNetUserClaims_pkey" PRIMARY KEY ("Id");


--
-- Name: AspNetUserLogins AspNetUserLogins_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "AspNetUserLogins_pkey" PRIMARY KEY ("LoginProvider", "ProviderKey");


--
-- Name: AspNetUserRoles AspNetUserRoles_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "AspNetUserRoles_pkey" PRIMARY KEY ("UserId", "RoleId");


--
-- Name: AspNetUserTokens AspNetUserTokens_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserTokens"
    ADD CONSTRAINT "AspNetUserTokens_pkey" PRIMARY KEY ("UserId", "LoginProvider", "Name");


--
-- Name: AspNetUsers AspNetUsers_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUsers"
    ADD CONSTRAINT "AspNetUsers_pkey" PRIMARY KEY ("Id");


--
-- Name: Connection_Type Connection_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Connection_Type"
    ADD CONSTRAINT "Connection_Type_pkey" PRIMARY KEY ("Connection_Type_ID");


--
-- Name: Frequency Frequency_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Frequency"
    ADD CONSTRAINT "Frequency_pkey" PRIMARY KEY ("Frequency_ID");


--
-- Name: Item_Mode Item_Mode_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Mode"
    ADD CONSTRAINT "Item_Mode_pkey" PRIMARY KEY ("Item_Mode_ID");


--
-- Name: Item_Status Item_Status_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Status"
    ADD CONSTRAINT "Item_Status_pkey" PRIMARY KEY ("Item_Status_ID");


--
-- Name: Item_Type Item_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item_Type"
    ADD CONSTRAINT "Item_Type_pkey" PRIMARY KEY ("Item_Type_ID");


--
-- Name: Item Item_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_pkey" PRIMARY KEY ("Item_ID");


--
-- Name: Location Location_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_pkey" PRIMARY KEY ("Location_ID");


--
-- Name: Manufacturer Manufacturer_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Manufacturer"
    ADD CONSTRAINT "Manufacturer_pkey" PRIMARY KEY ("Manufacturer_ID");


--
-- Name: Measure Measure_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Measure"
    ADD CONSTRAINT "Measure_pkey" PRIMARY KEY ("Measure_ID");


--
-- Name: Model Model_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Model_pkey" PRIMARY KEY ("Model_ID");


--
-- Name: Owner Owner_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Owner"
    ADD CONSTRAINT "Owner_pkey" PRIMARY KEY ("Owner_ID");


--
-- Name: Region Region_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Region"
    ADD CONSTRAINT "Region_pkey" PRIMARY KEY ("Region_ID");


--
-- Name: Site_Type Site_Type_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site_Type"
    ADD CONSTRAINT "Site_Type_pkey" PRIMARY KEY ("Site_Type_ID");


--
-- Name: Site Site_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_pkey" PRIMARY KEY ("Site_ID");


--
-- Name: Speedy_Stock Speedy_Stock_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Stock"
    ADD CONSTRAINT "Speedy_Stock_pkey" PRIMARY KEY ("Speedy_Stock_ID");


--
-- Name: Speedy_Transfer Speedy_Transfer_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_pkey" PRIMARY KEY ("Speedy_Transfer_ID");


--
-- Name: Speedy Speedy_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy"
    ADD CONSTRAINT "Speedy_pkey" PRIMARY KEY ("Speedy_ID");


--
-- Name: Transfer_Status Transfer_Status_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Transfer_Status"
    ADD CONSTRAINT "Transfer_Status_pkey" PRIMARY KEY ("Transfer_Status_ID");


--
-- Name: Worker_Position Worker_Position_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker_Position"
    ADD CONSTRAINT "Worker_Position_pkey" PRIMARY KEY ("Worker_Position_ID");


--
-- Name: Worker Worker_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_pkey" PRIMARY KEY ("Worker_ID");


--
-- Name: __EFMigrationsHistory __EFMigrationsHistory_pkey; Type: CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."__EFMigrationsHistory"
    ADD CONSTRAINT "__EFMigrationsHistory_pkey" PRIMARY KEY ("MigrationId");


--
-- Name: EmailIndex; Type: INDEX; Schema: public; Owner: inventory
--

CREATE INDEX "EmailIndex" ON public."AspNetUsers" USING btree ("NormalizedEmail");


--
-- Name: IX_AspNetRoleClaims_RoleId; Type: INDEX; Schema: public; Owner: inventory
--

CREATE INDEX "IX_AspNetRoleClaims_RoleId" ON public."AspNetRoleClaims" USING btree ("RoleId");


--
-- Name: IX_AspNetUserClaims_UserId; Type: INDEX; Schema: public; Owner: inventory
--

CREATE INDEX "IX_AspNetUserClaims_UserId" ON public."AspNetUserClaims" USING btree ("UserId");


--
-- Name: IX_AspNetUserLogins_UserId; Type: INDEX; Schema: public; Owner: inventory
--

CREATE INDEX "IX_AspNetUserLogins_UserId" ON public."AspNetUserLogins" USING btree ("UserId");


--
-- Name: IX_AspNetUserRoles_RoleId; Type: INDEX; Schema: public; Owner: inventory
--

CREATE INDEX "IX_AspNetUserRoles_RoleId" ON public."AspNetUserRoles" USING btree ("RoleId");


--
-- Name: RoleNameIndex; Type: INDEX; Schema: public; Owner: inventory
--

CREATE UNIQUE INDEX "RoleNameIndex" ON public."AspNetRoles" USING btree ("NormalizedName");


--
-- Name: UserNameIndex; Type: INDEX; Schema: public; Owner: inventory
--

CREATE UNIQUE INDEX "UserNameIndex" ON public."AspNetUsers" USING btree ("NormalizedUserName");


--
-- Name: AspNetRoleClaims AspNetRoleClaims_RoleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "AspNetRoleClaims_RoleId_fkey" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserClaims AspNetUserClaims_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "AspNetUserClaims_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserLogins AspNetUserLogins_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "AspNetUserLogins_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles AspNetUserRoles_RoleId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "AspNetUserRoles_RoleId_fkey" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles AspNetUserRoles_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "AspNetUserRoles_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: Location Assigner_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Assigner_ID" FOREIGN KEY ("Assigner_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Site Connection_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Connection_Type_ID" FOREIGN KEY ("Connection_Type_ID") REFERENCES public."Connection_Type"("Connection_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AspNetRoleClaims FK_AspNetRoleClaims_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetRoleClaims"
    ADD CONSTRAINT "FK_AspNetRoleClaims_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserClaims FK_AspNetUserClaims_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserClaims"
    ADD CONSTRAINT "FK_AspNetUserClaims_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserLogins FK_AspNetUserLogins_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserLogins"
    ADD CONSTRAINT "FK_AspNetUserLogins_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles FK_AspNetUserRoles_AspNetRoles_RoleId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetRoles_RoleId" FOREIGN KEY ("RoleId") REFERENCES public."AspNetRoles"("Id") ON DELETE CASCADE;


--
-- Name: AspNetUserRoles FK_AspNetUserRoles_AspNetUsers_UserId; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."AspNetUserRoles"
    ADD CONSTRAINT "FK_AspNetUserRoles_AspNetUsers_UserId" FOREIGN KEY ("UserId") REFERENCES public."AspNetUsers"("Id") ON DELETE CASCADE;


--
-- Name: Model Frequency_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Frequency_ID" FOREIGN KEY ("Frequency_ID") REFERENCES public."Frequency"("Frequency_ID") MATCH FULL ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location From_Site_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "From_Site_ID" FOREIGN KEY ("From_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Item_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Item_ID" FOREIGN KEY ("Item_ID") REFERENCES public."Item"("Item_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Item Item_Item_Status_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_Item_Status_ID_fkey" FOREIGN KEY ("Item_Status_ID") REFERENCES public."Item_Status"("Item_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Item_Mode_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Item_Mode_ID" FOREIGN KEY ("Item_Mode_ID") REFERENCES public."Item_Mode"("Item_Mode_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Item_Model_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_Model_ID_fkey" FOREIGN KEY ("Model_ID") REFERENCES public."Model"("Model_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Item_Owner_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_Owner_ID_fkey" FOREIGN KEY ("Owner_ID") REFERENCES public."Owner"("Owner_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Item_Status_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Item_Status_ID" FOREIGN KEY ("Item_Status_ID") REFERENCES public."Item_Status"("Item_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Item_Status_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Item_Status_ID" FOREIGN KEY ("Item_Status_ID") REFERENCES public."Item_Status"("Item_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model Item_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Item_Type_ID" FOREIGN KEY ("Item_Type_ID") REFERENCES public."Item_Type"("Item_Type_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_Assigner_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Assigner_ID_fkey" FOREIGN KEY ("Assigner_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_From_Site_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_From_Site_ID_fkey" FOREIGN KEY ("From_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_Item_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Item_ID_fkey" FOREIGN KEY ("Item_ID") REFERENCES public."Item"("Item_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Location Location_Item_Mode_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Item_Mode_ID_fkey" FOREIGN KEY ("Item_Mode_ID") REFERENCES public."Item_Mode"("Item_Mode_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_Item_Status_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Item_Status_ID_fkey" FOREIGN KEY ("Item_Status_ID") REFERENCES public."Item_Status"("Item_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_PhysicalConnected_Item_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_PhysicalConnected_Item_ID_fkey" FOREIGN KEY ("PhysicalConnected_Item_ID") REFERENCES public."Item"("Item_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_Technician_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Technician_ID_fkey" FOREIGN KEY ("Technician_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_To_Site_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_To_Site_ID_fkey" FOREIGN KEY ("To_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Location_Transfer_Status_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Location_Transfer_Status_ID_fkey" FOREIGN KEY ("Transfer_Status_ID") REFERENCES public."Transfer_Status"("Transfer_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model Manufacturer_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Manufacturer_ID" FOREIGN KEY ("Manufacturer_ID") REFERENCES public."Manufacturer"("Manufacturer_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model Model_Frequency_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Model_Frequency_ID_fkey" FOREIGN KEY ("Frequency_ID") REFERENCES public."Frequency"("Frequency_ID") MATCH FULL ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Model_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Model_ID" FOREIGN KEY ("Model_ID") REFERENCES public."Model"("Model_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model Model_Item_Type_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Model_Item_Type_ID_fkey" FOREIGN KEY ("Item_Type_ID") REFERENCES public."Item_Type"("Item_Type_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Model Model_Manufacturer_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Model"
    ADD CONSTRAINT "Model_Manufacturer_ID_fkey" FOREIGN KEY ("Manufacturer_ID") REFERENCES public."Manufacturer"("Manufacturer_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Item Owner_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Item"
    ADD CONSTRAINT "Owner_ID" FOREIGN KEY ("Owner_ID") REFERENCES public."Owner"("Owner_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location PhysicalConnected_Item_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "PhysicalConnected_Item_ID" FOREIGN KEY ("PhysicalConnected_Item_ID") REFERENCES public."Item"("Item_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Site Region_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Region_ID" FOREIGN KEY ("Region_ID") REFERENCES public."Region"("Region_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Responsive_Person_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Responsive_Person_ID" FOREIGN KEY ("Responsive_Person_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Site_Connection_Type_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_Connection_Type_ID_fkey" FOREIGN KEY ("Connection_Type_ID") REFERENCES public."Connection_Type"("Connection_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Site_Region_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_Region_ID_fkey" FOREIGN KEY ("Region_ID") REFERENCES public."Region"("Region_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Site_Responsive_Person_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_Responsive_Person_ID_fkey" FOREIGN KEY ("Responsive_Person_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Site_Site_Type_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_Site_Type_ID_fkey" FOREIGN KEY ("Site_Type_ID") REFERENCES public."Site_Type"("Site_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Site Site_Type_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Site"
    ADD CONSTRAINT "Site_Type_ID" FOREIGN KEY ("Site_Type_ID") REFERENCES public."Site_Type"("Site_Type_ID") ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Speedy Speedy_Measure_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy"
    ADD CONSTRAINT "Speedy_Measure_ID_fkey" FOREIGN KEY ("Measure_ID") REFERENCES public."Measure"("Measure_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Stock Speedy_Stock_Site_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Stock"
    ADD CONSTRAINT "Speedy_Stock_Site_ID_fkey" FOREIGN KEY ("Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Stock Speedy_Stock_Speedy_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Stock"
    ADD CONSTRAINT "Speedy_Stock_Speedy_ID_fkey" FOREIGN KEY ("Speedy_ID") REFERENCES public."Speedy"("Speedy_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Transfer Speedy_Transfer_Assigner_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_Assigner_ID_fkey" FOREIGN KEY ("Assigner_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Transfer Speedy_Transfer_From_Site_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_From_Site_ID_fkey" FOREIGN KEY ("From_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Transfer Speedy_Transfer_Speedy_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_Speedy_ID_fkey" FOREIGN KEY ("Speedy_ID") REFERENCES public."Speedy"("Speedy_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Transfer Speedy_Transfer_Technician_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_Technician_ID_fkey" FOREIGN KEY ("Technician_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Speedy_Transfer Speedy_Transfer_To_Site_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Speedy_Transfer"
    ADD CONSTRAINT "Speedy_Transfer_To_Site_ID_fkey" FOREIGN KEY ("To_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Technician_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Technician_ID" FOREIGN KEY ("Technician_ID") REFERENCES public."Worker"("Worker_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location To_Site_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "To_Site_ID" FOREIGN KEY ("To_Site_ID") REFERENCES public."Site"("Site_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Location Transfer_Status_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Location"
    ADD CONSTRAINT "Transfer_Status_ID" FOREIGN KEY ("Transfer_Status_ID") REFERENCES public."Transfer_Status"("Transfer_Status_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Worker Worker_Position_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_Position_ID" FOREIGN KEY ("Worker_Position_ID") REFERENCES public."Worker_Position"("Worker_Position_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Worker Worker_Region_ID; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_Region_ID" FOREIGN KEY ("Region_ID") REFERENCES public."Region"("Region_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Worker Worker_Region_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_Region_ID_fkey" FOREIGN KEY ("Region_ID") REFERENCES public."Region"("Region_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: Worker Worker_Worker_Position_ID_fkey; Type: FK CONSTRAINT; Schema: public; Owner: inventory
--

ALTER TABLE ONLY public."Worker"
    ADD CONSTRAINT "Worker_Worker_Position_ID_fkey" FOREIGN KEY ("Worker_Position_ID") REFERENCES public."Worker_Position"("Worker_Position_ID") ON UPDATE CASCADE ON DELETE SET NULL;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

